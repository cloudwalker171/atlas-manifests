<?php
/**
 * Plugin Name: TNC A.T.L.A.S. Snapshot Bridge
 * Description: Repoints the PWA snapshot `atlas` block to the LIVE atlas-metrics.json feed (fixes the "ATLAS tab reads 0" bug) and attaches the throughput.json "Throughput & Ceiling" block. Hooks the documented tnc_pwa_snapshot filter. Fail-soft, cached.
 * Version: 1.0.0
 * Author: ATLAS deploy
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

if ( ! function_exists( 'tnc_atlas_bridge_fetch' ) ) {
	function tnc_atlas_bridge_fetch() {
		$cache = get_transient( 'tnc_atlas_metrics_cache' );
		if ( is_array( $cache ) ) { return $cache; }
		$url = apply_filters( 'tnc_atlas_metrics_url', 'https://raw.githubusercontent.com/cloudwalker171/atlas-manifests/main/status/hetzner/atlas-metrics.json' );
		$resp = wp_remote_get( $url, array( 'timeout' => 6, 'headers' => array( 'Cache-Control' => 'no-cache' ) ) );
		if ( is_wp_error( $resp ) || 200 !== (int) wp_remote_retrieve_response_code( $resp ) ) { return null; }
		$doc = json_decode( wp_remote_retrieve_body( $resp ), true );
		if ( ! is_array( $doc ) ) { return null; }
		$m = ( isset( $doc['metrics'] ) && is_array( $doc['metrics'] ) ) ? $doc['metrics'] : $doc;
		set_transient( 'tnc_atlas_metrics_cache', $m, 30 );
		return $m;
	}
}

if ( ! function_exists( 'tnc_atlas_throughput_fetch' ) ) {
	function tnc_atlas_throughput_fetch() {
		$cache = get_transient( 'tnc_atlas_throughput_cache' );
		if ( is_array( $cache ) ) { return $cache; }
		$url = apply_filters( 'tnc_atlas_throughput_url', 'https://raw.githubusercontent.com/cloudwalker171/atlas-manifests/main/status/hetzner/throughput.json' );
		$resp = wp_remote_get( $url, array( 'timeout' => 6, 'headers' => array( 'Cache-Control' => 'no-cache' ) ) );
		if ( is_wp_error( $resp ) || 200 !== (int) wp_remote_retrieve_response_code( $resp ) ) { return null; }
		$doc = json_decode( wp_remote_retrieve_body( $resp ), true );
		if ( ! is_array( $doc ) ) { return null; }
		set_transient( 'tnc_atlas_throughput_cache', $doc, 20 );
		return $doc;
	}
}

add_filter( 'tnc_pwa_snapshot', function ( $d ) {
	$m = tnc_atlas_bridge_fetch();
	if ( is_array( $m ) ) {
		$business_total = (int) ( isset( $m['business_total'] ) ? $m['business_total'] : 0 );
		$enr = ( isset( $m['enrichment'] ) && is_array( $m['enrichment'] ) ) ? $m['enrichment'] : array();
		$q   = ( isset( $m['queue'] ) && is_array( $m['queue'] ) ) ? $m['queue'] : array();
		$enriched_done = (int) ( isset( $enr['done'] ) ? $enr['done'] : ( isset( $q['done'] ) ? $q['done'] : 0 ) );
		$verified_pct  = (float) ( isset( $enr['progress_pct'] ) ? $enr['progress_pct'] : 0 );
		$intake_pm     = (float) ( isset( $m['intake_per_min'] ) ? $m['intake_per_min'] : 0 );
		if ( ! isset( $d['atlas'] ) || ! is_array( $d['atlas'] ) ) { $d['atlas'] = array(); }
		$d['atlas'] = array_merge( $d['atlas'], array(
			'records_total'     => $business_total,
			'processed_today'   => $enriched_done,
			'daily_goal'        => 1000000,
			'imports_today'     => (int) round( $intake_pm * 1440 ),
			'enriched_today'    => $enriched_done,
			'ai_enriched_today' => (int) ( isset( $d['atlas']['ai_enriched_today'] ) ? $d['atlas']['ai_enriched_today'] : 0 ),
			'verified_pct'      => (int) round( $verified_pct ),
			'fleet_workers'     => (int) ( isset( $d['atlas']['fleet_workers'] ) ? $d['atlas']['fleet_workers'] : 0 ),
			'fleet_workers_max' => (int) ( isset( $d['atlas']['fleet_workers_max'] ) ? $d['atlas']['fleet_workers_max'] : 0 ),
			'_source'           => 'atlas-metrics.json (live)',
		) );
	}
	$t = tnc_atlas_throughput_fetch();
	if ( is_array( $t ) ) { $d['throughput'] = $t; }
	return $d;
}, 20 );
