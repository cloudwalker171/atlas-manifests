<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<?php
/**
 * Lead Engine — Settings.
 * Read side is LIVE: sender identities, ISP throttles and module flags are read
 * from the running platform classes at render (with safe fallbacks). The Save
 * action posts to the existing tuanichat/v1 /admin/settings endpoint.
 */
$throttles = array(
	'gmail.com' => 60, 'outlook.com' => 30, 'yahoo.com' => 40, 'default' => 80,
);
if ( class_exists( 'TNC_Mail_Streams' ) && method_exists( 'TNC_Mail_Streams', 'isp_throttles' ) ) {
	$throttles = TNC_Mail_Streams::isp_throttles();
}
$identities = array();
if ( class_exists( 'TNC_Mail_Streams' ) && method_exists( 'TNC_Mail_Streams', 'status' ) ) {
	$identities = TNC_Mail_Streams::status();
}
$settings = array();
if ( class_exists( 'TNC_Settings' ) && method_exists( 'TNC_Settings', 'all' ) ) {
	$settings = (array) TNC_Settings::all();
}
$g = function ( $k, $d ) use ( $settings ) { return isset( $settings[ $k ] ) ? $settings[ $k ] : $d; };
?>
<div class="v3-section-head v3-boot">
	<div>
		<h1 class="v3-section-title">Lead Engine — Settings</h1>
		<p class="v3-section-desc">Outreach pacing, sender streams and engine modules. Status reads live from the platform; changes save to <code>/admin/settings</code>.</p>
	</div>
	<div class="v3-section-actions">
		<button class="v3-btn v3-btn--accent v3-acc-plasma" id="jv3-save">Save changes</button>
	</div>
</div>

<div class="v3-grid">

	<!-- LIVE STATUS TILES ------------------------------------------------- -->
	<div class="v3-tile v3-acc-plasma v3-lift v3-sheen v3-boot v3-pulse-target v3-span-3">
		<div class="v3-between"><span class="v3-t-label">Sender Streams</span><span class="v3-prov is-live">Live</span></div>
		<div class="v3-tile-row"><span class="v3-t-stat"><?php echo (int) count( $identities ); ?></span></div>
		<span class="v3-t-micro v3-muted">configured identities</span>
	</div>
	<div class="v3-tile v3-acc-arc v3-lift v3-sheen v3-boot v3-pulse-target v3-span-3">
		<div class="v3-between"><span class="v3-t-label">Suppressed</span><span class="v3-prov is-live">Live</span></div>
		<div class="v3-tile-row"><span class="v3-t-stat" data-v3-bind="inbox.suppressed" data-v3-kind="num" data-v3-fmt="comma">—</span></div>
		<span class="v3-t-micro v3-muted">on suppression list</span>
	</div>
	<div class="v3-tile v3-acc-flare v3-lift v3-sheen v3-boot v3-pulse-target v3-span-3">
		<div class="v3-between"><span class="v3-t-label">Paused Senders</span><span class="v3-prov is-live">Live</span></div>
		<div class="v3-tile-row"><span class="v3-t-stat" data-v3-bind="inbox.paused" data-v3-kind="num" data-v3-fmt="comma">—</span></div>
		<span class="v3-t-micro v3-muted">temporarily held</span>
	</div>
	<div class="v3-tile v3-acc-reactor v3-lift v3-sheen v3-boot v3-pulse-target v3-span-3">
		<div class="v3-between"><span class="v3-t-label">Inbox · Classified</span><span class="v3-prov is-live">Live</span></div>
		<div class="v3-tile-row"><span class="v3-t-stat" data-v3-bind="inbox.total" data-v3-kind="num" data-v3-fmt="comma">—</span></div>
		<span class="v3-t-micro v3-muted">messages triaged</span>
	</div>

	<!-- OUTREACH PACING --------------------------------------------------- -->
	<section class="v3-panel v3-acc-plasma v3-boot v3-span-6">
		<div class="v3-panel-head"><span class="v3-t-title">Outreach Pacing</span><span class="v3-prov is-est">Config · /admin/settings</span></div>

		<div class="v3-setrow">
			<div><h4>Daily send target</h4><p>Total messages the engine paces toward across all streams.</p></div>
			<div class="v3-setctl"><input class="v3-field" type="number" id="set-daily_target" value="<?php echo esc_attr( $g( 'daily_target', 500 ) ); ?>"><span class="v3-unit">/ day</span></div>
		</div>
		<div class="v3-setrow">
			<div><h4>Intake rate cap</h4><p>Max new prospects pulled into the enrichment queue per hour.</p></div>
			<div class="v3-setctl"><input class="v3-field" type="number" id="set-intake_cap" value="<?php echo esc_attr( $g( 'intake_cap', 1200 ) ); ?>"><span class="v3-unit">/ hr</span></div>
		</div>
		<div class="v3-setrow">
			<div><h4>Quiet hours</h4><p>Suspend outbound sends during these local hours.</p></div>
			<div class="v3-setctl">
				<input class="v3-field" type="number" min="0" max="23" id="set-quiet_from" value="<?php echo esc_attr( $g( 'quiet_from', 21 ) ); ?>" style="min-width:60px">
				<span class="v3-unit">to</span>
				<input class="v3-field" type="number" min="0" max="23" id="set-quiet_to" value="<?php echo esc_attr( $g( 'quiet_to', 7 ) ); ?>" style="min-width:60px">
			</div>
		</div>
		<div class="v3-setrow">
			<div><h4>Council AI annotation</h4><p>Let the local council model annotate decisions. Deterministic fallback always remains the source of truth.</p></div>
			<div class="v3-setctl"><button class="v3-pill v3-acc-plasma" role="switch" id="set-council" aria-pressed="<?php echo $g( 'council', 1 ) ? 'true' : 'false'; ?>"></button></div>
		</div>
	</section>

	<!-- ISP THROTTLES (live read) ---------------------------------------- -->
	<section class="v3-panel v3-acc-arc v3-boot v3-span-6">
		<div class="v3-panel-head"><span class="v3-t-title">ISP Throttles</span><span class="v3-prov is-live">Live read</span></div>
		<p class="v3-t-micro v3-muted" style="margin-top:-4px">Per-recipient-domain send ceilings (messages/hour). Loaded from the running mail-streams config.</p>
		<div class="v3-mt4">
		<?php foreach ( $throttles as $domain => $rate ) : ?>
			<div class="v3-setrow">
				<div><h4 style="font-family:var(--v3-font-data);font-weight:600"><?php echo esc_html( $domain ); ?></h4></div>
				<div class="v3-setctl"><input class="v3-field" type="number" data-isp="<?php echo esc_attr( $domain ); ?>" value="<?php echo esc_attr( (int) $rate ); ?>"><span class="v3-unit">/ hr</span></div>
			</div>
		<?php endforeach; ?>
		</div>
	</section>

	<!-- SENDER STREAMS (live) -------------------------------------------- -->
	<section class="v3-panel v3-acc-ion v3-boot v3-span-7">
		<div class="v3-panel-head"><span class="v3-t-title">Sender Streams</span><span class="v3-prov is-live">Live</span></div>
		<?php if ( empty( $identities ) ) : ?>
			<p class="v3-t-body v3-muted">No sender identities configured yet. Add one in the platform mail settings; it appears here with live send counts.</p>
		<?php else : foreach ( $identities as $idn ) :
			$cap  = max( 1, (int) ( isset( $idn['daily_cap'] ) ? $idn['daily_cap'] : 1 ) );
			$sent = (int) ( isset( $idn['sent_today'] ) ? $idn['sent_today'] : 0 );
			$pctv = min( 100, round( 100 * $sent / $cap ) );
			?>
			<div class="v3-worker v3-acc-ion <?php echo ! empty( $idn['active'] ) ? 'is-online' : ''; ?>" style="grid-template-columns:16px 1.6fr 96px 1fr 96px">
				<span class="v3-lamp <?php echo ! empty( $idn['active'] ) ? 'v3-acc-reactor' : ( ! empty( $idn['warmup'] ) ? 'v3-acc-flare' : 'v3-acc-off' ); ?>"></span>
				<div class="v3-worker-name"><b><?php echo esc_html( isset( $idn['from'] ) ? $idn['from'] : $idn['id'] ); ?></b><span><?php echo esc_html( isset( $idn['streams'] ) ? implode( ' · ', (array) $idn['streams'] ) : '' ); ?></span></div>
				<div class="v3-worker-metric"><b><?php echo esc_html( number_format( $sent ) ); ?></b><span>Sent</span></div>
				<div class="v3-qbar"><i class="q-running" style="width:<?php echo (int) $pctv; ?>%"></i><i class="q-queued" style="width:<?php echo (int) ( 100 - $pctv ); ?>%;background:var(--v3-depth)"></i></div>
				<div class="v3-worker-metric"><b><?php echo esc_html( number_format( $cap ) ); ?></b><span>Cap</span></div>
			</div>
		<?php endforeach; endif; ?>
	</section>

	<!-- ENGINE MODULES --------------------------------------------------- -->
	<section class="v3-panel v3-acc-reactor v3-boot v3-span-5">
		<div class="v3-panel-head"><span class="v3-t-title">Engine Modules</span><span class="v3-prov is-est">Config</span></div>
		<?php
		$modules = array(
			array( 'ev_ranking', 'EV-ranked queue', 'Rank enrichment by expected value, not arrival order.', 1 ),
			array( 'waterfall', 'Cost-aware waterfall', 'Run cheapest checks first; stop when confident.', 1 ),
			array( 'corroboration', 'Cross-source corroboration', 'Score agreement across independent sources.', 1 ),
			array( 'self_tuning_er', 'Self-tuning entity resolution', 'Learn match threshold from corrections.', 1 ),
			array( 'predictive', 'Predictive breach forecasting', 'Throttle before the ops ceiling, not after.', 0 ),
		);
		foreach ( $modules as $m ) : ?>
			<div class="v3-setrow">
				<div><h4><?php echo esc_html( $m[1] ); ?></h4><p><?php echo esc_html( $m[2] ); ?></p></div>
				<div class="v3-setctl"><button class="v3-pill v3-acc-reactor" role="switch" data-mod="<?php echo esc_attr( $m[0] ); ?>" aria-pressed="<?php echo $g( 'mod_' . $m[0], $m[3] ) ? 'true' : 'false'; ?>"></button></div>
			</div>
		<?php endforeach; ?>
		<p class="v3-t-micro v3-muted v3-mt3">V2 intelligence layer is staged on the enrichment node but cutover is a deliberate, separate step (MIGRATION_CUTOVER_PLAN). These switches persist intent to <code>/admin/settings</code>.</p>
	</section>

</div>

<script>
/* Lead Engine — pill toggles + Save to /admin/settings (existing endpoint). */
(function () {
	document.querySelectorAll('.tc-v3 .v3-pill[role="switch"]').forEach(function (p) {
		p.addEventListener('click', function () {
			var on = p.getAttribute('aria-pressed') === 'true';
			p.setAttribute('aria-pressed', on ? 'false' : 'true');
		});
	});
	var save = document.getElementById('jv3-save');
	if (!save) return;
	save.addEventListener('click', function () {
		var cfg = window.TNC_JARVIS_V3 || {};
		var payload = {
			daily_target: +val('set-daily_target'),
			intake_cap:   +val('set-intake_cap'),
			quiet_from:   +val('set-quiet_from'),
			quiet_to:     +val('set-quiet_to'),
			council:      pressed('set-council') ? 1 : 0,
			isp_throttles: {},
			modules: {}
		};
		document.querySelectorAll('[data-isp]').forEach(function (i) { payload.isp_throttles[i.getAttribute('data-isp')] = +i.value; });
		document.querySelectorAll('[data-mod]').forEach(function (b) { payload.modules[b.getAttribute('data-mod')] = b.getAttribute('aria-pressed') === 'true' ? 1 : 0; });
		if (!cfg.rest) { flash('Preview mode — not saved'); return; }
		save.disabled = true; save.textContent = 'Saving…';
		fetch(cfg.rest.replace(/\/$/, '') + '/admin/settings', {
			method: 'POST',
			headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': cfg.nonce || '' },
			credentials: 'same-origin', body: JSON.stringify(payload)
		}).then(function (r) { flash(r.ok ? 'Saved' : 'Save failed (' + r.status + ')'); })
		  .catch(function () { flash('Save failed'); })
		  .finally(function () { save.disabled = false; save.textContent = 'Save changes'; });
	});
	function val(id) { var e = document.getElementById(id); return e ? e.value : 0; }
	function pressed(id) { var e = document.getElementById(id); return e && e.getAttribute('aria-pressed') === 'true'; }
	function flash(t) { save.textContent = t; setTimeout(function () { save.textContent = 'Save changes'; }, 1800); }
})();
</script>
