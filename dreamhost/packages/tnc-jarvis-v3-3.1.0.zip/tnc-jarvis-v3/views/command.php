<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<?php
/**
 * J.A.R.V.I.S. Command Center.
 * Every tile declares its provenance. LIVE tiles bind to real cockpit fields;
 * PENDING tiles (A.T.L.A.S. index, LinkedIn / SMS engines) stay un-fed.
 */
?>
<div class="v3-section-head v3-boot">
	<div>
		<h1 class="v3-section-title">Command Center</h1>
		<p class="v3-section-desc">Real-time operations across intake, enrichment and outreach. Numbers update every 5&nbsp;seconds from the live REST cockpit. Amber <span class="v3-prov is-pending">PENDING</span> tiles are wired but await a data source going live.</p>
	</div>
</div>

<div class="v3-grid">

	<!-- KPI TILES ---------------------------------------------------------- -->
	<div class="v3-tile v3-acc-arc v3-lift v3-sheen v3-boot v3-pulse-target v3-span-3">
		<div class="v3-between"><span class="v3-t-label">Prospects · Active</span><span class="v3-prov is-live">Live</span></div>
		<div class="v3-tile-row"><span class="v3-t-stat" data-v3-bind="counts.prospects" data-v3-kind="num" data-v3-fmt="comma" data-v3-good="up">—</span></div>
		<canvas data-v3-spark="counts.prospects"></canvas>
	</div>

	<div class="v3-tile v3-acc-plasma v3-lift v3-sheen v3-boot v3-pulse-target v3-span-3">
		<div class="v3-between"><span class="v3-t-label">Demos Created</span><span class="v3-prov is-live">Live</span></div>
		<div class="v3-tile-row"><span class="v3-t-stat" data-v3-bind="counts.demos" data-v3-kind="num" data-v3-fmt="comma" data-v3-good="up">—</span></div>
		<canvas data-v3-spark="counts.demos"></canvas>
	</div>

	<div class="v3-tile v3-acc-arc v3-lift v3-sheen v3-boot v3-pulse-target v3-span-3">
		<div class="v3-between"><span class="v3-t-label">Crawl · Pages / min</span><span class="v3-prov is-live">Live</span></div>
		<div class="v3-tile-row"><span class="v3-t-stat" data-v3-bind="workers.pages_per_min" data-v3-kind="num" data-v3-fmt="int" data-v3-good="up">—</span></div>
		<canvas data-v3-spark="workers.pages_per_min"></canvas>
	</div>

	<div class="v3-tile v3-acc-reactor v3-lift v3-sheen v3-boot v3-pulse-target v3-span-3">
		<div class="v3-between"><span class="v3-t-label">Heartbeat</span><span class="v3-prov is-live">Live</span></div>
		<div class="v3-tile-row">
			<span class="v3-lamp" data-v3-bind="workers.heartbeat_age" data-v3-kind="lamp"></span>
			<span class="v3-t-stat" data-v3-bind="workers.heartbeat_age" data-v3-kind="num" data-v3-fmt="ago">—</span>
			<span class="v3-t-micro v3-muted">since last tick</span>
		</div>
		<canvas data-v3-spark="workers.queued"></canvas>
	</div>

	<!-- A.T.L.A.S. TICKER — PENDING (sink empty; needs ATLAS→WP bridge) ---- -->
	<section class="v3-panel v3-hud v3-acc-ion v3-boot v3-span-8">
		<div class="v3-panel-head">
			<div class="v3-panel-title-wrap"><span class="v3-panel-icon"></span><span class="v3-t-title">A.T.L.A.S. · Records Indexed</span></div>
			<span class="v3-prov is-pending">Pending · source not live</span>
		</div>
		<div class="v3-ticker is-pending">
			<div class="v3-ticker-digits" data-v3-bind="atlas.records_indexed" data-v3-kind="ticker" data-v3-prov="pending">0</div>
			<canvas></canvas>
			<p class="v3-t-micro v3-muted">A.T.L.A.S. sink currently empty (verified). This odometer activates the moment the enrichment node begins writing rows and the stats bridge is installed — see DEPLOY_JARVIS_V3.md.</p>
		</div>
	</section>

	<!-- SYSTEM HEALTH RINGS ---------------------------------------------- -->
	<section class="v3-panel v3-boot v3-span-4">
		<div class="v3-panel-head"><span class="v3-t-title">System Health</span></div>
		<div class="v3-gauges">
			<div class="v3-gauge-wrap v3-acc-arc">
				<div class="v3-ring" data-v3-bind="workers.pages_per_min" data-v3-kind="ring" data-v3-max="240" data-v3-size="104" data-v3-prov="est"></div>
				<div style="text-align:center"><div class="v3-t-label">Crawl Load</div><span class="v3-prov is-est">Est · vs 240 ceiling</span></div>
			</div>
			<div class="v3-gauge-wrap v3-acc-reactor">
				<div class="v3-ring" data-v3-kind="ring" data-v3-max="100" data-v3-size="104" data-v3-prov="pending"></div>
				<div style="text-align:center"><div class="v3-t-label">Deliverability</div><span class="v3-prov is-pending">Pending · bounce feed</span></div>
			</div>
		</div>
	</section>

	<!-- ENGINE CARDS ----------------------------------------------------- -->
	<section class="v3-panel v3-engine v3-acc-plasma v3-lift v3-sheen v3-boot v3-span-4">
		<div class="v3-panel-head">
			<div class="v3-row"><span class="v3-lamp" data-v3-bind="identities.0.active" data-v3-kind="lamp"></span><span class="v3-t-title">Email Engine</span></div>
			<span class="v3-prov is-live">Live</span>
		</div>
		<div class="v3-engine-meta">
			<div><span class="v3-t-label">Sent · Today</span><span class="v3-big" data-v3-bind="identities.0.sent_today" data-v3-kind="num" data-v3-fmt="comma">—</span></div>
			<div><span class="v3-t-label">Daily Cap</span><span class="v3-big" data-v3-bind="identities.0.daily_cap" data-v3-kind="num" data-v3-fmt="comma">—</span></div>
		</div>
		<canvas data-v3-spark="identities.0.sent_today"></canvas>
	</section>

	<section class="v3-panel v3-engine v3-acc-arc v3-boot v3-span-4">
		<div class="v3-panel-head">
			<div class="v3-row"><span class="v3-lamp v3-acc-off"></span><span class="v3-t-title">LinkedIn Engine</span></div>
			<span class="v3-prov is-pending">Pending</span>
		</div>
		<div class="v3-engine-meta">
			<div><span class="v3-t-label">Touches</span><span class="v3-big v3-muted">—</span></div>
			<div><span class="v3-t-label">Accepts</span><span class="v3-big v3-muted">—</span></div>
		</div>
		<p class="v3-t-micro v3-muted">No connector wired in tuanichat-platform yet. Card lights up when a LinkedIn outreach source posts to the cockpit.</p>
	</section>

	<section class="v3-panel v3-engine v3-acc-flare v3-boot v3-span-4">
		<div class="v3-panel-head">
			<div class="v3-row"><span class="v3-lamp v3-acc-off"></span><span class="v3-t-title">SMS Engine</span></div>
			<span class="v3-prov is-pending">Pending</span>
		</div>
		<div class="v3-engine-meta">
			<div><span class="v3-t-label">Sent</span><span class="v3-big v3-muted">—</span></div>
			<div><span class="v3-t-label">Carrier OK</span><span class="v3-big v3-muted">—</span></div>
		</div>
		<p class="v3-t-micro v3-muted">No SMS provider connected. Reserved surface; wired on first carrier integration.</p>
	</section>

	<!-- AI / OUTREACH DECISION FEED — LIVE (real mail_log) ---------------- -->
	<section class="v3-panel v3-acc-ion v3-boot v3-span-8">
		<div class="v3-panel-head">
			<div class="v3-panel-title-wrap"><span class="v3-panel-icon"></span><span class="v3-t-title">Outreach Decision Feed</span></div>
			<span class="v3-prov is-live">Live · mail log</span>
		</div>
		<div class="v3-feed" data-v3-feed>
			<!-- rows slot in from the real mail_log via TCV3.feed -->
		</div>
	</section>

	<!-- SPEND ------------------------------------------------------------- -->
	<section class="v3-panel v3-acc-reactor v3-boot v3-span-4">
		<div class="v3-panel-head"><span class="v3-t-title">AI Spend</span><span class="v3-prov is-live">Live</span></div>
		<div class="v3-stack">
			<div class="v3-between"><span class="v3-t-label">Today</span><span class="v3-big" data-v3-bind="spend.today_usd" data-v3-kind="num" data-v3-fmt="usd">—</span></div>
			<div class="v3-between"><span class="v3-t-label">Calls Today</span><span class="v3-big" data-v3-bind="spend.today_calls" data-v3-kind="num" data-v3-fmt="comma">—</span></div>
			<div class="v3-between"><span class="v3-t-label">Total</span><span class="v3-big v3-muted" data-v3-bind="spend.total_usd" data-v3-kind="num" data-v3-fmt="usd">—</span></div>
		</div>
	</section>

</div>
