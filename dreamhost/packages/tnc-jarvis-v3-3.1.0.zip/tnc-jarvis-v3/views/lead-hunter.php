<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<?php
/**
 * Lead Hunter — Workers.
 * Fleet node liveness, throughput and queue depth. Aggregate scalars bind live
 * to fleet.* / workers.*; the node roster and queue bar are hydrated each tick
 * by a small inline enhancer reading TNCJarvisLive.state(). Honest empty-state
 * when no node has checked in.
 */
$max_rows = 6;
?>
<div class="v3-section-head v3-boot">
	<div>
		<h1 class="v3-section-title">Lead Hunter — Workers</h1>
		<p class="v3-section-desc">Distributed enrichment + crawl fleet. Worker liveness, throughput and queue depth, refreshed every 5&nbsp;seconds from <code>/admin/fleet</code> and <code>/admin/cockpit</code>.</p>
	</div>
	<div class="v3-section-actions">
		<button class="v3-btn" id="jv3-refresh">Refresh now</button>
	</div>
</div>

<div class="v3-grid">

	<!-- AGGREGATE KPIs (live) -------------------------------------------- -->
	<div class="v3-tile v3-acc-ion v3-lift v3-sheen v3-boot v3-pulse-target v3-span-3">
		<div class="v3-between"><span class="v3-t-label">Active Workers</span><span class="v3-prov is-live">Live</span></div>
		<div class="v3-tile-row"><span class="v3-t-stat" data-v3-bind="fleet.workers_total" data-v3-kind="num" data-v3-fmt="int" data-v3-good="up">—</span></div>
		<canvas data-v3-spark="fleet.workers_total"></canvas>
	</div>
	<div class="v3-tile v3-acc-plasma v3-lift v3-sheen v3-boot v3-pulse-target v3-span-3">
		<div class="v3-between"><span class="v3-t-label">Fleet Throughput · ppm</span><span class="v3-prov is-live">Live</span></div>
		<div class="v3-tile-row"><span class="v3-t-stat" data-v3-bind="fleet.ppm_total" data-v3-kind="num" data-v3-fmt="int" data-v3-good="up">—</span></div>
		<canvas data-v3-spark="fleet.ppm_total"></canvas>
	</div>
	<div class="v3-tile v3-acc-arc v3-lift v3-sheen v3-boot v3-pulse-target v3-span-3">
		<div class="v3-between"><span class="v3-t-label">Crawl Queue</span><span class="v3-prov is-live">Live</span></div>
		<div class="v3-tile-row"><span class="v3-t-stat" data-v3-bind="workers.queued" data-v3-kind="num" data-v3-fmt="comma" data-v3-good="down">—</span></div>
		<canvas data-v3-spark="workers.queued"></canvas>
	</div>
	<div class="v3-tile v3-acc-reactor v3-lift v3-sheen v3-boot v3-pulse-target v3-span-3">
		<div class="v3-between"><span class="v3-t-label">Crawling Now</span><span class="v3-prov is-live">Live</span></div>
		<div class="v3-tile-row"><span class="v3-t-stat" data-v3-bind="workers.crawling" data-v3-kind="num" data-v3-fmt="int" data-v3-good="up">—</span></div>
		<canvas data-v3-spark="workers.crawling"></canvas>
	</div>

	<!-- QUEUE DEPTH (live, composed) ------------------------------------- -->
	<section class="v3-panel v3-acc-ion v3-boot v3-span-12">
		<div class="v3-panel-head">
			<div class="v3-panel-title-wrap"><span class="v3-panel-icon"></span><span class="v3-t-title">Enrichment Queue Depth</span></div>
			<span class="v3-prov is-live">Live · jobs</span>
		</div>
		<div class="v3-qbar" id="jv3-qbar">
			<i class="q-done" style="width:0"></i><i class="q-running" style="width:0"></i><i class="q-queued" style="width:0"></i><i class="q-dead" style="width:0"></i>
		</div>
		<div class="v3-qlegend">
			<div><i style="background:var(--v3-reactor)"></i>Done <b data-v3-bind="fleet.jobs.done" data-v3-kind="num" data-v3-fmt="comma">—</b></div>
			<div><i style="background:var(--v3-arc)"></i>Running <b data-v3-bind="fleet.jobs.running" data-v3-kind="num" data-v3-fmt="comma">—</b></div>
			<div><i style="background:var(--v3-ion)"></i>Queued <b data-v3-bind="fleet.jobs.queued" data-v3-kind="num" data-v3-fmt="comma">—</b></div>
			<div><i style="background:var(--v3-crimson)"></i>Dead <b data-v3-bind="fleet.jobs.dead" data-v3-kind="num" data-v3-fmt="comma">—</b></div>
		</div>
	</section>

	<!-- WORKER ROSTER (live, hydrated by enhancer) ----------------------- -->
	<section class="v3-panel v3-boot v3-span-8">
		<div class="v3-panel-head">
			<span class="v3-t-title">Fleet Node Roster</span>
			<span class="v3-prov is-live">Live · /admin/fleet</span>
		</div>
		<div id="jv3-roster">
			<?php for ( $i = 0; $i < $max_rows; $i++ ) : ?>
			<div class="v3-worker v3-acc-arc" data-row="<?php echo (int) $i; ?>" hidden>
				<span class="v3-lamp"></span>
				<div class="v3-worker-name"><b class="r-node">—</b><span class="r-state">—</span></div>
				<div class="v3-worker-metric"><b class="r-lanes">—</b><span>Lanes</span></div>
				<div class="v3-worker-metric"><b class="r-ppm">—</b><span>ppm</span></div>
				<canvas class="r-spark"></canvas>
				<div class="v3-worker-metric"><b class="r-age">—</b><span>Seen</span></div>
			</div>
			<?php endfor; ?>
			<div id="jv3-roster-empty" class="v3-stack" style="padding:18px 4px" hidden>
				<span class="v3-t-body v3-muted">No fleet node has checked in. Worker rows appear here the moment a node posts a heartbeat to <code>/admin/fleet</code>.</span>
			</div>
		</div>
	</section>

	<!-- SOURCE HEALTH (honest connector status) -------------------------- -->
	<section class="v3-panel v3-boot v3-span-4">
		<div class="v3-panel-head">
			<span class="v3-t-title">Source Health</span>
			<span class="v3-prov is-off">Static · registry</span>
		</div>
		<div class="v3-sources">
			<?php
			// Honest connector status mirrors ATLAS_LIVE_SOURCES_REGISTRY.md:
			// every source is deploy-ready but NOT ingesting (sink empty).
			$sources = array(
				array( 'CT Multi-log', 'deploy-ready', 'ready' ),
				array( 'SEC EDGAR', 'deploy-ready', 'ready' ),
				array( 'CO SOS', 'sandbox-only', 'idle' ),
				array( 'NYC DCWP', 'sandbox-only', 'idle' ),
				array( 'FL DBPR', 'deploy-ready', 'ready' ),
				array( 'IRS 990', 'deploy-ready', 'ready' ),
				array( 'Foursquare', 'scaffolded', 'off' ),
				array( 'OpenStreetMap', 'scaffolded', 'off' ),
			);
			foreach ( $sources as $s ) :
				$dot = 's-' . $s[2];
				?>
				<div class="v3-src">
					<div class="v3-src-top"><span class="v3-src-name"><?php echo esc_html( $s[0] ); ?></span><span class="v3-dot <?php echo esc_attr( $dot ); ?>"></span></div>
					<span class="v3-src-meta"><?php echo esc_html( strtoupper( $s[1] ) ); ?> · 0 rows</span>
				</div>
			<?php endforeach; ?>
		</div>
		<p class="v3-t-micro v3-muted v3-mt3">Verified empty sink. No source is durably ingesting yet; dots turn green when rows are written. (ATLAS_LIVE_SOURCES_REGISTRY.md)</p>
	</section>

</div>

<script>
/* Lead Hunter enhancer — hydrates the node roster + queue bar from the SAME
   cockpit poll the live layer already runs (no extra network calls). */
(function () {
	var TCV3 = window.TCV3, rowSparks = {};
	function pct(n, tot) { return tot > 0 ? (100 * n / tot) : 0; }
	function hydrate() {
		var st = window.TNCJarvisLive && window.TNCJarvisLive.state();
		if (!st) return;
		// queue bar
		var j = (st.fleet && st.fleet.jobs) || {};
		var tot = (j.done || 0) + (j.running || 0) + (j.queued || 0) + (j.dead || 0);
		var bar = document.getElementById('jv3-qbar');
		if (bar && tot >= 0) {
			bar.querySelector('.q-done').style.width = pct(j.done || 0, tot) + '%';
			bar.querySelector('.q-running').style.width = pct(j.running || 0, tot) + '%';
			bar.querySelector('.q-queued').style.width = pct(j.queued || 0, tot) + '%';
			bar.querySelector('.q-dead').style.width = pct(j.dead || 0, tot) + '%';
		}
		// roster
		var nodes = (st.fleet && st.fleet.nodes) || [];
		var rows = document.querySelectorAll('#jv3-roster .v3-worker');
		var shown = 0;
		rows.forEach(function (row, i) {
			var n = nodes[i];
			if (!n) { row.hidden = true; return; }
			row.hidden = false; shown++;
			row.classList.toggle('is-online', n.state === 'online');
			row.querySelector('.r-node').textContent = n.node;
			row.querySelector('.r-state').textContent = (n.state || '').toUpperCase();
			row.querySelector('.r-lanes').textContent = n.lanes;
			row.querySelector('.r-ppm').textContent = n.ppm;
			row.querySelector('.r-age').textContent = (n.age != null ? (n.age < 60 ? n.age + 's' : Math.floor(n.age / 60) + 'm') : '—');
			var lamp = row.querySelector('.v3-lamp');
			lamp.parentNode && lamp.classList.remove('v3-acc-reactor', 'v3-acc-flare', 'v3-acc-crimson');
			lamp.classList.add(n.state === 'online' ? 'v3-acc-reactor' : n.state === 'stale' ? 'v3-acc-flare' : 'v3-acc-crimson');
			// per-row throughput sparkline from live ppm
			if (TCV3) {
				if (!rowSparks[i]) rowSparks[i] = TCV3.sparkline(row.querySelector('.r-spark'), { fill: true });
				var key = 'ppm' + i; (rowSparks['_s' + i] = rowSparks['_s' + i] || []).push(n.ppm);
				if (rowSparks['_s' + i].length > 40) rowSparks['_s' + i].shift();
				if (rowSparks['_s' + i].length > 1) rowSparks[i].update(rowSparks['_s' + i].slice());
			}
		});
		var empty = document.getElementById('jv3-roster-empty');
		if (empty) empty.hidden = shown > 0;
	}
	setInterval(hydrate, 5000); setTimeout(hydrate, 600);
	var rb = document.getElementById('jv3-refresh');
	if (rb) rb.addEventListener('click', function () { window.TNCJarvisLive && window.TNCJarvisLive.refresh(); setTimeout(hydrate, 400); });
})();
</script>
