=== TuaniChat — J.A.R.V.I.S. V3 (ARC REACTOR) ===
Contributors: lionclickmedia
Requires at least: 5.8
Tested up to: 6.5
Requires PHP: 7.2
Stable tag: 3.1.0
License: GPLv2 or later

Unified ARC REACTOR command surfaces for the TuaniChat platform — Jarvis
Command, Lead Engine and Lead Hunter — with real-time data bound to the live
tuanichat/v1 REST cockpit.

== Description ==

This is an ADDITIVE companion plugin. It does NOT modify the core
tuanichat-platform plugin or its database. It registers a top-level
"J.A.R.V.I.S." admin menu with three surfaces that share one design language:

* Command      — real-time operations (intake, enrichment, outreach, spend).
* Lead Engine  — outreach pacing, sender streams, ISP throttles, engine modules.
* Lead Hunter  — fleet worker liveness, throughput, queue depth, source health.

All three load the ARC REACTOR design system (tuanichat-v3.css + tuanichat-v3.js)
and a live binding layer (tnc-jarvis-live.js) that polls /admin/cockpit every
5 seconds and fans real fields out to the viz components.

HONESTY: Metrics whose data source is not yet ingesting (A.T.L.A.S. records
indexed, LinkedIn / SMS engines, deliverability) are marked PENDING in the UI
and are never fed synthetic values. See DEPLOY_JARVIS_V3.md.

== Installation ==

1. Ensure tuanichat-platform (>= 1.23.x) is active — it exposes the REST cockpit.
2. Upload the tnc-jarvis-v3 folder to wp-content/plugins/ (or install the zip via
   Plugins > Add New > Upload).
3. Activate "TuaniChat — J.A.R.V.I.S. V3".
4. Open the J.A.R.V.I.S. menu in wp-admin.

== Changelog ==

= 3.1.0 =
* Unified the ARC REACTOR look across Command, Lead Engine and Lead Hunter.
* Added tnc-jarvis-live.js: declarative real-time binding to the REST cockpit.
* Added LIVE / EST / PENDING data-provenance badges (honesty primitive).
* Added source-health grid mirroring the verified connector registry.

= 3.0.0 =
* ARC REACTOR design system drop-in (CSS + JS).
