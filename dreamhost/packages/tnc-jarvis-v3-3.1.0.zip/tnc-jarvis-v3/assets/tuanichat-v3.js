/* ============================================================================
 * TuaniChat V3 — "ARC REACTOR" animation / viz library
 * v3.0.0 · 2026-06-07 · zero dependencies · IIFE → window.TCV3
 *
 * PRINCIPLES (enforced here, not just documented):
 *  - DATA-TRUE: every amplitude derives from a real delta or event weight.
 *    Zero delta ⇒ zero motion. No decorative randomness on metrics.
 *  - GPU/CANVAS ONLY: DOM gets transform+opacity; continuous viz is canvas.
 *  - IDLE = SILENT: sparkline/EKG/ring redraw only on update; stream & ticker
 *    run rAF only while animating; everything pauses off-screen / hidden tab.
 *  - REDUCED-MOTION SAFE: final static frames, snapped tickers, no loops.
 * ========================================================================== */
(function (global) {
  'use strict';

  /* ------------------------------------------------------------------ */
  /* core utils                                                          */
  /* ------------------------------------------------------------------ */
  var rmQuery = global.matchMedia ? global.matchMedia('(prefers-reduced-motion: reduce)') : { matches: false };
  var motionOverride = 'auto'; // 'auto' | 'on' | 'off'

  function motionOK() {
    if (motionOverride === 'on') return true;
    if (motionOverride === 'off') return false;
    return !rmQuery.matches;
  }

  function clamp01(x) { return x < 0 ? 0 : x > 1 ? 1 : x; }

  /** Normalized data-true amplitude from old→new value. */
  function amplitude(oldV, newV) {
    if (oldV === newV || oldV == null) return 0;
    var base = Math.max(Math.abs(oldV), 1e-9);
    return clamp01(Math.abs(newV - oldV) / base * 4); // 25% change ⇒ full amp
  }

  var easeOut = function (t) { return 1 - Math.pow(1 - t, 3); };
  var easeInOut = function (t) { return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; };

  /* visibility management: pause every renderer when hidden/off-screen */
  var renderers = [];
  var io = ('IntersectionObserver' in global)
    ? new IntersectionObserver(function (entries) {
        entries.forEach(function (e) {
          var r = e.target.__tcv3;
          if (r) r._visible = e.isIntersecting;
        });
      }, { rootMargin: '80px' })
    : null;

  document.addEventListener('visibilitychange', function () {
    var hidden = document.hidden;
    renderers.forEach(function (r) { r._tabVisible = !hidden; if (!hidden && r._wake) r._wake(); });
  });

  function register(el, r) {
    r._visible = true;
    r._tabVisible = !document.hidden;
    el.__tcv3 = r;
    renderers.push(r);
    if (io) io.observe(el);
    return r;
  }
  function canRender(r) { return r._visible && r._tabVisible; }

  /* DPR-aware canvas sizing */
  function fitCanvas(canvas) {
    var dpr = Math.min(global.devicePixelRatio || 1, 2);
    var rect = canvas.getBoundingClientRect();
    var w = Math.max(1, Math.round(rect.width * dpr));
    var h = Math.max(1, Math.round(rect.height * dpr));
    if (canvas.width !== w || canvas.height !== h) {
      canvas.width = w; canvas.height = h;
    }
    return { ctx: canvas.getContext('2d'), w: w, h: h, dpr: dpr };
  }

  function cssVar(el, name, fallback) {
    var v = getComputedStyle(el).getPropertyValue(name).trim();
    return v || fallback;
  }
  function accentOf(el, opt) {
    return (opt && opt.color) || cssVar(el, '--v3-acc', '#4fd9ff');
  }
  function accentHiOf(el, opt) {
    return (opt && opt.colorHi) || cssVar(el, '--v3-acc-hi', '#a6eeff');
  }
  function hexA(hex, a) {
    if (hex[0] !== '#') return hex;
    var n = parseInt(hex.length === 4
      ? hex.slice(1).split('').map(function (c) { return c + c; }).join('')
      : hex.slice(1), 16);
    return 'rgba(' + ((n >> 16) & 255) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')';
  }

  /* tween manager: shared rAF that only runs while tweens exist */
  var tweens = [];
  var rafId = null;
  function tick(now) {
    rafId = null;
    for (var i = tweens.length - 1; i >= 0; i--) {
      var tw = tweens[i];
      var t = clamp01((now - tw.start) / tw.dur);
      tw.fn(tw.ease(t));
      if (t >= 1) {
        tweens.splice(i, 1);
        if (tw.done) tw.done();
      }
    }
    if (tweens.length) rafId = requestAnimationFrame(tick);
  }
  function tween(dur, ease, fn, done) {
    if (!motionOK() || dur <= 0) { fn(1); if (done) done(); return; }
    tweens.push({ start: performance.now(), dur: dur, ease: ease, fn: fn, done: done });
    if (!rafId) rafId = requestAnimationFrame(tick);
  }

  /* ------------------------------------------------------------------ */
  /* TCV3.pulse — data-true DOM pulse                                    */
  /* ------------------------------------------------------------------ */
  /**
   * Pulse an element proportionally to a real delta.
   * @param {Element} el        target (give it .v3-pulse-target in markup)
   * @param {number}  delta     normalized 0..1 (use TCV3.amp(oldV,newV))
   * @param {string} [goodDir]  'up'|'down' — colors the wash semantically
   */
  function pulse(el, delta, goodDir) {
    if (!el || delta <= 0 || !motionOK()) return;
    el.style.setProperty('--v3-amp', String(clamp01(delta)));
    el.classList.remove('is-pulsing');
    void el.offsetWidth; // restart animation
    el.classList.add('is-pulsing');
    if (goodDir) el.setAttribute('data-v3-good', goodDir);
    var clear = function () { el.classList.remove('is-pulsing'); el.removeEventListener('animationend', clear); };
    el.addEventListener('animationend', clear);
  }

  /* ------------------------------------------------------------------ */
  /* TCV3.sparkline — canvas sparkline bound to a real series            */
  /* ------------------------------------------------------------------ */
  /**
   * @param {HTMLCanvasElement} canvas
   * @param {{series?:number[], color?:string, colorHi?:string, fill?:boolean, max?:number}} [opt]
   * @returns {{update:(pointOrSeries:number|number[])=>void, destroy:()=>void}}
   */
  function sparkline(canvas, opt) {
    opt = opt || {};
    var series = (opt.series || []).slice(-60);
    var color = accentOf(canvas, opt);
    var colorHi = accentHiOf(canvas, opt);
    var drawProgress = 1; // boot draw-on uses 0→1
    var r = register(canvas, {});

    function draw() {
      if (!canRender(r)) return;
      var f = fitCanvas(canvas), ctx = f.ctx, w = f.w, h = f.h;
      ctx.clearRect(0, 0, w, h);
      if (series.length < 2) return;
      var n = series.length;
      var max = opt.max != null ? opt.max : Math.max.apply(null, series);
      var min = Math.min.apply(null, series);
      if (max === min) { max = min + 1; }
      var pad = 2 * f.dpr;
      var lastI = Math.max(1, Math.floor((n - 1) * drawProgress));
      var px = function (i) { return pad + (w - 2 * pad) * (i / (n - 1)); };
      var py = function (v) { return h - pad - (h - 2 * pad) * ((v - min) / (max - min)); };

      // area fill
      if (opt.fill !== false) {
        var grad = ctx.createLinearGradient(0, 0, 0, h);
        grad.addColorStop(0, hexA(color, 0.18));
        grad.addColorStop(1, hexA(color, 0));
        ctx.beginPath();
        ctx.moveTo(px(0), h);
        for (var i = 0; i <= lastI; i++) ctx.lineTo(px(i), py(series[i]));
        ctx.lineTo(px(lastI), h);
        ctx.closePath();
        ctx.fillStyle = grad;
        ctx.fill();
      }
      // line
      ctx.beginPath();
      for (var j = 0; j <= lastI; j++) {
        if (j === 0) ctx.moveTo(px(j), py(series[j])); else ctx.lineTo(px(j), py(series[j]));
      }
      ctx.strokeStyle = color;
      ctx.lineWidth = 1.5 * f.dpr;
      ctx.lineJoin = 'round';
      ctx.stroke();
      // glow head dot
      var hx = px(lastI), hy = py(series[lastI]);
      ctx.beginPath();
      ctx.arc(hx, hy, 2.2 * f.dpr, 0, Math.PI * 2);
      ctx.fillStyle = colorHi;
      ctx.shadowColor = color;
      ctx.shadowBlur = 6 * f.dpr;
      ctx.fill();
      ctx.shadowBlur = 0;
    }

    r._wake = draw;

    // boot draw-on (left→right) — only if motion allowed
    if (series.length > 1 && motionOK()) {
      drawProgress = 0;
      tween(700, easeInOut, function (t) { drawProgress = t; draw(); });
    } else {
      requestAnimationFrame(draw);
    }

    return {
      /** Push one new point or replace the whole series. Redraws once. */
      update: function (pointOrSeries) {
        if (Array.isArray(pointOrSeries)) series = pointOrSeries.slice(-60);
        else { series.push(pointOrSeries); if (series.length > 60) series.shift(); }
        drawProgress = 1;
        draw();
      },
      destroy: function () { if (io) io.unobserve(canvas); }
    };
  }

  /* ------------------------------------------------------------------ */
  /* TCV3.ekg — event-driven EKG trace                                   */
  /* ------------------------------------------------------------------ */
  /**
   * Flat line that spikes ONLY when .beat(intensity) is called with a real
   * event. Spike height = intensity (0..1). Idle trace does not animate.
   * @returns {{beat:(intensity:number)=>void, destroy:()=>void}}
   */
  function ekg(canvas, opt) {
    opt = opt || {};
    var color = accentOf(canvas, opt);
    var buf = []; // ring buffer of y-offsets
    var N = 120;
    for (var i = 0; i < N; i++) buf.push(0);
    var animating = false;
    var pending = 0; // queued beat intensity
    var r = register(canvas, {});

    function draw() {
      var f = fitCanvas(canvas), ctx = f.ctx, w = f.w, h = f.h;
      ctx.clearRect(0, 0, w, h);
      var mid = h * 0.62;
      ctx.beginPath();
      for (var i = 0; i < N; i++) {
        var x = (i / (N - 1)) * w;
        var y = mid - buf[i] * (h * 0.5);
        if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      }
      ctx.strokeStyle = color;
      ctx.lineWidth = 1.4 * f.dpr;
      ctx.shadowColor = color;
      ctx.shadowBlur = 4 * f.dpr;
      ctx.stroke();
      ctx.shadowBlur = 0;
    }

    function step() {
      buf.shift();
      if (pending > 0) {
        // inject a QRS-like spike scaled by event intensity
        var k = pending; pending = 0;
        buf.push(0.12 * k);
        buf.push(-0.2 * k); buf.shift();
        buf.push(1.0 * k); buf.shift();
        buf.push(-0.35 * k); buf.shift();
        buf.push(0.08 * k); buf.shift();
      } else {
        buf.push(0);
      }
      if (canRender(r)) draw();
      // keep scrolling only while a spike is still visible
      var live = buf.some(function (v) { return Math.abs(v) > 0.005; });
      if (live && motionOK()) requestAnimationFrame(step);
      else animating = false;
    }

    r._wake = draw;
    requestAnimationFrame(draw);

    return {
      beat: function (intensity) {
        pending = clamp01(intensity == null ? 0.6 : intensity);
        if (pending <= 0) return;
        if (!motionOK()) { // static: draw one spike frame
          buf[N - 8] = pending; draw(); buf[N - 8] = 0;
          return;
        }
        if (!animating) { animating = true; requestAnimationFrame(step); }
      },
      destroy: function () { if (io) io.unobserve(canvas); }
    };
  }

  /* ------------------------------------------------------------------ */
  /* TCV3.ring — SVG ring gauge, sweeps only on change                   */
  /* ------------------------------------------------------------------ */
  /**
   * Builds the SVG inside `el` (a .v3-ring container).
   * @param {Element} el
   * @param {{value?:number, max?:number, size?:number, stroke?:number,
   *          color?:string, colorHi?:string, format?:(v:number)=>string}} [opt]
   * @returns {{update:(value:number)=>void, destroy:()=>void}}
   */
  function ring(el, opt) {
    opt = opt || {};
    var size = opt.size || 96;
    var strokeW = opt.stroke || 7;
    var max = opt.max || 100;
    var color = accentOf(el, opt);
    var colorHi = accentHiOf(el, opt);
    var rad = (size - strokeW) / 2;
    var circ = 2 * Math.PI * rad;
    var gid = 'v3g' + Math.random().toString(36).slice(2, 8);

    el.innerHTML =
      '<svg width="' + size + '" height="' + size + '" viewBox="0 0 ' + size + ' ' + size + '">' +
      '<defs><linearGradient id="' + gid + '" x1="0" y1="0" x2="1" y2="1">' +
      '<stop offset="0" stop-color="' + color + '"/><stop offset="1" stop-color="' + colorHi + '"/>' +
      '</linearGradient></defs>' +
      '<circle class="v3-ring-track" cx="' + size / 2 + '" cy="' + size / 2 + '" r="' + rad + '" stroke-width="' + strokeW + '"/>' +
      '<circle class="v3-ring-arc" cx="' + size / 2 + '" cy="' + size / 2 + '" r="' + rad + '" stroke-width="' + strokeW + '"' +
      ' stroke="url(#' + gid + ')" stroke-dasharray="' + circ + '" stroke-dashoffset="' + circ + '"/>' +
      '<circle class="v3-ring-dot" r="' + (strokeW / 2 + 1) + '" fill="' + colorHi + '"/>' +
      '</svg>' +
      '<div class="v3-ring-val">--</div>';

    var arc = el.querySelector('.v3-ring-arc');
    var dot = el.querySelector('.v3-ring-dot');
    var valEl = el.querySelector('.v3-ring-val');
    var fmt = opt.format || function (v) { return Math.round(v / max * 100) + '%'; };
    var cur = 0;
    var r = register(el, {});

    function paint(v) {
      var frac = clamp01(v / max);
      arc.setAttribute('stroke-dashoffset', String(circ * (1 - frac)));
      var ang = frac * Math.PI * 2 - Math.PI / 2 + Math.PI / 2; // svg pre-rotated -90 via CSS
      // dot position in the rotated coordinate space (svg is rotated -90deg in CSS)
      var a = frac * Math.PI * 2;
      dot.setAttribute('cx', String(size / 2 + rad * Math.cos(a)));
      dot.setAttribute('cy', String(size / 2 + rad * Math.sin(a)));
      dot.setAttribute('opacity', frac > 0.01 ? '1' : '0');
      valEl.textContent = fmt(v);
    }

    function sweepTo(v) {
      var from = cur, to = clamp01(v / max) * max;
      var amp = amplitude(from || 0.0001, to);
      var dur = from === 0 ? 900 : (220 + 380 * amp); // boot sweep is longer
      if (!canRender(r) || !motionOK()) { cur = to; paint(to); return; }
      tween(dur, easeOut, function (t) {
        var x = from + (to - from) * t;
        paint(x);
      }, function () { cur = to; });
    }

    r._wake = function () { paint(cur); };
    if (opt.value != null) sweepTo(opt.value);

    return {
      update: function (v) { if (v !== cur) sweepTo(v); },
      destroy: function () { if (io) io.unobserve(el); }
    };
  }

  /* ------------------------------------------------------------------ */
  /* TCV3.ticker — odometer digit roller (A.T.L.A.S.)                    */
  /* ------------------------------------------------------------------ */
  /**
   * Per-digit rolling counter. Roll duration scales with digits changed;
   * big jumps batch into one roll. Builds columns inside `el`
   * (a .v3-ticker-digits container).
   * @returns {{update:(value:number)=>void, destroy:()=>void}}
   */
  function ticker(el, opt) {
    opt = opt || {};
    var cur = -1;
    var r = register(el, {});

    function fmt(n) {
      var s = String(Math.max(0, Math.floor(n)));
      var out = [];
      for (var i = 0; i < s.length; i++) {
        out.push(s[i]);
        var rem = s.length - 1 - i;
        if (rem > 0 && rem % 3 === 0) out.push(',');
      }
      return out;
    }

    function build(chars) {
      el.innerHTML = '';
      chars.forEach(function (ch) {
        if (ch === ',') {
          var sep = document.createElement('span');
          sep.className = 'v3-digit-sep';
          sep.textContent = ',';
          el.appendChild(sep);
        } else {
          var d = document.createElement('span');
          d.className = 'v3-digit';
          var col = document.createElement('span');
          col.className = 'v3-digit-col';
          for (var k = 0; k <= 9; k++) {
            var s = document.createElement('span');
            s.textContent = String(k);
            col.appendChild(s);
          }
          d.appendChild(col);
          d.__col = col;
          el.appendChild(d);
        }
      });
    }

    function setDigits(value, animate) {
      var chars = fmt(value);
      var digits = el.querySelectorAll('.v3-digit');
      var curDigitCount = digits.length;
      var newDigitCount = chars.filter(function (c) { return c !== ','; }).length;
      if (curDigitCount !== newDigitCount) { build(chars); digits = el.querySelectorAll('.v3-digit'); animate = animate && motionOK(); }

      var di = 0, changed = 0;
      var targets = [];
      chars.forEach(function (ch) {
        if (ch === ',') return;
        targets.push(parseInt(ch, 10));
      });
      targets.forEach(function (tgt, idx) {
        var d = digits[idx];
        var col = d.firstChild;
        var prev = d.__val == null ? -1 : d.__val;
        if (prev !== tgt) changed++;
        d.__val = tgt;
      });

      var dur = !animate || !motionOK() || !canRender(r) ? 0
        : Math.min(760, 200 + 90 * changed);

      targets.forEach(function (tgt, idx) {
        var d = digits[idx];
        var col = d.firstChild;
        var y = -tgt; // em offset
        if (dur === 0) {
          col.style.transition = 'none';
          col.style.transform = 'translateY(' + y + 'em)';
        } else {
          col.style.transition = 'transform ' + dur + 'ms cubic-bezier(.22,1,.36,1)';
          col.style.transform = 'translateY(' + y + 'em)';
        }
      });
    }

    r._wake = function () { if (cur >= 0) setDigits(cur, false); };

    return {
      update: function (value) {
        if (value === cur) return;
        var animate = cur >= 0; // first paint snaps unless boot roll requested
        cur = value;
        setDigits(value, animate);
      },
      /** boot roll: animate from a lower bound up to value */
      boot: function (value) {
        if (!motionOK()) { cur = value; setDigits(value, false); return; }
        var from = Math.max(0, Math.floor(value * 0.985));
        cur = from;
        setDigits(from, false);
        var self = this;
        requestAnimationFrame(function () {
          requestAnimationFrame(function () { self.update(value); });
        });
      },
      destroy: function () { if (io) io.unobserve(el); }
    };
  }

  /* ------------------------------------------------------------------ */
  /* TCV3.stream — event-driven particle data-stream                     */
  /* ------------------------------------------------------------------ */
  /**
   * Particles spawn ONLY via .event(weight). Idle feed stills completely.
   * @returns {{event:(weight?:number)=>void, destroy:()=>void}}
   */
  function stream(canvas, opt) {
    opt = opt || {};
    var color = accentOf(canvas, opt);
    var colorHi = accentHiOf(canvas, opt);
    var parts = [];
    var MAX = 90;
    var running = false;
    var r = register(canvas, {});

    function spawn(weight) {
      var count = Math.max(1, Math.round(1 + 3 * clamp01(weight)));
      for (var i = 0; i < count && parts.length < MAX; i++) {
        parts.push({
          x: 0,
          y: 0.25 + Math.random() * 0.5,           // lane (visual only, not data)
          v: 0.45 + 0.55 * clamp01(weight),        // speed ∝ event weight (data-true)
          a: 0.5 + 0.5 * clamp01(weight),
          s: 1 + Math.round(clamp01(weight) * 1.5)
        });
      }
    }

    function frame() {
      if (!parts.length) { running = false; return; }
      var f = fitCanvas(canvas), ctx = f.ctx, w = f.w, h = f.h;
      ctx.clearRect(0, 0, w, h);
      // route line
      ctx.strokeStyle = hexA(color, 0.12);
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(0, h / 2); ctx.lineTo(w, h / 2);
      ctx.stroke();
      ctx.globalCompositeOperation = 'lighter';
      for (var i = parts.length - 1; i >= 0; i--) {
        var p = parts[i];
        p.x += p.v * 0.012;
        if (p.x > 1.05) { parts.splice(i, 1); continue; }
        var px = p.x * w;
        var py = p.y * h;
        // trail
        ctx.strokeStyle = hexA(color, 0.25 * p.a);
        ctx.lineWidth = p.s * f.dpr * 0.6;
        ctx.beginPath();
        ctx.moveTo(px - 14 * f.dpr * p.v, py);
        ctx.lineTo(px, py);
        ctx.stroke();
        // head
        ctx.fillStyle = hexA(colorHi, p.a);
        ctx.beginPath();
        ctx.arc(px, py, p.s * f.dpr * 0.8, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalCompositeOperation = 'source-over';
      if (canRender(r) && motionOK()) requestAnimationFrame(frame);
      else { running = false; }
    }

    function drawStatic() {
      var f = fitCanvas(canvas), ctx = f.ctx, w = f.w, h = f.h;
      ctx.clearRect(0, 0, w, h);
      ctx.strokeStyle = hexA(color, 0.25);
      ctx.setLineDash([2 * f.dpr, 5 * f.dpr]);
      ctx.beginPath(); ctx.moveTo(0, h / 2); ctx.lineTo(w, h / 2); ctx.stroke();
      ctx.setLineDash([]);
    }

    r._wake = function () { if (!running) drawStatic(); };
    requestAnimationFrame(drawStatic);

    return {
      event: function (weight) {
        if (!motionOK()) { drawStatic(); return; }
        spawn(weight == null ? 0.5 : weight);
        if (!running && canRender(r)) { running = true; requestAnimationFrame(frame); }
      },
      destroy: function () { if (io) io.unobserve(canvas); }
    };
  }

  /* ------------------------------------------------------------------ */
  /* TCV3.feed — decision feed controller                                */
  /* ------------------------------------------------------------------ */
  /**
   * @param {Element} el  .v3-feed container
   * @param {{max?:number}} [opt]
   * @returns {{push:(item:{time:string,actor:string,verdict:string,text:string,tone?:string})=>void}}
   */
  function feed(el, opt) {
    opt = opt || {};
    var max = opt.max || 6;

    return {
      push: function (item) {
        var row = document.createElement('div');
        var tone = item.tone || 'ion';
        row.className = 'v3-feed-row v3-acc-' + tone + (motionOK() ? ' is-new' : '');
        row.innerHTML =
          '<span class="v3-t-micro">' + item.time + '</span>' +
          '<span class="v3-chip v3-chip-actor v3-acc-ion">' + item.actor + '</span>' +
          '<span class="v3-feed-text">' + item.text + '</span>' +
          '<span class="v3-chip v3-acc-' + tone + '">' + item.verdict + '</span>';
        el.insertBefore(row, el.firstChild);
        // accent bar settles after 1.4s
        setTimeout(function () { row.classList.add('is-settled'); }, 60);
        // age + trim
        var rows = el.querySelectorAll('.v3-feed-row');
        for (var i = 0; i < rows.length; i++) {
          rows[i].classList.toggle('is-old', i >= Math.ceil(max / 2));
          if (i >= max) el.removeChild(rows[i]);
        }
      }
    };
  }

  /* ------------------------------------------------------------------ */
  /* TCV3.orbitOnce — one-shot gradient border flourish                  */
  /* ------------------------------------------------------------------ */
  function orbitOnce(el) {
    if (!motionOK()) return;
    el.classList.add('v3-orbit-once');
    el.classList.remove('is-orbiting');
    void el.offsetWidth;
    el.classList.add('is-orbiting');
    var clear = function () { el.classList.remove('is-orbiting'); el.removeEventListener('animationend', clear); };
    el.addEventListener('animationend', clear);
  }

  /* ------------------------------------------------------------------ */
  /* TCV3.init — boot choreography                                       */
  /* ------------------------------------------------------------------ */
  /**
   * @param {Element} root            element carrying .tc-v3
   * @param {{motion?:'auto'|'on'|'off', ambient?:boolean}} [opt]
   */
  function init(root, opt) {
    opt = opt || {};
    if (opt.motion) motionOverride = opt.motion;
    if (opt.ambient !== false && motionOK()) root.setAttribute('data-v3-ambient', 'on');
    if (motionOverride === 'off') root.setAttribute('data-v3-motion', 'off');

    var boots = root.querySelectorAll('.v3-boot');
    if (!motionOK()) {
      root.classList.remove('v3-preboot');
      boots.forEach(function (b) { b.classList.add('is-booted'); });
      return;
    }

    root.classList.add('v3-preboot');
    // stagger: cap at 8 unique slots, then batch
    boots.forEach(function (b, i) {
      b.style.setProperty('--v3-boot-delay', (Math.min(i, 8) * 55) + 'ms');
    });
    requestAnimationFrame(function () {
      root.classList.remove('v3-preboot');
      boots.forEach(function (b) { b.classList.add('is-booted'); });
    });

    // one-time scanline sweep
    var scan = document.createElement('div');
    scan.className = 'v3-scanline';
    root.appendChild(scan);
    scan.addEventListener('animationend', function () { scan.remove(); });
  }

  /* ------------------------------------------------------------------ */
  /* export                                                              */
  /* ------------------------------------------------------------------ */
  global.TCV3 = {
    init: init,
    sparkline: sparkline,
    ekg: ekg,
    ring: ring,
    ticker: ticker,
    stream: stream,
    feed: feed,
    pulse: pulse,
    orbitOnce: orbitOnce,
    amp: amplitude,
    motionOK: motionOK
  };

})(window);
