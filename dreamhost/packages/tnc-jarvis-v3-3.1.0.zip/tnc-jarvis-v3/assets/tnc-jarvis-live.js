/* ============================================================================
 * TuaniChat J.A.R.V.I.S. V3 — LIVE DATA BINDING LAYER
 * v3.1.0 · zero dependencies · pairs with TCV3 (tuanichat-v3.js)
 *
 * WHAT THIS DOES
 *  - Polls the plugin's REST cockpit (/wp-json/tuanichat/v1/admin/cockpit) on a
 *    fixed cadence and fans the REAL fields out to TCV3 viz controllers and to
 *    plain text targets, declaratively, via data-v3-bind attributes.
 *  - Keeps a short rolling history per metric so sparklines reflect ACTUAL
 *    movement of real numbers (not synthetic jitter).
 *  - Is honest: any element marked data-v3-prov="pending" is NEVER fed a fake
 *    value. It keeps its placeholder and its amber PENDING badge until a real
 *    source is wired. Provenance is data-driven, not decorative.
 *
 * DEMO / PREVIEW MODE
 *  - If no REST root is present (window.TNC_JARVIS_V3.rest unset) the layer runs
 *    in demo mode against window.TNC_JARVIS_V3.demo so the preview page animates.
 *    Demo mode is clearly flagged in the system pill ("PREVIEW — SIMULATED").
 *
 * DECLARATIVE BINDING (in markup)
 *   data-v3-bind="counts.prospects"     dotted path into the cockpit payload
 *   data-v3-kind="num|ticker|ring|pct|lamp|text|spark"
 *   data-v3-fmt="int|comma|usd|pct|ago|plain"
 *   data-v3-prov="live|est|pending|off"  provenance (drives the badge + scrim)
 *   data-v3-good="up|down"               semantic colour of the update pulse
 *   data-v3-max="100"                    for ring/pct
 *   data-v3-spark="counts.prospects"     series key for the tile's <canvas>
 * ========================================================================== */
(function (global) {
  'use strict';

  var CFG = global.TNC_JARVIS_V3 || (global.TNC_JARVIS_V3 = {});
  var INTERVAL = CFG.interval || 5000;          // poll cadence (ms)
  var HISTORY = 60;                              // points kept per series
  var T = global.TCV3;

  /* ---- value resolution ---------------------------------------------------- */
  function dig(obj, path) {
    if (!obj || !path) return undefined;
    var parts = path.split('.'), cur = obj;
    for (var i = 0; i < parts.length; i++) {
      if (cur == null) return undefined;
      cur = cur[parts[i]];
    }
    return cur;
  }

  /* ---- formatting ---------------------------------------------------------- */
  function commafy(n) {
    n = Math.round(Number(n) || 0);
    return n.toLocaleString('en-US');
  }
  function fmt(v, how) {
    if (v == null || (typeof v === 'number' && isNaN(v))) return '—';
    switch (how) {
      case 'comma': return commafy(v);
      case 'int':   return String(Math.round(Number(v) || 0));
      case 'usd':   return '$' + (Number(v) || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
      case 'pct':   return Math.round(Number(v) || 0) + '%';
      case 'ago':   return agoStr(v);
      default:      return String(v);
    }
  }
  function agoStr(sec) {
    sec = Number(sec); if (isNaN(sec) || sec < 0) return '—';
    if (sec < 60) return sec + 's';
    if (sec < 3600) return Math.floor(sec / 60) + 'm';
    return Math.floor(sec / 3600) + 'h';
  }

  /* ---- rolling history per series key ------------------------------------- */
  var series = {};
  function pushSeries(key, val) {
    if (typeof val !== 'number' || isNaN(val)) return null;
    var a = series[key] || (series[key] = []);
    // only append when the value actually changes or on the first sample —
    // a flat series should render flat (data-true).
    if (a.length === 0 || a[a.length - 1] !== val) a.push(val);
    else a.push(val);
    if (a.length > HISTORY) a.shift();
    return a;
  }

  /* ---- bound element registry --------------------------------------------- */
  var bounds = [];   // { el, path, kind, fmt, good, prov, ctrl, last, sparkKey }
  function scan(root) {
    bounds.length = 0;
    var els = root.querySelectorAll('[data-v3-bind], [data-v3-spark]');
    Array.prototype.forEach.call(els, function (el) {
      var b = {
        el: el,
        path: el.getAttribute('data-v3-bind'),
        kind: el.getAttribute('data-v3-kind') || 'num',
        fmt: el.getAttribute('data-v3-fmt') || 'plain',
        good: el.getAttribute('data-v3-good') || null,
        prov: el.getAttribute('data-v3-prov') || 'live',
        max: parseFloat(el.getAttribute('data-v3-max')) || 100,
        sparkKey: el.getAttribute('data-v3-spark') || el.getAttribute('data-v3-bind'),
        ctrl: null,
        last: null
      };
      // instantiate the right TCV3 controller once
      if (T) {
        if (b.kind === 'spark') {
          b.ctrl = T.sparkline(el, { fill: true });
        } else if (b.kind === 'ring' || b.kind === 'pct' && el.classList.contains('v3-ring')) {
          b.ctrl = T.ring(el, { value: 0, max: b.max, size: parseInt(el.getAttribute('data-v3-size'), 10) || 96 });
        } else if (b.kind === 'ticker') {
          b.ctrl = T.ticker(el, {});
        }
      }
      bounds.push(b);
    });
  }

  /* ---- apply one cockpit payload to all bound elements -------------------- */
  function apply(state) {
    var t = Date.now();
    bounds.forEach(function (b) {
      // PENDING / OFF: never inject a value. Honesty guard.
      if (b.prov === 'pending' || b.prov === 'off') return;

      var raw = dig(state, b.path);

      if (b.kind === 'spark') {
        var sk = pushSeries(b.sparkKey, typeof raw === 'number' ? raw : dig(state, b.sparkKey));
        if (b.ctrl && sk && sk.length > 1) b.ctrl.update(sk.slice());
        return;
      }
      if (raw === undefined || raw === null) return;

      if (b.kind === 'ring' || b.kind === 'pct') {
        if (b.ctrl) b.ctrl.update(Number(raw));
        else b.el.textContent = fmt(raw, b.fmt || 'pct');
        return;
      }
      if (b.kind === 'ticker') {
        if (b.ctrl) b.ctrl.update(Math.round(Number(raw)));
        return;
      }
      if (b.kind === 'lamp') {
        applyLamp(b.el, raw);
        return;
      }
      // num / text
      var txt = fmt(raw, b.fmt);
      if (txt !== b.el.textContent) {
        b.el.textContent = txt;
        // data-true pulse on the nearest pulse target
        if (T && typeof raw === 'number' && b.last != null) {
          var amp = T.amp(b.last, raw);
          var tgt = b.el.closest('.v3-pulse-target') || b.el;
          T.pulse(tgt, amp, b.good || (raw >= b.last ? 'up' : 'down'));
        }
        // keep a sparkline fed if the same element drives one elsewhere
        pushSeries(b.path, typeof raw === 'number' ? raw : null);
      }
      if (typeof raw === 'number') b.last = raw;
    });
  }

  function applyLamp(el, state) {
    var cls = { online: 'v3-acc-reactor', running: 'v3-acc-reactor', stale: 'v3-acc-flare',
                degraded: 'v3-acc-flare', warmup: 'v3-acc-flare', offline: 'v3-acc-crimson',
                down: 'v3-acc-crimson', off: 'v3-acc-off' };
    ['v3-acc-reactor', 'v3-acc-flare', 'v3-acc-crimson', 'v3-acc-off'].forEach(function (c) { el.classList.remove(c); });
    el.classList.add(cls[String(state)] || 'v3-acc-off');
  }

  /* ---- decision feed (real mail_log rows) --------------------------------- */
  var feedCtrl = null, feedSeen = {};
  function applyFeed(state) {
    var feedEl = document.querySelector('[data-v3-feed]');
    if (!feedEl) return;
    if (!feedCtrl && T) feedCtrl = T.feed(feedEl, { max: 6 });
    var log = (state && state.mail_log) || [];
    // newest first; push only unseen rows
    for (var i = Math.min(log.length, 6) - 1; i >= 0; i--) {
      var m = log[i];
      var id = (m.ts || '') + '|' + (m.to || m.subject || i);
      if (feedSeen[id]) continue;
      feedSeen[id] = 1;
      var tone = m.status === 'bounced' || m.status === 'error' ? 'crimson'
               : m.status === 'queued' ? 'flare' : 'plasma';
      if (feedCtrl) feedCtrl.push({
        time: (m.ts ? new Date(m.ts * 1000) : new Date()).toLocaleTimeString('en-US', { hour12: false }),
        actor: 'MAIL',
        verdict: (m.status || 'sent').toUpperCase(),
        text: (m.subject || m.to || 'message') + '',
        tone: tone
      });
    }
  }

  /* ---- system status pill ------------------------------------------------- */
  function setSys(state, demo) {
    var el = document.querySelector('[data-v3-sys]');
    if (!el) return;
    if (demo) { el.className = 'v3-sys is-warn'; el.textContent = 'PREVIEW — SIMULATED'; return; }
    var w = state.workers || {}, age = w.heartbeat_age;
    var ok = age == null || age < 180;
    var degraded = (state.fleet && state.fleet.offline_nodes && state.fleet.offline_nodes.length);
    el.className = 'v3-sys' + (!ok ? ' is-down' : degraded ? ' is-warn' : '');
    el.textContent = !ok ? 'HEARTBEAT STALE' : degraded ? 'DEGRADED — NODE OFFLINE' : 'ALL SYSTEMS NOMINAL';
  }

  /* ---- clock -------------------------------------------------------------- */
  function tickClock() {
    var el = document.querySelector('[data-v3-clock]');
    if (el) el.textContent = new Date().toLocaleTimeString('en-US', { hour12: false });
  }

  /* ---- fetch loop --------------------------------------------------------- */
  var stopped = false;
  function poll() {
    if (stopped) return;
    if (!CFG.rest) { // demo mode
      apply(CFG.demo || {}); applyFeed(CFG.demo || {}); setSys(CFG.demo || {}, true);
      return schedule();
    }
    fetch(CFG.rest.replace(/\/$/, '') + '/admin/cockpit', {
      headers: { 'X-WP-Nonce': CFG.nonce || '' }, credentials: 'same-origin'
    }).then(function (r) { return r.ok ? r.json() : Promise.reject(r.status); })
      .then(function (state) {
        CFG._last = state;
        apply(state); applyFeed(state); setSys(state, false);
      })
      .catch(function () {
        var el = document.querySelector('[data-v3-sys]');
        if (el) { el.className = 'v3-sys is-down'; el.textContent = 'CONNECTION LOST'; }
      })
      .finally(schedule);
  }
  var timer = null;
  function schedule() { clearTimeout(timer); timer = setTimeout(poll, INTERVAL); }

  /* ---- demo driver: nudges the demo payload so the preview breathes -------- */
  function startDemoDrift() {
    if (CFG.rest || !CFG.demo) return;
    setInterval(function () {
      var d = CFG.demo;
      // gentle, bounded random walk on the LIVE-class demo fields only;
      // pending fields are left frozen so the preview shows them as pending.
      if (d.counts) d.counts.prospects += Math.round((Math.random() - 0.35) * 3);
      if (d.workers) d.workers.pages_per_min = Math.max(0, d.workers.pages_per_min + Math.round((Math.random() - 0.5) * 6));
      if (d.spend) d.spend.today_calls += Math.random() < 0.4 ? 1 : 0;
      if (d.fleet && d.fleet.jobs) {
        var mv = Math.random() < 0.5 ? 1 : 0;
        d.fleet.jobs.queued = Math.max(0, d.fleet.jobs.queued - mv);
        d.fleet.jobs.done += mv;
      }
      apply(d); applyFeed(d);
    }, INTERVAL);
  }

  /* ---- boot --------------------------------------------------------------- */
  function boot() {
    var root = document.querySelector('.tc-v3');
    if (!root) return;
    if (T) T.init(root, { motion: CFG.motion || 'auto' });
    scan(root);
    setInterval(tickClock, 1000); tickClock();
    poll();
    startDemoDrift();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();

  global.TNCJarvisLive = {
    refresh: function () { poll(); },
    stop: function () { stopped = true; clearTimeout(timer); },
    state: function () { return CFG._last; },
    _series: series
  };
})(window);
