<?php
/**
 * Plugin Name:       TuaniChat — J.A.R.V.I.S. V3 (ARC REACTOR)
 * Plugin URI:        https://chat.lionclickmedia.com/
 * Description:        Unified ARC REACTOR command surfaces for the TuaniChat platform — Jarvis Command, Lead Engine, and Lead Hunter — with real-time data bound to the live REST cockpit. Additive and scoped; does not modify the core tuanichat-platform plugin.
 * Version:           3.1.0
 * Author:            Lion Click Media
 * Requires at least: 5.8
 * Requires PHP:      7.2
 * Text Domain:       tnc-jarvis-v3
 *
 * HONESTY NOTE: This plugin renders the V3 interface and binds it to the real
 * tuanichat/v1 REST cockpit (/admin/cockpit, /admin/fleet, /admin/state).
 * Metrics whose data source is not yet ingesting (e.g. A.T.L.A.S. records
 * indexed, LinkedIn / SMS engines) are marked PENDING in the UI and are never
 * fed synthetic values. See DEPLOY_JARVIS_V3.md.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'TNC_JV3_VERSION', '3.1.0' );
define( 'TNC_JV3_DIR', plugin_dir_path( __FILE__ ) );
define( 'TNC_JV3_URL', plugin_dir_url( __FILE__ ) );
// REST namespace exposed by tuanichat-platform. Falls back to the known default.
if ( ! defined( 'TNC_REST_NS' ) ) {
	define( 'TNC_REST_NS', 'tuanichat/v1' );
}

/**
 * Surface registry — one definition drives the menu, routing and the active tab.
 */
function tnc_jv3_surfaces() {
	return array(
		'command'     => array( 'label' => 'Command',     'title' => 'J.A.R.V.I.S. Command Center', 'view' => 'command.php',     'accent' => 'arc' ),
		'lead-engine' => array( 'label' => 'Lead Engine', 'title' => 'Lead Engine — Settings',       'view' => 'lead-engine.php', 'accent' => 'plasma' ),
		'lead-hunter' => array( 'label' => 'Lead Hunter', 'title' => 'Lead Hunter — Workers',        'view' => 'lead-hunter.php', 'accent' => 'ion' ),
	);
}

/**
 * Admin menu: top-level J.A.R.V.I.S. + three submenus.
 */
add_action( 'admin_menu', function () {
	$cap = 'manage_options';
	add_menu_page(
		'J.A.R.V.I.S. V3', 'J.A.R.V.I.S.', $cap, 'tnc-jv3-command',
		function () { tnc_jv3_render( 'command' ); },
		'dashicons-superhero', 3
	);
	foreach ( tnc_jv3_surfaces() as $slug => $s ) {
		add_submenu_page(
			'tnc-jv3-command',
			$s['title'],
			$s['label'],
			$cap,
			'tnc-jv3-' . $slug,
			function () use ( $slug ) { tnc_jv3_render( $slug ); }
		);
	}
	// Rename the auto-created first submenu to "Command".
	global $submenu;
	if ( isset( $submenu['tnc-jv3-command'][0][0] ) ) {
		$submenu['tnc-jv3-command'][0][0] = 'Command';
	}
} );

/**
 * Enqueue the V3 assets ONLY on our own screens (no global footprint).
 */
add_action( 'admin_enqueue_scripts', function ( $hook ) {
	if ( false === strpos( (string) $hook, 'tnc-jv3-' ) ) {
		return;
	}
	$v = TNC_JV3_VERSION;
	wp_enqueue_style( 'tnc-v3-core', TNC_JV3_URL . 'assets/tuanichat-v3.css', array(), $v );
	wp_enqueue_style( 'tnc-v3-app', TNC_JV3_URL . 'assets/tnc-jarvis-app.css', array( 'tnc-v3-core' ), $v );
	wp_enqueue_script( 'tnc-v3-lib', TNC_JV3_URL . 'assets/tuanichat-v3.js', array(), $v, true );
	wp_enqueue_script( 'tnc-v3-live', TNC_JV3_URL . 'assets/tnc-jarvis-live.js', array( 'tnc-v3-lib' ), $v, true );

	// Google fonts used by the design system (graceful degrade if blocked).
	wp_enqueue_style( 'tnc-v3-fonts', 'https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@500;600&display=swap', array(), null );

	wp_localize_script( 'tnc-v3-live', 'TNC_JARVIS_V3', array(
		'rest'     => esc_url_raw( rest_url( TNC_REST_NS ) ),
		'nonce'    => wp_create_nonce( 'wp_rest' ),
		'interval' => 5000,
		'motion'   => 'auto',
		'version'  => $v,
	) );
} );

/**
 * Render a surface: shared shell (topbar + nav) + the view partial.
 */
function tnc_jv3_render( $active ) {
	$surfaces = tnc_jv3_surfaces();
	if ( ! isset( $surfaces[ $active ] ) ) {
		$active = 'command';
	}
	$view = TNC_JV3_DIR . 'views/' . $surfaces[ $active ]['view'];
	echo '<div class="wrap" style="margin:0;padding:0;max-width:none;">';
	echo '<div class="tc-v3 v3-preboot" data-v3-ambient="on">';
	tnc_jv3_topbar( $active, $surfaces );
	echo '<main class="v3-app">';
	if ( file_exists( $view ) ) {
		include $view;
	} else {
		echo '<p style="padding:24px;color:#b9cce2">View not found: ' . esc_html( $surfaces[ $active ]['view'] ) . '</p>';
	}
	echo '</main>';
	tnc_jv3_tabbar( $active );
	echo '</div></div>';
}

/**
 * Shared top command bar with surface navigation.
 */
function tnc_jv3_topbar( $active, $surfaces ) {
	?>
	<header class="v3-topbar v3-boot">
		<div class="v3-brand">
			<span class="v3-reactor-mark" aria-hidden="true"></span>
			<div>
				<div class="v3-brand-name">TUANICHAT <b>V3</b></div>
				<div class="v3-brand-sub">Arc Reactor · Jarvis Command</div>
			</div>
		</div>
		<nav class="v3-nav" aria-label="Surfaces">
			<?php foreach ( $surfaces as $slug => $s ) : ?>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=tnc-jv3-' . $slug ) ); ?>"
				   class="v3-acc-<?php echo esc_attr( $s['accent'] ); ?><?php echo $active === $slug ? ' is-active' : ''; ?>">
					<span class="v3-nav-dot"></span><?php echo esc_html( $s['label'] ); ?>
				</a>
			<?php endforeach; ?>
		</nav>
		<div class="v3-topbar-spacer"></div>
		<span class="v3-clock" data-v3-clock>--:--:--</span>
		<span class="v3-sys" data-v3-sys>CONNECTING…</span>
	</header>
	<?php
}

/**
 * Mobile bottom tab bar (mirrors the nav on small screens / PWA).
 */
function tnc_jv3_tabbar( $active ) {
	$tabs = tnc_jv3_surfaces();
	echo '<nav class="v3-tabbar" aria-label="Surfaces">';
	foreach ( $tabs as $slug => $s ) {
		printf(
			'<a href="%s" class="v3-acc-%s%s"><span class="v3-tab-ico"></span>%s</a>',
			esc_url( admin_url( 'admin.php?page=tnc-jv3-' . $slug ) ),
			esc_attr( $s['accent'] ),
			$active === $slug ? ' is-active' : '',
			esc_html( $s['label'] )
		);
	}
	echo '</nav>';
}
