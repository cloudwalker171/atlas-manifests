/**
 * TuaniChat thin-client demo widget (v1.5 — Lion Click launcher/teaser DNA + Intercom conversation DNA).
 * Modes: standard (greeting + starter chips) | advanced (persona header,
 * section title, guided choices, AI-disclosure attribution lines).
 * Talks only to the central TuaniChat proxy — no keys, no KB on the client.
 */
(function () {
  'use strict';
  var cfg = window.TNC_DEMO || {};
  var body = document.getElementById('tncBody');
  var input = document.getElementById('tncInput');
  var sendBtn = document.getElementById('tncSend');
  var startersEl = document.getElementById('tncStarters');
  var leadForm = document.getElementById('tncLead');
  var history = [];
  var busy = false;
  var advanced = cfg.mode === 'advanced';
  var btnStyle = cfg.btnStyle === 'solid' ? 'style-solid' : 'style-outline';
  var session = 's-' + Math.random().toString(36).slice(2, 12) + Date.now().toString(36);
  var choicesEl = null;
  var sectEl = null;

  function el(cls, text, parent) {
    var d = document.createElement('div');
    d.className = cls + ' fadein';
    d.textContent = text;
    (parent || body).appendChild(d);
    body.scrollTop = body.scrollHeight;
    return d;
  }

  function avatarEl() {
    var a = document.createElement('div');
    a.className = 'bav';
    if (cfg.avatar) {
      var i = document.createElement('img');
      i.src = cfg.avatar;
      i.alt = '';
      a.appendChild(i);
    } else {
      a.textContent = '\u2726';
    }
    return a;
  }

  function stamp() {
    try {
      return new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
    } catch (e) { return ''; }
  }

  function botMessage(text) {
    var row = document.createElement('div');
    row.className = 'brow fadein';
    row.appendChild(avatarEl());
    var wrap = document.createElement('div');
    wrap.className = 'msg bot';
    var txt = document.createElement('div');
    txt.textContent = text;
    wrap.appendChild(txt);
    // Per-message meta: 'minimal' (default) shows nothing under the bubble
    // (avatar carries identity); 'full' shows sender + AI-Agent + time; 'none' off.
    if (cfg.metaMode === 'full') {
      var attr = document.createElement('div');
      attr.className = advanced ? 'attr' : 'msg-meta';
      attr.textContent = (cfg.agentName || 'Assistant') + ' · AI Agent · ' + stamp();
      wrap.appendChild(attr);
    }
    row.appendChild(wrap);
    body.appendChild(row);
    // SCROLL UX: for a LONG reply, land at the TOP of the new message so the
    // client reads it from line 1 (not the end). Short messages: normal bottom.
    requestAnimationFrame(function () {
      if (row.offsetHeight > body.clientHeight - 44) {
        var br = body.getBoundingClientRect(), rr = row.getBoundingClientRect();
        body.scrollTop += (rr.top - br.top) - 10;
      } else {
        body.scrollTop = body.scrollHeight;
      }
    });
    return row;
  }

  /* Typing indicator: three brand-tinted bouncing dots (never plain text). */
  function typingBubble() {
    var row = document.createElement('div');
    row.className = 'brow fadein';
    row.appendChild(avatarEl());
    var b = document.createElement('div');
    b.className = 'msg bot typing';
    b.innerHTML = '<span class="tdots"><i></i><i></i><i></i></span>';
    row.appendChild(b);
    body.appendChild(row);
    body.scrollTop = body.scrollHeight;
    return row;
  }

  /* ---- Standard mode: starter chips under the thread ---- */
  function addStarters() {
    if (!startersEl || !cfg.starters || !cfg.starters.length) return;
    startersEl.classList.add(btnStyle);
    cfg.starters.forEach(function (q) {
      var b = document.createElement('button');
      b.type = 'button';
      b.textContent = q;
      b.addEventListener('click', function () {
        startersEl.style.display = 'none';
        send(q);
      });
      startersEl.appendChild(b);
    });
    addCtaChip(startersEl);
  }

  /* Accent CTA chip: the conversion driver, visually distinct from questions. */
  function addCtaChip(parent) {
    if (!cfg.ctaChip || !cfg.ctaChip.url) return;
    var b = document.createElement('button');
    b.type = 'button';
    b.className = 'chip-accent';
    b.textContent = cfg.ctaChip.label || 'Book a call';
    b.addEventListener('click', function () {
      window.open(cfg.ctaChip.url, '_blank', 'noopener');
    });
    parent.appendChild(b);
  }

  /* ---- Advanced mode: centered section title + guided choices ---- */
  function addChoices() {
    if (sectEl || !cfg.choices || !cfg.choices.length) return;
    sectEl = el('sect', cfg.sectionTitle || 'How can we help you?');
    choicesEl = document.createElement('div');
    choicesEl.className = 'choices ' + btnStyle + ' fadein';
    cfg.choices.forEach(function (q) {
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'choice';
      b.textContent = q;
      b.addEventListener('click', function () {
        hideChoices();
        send(q);
      });
      choicesEl.appendChild(b);
    });
    addCtaChip(choicesEl);
    body.appendChild(choicesEl);
    body.scrollTop = body.scrollHeight;
  }

  function hideChoices() {
    if (sectEl) { sectEl.remove(); sectEl = null; }
    if (choicesEl) { choicesEl.remove(); choicesEl = null; }
  }

  function showChoicesAgain() {
    if (busy || sectEl) return;
    addChoices();
  }

  function send(text) {
    text = (text || '').trim();
    if (!text || busy) return;
    busy = true;
    sendBtn.disabled = true;
    if (advanced) hideChoices();
    el('msg user', text);
    if (cfg.metaMode === 'full') { el('umeta', 'You · ' + stamp()); }
    history.push({ role: 'user', content: text });
    var typing = typingBubble();

    fetch(cfg.rest + '/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        slug: cfg.slug,
        token: cfg.token,
        session: session,
        messages: history.slice(-12)
      })
    })
      .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, j: j }; }); })
      .then(function (res) {
        typing.remove();
        if (res.ok && res.j && res.j.reply) {
          botMessage(res.j.reply);
          history.push({ role: 'assistant', content: res.j.reply });
        } else {
          var msg = (res.j && res.j.message) ? res.j.message : 'Sorry — something went wrong. Please try again.';
          botMessage(msg);
        }
      })
      .catch(function () {
        typing.remove();
        botMessage('Sorry — connection issue. Please try again.');
      })
      .finally(function () {
        busy = false;
        sendBtn.disabled = false;
        input.focus();
      });
  }

  if (sendBtn) {
    sendBtn.addEventListener('click', function () {
      var v = input.value;
      input.value = '';
      send(v);
    });
  }
  if (input) {
    input.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') {
        e.preventDefault();
        var v = input.value;
        input.value = '';
        send(v);
      }
    });
  }

  // Launcher / panel (v1.4 site-preview demo): chat opens from the floating launcher.
  var launcher = document.getElementById('tncLaunch');
  var panel = document.getElementById('tncPanel');
  var initialized = false;

  function initOpening() {
    if (initialized) return;
    initialized = true;
    if (advanced) {
      if (startersEl) startersEl.style.display = 'none';
      addChoices();
    } else if (cfg.greeting) {
      botMessage(cfg.greeting);
      history.push({ role: 'assistant', content: cfg.greeting });
      addStarters();
    }
  }
  function openPanel() {
    if (panel) panel.classList.add('open');
    if (launcher) launcher.classList.add('hide');
    initOpening();
    if (input) setTimeout(function () { input.focus(); }, 250);
  }
  function closePanel() {
    if (panel) panel.classList.remove('open');
    if (launcher) launcher.classList.remove('hide');
  }
  if (launcher) launcher.addEventListener('click', function () { hideTeaser(); openPanel(); });

  /* OPEN MODES (client-toggleable):
     'popup'  — Intercom-style: panel opens on load showing greeting + starters.
     'bubble' — launcher + greeting teaser only; never auto-opens.
     ''       — legacy: pulsing launcher + teaser, auto-open after the delay. */
  var teaser = null;
  function showTeaser() {
    if (teaser || !launcher || !cfg.greeting) return;
    if (panel && panel.classList.contains('open')) return;
    var dKey = 'tnc_teaser_' + (cfg.slug || '');
    try { if (window.sessionStorage.getItem(dKey)) return; } catch (e) {}
    teaser = document.createElement('div');
    teaser.className = 'tnc-teaser';
    var snip = String(cfg.greeting);
    teaser.textContent = snip.length > 150 ? snip.slice(0, 147) + '…' : snip;
    var x = document.createElement('button');
    x.className = 'tx-close';
    x.type = 'button';
    x.setAttribute('aria-label', 'Dismiss');
    x.textContent = '×';
    x.addEventListener('click', function (e) {
      e.stopPropagation();
      try { window.sessionStorage.setItem(dKey, '1'); } catch (er) {}
      hideTeaser();
    });
    teaser.appendChild(x);
    teaser.addEventListener('click', doOpen);
    launcher.parentNode.appendChild(teaser);
    requestAnimationFrame(function () { requestAnimationFrame(function () { if (teaser) teaser.classList.add('show'); }); });
  }
  function hideTeaser() {
    if (!teaser) return;
    teaser.classList.remove('show');
    var t = teaser;
    teaser = null;
    setTimeout(function () { if (t.parentNode) t.parentNode.removeChild(t); }, 350);
  }
  function doOpen() { hideTeaser(); openPanel(); }

  if (launcher && panel) {
    if (cfg.openMode === 'popup') {
      // INITIAL POPUP: open immediately with greeting + starter buttons visible.
      setTimeout(doOpen, 350);
    } else {
      setTimeout(showTeaser, 1400);
      if (cfg.openMode !== 'bubble') {
        var autoKey = 'tnc_auto_' + (cfg.slug || '');
        var seen = false;
        var delayMs = Math.max(3, Math.min(10, parseInt(cfg.autoOpen, 10) || 6)) * 1000;
        try { seen = !!window.sessionStorage.getItem(autoKey); } catch (e) {}
        if (!seen) {
          setTimeout(function () {
            try { window.sessionStorage.setItem(autoKey, '1'); } catch (e) {}
            if (!panel.classList.contains('open')) doOpen();
          }, delayMs);
        }
      }
    }
  }

  // Advanced header controls: back re-opens the guided choices; close minimizes to the launcher.
  var backBtn = document.getElementById('tncBack');
  if (backBtn) backBtn.addEventListener('click', showChoicesAgain);
  var closeBtn = document.getElementById('tncCloseBtn');
  if (closeBtn) closeBtn.addEventListener('click', closePanel);

  if (leadForm) {
    leadForm.addEventListener('submit', function (e) {
      e.preventDefault();
      var out = document.getElementById('tncLOut');
      var name = document.getElementById('tncLName').value.trim();
      var email = document.getElementById('tncLEmail').value.trim();
      var phone = document.getElementById('tncLPhone').value.trim();
      var msg = document.getElementById('tncLMsg').value.trim();
      if (!name && !email && !phone) {
        out.innerHTML = '<div class="err">Please add your name and a way to reach you.</div>';
        return;
      }
      fetch(cfg.rest + '/lead', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ slug: cfg.slug, token: cfg.token, name: name, email: email, phone: phone, message: msg })
      })
        .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, j: j }; }); })
        .then(function (res) {
          if (res.ok && res.j && res.j.ok) {
            leadForm.querySelectorAll('input,textarea,button').forEach(function (n) { n.disabled = true; });
            out.innerHTML = '<div class="ok">✓ Thanks! We received your details and will reach out shortly.</div>';
          } else {
            out.innerHTML = '<div class="err">' + ((res.j && res.j.message) || 'Could not submit — try again.') + '</div>';
          }
        })
        .catch(function () {
          out.innerHTML = '<div class="err">Connection issue — please try again.</div>';
        });
    });
  }

  /* ---- GUARANTEED CANVAS (P0): the branded mock (CSS z-index 1) is the PERMANENT
     floor and is NEVER hidden by JS. The cached screenshot (z2) and a verified
     iframe (z3) only OVERLAY it once they truly paint at full size. If both fail,
     the mock simply remains — the canvas is never blank or broken. ---- */
  (function () {
    var frame = document.getElementById('tncFrame');
    var shot = document.getElementById('tncShot');
    function showShot(src, w, h) {
      if (!shot) return false;
      if (w >= 600 && h >= 300) { shot.src = src; shot.style.display = 'block'; return true; }
      return false;
    }
    // 1) Cached screenshot present? Only reveal it after verifying it's a real image.
    var cached = shot && shot.getAttribute('src');
    if (cached) {
      if (shot.complete && shot.naturalWidth) {
        if (!showShot(cached, shot.naturalWidth, shot.naturalHeight)) { shot.removeAttribute('src'); cached = ''; }
      } else {
        shot.onload = function () { if (!showShot(cached, shot.naturalWidth, shot.naturalHeight)) { shot.style.display = 'none'; } };
        shot.onerror = function () { shot.style.display = 'none'; }; // mock floor stays.
      }
    }
    // 2) No good cached shot -> probe a live mShots render in the background (hard
    //    ceiling); swap in ONLY when a real full-size image arrives. Never blocks.
    if (!cached && cfg.shotAsync && shot) {
      var done = false, deadline = Date.now() + 12000;
      var tryOnce = function () {
        if (done || Date.now() > deadline) return;
        var p = new Image();
        p.onload = function () {
          if (done) return;
          if (p.naturalWidth >= 900 && p.naturalHeight >= 400) { done = true; showShot(p.src, p.naturalWidth, p.naturalHeight); }
          else { setTimeout(tryOnce, 3500); }
        };
        p.onerror = function () { if (!done) setTimeout(tryOnce, 3500); };
        p.src = cfg.shotAsync + '&cb=' + Date.now();
      };
      setTimeout(tryOnce, 1500);
    }
    // 3) Iframe only overlays if it genuinely paints within 6s (framable verified).
    //    A blocked/lying X-Frame site never fires a real load -> stays hidden, mock shows.
    if (frame) {
      var painted = false;
      frame.addEventListener('load', function () { painted = true; frame.style.display = 'block'; });
      setTimeout(function () { if (!painted) { frame.style.display = 'none'; } }, 6000);
    }
  })();

  /* ---- ROI calculator  /* ---- ROI calculator: industry economics, live sliders, pulsating annual hero ---- */
  var roiWrap = document.getElementById('tncRoi');
  if (roiWrap && cfg.roi) {
    var rVis = document.getElementById('roiVis');
    var rDeal = document.getElementById('roiDeal');
    var rClose = document.getElementById('roiClose');
    var rMo = document.getElementById('roiMo');
    var rYr = document.getElementById('roiYr');
    var reduced = false;
    try { reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (e) {}
    var fmt = function (n) {
      n = Math.round(n);
      return '$' + String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    };
    var curYr = 0, anim = null;
    var setFill = function (el) {
      var pct = ((el.value - el.min) / (el.max - el.min)) * 100;
      el.style.setProperty('--fill', pct + '%');
    };
    var paint = function (yr, mo) {
      rMo.textContent = fmt(mo);
      if (reduced) { rYr.textContent = fmt(yr); curYr = yr; return; }
      if (anim) clearInterval(anim);
      var from = curYr, steps = 16, i = 0;
      anim = setInterval(function () {
        i++;
        var v = i >= steps ? yr : from + (yr - from) * (i / steps);
        rYr.textContent = fmt(v);
        if (i >= steps) { clearInterval(anim); curYr = yr; }
      }, 28);
    };
    var calc = function () {
      var V = parseInt(rVis.value, 10) || 0;
      var D = parseInt(rDeal.value, 10) || 0;
      var C = (parseInt(rClose.value, 10) || 0) / 100;
      // ~3% of visitors have intent; ~35% of inquiries go unanswered today; assistant captures ~60% of those.
      var extraLeads = V * 0.03 * 0.35 * 0.6;
      var mo = extraLeads * C * D;
      document.getElementById('roiVisVal').textContent = String(V).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
      document.getElementById('roiDealVal').textContent = fmt(D);
      document.getElementById('roiCloseVal').textContent = rClose.value + '%';
      [rVis, rDeal, rClose].forEach(setFill);
      paint(mo * 12, mo);
    };
    [rVis, rDeal, rClose].forEach(function (el) {
      el.addEventListener('input', calc);
    });
    calc();
  }

  /* ---- Opening state ---- */
  if (body && !launcher) {
    // No launcher on the page (legacy layout) — initialize immediately.
    initOpening();
  }
})();
