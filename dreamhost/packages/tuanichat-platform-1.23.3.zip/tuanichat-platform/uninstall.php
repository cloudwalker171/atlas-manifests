<?php
/**
 * Uninstall — SAFE BY DEFAULT.
 * Deleting a plugin copy (including old duplicates during update swaps) must
 * NEVER wipe live configuration. Historical bug: this file unconditionally
 * deleted tnc_settings, erasing the API key on every update-swap delete.
 * A real purge now requires the explicit opt-in option below.
 */
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}
if ( get_option( 'tnc_allow_uninstall_purge' ) ) {
	delete_option( 'tnc_settings' );
	delete_option( 'tnc_settings_backup' );
	delete_option( 'tnc_db_version' );
	delete_option( 'tnc_demo_secret' );
	delete_option( 'tnc_worker_secret' );
	delete_option( 'tnc_allow_uninstall_purge' );
}
// Tables and all options are otherwise preserved — prospect data and keys are valuable.
