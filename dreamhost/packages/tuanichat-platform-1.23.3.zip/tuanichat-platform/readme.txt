=== TuaniChat Platform ===
Contributors: tuanilabs
Requires at least: 6.4
Tested up to: 7.0
Requires PHP: 8.1
Stable tag: 1.0.0
License: Proprietary

AI Intake Assistant platform by TuaniLabs LLC — the central brain.

== Description ==
Phase 1 "Demo Builder":
* Prospect manager (CRUD, statuses, scoring)
* Platform-aware crawler (WordPress / Shopify / generic) with SSRF guard
* Chunked knowledge base with BM25-style retrieval, Q&A pairs, supplemental text & .txt upload
* Central chat proxy (Anthropic; server-side key; rate-limited REST)
* Private demo pages at /demo/{slug} with industry theme presets, website audit panel & lead capture
* AI outreach kit generator (cold email, follow-up, LinkedIn, audit) + 0-100 prospect score

== Installation ==
1. Upload and activate the plugin.
2. Go to TuaniChat → Settings and paste your Anthropic API key.
3. Add a prospect (TuaniChat → Prospects), click "Crawl Website".
4. Open the demo link and send it to the prospect.

Note: visiting Settings → Permalinks once after activation refreshes rewrite rules if /demo/ URLs 404 (activation already flushes them).

== Changelog ==
= 1.0.0 =
* Phase 1 release.
