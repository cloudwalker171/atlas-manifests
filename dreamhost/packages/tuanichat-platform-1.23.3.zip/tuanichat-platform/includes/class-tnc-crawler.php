<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Platform-aware polite crawler with SSRF guard.
 * Supports crawl profiles: demo (sync, small) and full (batched via TNC_Crawl_Jobs).
 */
class TNC_Crawler {

	const UA = 'TuaniChatBot/1.0 (+https://tuanilabs.com; site analysis for demo)';

	private $base_host    = '';
	private $base_scheme  = 'https';
	private $timeout      = 10;
	private $errors       = array();
	private $fetched      = array();
	private $home_framable = true;
	private $js_blob       = '';

	public function __construct() {
		$this->timeout = (int) TNC_Settings::get( 'crawl_timeout', 10 );
	}

	/**
	 * Discovery phase: homepage, platform, prioritized URL queue.
	 * Returns: platform, home_url, home_record, home_html, queue (capped, priority-ordered), total_discovered.
	 */
	public function prepare( $url, $cap ) {
		$this->errors  = array();
		$this->fetched = array();

		$url = $this->normalize_start_url( $url );
		if ( is_wp_error( $url ) ) {
			return $url;
		}
		$parts             = wp_parse_url( $url );
		$this->base_host   = strtolower( $parts['host'] );
		$this->base_scheme = isset( $parts['scheme'] ) ? $parts['scheme'] : 'https';

		$home = $this->fetch( $url );
		if ( is_wp_error( $home ) ) {
			return new WP_Error( 'tnc_crawl', 'Could not fetch the homepage: ' . $home->get_error_message() );
		}
		$home_html = $home['body'];
		$platform  = $this->detect_platform( $home_html, $url );

		// Frame test for the site-preview demo: X-Frame-Options / CSP frame-ancestors.
		$this->home_framable = true;
		$headers = isset( $home['headers'] ) ? $home['headers'] : null;
		if ( $headers ) {
			$xfo = is_object( $headers ) || is_array( $headers ) ? ( isset( $headers['x-frame-options'] ) ? $headers['x-frame-options'] : '' ) : '';
			$csp = is_object( $headers ) || is_array( $headers ) ? ( isset( $headers['content-security-policy'] ) ? $headers['content-security-policy'] : '' ) : '';
			$xfo = is_array( $xfo ) ? implode( ' ', $xfo ) : (string) $xfo;
			$csp = is_array( $csp ) ? implode( ' ', $csp ) : (string) $csp;
			if ( preg_match( '/deny|sameorigin/i', $xfo ) || false !== stripos( $csp, 'frame-ancestors' ) ) {
				$this->home_framable = false;
			}
		}

		// Detection v5: sample linked JS (same-host + CDN + tag managers) and
		// resolve GTM containers so tag-manager-injected chat widgets (the classic
		// false-negative, e.g. Dolman) are visible to the code detector.
		$this->js_blob = $this->sample_js( $home_html, $url );

		$queue = array();
		foreach ( $this->sitemap_urls( $url, $cap ) as $u ) {
			$queue[ $u ] = 1;
		}
		if ( 'wordpress' === $platform ) {
			foreach ( $this->wp_api_urls( $url ) as $u ) {
				$queue[ $u ] = 1;
			}
		}
		if ( 'shopify' === $platform ) {
			foreach ( $this->shopify_urls( $url ) as $u ) {
				$queue[ $u ] = 1;
			}
		}
		foreach ( $this->extract_links( $home_html, $url ) as $u ) {
			if ( ! isset( $queue[ $u ] ) ) {
				$queue[ $u ] = 1;
			}
		}
		unset( $queue[ $url ] );

		$total_discovered = count( $queue ) + 1;
		$queue            = $this->prioritize( $queue );
		$queue_all        = array_keys( $queue );
		$queue            = array_slice( $queue_all, 0, max( 0, $cap - 1 ) );

		return array(
			'platform'         => $platform,
			'home_url'         => $url,
			'home_record'      => $this->page_record( $url, $home_html ),
			'home_html'        => substr( $home_html, 0, 250000 ),
			'queue'            => $queue,
			'queue_all'        => array_slice( $queue_all, 0, 1000 ),
			'total_discovered' => $total_discovered,
			'framable'         => $this->home_framable,
		);
	}

	/** Fetch + parse a single page (public, used by the batch engine). */
	public function fetch_page( $url ) {
		$res = $this->fetch( $url );
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		return $this->page_record( $url, $res['body'] );
	}

	/** Build the final crawl result array from accumulated pages. */
	public function assemble( $pages, $home_html, $platform, $errors, $framable = null ) {
		$extracted             = $this->extract_business_data( $pages, $home_html, $platform );
		$extracted['framable'] = null === $framable ? $this->home_framable : (bool) $framable;
		// Real-homepage screenshot for the demo canvas (free WP.com mShots renderer).
		$home_url = '';
		foreach ( $pages as $u => $r ) { $home_url = $u; break; }
		if ( $home_url ) {
			$extracted['screenshot'] = 'https://s0.wp.com/mshots/v1/' . rawurlencode( $home_url ) . '?w=1280&h=900';
			wp_remote_get( $extracted['screenshot'], array( 'timeout' => 0.01, 'blocking' => false ) ); // warm the render now.
		} else {
			$extracted['screenshot'] = '';
		}
		return array(
			'platform'   => $platform,
			'pages'      => $pages,
			'extracted'  => $extracted,
			'products'   => $this->extract_products( $home_url, $platform, $pages ),
			'errors'     => $errors,
			'crawled_at' => current_time( 'mysql' ),
			'page_count' => count( $pages ),
		);
	}

	/**
	 * PRODUCT CATALOG EXTRACTION (product-aware KB): structured products with
	 * names, specs/attributes and PRICING — the only source product answers may
	 * quote from. Sources: Shopify products.json, WooCommerce Store API,
	 * JSON-LD Product schema on crawled pages. Cap 120.
	 */
	public function extract_products( $base_url, $platform, $pages = array() ) {
		$base     = untrailingslashit( (string) $base_url );
		$products = array();
		$push     = function ( $prod ) use ( &$products ) {
			if ( empty( $prod['name'] ) || count( $products ) >= 120 ) {
				return;
			}
			$key = strtolower( trim( $prod['name'] ) );
			foreach ( $products as $existing ) {
				if ( strtolower( trim( $existing['name'] ) ) === $key ) {
					return;
				}
			}
			$products[] = $prod;
		};

		if ( 'shopify' === $platform && $base ) {
			for ( $pg = 1; $pg <= 2; $pg++ ) {
				$r = $this->fetch( $base . '/products.json?limit=100&page=' . $pg, true );
				if ( is_wp_error( $r ) ) {
					break;
				}
				$j = json_decode( $r['body'], true );
				if ( empty( $j['products'] ) || ! is_array( $j['products'] ) ) {
					break;
				}
				foreach ( $j['products'] as $sp ) {
					$variants = array();
					$price    = '';
					$compare  = '';
					$sku      = '';
					foreach ( array_slice( isset( $sp['variants'] ) ? $sp['variants'] : array(), 0, 8 ) as $v ) {
						if ( '' === $price && isset( $v['price'] ) ) {
							$price   = (string) $v['price'];
							$compare = isset( $v['compare_at_price'] ) ? (string) $v['compare_at_price'] : '';
							$sku     = isset( $v['sku'] ) ? (string) $v['sku'] : '';
						}
						if ( isset( $v['title'], $v['price'] ) && 'Default Title' !== $v['title'] ) {
							$variants[] = $v['title'] . ' @ $' . $v['price'];
						}
					}
					$opts = array();
					foreach ( isset( $sp['options'] ) ? $sp['options'] : array() as $o ) {
						if ( ! empty( $o['name'] ) && ! empty( $o['values'] ) && 'Title' !== $o['name'] ) {
							$opts[] = $o['name'] . ': ' . implode( ', ', array_slice( (array) $o['values'], 0, 10 ) );
						}
					}
					$push( array(
						'name'     => isset( $sp['title'] ) ? $sp['title'] : '',
						'price'    => $price,
						'compare'  => $compare && $compare !== $price ? $compare : '',
						'sku'      => $sku,
						'type'     => isset( $sp['product_type'] ) ? $sp['product_type'] : '',
						'vendor'   => isset( $sp['vendor'] ) ? $sp['vendor'] : '',
						'variants' => $variants,
						'specs'    => $opts,
						'desc'     => mb_substr( trim( wp_strip_all_tags( isset( $sp['body_html'] ) ? $sp['body_html'] : '' ) ), 0, 400 ),
						'url'      => $base . '/products/' . ( isset( $sp['handle'] ) ? $sp['handle'] : '' ),
						'source'   => 'shopify_products_json',
					) );
				}
				if ( count( $j['products'] ) < 100 ) {
					break;
				}
			}
		}

		if ( ! $products && 'wordpress' === $platform && $base ) {
			$r = $this->fetch( $base . '/wp-json/wc/store/v1/products?per_page=100', true );
			if ( ! is_wp_error( $r ) ) {
				$j = json_decode( $r['body'], true );
				if ( is_array( $j ) && isset( $j[0]['name'] ) ) {
					foreach ( $j as $wp ) {
						$minor = isset( $wp['prices']['currency_minor_unit'] ) ? (int) $wp['prices']['currency_minor_unit'] : 2;
						$div   = pow( 10, $minor );
						$price = isset( $wp['prices']['price'] ) ? number_format( ( (int) $wp['prices']['price'] ) / $div, $minor, '.', '' ) : '';
						$attrs = array();
						foreach ( isset( $wp['attributes'] ) ? $wp['attributes'] : array() as $a ) {
							if ( ! empty( $a['name'] ) && ! empty( $a['terms'] ) ) {
								$vals = array();
								foreach ( array_slice( (array) $a['terms'], 0, 10 ) as $t ) {
									$vals[] = isset( $t['name'] ) ? $t['name'] : '';
								}
								$attrs[] = $a['name'] . ': ' . implode( ', ', array_filter( $vals ) );
							}
						}
						$push( array(
							'name'     => $wp['name'],
							'price'    => $price,
							'compare'  => '',
							'sku'      => isset( $wp['sku'] ) ? (string) $wp['sku'] : '',
							'type'     => '',
							'vendor'   => '',
							'variants' => array(),
							'specs'    => $attrs,
							'desc'     => mb_substr( trim( wp_strip_all_tags( isset( $wp['short_description'] ) ? $wp['short_description'] : '' ) ), 0, 400 ),
							'url'      => isset( $wp['permalink'] ) ? $wp['permalink'] : '',
							'source'   => 'woocommerce_store_api',
						) );
					}
				}
			}
		}

		// JSON-LD Product schema fallback from crawled pages (any platform).
		if ( ! $products && $pages ) {
			foreach ( $pages as $purl => $page ) {
				$html = isset( $page['html'] ) ? $page['html'] : '';
				if ( ! $html || ! preg_match_all( '#<script[^>]*type=["\']application/ld\\+json["\'][^>]*>(.*?)</script>#is', $html, $lm ) ) {
					continue;
				}
				foreach ( $lm[1] as $blob ) {
					$j = json_decode( trim( $blob ), true );
					$items = array();
					if ( isset( $j['@type'] ) && 'Product' === $j['@type'] ) {
						$items[] = $j;
					} elseif ( isset( $j['@graph'] ) && is_array( $j['@graph'] ) ) {
						foreach ( $j['@graph'] as $g ) {
							if ( isset( $g['@type'] ) && 'Product' === $g['@type'] ) {
								$items[] = $g;
							}
						}
					}
					foreach ( $items as $it ) {
						$offer = isset( $it['offers'] ) ? ( isset( $it['offers'][0] ) ? $it['offers'][0] : $it['offers'] ) : array();
						$push( array(
							'name'     => isset( $it['name'] ) ? $it['name'] : '',
							'price'    => isset( $offer['price'] ) ? (string) $offer['price'] : '',
							'compare'  => '',
							'sku'      => isset( $it['sku'] ) ? (string) $it['sku'] : '',
							'type'     => '',
							'vendor'   => isset( $it['brand']['name'] ) ? $it['brand']['name'] : '',
							'variants' => array(),
							'specs'    => array(),
							'desc'     => mb_substr( trim( wp_strip_all_tags( isset( $it['description'] ) ? $it['description'] : '' ) ), 0, 400 ),
							'url'      => $purl,
							'source'   => 'jsonld_product',
						) );
					}
				}
			}
		}
		return $products;
	}

	/**
	 * Parallel fetch via curl_multi: waves sized by crawl_concurrency, with a
	 * per-host politeness cap. SSRF-guarded per URL. Sequential fallback when
	 * curl_multi is unavailable. Returns url => array('body'=>...) | WP_Error.
	 */
	private function fetch_many( $urls ) {
		$out  = array();
		$todo = array();
		foreach ( array_values( array_unique( $urls ) ) as $u ) {
			if ( isset( $this->fetched[ $u ] ) ) {
				continue;
			}
			if ( ! self::is_safe_url( $u ) ) {
				$out[ $u ] = new WP_Error( 'tnc_blocked', 'Blocked unsafe URL.' );
				$this->fetched[ $u ] = true;
				continue;
			}
			$this->fetched[ $u ] = true;
			$todo[] = $u;
		}
		if ( empty( $todo ) ) {
			return $out;
		}
		if ( ! function_exists( 'curl_multi_init' ) ) {
			foreach ( $todo as $u ) {
				unset( $this->fetched[ $u ] ); // fetch() re-marks it.
				$out[ $u ] = $this->fetch( $u );
				usleep( 250000 );
			}
			return $out;
		}

		$conc     = max( 2, min( 8, (int) TNC_Settings::get( 'crawl_concurrency', 6 ) ) );
		$per_host = max( 1, min( 4, (int) TNC_Settings::get( 'crawl_per_host', 3 ) ) );

		// Shared-host deadlock guard: if the target resolves to OUR server,
		// parallel requests would starve our own PHP pool. Go single-file.
		$own_host = (string) wp_parse_url( home_url(), PHP_URL_HOST );
		$own_ip   = $own_host ? gethostbyname( $own_host ) : '';
		$tgt_ip   = gethostbyname( $this->base_host );
		if ( $own_ip && $tgt_ip && $own_ip === $tgt_ip ) {
			$per_host = 1;
			$conc     = 1;
		}

		$by_host = array();
		foreach ( $todo as $u ) {
			$h = strtolower( (string) wp_parse_url( $u, PHP_URL_HOST ) );
			$by_host[ $h ][] = $u;
		}

		$waves = array();
		while ( ! empty( $by_host ) ) {
			$wave = array();
			foreach ( array_keys( $by_host ) as $h ) {
				foreach ( array_splice( $by_host[ $h ], 0, $per_host ) as $u ) {
					$wave[] = $u;
				}
				if ( empty( $by_host[ $h ] ) ) {
					unset( $by_host[ $h ] );
				}
			}
			foreach ( array_chunk( $wave, $conc ) as $chunk ) {
				$waves[] = $chunk;
			}
		}

		foreach ( $waves as $wave ) {
			$mh      = curl_multi_init();
			$handles = array();
			foreach ( $wave as $u ) {
				$ch = curl_init();
				curl_setopt_array( $ch, array(
					CURLOPT_URL             => $u,
					CURLOPT_RETURNTRANSFER  => true,
					CURLOPT_FOLLOWLOCATION  => true,
					CURLOPT_MAXREDIRS       => 3,
					CURLOPT_CONNECTTIMEOUT  => 6,
					CURLOPT_TIMEOUT         => max( 3, $this->timeout ),
					CURLOPT_USERAGENT       => self::UA,
					CURLOPT_HTTPHEADER      => array( 'Accept: text/html,application/xhtml+xml,application/xml,application/json' ),
					CURLOPT_PROTOCOLS       => CURLPROTO_HTTP | CURLPROTO_HTTPS,
					CURLOPT_REDIR_PROTOCOLS => CURLPROTO_HTTP | CURLPROTO_HTTPS,
					CURLOPT_SSL_VERIFYPEER  => true,
					CURLOPT_ENCODING        => '',
				) );
				curl_multi_add_handle( $mh, $ch );
				$handles[ $u ] = $ch;
			}
			do {
				$status = curl_multi_exec( $mh, $running );
				if ( $running ) {
					curl_multi_select( $mh, 0.4 );
				}
			} while ( $running && CURLM_OK === $status );

			foreach ( $handles as $u => $ch ) {
				$body = curl_multi_getcontent( $ch );
				$code = (int) curl_getinfo( $ch, CURLINFO_RESPONSE_CODE );
				$err  = curl_error( $ch );
				curl_multi_remove_handle( $mh, $ch );
				curl_close( $ch );
				if ( '' !== $err && '' === (string) $body ) {
					$out[ $u ] = new WP_Error( 'tnc_curl', $err );
				} elseif ( $code < 200 || $code >= 400 ) {
					$out[ $u ] = new WP_Error( 'tnc_http', 'HTTP ' . $code );
				} else {
					$out[ $u ] = array( 'body' => substr( (string) $body, 0, 2 * MB_IN_BYTES ) );
				}
			}
			curl_multi_close( $mh );
			usleep( 150000 ); // brief breath between waves — stay polite.
		}
		return $out;
	}

	/**
	 * Synchronous crawl (demo profile). $profile: demo|full — full should
	 * normally go through TNC_Crawl_Jobs::enqueue() instead.
	 */
	public function crawl( $url, $profile = 'demo' ) {
		$cap  = TNC_Crawl_Jobs::cap_for_profile( $profile );
		$prep = $this->prepare( $url, $cap );
		if ( is_wp_error( $prep ) ) {
			return $prep;
		}

		$pages        = array( $prep['home_url'] => $prep['home_record'] );
		$depth2_links = array();

		// Depth-1: parallel waves over the prioritized queue.
		$results = $this->fetch_many( array_slice( $prep['queue'], 0, max( 0, $cap - count( $pages ) ) ) );
		foreach ( $results as $u => $res ) {
			if ( is_wp_error( $res ) ) {
				$this->errors[] = array( 'url' => $u, 'error' => $res->get_error_message() );
				continue;
			}
			if ( count( $pages ) < $cap ) {
				$pages[ $u ] = $this->page_record( $u, $res['body'] );
				foreach ( $this->extract_links( $res['body'], $u ) as $link ) {
					if ( ! isset( $pages[ $link ] ) && ! isset( $this->fetched[ $link ] ) ) {
						$depth2_links[ $link ] = 2;
					}
				}
			}
		}

		// Depth-2 follow-up within budget, also parallel.
		if ( count( $pages ) < $cap && $depth2_links ) {
			$depth2_links = array_keys( $this->prioritize( $depth2_links ) );
			$results2     = $this->fetch_many( array_slice( $depth2_links, 0, $cap - count( $pages ) ) );
			foreach ( $results2 as $u => $res ) {
				if ( is_wp_error( $res ) ) {
					$this->errors[] = array( 'url' => $u, 'error' => $res->get_error_message() );
					continue;
				}
				if ( count( $pages ) < $cap ) {
					$pages[ $u ] = $this->page_record( $u, $res['body'] );
				}
			}
		}

		return $this->assemble( $pages, $prep['home_html'], $prep['platform'], $this->errors, $prep['framable'] );
	}

	/* ---------- URL safety (SSRF guard) ---------- */

	public static function is_safe_url( $url ) {
		$parts = wp_parse_url( $url );
		if ( empty( $parts['host'] ) || empty( $parts['scheme'] ) ) {
			return false;
		}
		if ( ! in_array( strtolower( $parts['scheme'] ), array( 'http', 'https' ), true ) ) {
			return false;
		}
		if ( isset( $parts['port'] ) && ! in_array( (int) $parts['port'], array( 80, 443 ), true ) ) {
			return false;
		}
		$host = strtolower( $parts['host'] );
		if ( 'localhost' === $host || '' === $host ) {
			return false;
		}
		$ips = array();
		if ( filter_var( $host, FILTER_VALIDATE_IP ) ) {
			$ips[] = $host;
		} else {
			$records = @dns_get_record( $host, DNS_A );
			if ( is_array( $records ) ) {
				foreach ( $records as $r ) {
					if ( ! empty( $r['ip'] ) ) {
						$ips[] = $r['ip'];
					}
				}
			}
			if ( empty( $ips ) ) {
				$resolved = gethostbyname( $host );
				if ( $resolved !== $host ) {
					$ips[] = $resolved;
				}
			}
		}
		if ( empty( $ips ) ) {
			return false;
		}
		foreach ( $ips as $ip ) {
			if ( false === filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) ) {
				return false;
			}
		}
		return true;
	}

	private function normalize_start_url( $url ) {
		$url = trim( (string) $url );
		if ( '' === $url ) {
			return new WP_Error( 'tnc_url', 'No URL provided.' );
		}
		if ( ! preg_match( '#^https?://#i', $url ) ) {
			$url = 'https://' . $url;
		}
		$url = esc_url_raw( $url );
		if ( ! self::is_safe_url( $url ) ) {
			return new WP_Error( 'tnc_url', 'URL is not allowed (private, local, or unresolvable host).' );
		}
		return untrailingslashit( $url ) . '/';
	}

	private function fetch( $url, $as_json = false ) {
		if ( ! self::is_safe_url( $url ) ) {
			return new WP_Error( 'tnc_blocked', 'Blocked unsafe URL.' );
		}
		if ( isset( $this->fetched[ $url ] ) ) {
			return new WP_Error( 'tnc_dup', 'Already fetched.' );
		}
		$this->fetched[ $url ] = true;
		$res = wp_remote_get( $url, array(
			'timeout'             => $this->timeout,
			'redirection'         => 3,
			'user-agent'          => self::UA,
			'limit_response_size' => 2 * MB_IN_BYTES,
			'headers'             => array( 'Accept' => $as_json ? 'application/json' : 'text/html,application/xhtml+xml,application/xml' ),
		) );
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		$code = wp_remote_retrieve_response_code( $res );
		if ( $code < 200 || $code >= 400 ) {
			return new WP_Error( 'tnc_http', 'HTTP ' . $code );
		}
		return array(
			'body'    => wp_remote_retrieve_body( $res ),
			'headers' => wp_remote_retrieve_headers( $res ),
		);
	}

	/* ---------- Platform detection ---------- */

	/**
	 * Commerce attribute (multi-signal): WooCommerce is GENUINELY active only
	 * when at least TWO independent signals agree — active woo assets, cart/
	 * checkout endpoints, product schema. A stray stylesheet never counts.
	 */
	public static function detect_commerce( $html ) {
		$h       = strtolower( $html );
		$signals = 0;
		if ( preg_match( '#/plugins/woocommerce/.+\.(css|js)#', $h ) ) { $signals++; } // active plugin assets.
		if ( false !== strpos( $h, 'wc-ajax' ) || false !== strpos( $h, 'wc_cart_fragments' ) || false !== strpos( $h, 'add-to-cart' ) ) { $signals++; } // cart machinery.
		if ( false !== strpos( $h, '"@type":"product"' ) || false !== strpos( $h, "'@type':'product'" ) || false !== strpos( $h, 'woocommerce-product' ) ) { $signals++; } // product schema/markup.
		return $signals >= 2 ? 'woocommerce' : '';
	}

	/** Light platform re-detect for an existing prospect (homepage fetch only). */
	public static function redetect( $url ) {
		$c   = new self();
		$res = $c->fetch( $url );
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		return array(
			'platform' => $c->detect_platform( $res['body'], $url ),
			'commerce' => self::detect_commerce( $res['body'] ),
		);
	}

	public function detect_platform( $html, $base_url ) {
		$h = strtolower( $html );
		if ( false !== strpos( $h, 'cdn.shopify.com' ) || false !== strpos( $h, 'shopify.theme' ) || false !== strpos( $h, 'x-shopify' ) ) {
			return 'shopify';
		}
		if ( false !== strpos( $h, '/wp-content/' ) || false !== strpos( $h, '/wp-includes/' ) || false !== strpos( $h, 'wp-json' ) ) {
			// TAXONOMY: WooCommerce is a WordPress PLUGIN, not a platform. The
			// platform is WordPress; commerce is detected separately as an
			// attribute via detect_commerce() (multi-signal, never one stray asset).
			return 'wordpress';
		}
		if ( false !== strpos( $h, 'webflow.js' ) || false !== strpos( $h, 'data-wf-page' ) || false !== strpos( $h, 'website-files.com' ) ) {
			return 'webflow';
		}
		$probe = $this->fetch( untrailingslashit( $base_url ) . '/wp-json/', true );
		if ( ! is_wp_error( $probe ) && false !== strpos( $probe['body'], '"namespaces"' ) ) {
			return 'wordpress';
		}
		$probe2 = $this->fetch( untrailingslashit( $base_url ) . '/products.json?limit=1', true );
		if ( ! is_wp_error( $probe2 ) && false !== strpos( $probe2['body'], '"products"' ) ) {
			return 'shopify';
		}
		if ( false !== strpos( $h, 'wix.com' ) || false !== strpos( $h, 'wixstatic' ) ) {
			return 'wix';
		}
		if ( false !== strpos( $h, 'squarespace' ) ) {
			return 'squarespace';
		}
		if ( false !== strpos( $h, 'gohighlevel' ) || false !== strpos( $h, 'leadconnector' ) ) {
			return 'gohighlevel';
		}
		// No strong CMS fingerprint: custom build vs unknown — never guess a CMS.
		if ( preg_match( '/<meta[^>]+generator[^>]+content=["\']([^"\']+)/i', $html, $g ) ) {
			return 'unknown'; // generator present but unrecognized — flag for review.
		}
		return 'custom';
	}

	/* ---------- URL discovery ---------- */

	private function sitemap_urls( $base, $cap = 100 ) {
		$urls  = array();
		$limit = max( 100, min( TNC_Crawl_Jobs::HARD_CAP * 2, $cap * 3 ) );
		foreach ( array( 'sitemap.xml', 'sitemap_index.xml', 'wp-sitemap.xml' ) as $name ) {
			$res = $this->fetch( untrailingslashit( $base ) . '/' . $name );
			if ( is_wp_error( $res ) ) {
				continue;
			}
			$found = $this->parse_sitemap( $res['body'], 0, $limit );
			if ( $found ) {
				$urls = array_merge( $urls, $found );
				break;
			}
		}
		return array_slice( array_values( array_unique( $urls ) ), 0, $limit );
	}

	private function parse_sitemap( $xml, $level, $limit = 100 ) {
		$urls = array();
		if ( $level > 1 || '' === trim( $xml ) ) {
			return $urls;
		}
		if ( ! preg_match_all( '#<loc>\s*([^<]+?)\s*</loc>#i', $xml, $m ) ) {
			return $urls;
		}
		$locs     = array_map( 'html_entity_decode', $m[1] );
		$is_index = false !== stripos( $xml, '<sitemapindex' );
		if ( $is_index ) {
			usort( $locs, function ( $a, $b ) {
				$score = function ( $u ) {
					if ( false !== stripos( $u, 'page' ) ) { return 0; }
					if ( false !== stripos( $u, 'post' ) ) { return 1; }
					if ( false !== stripos( $u, 'product' ) ) { return 2; }
					return 3;
				};
				return $score( $a ) - $score( $b );
			} );
			foreach ( array_slice( $locs, 0, 6 ) as $child ) {
				if ( count( $urls ) >= $limit ) {
					break;
				}
				if ( $this->same_host( $child ) ) {
					$res = $this->fetch( $child );
					if ( ! is_wp_error( $res ) ) {
						$urls = array_merge( $urls, $this->parse_sitemap( $res['body'], $level + 1, $limit - count( $urls ) ) );
					}
				}
			}
		} else {
			foreach ( $locs as $loc ) {
				if ( count( $urls ) >= $limit ) {
					break;
				}
				if ( $this->same_host( $loc ) && ! $this->is_skippable( $loc ) ) {
					$urls[] = $loc;
				}
			}
		}
		return $urls;
	}

	private function wp_api_urls( $base ) {
		$urls = array();
		foreach ( array( 'pages', 'posts' ) as $type ) {
			$res = $this->fetch( untrailingslashit( $base ) . '/wp-json/wp/v2/' . $type . '?per_page=20&_fields=link,title', true );
			if ( is_wp_error( $res ) ) {
				continue;
			}
			$items = json_decode( $res['body'], true );
			if ( is_array( $items ) ) {
				foreach ( $items as $item ) {
					if ( ! empty( $item['link'] ) && $this->same_host( $item['link'] ) && ! $this->is_skippable( $item['link'] ) ) {
						$urls[] = $item['link'];
					}
				}
			}
		}
		return $urls;
	}

	private function shopify_urls( $base ) {
		$urls = array( untrailingslashit( $base ) . '/products.json?limit=30' );
		foreach ( array( '/collections', '/pages/about-us', '/pages/about', '/pages/faq', '/pages/contact', '/policies/shipping-policy', '/policies/refund-policy' ) as $path ) {
			$urls[] = untrailingslashit( $base ) . $path;
		}
		return $urls;
	}

	private function extract_links( $html, $current_url ) {
		$links = array();
		if ( ! preg_match_all( '#<a[^>]+href=["\']([^"\'\#]+)["\']#i', $html, $m ) ) {
			return $links;
		}
		foreach ( array_unique( $m[1] ) as $href ) {
			$abs = $this->absolutize( $href, $current_url );
			if ( $abs && $this->same_host( $abs ) && ! $this->is_skippable( $abs ) ) {
				$links[] = $abs;
			}
			if ( count( $links ) >= 60 ) {
				break;
			}
		}
		return $links;
	}

	private function absolutize( $href, $base ) {
		$href = trim( $href );
		if ( '' === $href || 0 === strpos( $href, 'javascript:' ) || 0 === strpos( $href, 'mailto:' ) || 0 === strpos( $href, 'tel:' ) ) {
			return '';
		}
		if ( preg_match( '#^https?://#i', $href ) ) {
			return $href;
		}
		if ( 0 === strpos( $href, '//' ) ) {
			return $this->base_scheme . ':' . $href;
		}
		$bp   = wp_parse_url( $base );
		$root = $this->base_scheme . '://' . $bp['host'];
		if ( 0 === strpos( $href, '/' ) ) {
			return $root . $href;
		}
		$path = isset( $bp['path'] ) ? preg_replace( '#/[^/]*$#', '/', $bp['path'] ) : '/';
		return $root . $path . $href;
	}

	private function same_host( $url ) {
		$h = wp_parse_url( $url, PHP_URL_HOST );
		if ( ! $h ) {
			return false;
		}
		$h = strtolower( $h );
		return $h === $this->base_host || $h === 'www.' . $this->base_host || 'www.' . $h === $this->base_host;
	}

	private function is_skippable( $url ) {
		$u = strtolower( $url );
		if ( preg_match( '#\.(jpg|jpeg|png|gif|webp|svg|ico|pdf|zip|mp4|mp3|webm|css|js|woff2?|ttf|xml(?!$))(\?|$)#', $u ) ) {
			return true;
		}
		foreach ( array( '/cart', '/checkout', '/login', '/log-in', '/signin', '/sign-in', '/register', '/my-account', '/account', '/wp-admin', '/wp-login', '/admin', '/feed', '/tag/', '/category/', '/author/', '?add-to-cart', '/privacy', '/terms', '/refund', '/cookie' ) as $bad ) {
			if ( false !== strpos( $u, $bad ) ) {
				return true;
			}
		}
		return false;
	}

	/** Priority ordering — capped crawls always take the most valuable pages first. */
	private function prioritize( $queue ) {
		$keywords = array(
			'about' => 10, 'service' => 10, 'practice-area' => 10, 'practice_area' => 10, 'treatment' => 10,
			'faq' => 9, 'contact' => 9, 'location' => 9, 'testimonial' => 8, 'review' => 8,
			'pricing' => 8, 'price' => 8, 'booking' => 8, 'consultation' => 8, 'appointment' => 8,
			'product' => 7, 'collection' => 6, 'team' => 6, 'staff' => 6, 'our-' => 5, 'why' => 4,
			'repair' => 6, 'install' => 6, 'emergency' => 6, 'financing' => 5, 'insurance' => 5,
		);
		$scored = array();
		foreach ( $queue as $url => $depth ) {
			$score = 0;
			$lu    = strtolower( $url );
			foreach ( $keywords as $kw => $pts ) {
				if ( false !== strpos( $lu, $kw ) ) {
					$score += $pts;
				}
			}
			$path   = wp_parse_url( $url, PHP_URL_PATH );
			$score -= substr_count( $path ? $path : '/', '/' );
			$scored[ $url ] = array( $score, $depth );
		}
		uasort( $scored, function ( $a, $b ) {
			return $b[0] - $a[0];
		} );
		$out = array();
		foreach ( $scored as $url => $pair ) {
			$out[ $url ] = $pair[1];
		}
		return $out;
	}

	/* ---------- Content extraction ---------- */

	private function page_record( $url, $body ) {
		$trim = ltrim( $body );
		if ( '' !== $trim && ( '{' === $trim[0] || '[' === $trim[0] ) ) {
			return array(
				'title' => $this->title_from_url( $url ),
				'text'  => $this->json_to_text( $trim ),
				'html'  => '',
			);
		}
		return array(
			'title' => $this->extract_title( $body, $url ),
			'text'  => mb_substr( self::html_to_text( $body ), 0, 12000 ),
			'html'  => substr( $body, 0, 25000 ), // hard cap: 150KB/page blobs exhausted memory at scale (the 189/200 stall).
		);
	}

	private function title_from_url( $url ) {
		$path = wp_parse_url( $url, PHP_URL_PATH );
		$path = trim( (string) $path, '/' );
		return $path ? ucwords( str_replace( array( '-', '_', '/' ), ' ', preg_replace( '#\.\w+$#', '', $path ) ) ) : 'Home';
	}

	private function json_to_text( $json ) {
		$data = json_decode( $json, true );
		if ( ! is_array( $data ) ) {
			return '';
		}
		$lines = array();
		if ( isset( $data['products'] ) && is_array( $data['products'] ) ) {
			foreach ( array_slice( $data['products'], 0, 30 ) as $pr ) {
				$price = '';
				if ( ! empty( $pr['variants'][0]['price'] ) ) {
					$price = ' — from $' . $pr['variants'][0]['price'];
				}
				$desc    = ! empty( $pr['body_html'] ) ? ' ' . wp_strip_all_tags( $pr['body_html'] ) : '';
				$lines[] = 'Product: ' . ( isset( $pr['title'] ) ? $pr['title'] : '' ) . $price . '.' . substr( $desc, 0, 300 );
			}
			return implode( "\n", $lines );
		}
		array_walk_recursive( $data, function ( $v, $k ) use ( &$lines ) {
			if ( is_string( $v ) && strlen( $v ) > 3 && strlen( $v ) < 500 && ! preg_match( '#^https?://#', $v ) ) {
				$lines[] = $v;
			}
		} );
		return implode( "\n", array_slice( $lines, 0, 100 ) );
	}

	private function extract_title( $html, $url ) {
		if ( preg_match( '#<title[^>]*>(.*?)</title>#is', $html, $m ) ) {
			return trim( html_entity_decode( wp_strip_all_tags( $m[1] ) ) );
		}
		if ( preg_match( '#<h1[^>]*>(.*?)</h1>#is', $html, $m ) ) {
			return trim( html_entity_decode( wp_strip_all_tags( $m[1] ) ) );
		}
		return $this->title_from_url( $url );
	}

	public static function html_to_text( $html ) {
		$html = preg_replace( '#<(script|style|noscript|svg|iframe|form)[^>]*>.*?</\1>#is', ' ', $html );
		$html = preg_replace( '#<!--.*?-->#s', ' ', $html );
		$html = preg_replace( '#<h([1-4])[^>]*>#i', "\n\n## ", $html );
		$html = preg_replace( '#</h[1-4]>#i', "\n", $html );
		$html = preg_replace( '#<(br|/p|/div|/li|/tr)[^>]*>#i', "\n", $html );
		$text = wp_strip_all_tags( $html );
		$text = html_entity_decode( $text, ENT_QUOTES | ENT_HTML5 );
		$text = preg_replace( '/[ \t]+/', ' ', $text );
		$text = preg_replace( '/\n{3,}/', "\n\n", $text );
		return trim( $text );
	}



	/**
	 * Chat Detection v2: provider fingerprints + custom-widget heuristics.
	 * Returns: provider (display name|''), type (none|provider|custom|tuanichat), grade (none|basic|ai).
	 */
	/**
	 * Detection v5 JS sampling: same-host + CDN scripts PLUS tag-manager
	 * containers. GTM installs are inline snippets that BUILD the script URL,
	 * so the <script src> scan never sees the chat vendor — we extract every
	 * GTM-XXXX container id from the raw HTML and fetch the container JS
	 * directly. If the rendered page loads a chat widget through GTM, its
	 * fingerprint is in that container — render-truth via code.
	 */
	private function sample_js( $home_html, $url ) {
		$blob    = '';
		$js_urls = array();
		$allow   = array( 'googletagmanager.com', 'connect.facebook.net' );
		if ( preg_match_all( '#<script[^>]+src=["\']([^"\']+)["\']#i', $home_html, $sm ) ) {
			foreach ( $sm[1] as $src ) {
				$abs = $this->absolutize( html_entity_decode( $src ), $url );
				if ( ! $abs ) {
					continue;
				}
				$jh = strtolower( (string) wp_parse_url( $abs, PHP_URL_HOST ) );
				$ok = $jh && ( $this->same_host( $abs ) || false !== strpos( $jh, 'cdn' ) );
				foreach ( $allow as $a ) {
					if ( $jh && false !== strpos( $jh, $a ) ) {
						$ok = true;
					}
				}
				if ( $ok ) {
					$js_urls[] = $abs;
				}
				if ( count( $js_urls ) >= 8 ) {
					break;
				}
			}
		}
		// GTM containers referenced anywhere (inline snippet, data attrs, amp).
		if ( preg_match_all( '/\\bGTM-[A-Z0-9]{4,10}\\b/', $home_html, $gm ) ) {
			foreach ( array_slice( array_unique( $gm[0] ), 0, 3 ) as $cid ) {
				$js_urls[] = 'https://www.googletagmanager.com/gtm.js?id=' . $cid;
			}
		}
		foreach ( $this->fetch_many( array_values( array_unique( $js_urls ) ) ) as $jr ) {
			if ( ! is_wp_error( $jr ) ) {
				$blob .= ' ' . substr( strtolower( $jr['body'] ), 0, 150000 );
			}
			if ( strlen( $blob ) > 700000 ) {
				break;
			}
		}
		return $blob;
	}

	/**
	 * Lightweight chat-only re-detection for an existing prospect (no full
	 * crawl): homepage + Detection v5 JS sample -> detect_chat verdict.
	 */
	public static function redetect_chat( $url ) {
		$c   = new self();
		$res = $c->fetch( $url );
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		$blob = $c->sample_js( $res['body'], $url );
		return self::detect_chat( strtolower( $res['body'] ) . ' ' . $blob );
	}

	/** Provider signature map (sig => [display, grade]) — shared with fleet v2 agents. */
	public static function chat_signatures() {
		return array(
			'widget.intercom.io' => array( 'Intercom', 'ai' ), 'intercomsettings' => array( 'Intercom', 'ai' ), 'window.intercom' => array( 'Intercom', 'ai' ),
			'js.driftt.com' => array( 'Drift', 'ai' ), 'js.hs-scripts.com' => array( 'HubSpot Chat', 'basic' ), 'js.usemessages.com' => array( 'HubSpot Chat', 'basic' ),
			'hubspot-messages' => array( 'HubSpot Chat', 'basic' ), 'embed.tawk.to' => array( 'Tawk.to', 'basic' ), 'v2.zopim.com' => array( 'Zendesk Chat', 'basic' ),
			'static.zdassets.com' => array( 'Zendesk Chat', 'basic' ), 'cdn.livechatinc.com' => array( 'LiveChat', 'basic' ), 'livechatinc' => array( 'LiveChat', 'basic' ),
			'code.tidio.co' => array( 'Tidio', 'basic' ), 'client.crisp.chat' => array( 'Crisp', 'basic' ), '$crisp' => array( 'Crisp', 'basic' ),
			'static.olark.com' => array( 'Olark', 'basic' ), 'wchat.freshchat.com' => array( 'Freshchat', 'basic' ), 'fw-cdn.com' => array( 'Freshchat', 'basic' ),
			'smartsupp' => array( 'Smartsupp', 'basic' ), 'gorgias' => array( 'Gorgias Chat', 'basic' ), 'lptag' => array( 'LivePerson', 'ai' ),
			'purechat' => array( 'Pure Chat', 'basic' ), 'userlike' => array( 'Userlike', 'basic' ), 'chaport' => array( 'Chaport', 'basic' ),
			'fb-customerchat' => array( 'Facebook Customer Chat', 'basic' ), 'xfbml.customerchat' => array( 'Facebook Customer Chat', 'basic' ),
			'chatwoot' => array( 'Chatwoot', 'basic' ), 'shopify-chat' => array( 'Shopify Inbox', 'basic' ), 'shopifycloud/shop-chat' => array( 'Shopify Inbox', 'basic' ),
			'inbox.shopify' => array( 'Shopify Inbox', 'basic' ), 'manychat' => array( 'ManyChat', 'basic' ), 'birdeye' => array( 'Birdeye', 'basic' ),
			'podium' => array( 'Podium', 'basic' ), 'smith.ai' => array( 'Smith.ai', 'basic' ), 'ngagelive' => array( 'Ngage', 'basic' ),
			'apexchat' => array( 'ApexChat', 'basic' ), 'leadconnector' => array( 'LeadConnector Chat', 'basic' ), 'intaker' => array( 'Intaker', 'ai' ),
			'snapengage' => array( 'SnapEngage', 'basic' ), 'liveadmins' => array( 'LiveAdmins', 'basic' ), 'juvoleads' => array( 'Juvo Leads', 'basic' ),
			'blazeo' => array( 'Blazeo (ApexChat)', 'basic' ),
		);
	}

	public static function detect_chat( $lh ) {
		// Our own widget first.
		if ( false !== strpos( $lh, 'tnc-widget' ) || false !== strpos( $lh, 'tnc_demo' ) || false !== strpos( $lh, 'tuanichat' ) ) {
			return array( 'provider' => 'TuaniChat', 'type' => 'tuanichat', 'grade' => 'ai', 'confidence' => 'verified_present' );
		}

		// Major providers by script/code fingerprint. Order matters (specific → generic).
		$providers = array(
			'widget.intercom.io'   => array( 'Intercom', 'ai' ),
			'intercomsettings'     => array( 'Intercom', 'ai' ),
			'window.intercom'      => array( 'Intercom', 'ai' ),
			'js.driftt.com'        => array( 'Drift', 'ai' ),
			'js.hs-scripts.com'    => array( 'HubSpot Chat', 'basic' ),
			'js.usemessages.com'   => array( 'HubSpot Chat', 'basic' ),
			'hubspot-messages'     => array( 'HubSpot Chat', 'basic' ),
			'embed.tawk.to'        => array( 'Tawk.to', 'basic' ),
			'v2.zopim.com'         => array( 'Zendesk Chat', 'basic' ),
			'static.zdassets.com'  => array( 'Zendesk Chat', 'basic' ),
			'cdn.livechatinc.com'  => array( 'LiveChat', 'basic' ),
			'livechatinc'          => array( 'LiveChat', 'basic' ),
			'code.tidio.co'        => array( 'Tidio', 'basic' ),
			'client.crisp.chat'    => array( 'Crisp', 'basic' ),
			'$crisp'               => array( 'Crisp', 'basic' ),
			'static.olark.com'     => array( 'Olark', 'basic' ),
			'wchat.freshchat.com'  => array( 'Freshchat', 'basic' ),
			'fw-cdn.com'           => array( 'Freshchat', 'basic' ),
			'smartsupp'            => array( 'Smartsupp', 'basic' ),
			'gorgias'              => array( 'Gorgias Chat', 'basic' ),
			'lptag'                => array( 'LivePerson', 'ai' ),
			'purechat'             => array( 'Pure Chat', 'basic' ),
			'userlike'             => array( 'Userlike', 'basic' ),
			'chaport'              => array( 'Chaport', 'basic' ),
			'fb-customerchat'      => array( 'Facebook Customer Chat', 'basic' ),
			'xfbml.customerchat'   => array( 'Facebook Customer Chat', 'basic' ),
			'chatwoot'             => array( 'Chatwoot', 'basic' ),
			'shopify-chat'         => array( 'Shopify Inbox', 'basic' ),
			'shopifycloud/shop-chat' => array( 'Shopify Inbox', 'basic' ),
			'inbox.shopify'        => array( 'Shopify Inbox', 'basic' ),
			'manychat'             => array( 'ManyChat', 'basic' ),
			'birdeye'              => array( 'Birdeye', 'basic' ),
			'podium'               => array( 'Podium', 'basic' ),
			'smith.ai'             => array( 'Smith.ai', 'basic' ),
			'ngagelive'            => array( 'Ngage', 'basic' ),
			'apexchat'             => array( 'ApexChat', 'basic' ),
			'leadconnector'        => array( 'LeadConnector Chat', 'basic' ),
			'intaker'              => array( 'Intaker', 'ai' ),
			'snapengage'           => array( 'SnapEngage', 'basic' ),
			'liveadmins'           => array( 'LiveAdmins', 'basic' ),
			'juvoleads'            => array( 'Juvo Leads', 'basic' ),
			'blazeo'               => array( 'Blazeo (ApexChat)', 'basic' ),
		);
		foreach ( $providers as $sig => $info ) {
			if ( false !== strpos( $lh, $sig ) ) {
				return array( 'provider' => $info[0], 'type' => 'provider', 'grade' => $info[1], 'confidence' => 'verified_present' );
			}
		}

		// WhatsApp click-to-chat widget: wa.me link + floating/whatsapp widget markers.
		if ( false !== strpos( $lh, 'wa.me/' ) || false !== strpos( $lh, 'api.whatsapp.com/send' ) ) {
			if ( preg_match( '/(class|id)\s*=\s*["\'][^"\']*(whatsapp|wa-)[^"\']*(float|widget|button|chat|btn)[^"\']*["\']/i', $lh )
				|| preg_match( '/(whatsapp[^>]{0,80}position\s*:\s*fixed|position\s*:\s*fixed[^>]{0,120}whatsapp)/i', $lh ) ) {
				return array( 'provider' => 'WhatsApp Widget', 'type' => 'provider', 'grade' => 'basic', 'confidence' => 'verified_present' );
			}
		}

		// Custom hand-built widgets: launcher/panel DOM + JS construction markers...
		$custom_markers = 0;
		// Our own short-prefix builds (lcc-/llc- style) + data-chat attributes.
		if ( preg_match( '/(^|["\'\s.#])(lcc|llc)[-_](chat|widget|launcher|bubble|panel)/i', $lh ) ) {
			$custom_markers += 3;
		}
		if ( preg_match( '/data-chat[a-z-]*\s*=/i', $lh ) ) {
			$custom_markers += 2;
		}
		// JS launcher construction / selectors targeting chat elements.
		if ( preg_match( '/(getelementbyid|queryselector(all)?)\(\s*["\'][#.]?[a-z0-9_-]*chat[a-z0-9_-]*["\']/i', $lh ) ) {
			$custom_markers += 2;
		}
		// Localized/inline chat config objects (wp_localize-style or globals).
		if ( preg_match( '/(var|let|const|window\.)\s*[a-z0-9_]*chat[a-z0-9_]*\s*=\s*\{|[a-z0-9_]*chat(_params|_settings|_config|_vars)\b/i', $lh ) ) {
			$custom_markers += 2;
		}
		// Human copy used by live widgets ("Powered by X AI", "replies instantly").
		if ( preg_match( '/powered by [a-z0-9 .&-]{0,40}(ai|chat)/i', $lh ) ) {
			$custom_markers += 2;
		}
		if ( preg_match( '/(class|id)\s*=\s*["\'][^"\']*(chat|messenger)[-_]?(widget|launcher|button|panel|bubble|box|toggle|window|container|popup|float)[^"\']*["\']/i', $lh ) ) {
			$custom_markers += 2;
		}
		if ( preg_match( '/(class|id)\s*=\s*["\'][^"\']*(chat-?bubble|chatbox|chat-?launcher|live-?chat|chat-?open|open-?chat)[^"\']*["\']/i', $lh ) ) {
			$custom_markers += 2;
		}
		// ...short custom class prefixes wrapping chat markup (e.g. lcc-, llc- builds)...
		if ( preg_match( '/(class|id)\s*=\s*["\'][a-z]{2,4}[-_](chat|widget|launcher|bubble|panel)[^"\']*["\']/i', $lh ) ) {
			$custom_markers += 2;
		}
		// ...chat REST/AJAX endpoints in inline JS...
		if ( preg_match( '#(admin-ajax\.php[^"\']{0,80}action=[a-z_]*chat|/wp-json/[a-z0-9_/-]*chat|fetch\(\s*["\'][^"\']*chat[^"\']*["\']|xmlhttprequest[^;]{0,200}chat)#i', $lh ) ) {
			$custom_markers += 2;
		}
		// ...generic chat tokens + human copy markers count as support signals.
		if ( substr_count( $lh, 'chat-' ) + substr_count( $lh, 'chat_' ) >= 4 ) {
			$custom_markers += 1;
		}
		if ( preg_match( '/(replies instantly|chat with us|start a chat|live chat now|chat now)/i', $lh ) ) {
			$custom_markers += 2;
		}
		if ( $custom_markers >= 4 ) {
			return array( 'provider' => 'Custom chat widget', 'type' => 'custom', 'grade' => 'basic', 'confidence' => 'verified_present' );
		}
		if ( $custom_markers >= 2 ) {
			return array( 'provider' => 'Custom chat widget', 'type' => 'custom', 'grade' => 'basic', 'confidence' => 'possible' );
		}
		if ( 1 === $custom_markers ) {
			return array( 'provider' => '', 'type' => 'none', 'grade' => 'none', 'confidence' => 'needs_review' );
		}

		// Code shows nothing. Without a visual check we never assert "verified no chat".
		return array( 'provider' => '', 'type' => 'none', 'grade' => 'none', 'confidence' => 'needs_review' );
	}

	/** Extract brand colors (meta theme-color, CSS frequency) + logo URL from the homepage. */
	/** Public: fetch a homepage and extract its brand palette (primary/secondary/
	 * logo/site_mode). Used to theme demos from the prospect's OWN site colors. */
	public static function brand_for_url( $url ) {
		$c   = new self();
		$res = $c->fetch( $url );
		if ( is_wp_error( $res ) || empty( $res['body'] ) ) {
			return array();
		}
		return $c->extract_brand( $res['body'] );
	}

	private function extract_brand( $home_html ) {
		$brand = array( 'primary' => '', 'secondary' => '', 'logo' => '', 'site_mode' => '', 'vibrancy' => '', 'radius' => '' );

		$counts = array();
		$bump   = function ( $hex, $w = 1 ) use ( &$counts ) {
			$hex = strtolower( $hex );
			if ( 4 === strlen( $hex ) ) {
				$hex = '#' . $hex[1] . $hex[1] . $hex[2] . $hex[2] . $hex[3] . $hex[3];
			}
			$counts[ $hex ] = isset( $counts[ $hex ] ) ? $counts[ $hex ] + $w : $w;
		};

		// meta theme-color gets a strong vote.
		if ( preg_match( '#name=["\']theme-color["\'][^>]*content=["\'](\#[0-9a-fA-F]{3,6})#i', $home_html, $m )
			|| preg_match( '#content=["\'](\#[0-9a-fA-F]{3,6})["\'][^>]*name=["\']theme-color#i', $home_html, $m ) ) {
			$bump( $m[1], 60 );
		}

		// Button / link / brand-ish CSS declarations weigh more than generic colors.
		if ( preg_match_all( '/(background(?:-color)?|border-color|color)\s*:\s*(\#[0-9a-fA-F]{6}|\#[0-9a-fA-F]{3})/i', $home_html, $mm, PREG_SET_ORDER ) ) {
			foreach ( array_slice( $mm, 0, 4000 ) as $hit ) {
				$bump( $hit[2], 0 === strcasecmp( 'color', $hit[1] ) ? 1 : 2 );
			}
		}
		if ( preg_match_all( '/--(?:[a-z0-9-]*(?:primary|accent|brand|main|theme)[a-z0-9-]*)\s*:\s*(\#[0-9a-fA-F]{6}|\#[0-9a-fA-F]{3})/i', $home_html, $mv ) ) {
			foreach ( $mv[1] as $hex ) {
				$bump( $hex, 25 );
			}
		}

		// Rank usable (saturated, contrast-safe) colors.
		arsort( $counts );
		$picked = array();
		foreach ( $counts as $hex => $n ) {
			if ( ! class_exists( 'TNC_Themes' ) || ! TNC_Themes::usable_brand_color( $hex ) ) {
				continue;
			}
			$distinct = true;
			foreach ( $picked as $prev ) {
				if ( $this->color_distance( $prev, $hex ) < 60 ) {
					$distinct = false;
					break;
				}
			}
			if ( $distinct ) {
				$picked[] = $hex;
			}
			if ( count( $picked ) >= 2 ) {
				break;
			}
		}
		if ( isset( $picked[0] ) ) { $brand['primary'] = $picked[0]; }
		if ( isset( $picked[1] ) ) { $brand['secondary'] = $picked[1]; }

		// Logo: header/nav <img> with logo hints, else og:image.
		if ( preg_match( '#<img[^>]+(?:class|id|src|alt)=["\'][^"\']*logo[^"\']*["\'][^>]*>#i', $home_html, $li )
			&& preg_match( '#src=["\']([^"\']+)["\']#i', $li[0], $ls ) ) {
			$brand['logo'] = $this->absolutize( html_entity_decode( $ls[1] ), $this->base_scheme . '://' . $this->base_host . '/' );
		} elseif ( preg_match( '#property=["\']og:image["\'][^>]*content=["\']([^"\']+)#i', $home_html, $og )
			|| preg_match( '#content=["\']([^"\']+)["\'][^>]*property=["\']og:image#i', $home_html, $og ) ) {
			$brand['logo'] = $this->absolutize( html_entity_decode( $og[1] ), $this->base_scheme . '://' . $this->base_host . '/' );
		}
		if ( $brand['logo'] && ! preg_match( '#^https?://#i', $brand['logo'] ) ) {
			$brand['logo'] = '';
		}

		// Site feel: dark vs light (weighted background luminance).
		$bg_lum = array();
		if ( preg_match_all( '/background(?:-color)?\s*:\s*(\#[0-9a-fA-F]{6}|\#[0-9a-fA-F]{3})/i', $home_html, $bm ) ) {
			foreach ( array_slice( $bm[1], 0, 400 ) as $hex ) {
				$bg_lum[] = class_exists( 'TNC_Themes' ) ? TNC_Themes::luminance( $hex ) : 1;
			}
		}
		if ( $bg_lum ) {
			$avg                = array_sum( $bg_lum ) / count( $bg_lum );
			$brand['site_mode'] = $avg < 0.42 ? 'dark' : 'light';
		}

		// Vibrancy: saturation spread of the primary brand color.
		if ( $brand['primary'] ) {
			$hex = ltrim( $brand['primary'], '#' );
			$r   = hexdec( substr( $hex, 0, 2 ) ); $g = hexdec( substr( $hex, 2, 2 ) ); $b = hexdec( substr( $hex, 4, 2 ) );
			$brand['vibrancy'] = ( max( $r, $g, $b ) - min( $r, $g, $b ) ) >= 110 ? 'vibrant' : 'muted';
		}

		// Roundness: pill vs rounded vs sharp from border-radius usage.
		$pill = preg_match_all( '/border-radius\s*:\s*(?:999|9999|100)px|border-radius\s*:\s*50%/i', $home_html, $x1 );
		$big  = preg_match_all( '/border-radius\s*:\s*(1[5-9]|[2-9]\d)px/i', $home_html, $x2 );
		$small= preg_match_all( '/border-radius\s*:\s*[0-7]px/i', $home_html, $x3 );
		if ( $pill + $big + $small > 3 ) {
			if ( $pill >= $big && $pill >= $small ) { $brand['radius'] = 'pill'; }
			elseif ( $small > $big ) { $brand['radius'] = 'sharp'; }
			else { $brand['radius'] = 'rounded'; }
		}
		return $brand;
	}

	private function color_distance( $a, $b ) {
		$rgb = function ( $hex ) {
			$hex = ltrim( $hex, '#' );
			return array( hexdec( substr( $hex, 0, 2 ) ), hexdec( substr( $hex, 2, 2 ) ), hexdec( substr( $hex, 4, 2 ) ) );
		};
		$ca = $rgb( $a );
		$cb = $rgb( $b );
		return abs( $ca[0] - $cb[0] ) + abs( $ca[1] - $cb[1] ) + abs( $ca[2] - $cb[2] );
	}

	private function extract_business_data( $pages, $home_html, $platform ) {
		$all_text = '';
		foreach ( $pages as $p ) {
			$all_text .= "\n" . $p['text'];
		}
		$all_html = $home_html;
		foreach ( $pages as $p ) {
			if ( ! empty( $p['html'] ) ) {
				$all_html .= $p['html'];
			}
		}

		$data = array(
			'company_name'  => '',
			'description'   => '',
			'services'      => array(),
			'locations'     => array(),
			'phones'        => array(),
			'emails'        => array(),
			'faqs'          => array(),
			'ctas'          => array(),
			'forms_present' => false,
			'trust_signals' => array(),
			'chat_widget'   => '',
			'chat_type'     => 'none',
			'chat_grade'    => 'none',
			'pixels'        => array(),
			'hours_listed'  => false,
			'hero'          => '',
			'brand'         => array( 'primary' => '', 'secondary' => '', 'logo' => '' ),
			'pricing'       => array(),
		);

		if ( preg_match( '#property=["\']og:site_name["\'][^>]*content=["\']([^"\']+)#i', $home_html, $m )
			|| preg_match( '#content=["\']([^"\']+)["\'][^>]*property=["\']og:site_name#i', $home_html, $m ) ) {
			$data['company_name'] = trim( html_entity_decode( $m[1] ) );
		} elseif ( preg_match( '#<title[^>]*>(.*?)</title>#is', $home_html, $m ) ) {
			$t    = html_entity_decode( wp_strip_all_tags( $m[1] ) );
			$bits = preg_split( '/\s*[\|\x{2013}\x{2014}-]\s+/u', $t );
			$last = is_array( $bits ) ? trim( (string) end( $bits ) ) : '';
			$data['company_name'] = ( count( $bits ) > 1 && '' !== $last && strlen( $last ) < 40 ) ? $last : trim( $bits[0] );
		}

		if ( preg_match( '#name=["\']description["\'][^>]*content=["\']([^"\']+)#i', $home_html, $m )
			|| preg_match( '#content=["\']([^"\']+)["\'][^>]*name=["\']description#i', $home_html, $m ) ) {
			$data['description'] = trim( html_entity_decode( $m[1] ) );
		}

		if ( preg_match_all( '#href=["\']tel:([^"\']+)#i', $all_html, $m ) ) {
			$data['phones'] = array_slice( array_values( array_unique( array_map( 'trim', $m[1] ) ) ), 0, 4 );
		}
		if ( empty( $data['phones'] ) && preg_match_all( '/\(?\b\d{3}\)?[\s.-]\d{3}[\s.-]\d{4}\b/', $all_text, $m ) ) {
			$data['phones'] = array_slice( array_values( array_unique( $m[0] ) ), 0, 3 );
		}

		if ( preg_match_all( '/[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}/i', $all_html, $m ) ) {
			$emails = array();
			foreach ( array_unique( $m[0] ) as $e ) {
				if ( ! preg_match( '/\.(png|jpg|gif|webp|svg|js|css)$/i', $e ) && false === strpos( $e, 'example.' ) && false === strpos( $e, 'sentry' ) ) {
					$emails[] = strtolower( $e );
				}
			}
			$data['emails'] = array_slice( array_values( array_unique( $emails ) ), 0, 3 );
		}

		$services = array();
		foreach ( $pages as $url => $p ) {
			$lu = strtolower( $url );
			if ( preg_match( '#(service|practice|treatment|product|what-we|procedures)#', $lu ) ) {
				if ( preg_match_all( '/^## (.{4,70})$/m', $p['text'], $hm ) ) {
					foreach ( $hm[1] as $h ) {
						$h = trim( $h );
						if ( ! preg_match( '/(contact|about|home|menu|search|share|follow|subscribe|©)/i', $h ) ) {
							$services[] = $h;
						}
					}
				}
			}
		}
		$data['services'] = array_slice( array_values( array_unique( $services ) ), 0, 15 );

		if ( preg_match_all( '/\b\d{1,5}\s+[A-Z][A-Za-z0-9 .]{3,40}(?:Street|St\.?|Avenue|Ave\.?|Boulevard|Blvd\.?|Road|Rd\.?|Drive|Dr\.?|Suite|Ste\.?|Lane|Ln\.?|Way|Court|Ct\.?|Pkwy|Parkway)[,\s]+[A-Z][A-Za-z .]+,?\s+[A-Z]{2}\s+\d{5}/', $all_text, $m ) ) {
			$data['locations'] = array_slice( array_values( array_unique( array_map( 'trim', $m[0] ) ) ), 0, 5 );
		}

		foreach ( $pages as $url => $p ) {
			if ( preg_match_all( '/^## ([^\n?]{8,120}\?)\s*\n([^#]{20,600})/m', $p['text'], $fm, PREG_SET_ORDER ) ) {
				foreach ( $fm as $f ) {
					$data['faqs'][] = array( 'q' => trim( $f[1] ), 'a' => trim( preg_replace( '/\s+/', ' ', substr( $f[2], 0, 500 ) ) ) );
					if ( count( $data['faqs'] ) >= 12 ) {
						break 2;
					}
				}
			}
		}

		if ( preg_match_all( '#<a[^>]+class=["\'][^"\']*(?:btn|button|cta)[^"\']*["\'][^>]*>(.*?)</a>#is', $home_html, $m ) ) {
			foreach ( $m[1] as $c ) {
				$c = trim( wp_strip_all_tags( $c ) );
				if ( strlen( $c ) > 2 && strlen( $c ) < 50 ) {
					$data['ctas'][] = $c;
				}
			}
			$data['ctas'] = array_slice( array_values( array_unique( $data['ctas'] ) ), 0, 8 );
		}

		$data['forms_present'] = (bool) preg_match( '#<form[\s>]#i', $all_html )
			|| false !== stripos( $all_html, 'wpcf7' ) || false !== stripos( $all_html, 'gform' )
			|| false !== stripos( $all_html, 'hs-form' ) || false !== stripos( $all_html, 'elementor-form' );

		$trust_words = array( 'award' => 'Awards mentioned', 'certified' => 'Certifications', 'accredited' => 'Accreditation', 'bbb' => 'BBB', 'google review' => 'Google reviews', 'five star' => '5-star reviews', '5-star' => '5-star reviews', 'years of experience' => 'Years of experience', 'testimonial' => 'Testimonials', 'board-certified' => 'Board-certified', 'licensed' => 'Licensed', 'insured' => 'Insured', 'super lawyers' => 'Super Lawyers', 'avvo' => 'Avvo' );
		$lt = strtolower( $all_text );
		foreach ( $trust_words as $w => $label ) {
			if ( false !== strpos( $lt, $w ) ) {
				$data['trust_signals'][] = $label;
			}
		}
		$data['trust_signals'] = array_values( array_unique( $data['trust_signals'] ) );

		$lh   = strtolower( $all_html ) . ' ' . $this->js_blob;
		$chat = self::detect_chat( $lh );
		$data['chat_widget']     = $chat['provider'];
		$data['chat_type']       = $chat['type'];
		$data['chat_grade']      = $chat['grade'];
		$data['chat_confidence'] = isset( $chat['confidence'] ) ? $chat['confidence'] : ( 'none' === $chat['type'] ? 'needs_review' : 'verified_present' );

		$pixels = array( 'googletagmanager' => 'GTM', 'gtag(' => 'Google Analytics', 'fbq(' => 'Meta Pixel', 'connect.facebook.net' => 'Meta Pixel', 'tiktok' => 'TikTok Pixel', 'clarity.ms' => 'MS Clarity', 'hotjar' => 'Hotjar' );
		foreach ( $pixels as $sig => $label ) {
			if ( false !== strpos( $lh, $sig ) ) {
				$data['pixels'][] = $label;
			}
		}
		$data['pixels'] = array_values( array_unique( $data['pixels'] ) );

		$data['hours_listed'] = (bool) preg_match( '/(mon(day)?\s*[-–]\s*fri(day)?|opening hours|business hours|\b9\s*(am)?\s*[-–]\s*5\s*pm|24\/7|24 hours)/i', $all_text );

		// Structured price extraction: bind each price to its nearest heading (service/product context).
		$seen_prices = array();
		foreach ( $pages as $url => $p ) {
			$heading = $p['title'];
			foreach ( preg_split( '/\n/', $p['text'] ) as $line ) {
				$line = trim( $line );
				if ( 0 === strpos( $line, '## ' ) ) {
					$h = trim( substr( $line, 3 ) );
					if ( strlen( $h ) > 2 && strlen( $h ) < 80 ) {
						$heading = $h;
					}
					continue;
				}
				if ( preg_match_all( '/(?:(?:starting|from|only|now)\s+(?:at\s+)?)?\$\s?\d[\d,]*(?:\.\d{2})?(?:\s?[-\x{2013}]\s?\$?\s?\d[\d,]*(?:\.\d{2})?)?(?:\s?(?:\/|per)\s?[a-z][a-z ]{0,12})?/iu', $line, $pm ) ) {
					foreach ( $pm[0] as $price ) {
						$price = trim( preg_replace( '/\s+/', ' ', $price ) );
						$item  = trim( preg_replace( '/\s+/', ' ', $heading ) );
						$key   = strtolower( $item . '|' . $price );
						if ( isset( $seen_prices[ $key ] ) || count( $data['pricing'] ) >= 25 ) {
							continue;
						}
						$seen_prices[ $key ] = true;
						$data['pricing'][]   = array(
							'item'    => $item,
							'price'   => $price,
							'url'     => $url,
							'context' => mb_substr( $line, 0, 160 ),
						);
					}
				}
			}
		}

		// Hero line: first H1 on the homepage.
		if ( preg_match( '#<h1[^>]*>(.*?)</h1>#is', $home_html, $m ) ) {
			$hero = trim( preg_replace( '/\s+/', ' ', html_entity_decode( wp_strip_all_tags( $m[1] ) ) ) );
			if ( strlen( $hero ) > 3 && strlen( $hero ) < 140 ) {
				$data['hero'] = $hero;
			}
		}

		// Brand tokens: colors + logo (preset fallback applies when unusable).
		$data['brand']    = $this->extract_brand( $home_html );
		$data['commerce'] = self::detect_commerce( $home_html );

		return $data;
	}
}
