<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * INTERSERVER FLEET — host-generic job queue the brain exposes to remote
 * worker daemons over authenticated HTTPS. Core of the muscle plan (#50):
 * the DreamHost brain stays the single source of truth; fleet nodes only
 * pull jobs, renew leases, and report results. Lease-based self-heal: a
 * worker that dies mid-job simply stops renewing, and the job re-queues.
 */
class TNC_Fleet {
	const FLEET_BUILD = '1.23.2'; // current fleet worker/bridge code version (self-updater compares this).

	const LEASE_TTL  = 60;  // seconds without renewal = dead worker, job re-queues.
	const NODE_FRESH = 90;  // node heartbeat younger than this = ONLINE.
	// DISPLAY/ALERT THRESHOLDS (#cockpit-flicker): a node is only treated as
	// gone when its heartbeat is truly old. Between NODE_FRESH and NODE_STALE
	// the cockpit keeps showing last-known lanes (no flicker to 0 on a missed
	// beat or snapshot gap).
	const NODE_STALE   = 180;   // 90s-180s: still ONLINE for display (last-known).
	const NODE_OFFLINE = 300;   // > 5 min: OFFLINE -> cockpit flag + email alert.
	const NODE_PRUNE   = 86400; // > 24 h offline: drop from the node list entirely.

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		// ANONYMOUS-SAFE TRANSPORT: admin-ajax nopriv. The custom REST namespace
		// is 403'd for logged-out clients on this host (a security/mod_security
		// rule, not Cloudflare and not a global REST gate). admin-ajax nopriv is
		// the reliable anonymous path that the VPS workers and the curl|bash
		// installer use. Everything stays token-gated.
		add_action( 'wp_ajax_nopriv_tnc_fleet', array( __CLASS__, 'ajax' ) );
		add_action( 'wp_ajax_tnc_fleet', array( __CLASS__, 'ajax' ) );
	}

	/** admin-ajax dispatcher: ?action=tnc_fleet&op=pull&token=... (or t= for bootstrap). */
	public static function ajax() {
		$op  = isset( $_REQUEST['op'] ) ? sanitize_key( wp_unslash( $_REQUEST['op'] ) ) : '';
		$req = new TNC_Fleet_Req();
		switch ( $op ) {
			case 'bootstrap':
				$res = self::bootstrap( $req ); // echoes+exits on success
				if ( is_wp_error( $res ) ) { status_header( 403 ); echo 'Forbidden'; }
				exit;
			case 'register': $res = self::register( $req ); break;
			case 'pull':     $res = self::pull( $req );     break;
			case 'renew':    $res = self::renew( $req );    break;
			case 'result':   $res = self::result( $req );   break;
			case 'heartbeat':$res = self::heartbeat( $req );break;
			case 'results':  $res = self::results_batch( $req ); break;
			default:
				status_header( 400 ); wp_send_json( array( 'ok' => false, 'error' => 'unknown op' ) );
		}
		if ( is_wp_error( $res ) ) {
			status_header( 403 ); wp_send_json( array( 'ok' => false, 'error' => $res->get_error_message() ) );
		}
		wp_send_json( $res->get_data() );
	}

	public static function routes() {
		$pub = '__return_true'; // token-checked inside each handler.
		register_rest_route( TNC_REST_NS, '/fleet/bootstrap', array(
			'methods' => 'GET', 'callback' => array( __CLASS__, 'bootstrap' ), 'permission_callback' => '__return_true',
		) );
		register_rest_route( TNC_REST_NS, '/fleet/version', array(
			'methods' => 'GET', 'callback' => array( __CLASS__, 'version' ), 'permission_callback' => '__return_true',
		) );
		register_rest_route( TNC_REST_NS, '/fleet/jarvis-bundle', array(
			'methods' => 'GET', 'callback' => array( __CLASS__, 'jarvis_bundle' ), 'permission_callback' => '__return_true',
		) );
		register_rest_route( TNC_REST_NS, '/fleet/migparity', array(
			'methods' => 'GET', 'callback' => array( __CLASS__, 'migparity' ), 'permission_callback' => '__return_true',
		) );
		register_rest_route( TNC_REST_NS, '/fleet/component', array(
			'methods' => 'GET', 'callback' => array( __CLASS__, 'component' ), 'permission_callback' => '__return_true',
		) );
		register_rest_route( TNC_REST_NS, '/fleet/update-log', array(
			'methods' => array( 'GET', 'POST' ), 'callback' => array( __CLASS__, 'update_log' ), 'permission_callback' => '__return_true',
		) );
		foreach ( array( 'register', 'pull', 'renew', 'result', 'heartbeat', 'shot', 'ingest' ) as $ep ) {
			register_rest_route( TNC_REST_NS, '/fleet/' . $ep, array(
				'methods' => 'POST', 'callback' => array( __CLASS__, $ep ), 'permission_callback' => $pub,
			) );
		}
	}

	/**
	 * SELF-HOSTED SCREENSHOT UPLOAD: the fleet captures a real screenshot of the
	 * prospect's site via headless Chromium and POSTs the JPEG here (base64). We
	 * store it on OUR server (uploads/tnc-shots) and serve it cached/instantly on
	 * the demo — no third-party (mShots) dependence, no rate limit. Also records
	 * the framable verdict so the demo only iframes sites that truly allow it.
	 */
	/**
	 * EXTERNAL-SOURCE INTAKE (data contract for the CertStream CT-log daemon AND
	 * licensing-board fetchers). Token-gated. Accepts a batch of fresh leads and
	 * runs them through the SAME dedupe -> enrich -> email-gate -> promote pipeline
	 * with source provenance. freshly_launched leads get DAY-0 priority. Also a
	 * lightweight heartbeat so the Fresh-Launch Radar can show stream health.
	 *
	 * POST JSON: { token, source:'ct-stream'|'licensing'|..., items:[ {name,website,
	 *   email,phone,city,state,industry,freshly_launched,ts}, ... ], certs_seen?, matched? }
	 */
	public static function ingest( $req ) {
		if ( ! self::auth( $req ) ) {
			return new WP_Error( 'tnc_auth', 'Bad token.', array( 'status' => 403 ) );
		}
		$source = sanitize_key( (string) $req->get_param( 'source' ) );
		if ( '' === $source ) { $source = 'external'; }
		$items  = $req->get_param( 'items' );
		if ( is_string( $items ) ) { $items = json_decode( $items, true ); }
		$items  = is_array( $items ) ? $items : array();
		$res = array( 'ok' => true, 'source' => $source, 'received' => count( $items ), 'staged' => 0, 'dupes' => 0 );
		if ( class_exists( 'TNC_Leadhunter' ) ) {
			$res = array_merge( $res, (array) TNC_Leadhunter::ingest_external( $items, $source, $req ) );
		}
		return rest_ensure_response( $res );
	}

	/** Serve the zero-dep Jarvis Node module as raw base64 tar.gz (fleet-auth). */
	public static function jarvis_bundle( $req ) {
		if ( ! self::auth( $req ) ) { return new WP_Error( 'tnc_auth', 'Bad token.', array( 'status' => 403 ) ); }
		header( 'Content-Type: text/plain; charset=utf-8' );
		echo class_exists( 'TNC_Jarvis_Bundle' ) ? TNC_Jarvis_Bundle::b64() : ''; // phpcs:ignore
		exit;
	}

	/** MIGRATION PHASE 1 (zero-SSH, zero-DB-engine): hand the fleet a signed
	 * backup-export URL (backup token stays server-side) + live per-table row
	 * counts. The mig-phase1 component downloads the dump, counts INSERTs per
	 * table as text, and parity-checks against these counts — no MySQL needed. */
	public static function migparity( $req ) {
		if ( ! self::auth( $req ) ) { return new WP_Error( 'tnc_auth', 'Bad token.', array( 'status' => 403 ) ); }
		global $wpdb;
		$bt = (string) get_option( 'tnc_backup_token' );
		$counts = array(); $total = 0;
		foreach ( (array) $wpdb->get_col( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $wpdb->prefix . 'tnc_' ) . '%' ) ) as $tname ) {
			$n = (int) $wpdb->get_var( "SELECT COUNT(*) FROM `" . $tname . "`" ); // phpcs:ignore
			$counts[ $tname ] = $n; $total += $n;
		}
		return rest_ensure_response( array( 'ok' => true,
			'export_url' => admin_url( 'admin-ajax.php?action=tnc_backup&op=export&token=' . $bt ),
			'counts' => $counts, 'total' => $total, 'prefix' => $wpdb->prefix ) );
	}

	/** ZERO-SSH COMPONENT DEPLOY: serve component code as RAW base64 text —
	 * NOT JSON (WP REST escapes "/" as "\/" which corrupted the b64 stream and
	 * made the bootstrap integrity-check reject every component). Same proven
	 * transport as /fleet/bootstrap. */
	public static function component( $req ) {
		if ( ! self::auth( $req ) ) { return new WP_Error( 'tnc_auth', 'Bad token.', array( 'status' => 403 ) ); }
		$name = sanitize_key( (string) $req->get_param( 'name' ) );
		$src  = TNC_Components::source( $name );
		if ( '' === $src ) { return new WP_Error( 'tnc_component', 'Unknown component.', array( 'status' => 404 ) ); }
		header( 'Content-Type: text/plain; charset=utf-8' );
		echo base64_encode( $src ); // phpcs:ignore
		exit;
	}

	/** Self-updater event log (start/success/rollback/integrity-fail) + reader for the dashboard. */
	public static function update_log( $req ) {
		if ( ! self::auth( $req ) ) { return new WP_Error( 'tnc_auth', 'Bad token.', array( 'status' => 403 ) ); }
		$log = get_option( 'tnc_fleet_updatelog', array() ); if ( ! is_array( $log ) ) { $log = array(); }
		if ( 'POST' === $req->get_method() ) {
			$log[] = array(
				'ts' => time(),
				'node' => sanitize_text_field( (string) $req->get_param( 'node' ) ),
				'event' => sanitize_key( (string) $req->get_param( 'event' ) ),
				'from' => sanitize_text_field( (string) $req->get_param( 'from' ) ),
				'to' => sanitize_text_field( (string) $req->get_param( 'to' ) ),
			);
			$log = array_slice( $log, -40 );
			update_option( 'tnc_fleet_updatelog', $log, false );
			return rest_ensure_response( array( 'ok' => true ) );
		}
		return rest_ensure_response( array( 'ok' => true, 'build' => self::FLEET_BUILD, 'log' => array_reverse( array_slice( $log, -20 ) ) ) );
	}

	/** Current fleet code version — the self-updater polls this and re-bootstraps when it changes. */
	public static function version( $req ) {
		return rest_ensure_response( array( 'ok' => true, 'wbuild' => self::FLEET_BUILD ) );
	}

	public static function shot( $req ) {
		if ( ! self::auth( $req ) ) {
			return new WP_Error( 'tnc_auth', 'Bad token.', array( 'status' => 403 ) );
		}
		$pid = (int) $req->get_param( 'prospect' );
		if ( $pid <= 0 || ! class_exists( 'TNC_Prospects' ) ) {
			return new WP_Error( 'tnc_shot', 'Bad prospect.', array( 'status' => 400 ) );
		}
		$p = TNC_Prospects::get( $pid );
		if ( ! $p ) { return new WP_Error( 'tnc_shot', 'No prospect.', array( 'status' => 404 ) ); }
		$cd = is_array( $p['crawl_data'] ) ? $p['crawl_data'] : array();
		if ( ! isset( $cd['extracted'] ) || ! is_array( $cd['extracted'] ) ) { $cd['extracted'] = array(); }
		if ( ! isset( $cd['lh'] ) || ! is_array( $cd['lh'] ) ) { $cd['lh'] = array(); }
		// Framable verdict (worker checked X-Frame-Options / CSP frame-ancestors).
		$fr = $req->get_param( 'framable' );
		if ( null !== $fr ) { $cd['extracted']['framable'] = (bool) (int) $fr; $cd['lh']['framable_checked'] = time(); }
		// Image (base64 JPEG). Empty allowed = framable-only report.
		$b64 = (string) $req->get_param( 'img' );
		$url = '';
		if ( '' !== $b64 ) {
			$bin = base64_decode( $b64, true );
			if ( false !== $bin && strlen( $bin ) > 3000 ) { // reject empty/blank captures.
				$up  = wp_upload_dir();
				$dir = trailingslashit( $up['basedir'] ) . 'tnc-shots';
				if ( ! is_dir( $dir ) ) { wp_mkdir_p( $dir ); }
				$file = $dir . '/p' . $pid . '.jpg';
				if ( false !== file_put_contents( $file, $bin ) ) { // phpcs:ignore
					$url = trailingslashit( $up['baseurl'] ) . 'tnc-shots/p' . $pid . '.jpg';
					$cd['extracted']['screenshot_local'] = $url;
					$cd['extracted']['shot_ts'] = time();
				}
			}
		}
		TNC_Prospects::update( $pid, array( 'crawl_data' => wp_json_encode( $cd ) ) );
		if ( ! get_option( 'tnc_cap_shot' ) ) { update_option( 'tnc_cap_shot', 1, false ); }
		if ( '' !== $url ) {
			$hr = (int) floor( time() / 3600 );
			$u  = get_option( 'tnc_lh_shot_up', array() );
			$n  = ( is_array( $u ) && isset( $u['hr'] ) && (int) $u['hr'] === $hr ) ? (int) $u['n'] + 1 : 1;
			update_option( 'tnc_lh_shot_up', array( 'hr' => $hr, 'n' => $n ), false );
		}
		return rest_ensure_response( array( 'ok' => true, 'stored' => '' !== $url, 'url' => $url, 'framable' => isset( $cd['extracted']['framable'] ) ? (bool) $cd['extracted']['framable'] : null ) );
	}

	/** Token-gated one-line installer: curl -fsSL "...bootstrap?t=TOKEN" | bash */
	public static function bootstrap( $req ) {
		if ( ! hash_equals( self::token(), self::req_token( $req ) ) ) {
			return new WP_Error( 'tnc_auth', 'Not found.', array( 'status' => 403 ) );
		}
		header( 'Content-Type: text/plain; charset=utf-8' );
		// Base64 the script so no WAF/mod_security outbound rule can flag the
		// shell content; the one-liner pipes through `base64 -d | bash`.
		echo base64_encode( str_replace( array( '__TNC_TOKEN__', '__TNC_WBUILD__' ), array( self::token(), self::FLEET_BUILD ), self::bootstrap_script() ) ); // phpcs:ignore
		exit;
	}

	private static function bootstrap_script() {
		return <<<'EOS'
#!/bin/bash
# ============================================================================
# TuaniChat FLEET BOOTSTRAP v2 for the InterServer VPS (CentOS 7, OpenVZ)
# SAFE / ADDITIVE / RE-RUNNABLE. v2 adds: local REDIS job buffer + bridge
# daemon (workers pull locally — the brain is polled in batches, not per-job),
# and the 'enrich' job type (Pass 1-2 lead enrichment runs on the fleet).
# v2.1 adds: 'poi_query' job (local-map discovery from the isolated poi.db).
# v2.3 adds: 'shot' job (self-hosted headless-Chromium/wkhtmltoimage screenshot + framable detection).
# v2.2 adds: stale-worker kill on re-run, prior-count auto-detect, Redis
#            requirepass+AOF+boot-enable durability, worker auto-reconnect.
# Re-running on a live v1 fleet upgrades it in place (keeps workers running).
#
# USAGE:   bash tuanichat-fleet-bootstrap.sh <FLEET_TOKEN> [WORKERS]
# ============================================================================
set -u
TOKEN="${1:-__TNC_TOKEN__}"
WORKERS="${2:-0}"
# DURABLE: if no count passed, reuse the previously-installed worker count so a
# re-run never silently shrinks the fleet or leaves stale higher-numbered
# instances running OLD code. Falls back to 40 on a fresh box.
if [ "$WORKERS" -eq 0 ] 2>/dev/null || [ -z "$WORKERS" ]; then
  PREV=$(ls /etc/systemd/system/multi-user.target.wants/ 2>/dev/null | grep -c "^tnc-fleet@") || PREV=0
  if [ "${PREV:-0}" -gt 0 ]; then WORKERS=$PREV; else WORKERS=40; fi
fi
BRAIN="https://chat.lionclickmedia.com/wp-admin/admin-ajax.php?action=tnc_fleet&op="
DIR="/opt/tuanichat-fleet"
NODE="interserver-$(hostname -s 2>/dev/null || echo vps)"
WBUILD="__TNC_WBUILD__"
REST="https://chat.lionclickmedia.com/wp-json/tuanichat/v1/fleet"

echo "== [1/7] PHP CLI (side-by-side, web PHP untouched) =="
PHPBIN=""
for c in php81 php80 php74 php; do
  if command -v "$c" >/dev/null 2>&1; then PHPBIN="$(command -v $c)"; break; fi
done
if [ -z "$PHPBIN" ]; then
  yum -y install epel-release >/dev/null 2>&1
  yum -y install https://rpms.remirepo.net/enterprise/remi-release-7.rpm >/dev/null 2>&1
  yum -y install php81-php-cli php81-php-json php81-php-curl >/dev/null 2>&1 && PHPBIN="$(command -v php81 || true)"
fi
[ -z "$PHPBIN" ] && { echo "ERROR: no PHP CLI."; exit 1; }
echo "   PHP: $PHPBIN"

echo "== [2/7] Local Redis job buffer =="
REDIS_OK=0
REDIS_PASS=""
# Reuse an existing password if a prior install saved one.
[ -f "$DIR/redis.env" ] && . "$DIR/redis.env" 2>/dev/null
[ -f /opt/tuanichat-fleet/redis.env ] && . /opt/tuanichat-fleet/redis.env 2>/dev/null
REDIS_PASS="${REDIS_PASS:-${REDISPASS:-${REDIS_PASSWORD:-}}}"
if command -v redis-server >/dev/null 2>&1 || yum -y install redis >/dev/null 2>&1; then
  # Deterministic password: keep the saved one, else generate + persist once.
  if [ -z "$REDIS_PASS" ]; then REDIS_PASS="$(head -c 32 /dev/urandom | od -An -tx1 | tr -d ' \n' | cut -c1-32)"; fi
  RCONF="/etc/redis.conf"; [ -f /etc/redis/redis.conf ] && RCONF="/etc/redis/redis.conf"
  if [ -f "$RCONF" ]; then
    # Loopback-only, persistent (AOF), and require our password — idempotent.
    sed -i "s/^# *requirepass .*/requirepass $REDIS_PASS/; s/^requirepass .*/requirepass $REDIS_PASS/" "$RCONF" 2>/dev/null
    grep -q "^requirepass " "$RCONF" 2>/dev/null || echo "requirepass $REDIS_PASS" >> "$RCONF"
    grep -q "^appendonly yes" "$RCONF" 2>/dev/null || echo "appendonly yes" >> "$RCONF"
    grep -q "^bind 127.0.0.1" "$RCONF" 2>/dev/null || echo "bind 127.0.0.1 ::1" >> "$RCONF"
  fi
  systemctl enable redis >/dev/null 2>&1; systemctl restart redis >/dev/null 2>&1
  # Wait up to ~10s for Redis to accept AUTH (boot/restart can lag).
  for _t in 1 2 3 4 5 6 7 8 9 10; do
    if redis-cli -a "$REDIS_PASS" ping 2>/dev/null | grep -q PONG; then REDIS_OK=1; break; fi
    if redis-cli ping 2>/dev/null | grep -q PONG; then REDIS_OK=1; REDIS_PASS=""; break; fi
    sleep 1
  done
fi
echo "   Redis: $([ $REDIS_OK -eq 1 ] && echo UP '(bridge mode)' || echo 'unavailable — direct mode')"

echo "== [3/7] Worker agent v2 =="
mkdir -p "$DIR"
cat > "$DIR/worker.php" <<'PHPEOF'
<?php
/* TuaniChat fleet worker v2: enrich-capable; pulls from local Redis when
 * TNC_REDIS is set, else direct from the brain. */
$brain=getenv('TNC_BRAIN');$token=getenv('TNC_TOKEN');$node=getenv('TNC_NODE')?:'fleet-node';
$worker=$node.'-w'.(getenv('TNC_WORKER')?:getmypid());$redis=getenv('TNC_REDIS')?:'';$rpass=getenv('TNC_REDIS_PASS')?:'';
function rconn(){if(!empty($GLOBALS['__rs']))return $GLOBALS['__rs'];$s=@fsockopen('127.0.0.1',6379,$e,$m,3);if($s&&getenv('TNC_REDIS_PASS')){fwrite($s,"*2\r\n\$4\r\nAUTH\r\n\$".strlen(getenv('TNC_REDIS_PASS'))."\r\n".getenv('TNC_REDIS_PASS')."\r\n");fgets($s);}$GLOBALS['__rs']=$s?:null;return $GLOBALS['__rs'];}
function rdrop(){if(!empty($GLOBALS['__rs'])){@fclose($GLOBALS['__rs']);}$GLOBALS['__rs']=null;}
function rcmd(){$a=func_get_args();$s=rconn();if(!$s)return null;$o='*'.count($a)."\r\n";foreach($a as $p){$o.='$'.strlen($p)."\r\n".$p."\r\n";}if(@fwrite($s,$o)===false){rdrop();return null;}return rread($s);}
function rread($s){$l=fgets($s);if($l===false)return null;$t=$l[0];$l=trim(substr($l,1));
 if($t==='+'||$t===':')return $l;if($t==='-')return null;
 if($t==='$'){$n=(int)$l;if($n<0)return null;$d=stream_get_contents($s,$n+2);return substr($d,0,$n);}
 if($t==='*'){$n=(int)$l;$r=array();for($i=0;$i<$n;$i++){$r[]=rread($s);}return $r;}return null;}
function api($op,$body){global $brain,$token;$url=$brain.$op;
 foreach($body as $k=>$v){if(!is_array($v)&&strlen((string)$v)<=200){$url.='&'.rawurlencode($k).'='.rawurlencode($v);}}
 $ch=curl_init($url);curl_setopt_array($ch,array(CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>json_encode($body),
  CURLOPT_HTTPHEADER=>array('Content-Type: application/json','X-TNC-Token: '.$token),
  CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>30,CURLOPT_USERAGENT=>'Mozilla/5.0 (compatible; TuaniFleet/2.0)'));
 $out=curl_exec($ch);curl_close($ch);return json_decode((string)$out,true);}
function fetch_url($url,$t=20){$ch=curl_init($url);curl_setopt_array($ch,array(CURLOPT_RETURNTRANSFER=>true,
 CURLOPT_FOLLOWLOCATION=>true,CURLOPT_MAXREDIRS=>3,CURLOPT_TIMEOUT=>$t,
 CURLOPT_USERAGENT=>'Mozilla/5.0 (compatible; TuaniBot/1.0)'));$b=(string)curl_exec($ch);
 $c=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE);curl_close($ch);return array($c,$b);}
function run_job($job){$p=isset($job['payload'])?$job['payload']:array();
 switch($job['type']){
  case 'probe': case 'fetch':
   list($code,$html)=fetch_url(isset($p['url'])?$p['url']:'');
   $title=preg_match('#<title[^>]*>(.*?)</title>#si',$html,$m)?trim($m[1]):'';
   return array('http'=>$code,'bytes'=>strlen($html),'title'=>substr($title,0,160));
  case 'enrich':
   list($code,$html)=fetch_url(isset($p['url'])?$p['url']:'');
   if(!empty($p['namesearch'])){
    // SURVIVOR NAME-SEARCH: find the official website for a business OSM has
    // no site for. Parse organic result links, drop directories/socials.
    $links=array();
    if(preg_match_all('/href=["\x27]([^"\x27]+)["\x27]/i',$html,$lm)){
     foreach($lm[1] as $L){
      $L=html_entity_decode($L);
      if(preg_match('/[?&]uddg=([^&]+)/',$L,$um)){$L=urldecode($um[1]);}
      if(stripos($L,'http')!==0){continue;}
      $h=strtolower((string)parse_url($L,PHP_URL_HOST));
      if($h===''||strpos($h,'duckduckgo')!==false||preg_match('/(facebook|yelp|google|yellowpages|instagram|linkedin|tripadvisor|mapquest|bbb\.org|angi\.|healthgrades|zocdoc|wikipedia|youtube|twitter|x\.com|foursquare|nextdoor|groupon|thumbtack|houzz|avvo|realself|opentable|doordash|grubhub|ubereats|apple\.com|bing\.com|yahoo\.com)/',$h)){continue;}
      $L=preg_replace('/[?#].*$/','',$L);
      if(!in_array($L,$links,true)){$links[]=$L;}
      if(count($links)>=5){break;}
     }
    }
    if(!$links&&!empty($p['q2'])){
     // MULTI-ENGINE FALLBACK: DDG empty -> try Bing with the same query.
     list($c3,$h3)=fetch_url($p['q2']);
     if(preg_match_all('/href=["\x27](https?:\/\/[^"\x27]+)["\x27]/i',$h3,$lm3)){
      foreach($lm3[1] as $L){
       $L=html_entity_decode($L);
       if(stripos($L,'http')!==0){continue;}
       $h=strtolower((string)parse_url($L,PHP_URL_HOST));
       if($h===''||preg_match('/(bing\.|microsoft|msn\.|live\.com|facebook|yelp|google|yellowpages|instagram|linkedin|tripadvisor|mapquest|bbb\.org|wikipedia|youtube|twitter|x\.com|foursquare|groupon|thumbtack|houzz|avvo|doordash|grubhub)/',$h)){continue;}
       $L=preg_replace('/[?#].*$/','',$L);
       if(!in_array($L,$links,true)){$links[]=$L;}
       if(count($links)>=5){break;}
      }
     }
    }
    return array('http'=>$code,'namesearch'=>1,'links'=>$links,'engines'=>($links?($code?'ddg':'bing'):'none'));
   }
   $low=strtolower($html);$blob=$low;
   if(preg_match_all('/\bGTM-[A-Z0-9]{4,10}\b/',$html,$gm)){
    foreach(array_slice(array_unique($gm[0]),0,2) as $cid){
     list($c2,$b2)=fetch_url('https://www.googletagmanager.com/gtm.js?id='.$cid,12);
     if($c2===200){$blob.=' '.strtolower(substr($b2,0,200000));}usleep(300000);}}
   $emails=array();
   if(preg_match_all('/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}/i',$html,$em)){
    foreach(array_unique($em[0]) as $e){if(!preg_match('/\.(png|jpg|gif|svg|webp|js|css)$/i',$e)&&stripos($e,'example.')===false&&stripos($e,'sentry')===false){$emails[]=strtolower($e);if(count($emails)>=5)break;}}}
   $phones=array();
   if(preg_match_all('/href=["\x27]tel:([+0-9().\s-]{7,20})/i',$html,$tm)){$phones=array_slice(array_map('trim',array_unique($tm[1])),0,3);}
   $plat='';
   if(strpos($low,'cdn.shopify.com')!==false||strpos($low,'x-shopify')!==false){$plat='shopify';}
   elseif(strpos($low,'/wp-content/')!==false||strpos($low,'/wp-includes/')!==false||strpos($low,'wp-json')!==false){$plat='wordpress';}
   elseif(strpos($low,'webflow.js')!==false||strpos($low,'website-files.com')!==false){$plat='webflow';}
   elseif(strpos($low,'wixstatic')!==false||strpos($low,'wix.com')!==false){$plat='wix';}
   elseif(strpos($low,'squarespace')!==false){$plat='squarespace';}
   $sig='';foreach((array)(isset($p['sigs'])?$p['sigs']:array()) as $s2){if($s2!==''&&strpos($blob,strtolower($s2))!==false){$sig=$s2;break;}}
   $mk=0;
   if(preg_match('/(^|["\x27\s.#])(lcc|llc)[-_](chat|widget|launcher|bubble|panel)/i',$blob)){$mk+=3;}
   if(preg_match('/data-chat[a-z-]*\s*=/i',$blob)){$mk+=2;}
   if(preg_match('/(getelementbyid|queryselector(all)?)\(\s*["\x27][#.]?[a-z0-9_-]*chat[a-z0-9_-]*["\x27]/i',$blob)){$mk+=2;}
   if(preg_match('/[a-z0-9_]*chat(_params|_settings|_config|_vars)\b/i',$blob)){$mk+=2;}
   if(preg_match('/powered by [a-z0-9 .&-]{0,40}(ai|chat)/i',$blob)){$mk+=2;}
   if(preg_match('/(class|id)\s*=\s*["\x27][^"\x27]*(chat|messenger)[-_]?(widget|launcher|button|panel|bubble|box|toggle|window|container|popup|float)/i',$blob)){$mk+=2;}
   if(preg_match('/(chat-?bubble|chatbox|chat-?launcher|live-?chat|chat-?open|open-?chat)/i',$blob)){$mk+=2;}
   if(substr_count($blob,'chat-')+substr_count($blob,'chat_')>=4){$mk+=1;}
   if(preg_match('/(replies instantly|chat with us|start a chat|live chat now|chat now)/i',$blob)){$mk+=2;}
   $title=preg_match('#<title[^>]*>(.*?)</title>#si',$html,$m)?trim($m[1]):'';
   return array('http'=>$code,'bytes'=>strlen($html),'title'=>substr($title,0,160),'emails'=>$emails,'phones'=>$phones,'platform'=>$plat,'chat_sig'=>$sig,'chat_markers'=>$mk);
  case 'poi_query':
   // SCHEMA-ADAPTIVE: works with ANY poi.db layout (table + column names are
   // auto-detected from sqlite_master/table_info). The isolated DB is opened
   // read-only and never touches the brain DB.
   $dbf=getenv('TNC_POI_DB')?:'/opt/tuanichat-osm/poi.db';
   if(!class_exists('SQLite3')){return array('rows'=>array(),'db_total'=>0,'err'=>'no_sqlite3');}
   if(!is_file($dbf)){return array('rows'=>array(),'db_total'=>0,'poi_db'=>$dbf,'err'=>'no_db');}
   try{
    $db=new SQLite3($dbf,SQLITE3_OPEN_READONLY);$db->busyTimeout(5000);
    $tables=array();$tr=$db->query("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'");
    while($tr&&($r=$tr->fetchArray(SQLITE3_ASSOC))){$tables[]=$r['name'];}
    $pick='';$pickcols=array();$best=-1;$pref=array('poi','pois','places','place','osm','nodes','business','businesses');
    foreach($tables as $tn){
     $cols=array();$ci=$db->query('PRAGMA table_info("'.str_replace('"','',$tn).'")');
     while($ci&&($c=$ci->fetchArray(SQLITE3_ASSOC))){$cols[strtolower($c['name'])]=$c['name'];}
     $hl=false;$ho=false;foreach($cols as $lc=>$o){if(strpos($lc,'lat')!==false)$hl=true;if($lc==='lon'||$lc==='lng'||$lc==='x'||strpos($lc,'long')!==false)$ho=true;}
     if(!($hl&&$ho))continue;
     $sc=(in_array(strtolower($tn),$pref,true)?10:0)+count($cols);
     if($sc>$best){$best=$sc;$pick=$tn;$pickcols=$cols;}
    }
    if($pick===''&&$tables){$pick=$tables[0];$ci=$db->query('PRAGMA table_info("'.str_replace('"','',$pick).'")');while($ci&&($c=$ci->fetchArray(SQLITE3_ASSOC))){$pickcols[strtolower($c['name'])]=$c['name'];}}
    if($pick===''){$db->close();return array('rows'=>array(),'db_total'=>0,'tables'=>$tables,'err'=>'no_table');}
    $find=function($cands)use($pickcols){foreach($cands as $c){if(isset($pickcols[$c]))return $pickcols[$c];}foreach($cands as $c){foreach($pickcols as $lc=>$o){if(strpos($lc,$c)!==false)return $o;}}return '';};
    $c_name=$find(array('name','title'));$c_web=$find(array('website','url','site','web'));$c_phone=$find(array('phone','tel','telephone'));
    $c_city=$find(array('city','town'));$c_state=$find(array('state','region','province'));
    $c_lat=$find(array('lat','latitude','y'));$c_lon=$find(array('lon','lng','longitude','x'));
    $c_cat=$find(array('cat','category','class','kind','amenity','shop','type','tag'));
    $c_ot=$find(array('osm_type','otype'));$c_oid=$find(array('osm_id','osmid','id'));
    $Q=function($n){return $n?('"'.str_replace('"','',$n).'"'):'NULL';};
    $tbl='"'.str_replace('"','',$pick).'"';
    $tot=@$db->querySingle('SELECT COUNT(*) FROM '.$tbl);$tot=($tot===null||$tot===false)?0:(int)$tot;
    $mapped=array('table'=>$pick,'name'=>$c_name,'website'=>$c_web,'phone'=>$c_phone,'city'=>$c_city,'state'=>$c_state,'lat'=>$c_lat,'lon'=>$c_lon,'cat'=>$c_cat,'osm_type'=>$c_ot,'osm_id'=>$c_oid);
    if(!empty($p['probe'])){
     $samp=array();$sr=$db->query('SELECT * FROM '.$tbl.' LIMIT 2');while($sr&&($r=$sr->fetchArray(SQLITE3_ASSOC))){$samp[]=$r;}
     $db->close();return array('rows'=>array(),'db_total'=>$tot,'mapped'=>$mapped,'columns'=>array_values($pickcols),'sample'=>$samp);
    }
    $sel='SELECT '.$Q($c_ot).' AS osm_type, '.$Q($c_oid).' AS osm_id, '.$Q($c_name).' AS name, '.$Q($c_web).' AS website, '.$Q($c_phone).' AS phone, '.$Q($c_city).' AS city, '.$Q($c_state).' AS state, '.$Q($c_lat).' AS lat, '.$Q($c_lon).' AS lon FROM '.$tbl;
    $conds=array();$bind=array();
    if($c_name){$conds[]=$Q($c_name)." IS NOT NULL AND ".$Q($c_name)." <> ''";}
    $cats=isset($p['cats'])&&is_array($p['cats'])?$p['cats']:array();
    if($c_cat&&$cats){$vals=array();foreach($cats as $kv){$vals[]=$kv;$eq=strpos($kv,'=');if($eq!==false){$vals[]=substr($kv,$eq+1);}}$ph=array();$i=0;foreach(array_values(array_unique($vals)) as $v){$k=':c'.$i++;$ph[]=$k;$bind[$k]=$v;}$conds[]=$Q($c_cat).' IN ('.implode(',',$ph).')';}
    $bb=isset($p['bbox'])&&is_array($p['bbox'])?$p['bbox']:array();
    $hasbb=$c_lat&&$c_lon&&isset($bb['south'],$bb['north'],$bb['west'],$bb['east']);
    if($hasbb){$conds[]=$Q($c_lat).' BETWEEN :s AND :n AND '.$Q($c_lon).' BETWEEN :w AND :e';}
    $lim=isset($p['limit'])?max(1,min(2000,(int)$p['limit'])):200;
    $sql=$sel.($conds?(' WHERE '.implode(' AND ',$conds)):'').' LIMIT '.$lim;
    $st=$db->prepare($sql);
    if(!$st){$db->close();return array('rows'=>array(),'db_total'=>$tot,'mapped'=>$mapped,'err'=>'prepare_failed','sql'=>substr($sql,0,200));}
    foreach($bind as $k=>$v){$st->bindValue($k,$v,SQLITE3_TEXT);}
    if($hasbb){$st->bindValue(':s',(float)$bb['south'],SQLITE3_FLOAT);$st->bindValue(':n',(float)$bb['north'],SQLITE3_FLOAT);$st->bindValue(':w',(float)$bb['west'],SQLITE3_FLOAT);$st->bindValue(':e',(float)$bb['east'],SQLITE3_FLOAT);}
    $res=$st->execute();$rows=array();
    while($res&&($r=$res->fetchArray(SQLITE3_ASSOC))){$rows[]=$r;}
    $db->close();
    return array('rows'=>$rows,'db_total'=>$tot,'table'=>$pick,'matched'=>count($rows));
   }catch(\Throwable $e){return array('rows'=>array(),'db_total'=>0,'err'=>$e->getMessage());}
  case 'sitecrawl':
   // FULL DEEP CRAWL (up to 150 pages, same-domain BFS). Polite: robots-aware,
   // per-page pacing so one site is never hammered. $0 / code-only (no AI).
   $start=isset($p['url'])?$p['url']:'';
   if($start===''){return array('err'=>'no_url','pages'=>0);}
   $max=isset($p['max'])?max(1,min(150,(int)$p['max'])):150;
   $delay=isset($p['delay_ms'])?max(0,min(5000,(int)$p['delay_ms'])):800;
   $host=parse_url($start,PHP_URL_HOST);$scheme=parse_url($start,PHP_URL_SCHEME)?:'https';
   if(!$host){return array('err'=>'bad_url','pages'=>0);}
   $root=$scheme.'://'.$host;
   $dis=array();list($rc,$rb)=fetch_url($root.'/robots.txt',8);
   if($rc>=200&&$rc<400&&$rb){$cur='';foreach(preg_split('/\r?\n/',$rb) as $ln){$ln=trim($ln);if($ln===''||$ln[0]==='#')continue;if(preg_match('/^user-agent:\s*(.+)$/i',$ln,$m)){$cur=strtolower(trim($m[1]));}elseif(($cur==='*'||$cur==='tuanibot')&&preg_match('/^disallow:\s*(.+)$/i',$ln,$m)){$d=trim($m[1]);if($d!==''&&$d!=='/')$dis[]=$d;}}}
   $allowed=function($path)use($dis){foreach($dis as $d){if(strpos($path,$d)===0)return false;}return true;};
   $seen=array();$queue=array($start);$emails=array();$phones=array();$plat='';$pages=0;$mk=0;$blob='';$pdfs=array();$soc=array();$faq=0;$content='';$services=array();$hours='';
   while($queue&&$pages<$max){
    $u=array_shift($queue);$un=strtok($u,'#');if(isset($seen[$un]))continue;$seen[$un]=1;
    $path=parse_url($un,PHP_URL_PATH);if($path===null||$path===false||$path==='')$path='/';
    if(!$allowed($path))continue;
    list($code,$html)=fetch_url($un,15);$pages++;
    if($code<200||$code>=400||$html===''){if($delay)usleep($delay*1000);continue;}
    $low=strtolower($html);if(strlen($blob)<400000)$blob.=' '.$low;
    // P6/P8 CONTENT HARVEST: cache readable text from content-bearing pages + detect FAQ.
    $pl=strtolower($path);
    if(strlen($content)<9000&&(preg_match('/(about|service|faq|team|provider|staff|menu|pricing|price|hour|contact|blog|news|story|insurance|location)/',$pl)||$pages<=2)){
     $txt=preg_replace('#<(script|style|noscript)[^>]*>.*?</\\1>#is',' ',$html);
     $txt=preg_replace('/<[^>]+>/',' ',$txt);$txt=preg_replace('/\s+/',' ',html_entity_decode($txt,ENT_QUOTES));
     $content.=' '.trim(substr($txt,0,2400));
    }
    if(strpos($pl,'faq')!==false||stripos($html,'frequently asked')!==false){$faq=1;}
    if(preg_match_all('#<li[^>]*>([^<]{4,64})</li>#i',$html,$lis)){foreach($lis[1] as $li){$li=trim(html_entity_decode($li,ENT_QUOTES));if($li!==''&&count($services)<40&&!in_array($li,$services,true)){$services[]=$li;}}}
    if($plat===''){if(strpos($low,'/wp-content/')!==false||strpos($low,'wp-json')!==false)$plat='wordpress';elseif(strpos($low,'cdn.shopify')!==false||strpos($low,'x-shopify')!==false)$plat='shopify';elseif(strpos($low,'wixstatic')!==false)$plat='wix';elseif(strpos($low,'squarespace')!==false)$plat='squarespace';elseif(strpos($low,'website-files.com')!==false)$plat='webflow';}
    if(preg_match_all('/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}/i',$html,$em)){foreach(array_unique($em[0]) as $e){if(!preg_match('/\.(png|jpe?g|gif|svg|webp|js|css)$/i',$e)&&stripos($e,'example.')===false&&stripos($e,'sentry')===false&&stripos($e,'wixpress')===false){$el=strtolower($e);if(!in_array($el,$emails,true))$emails[]=$el;}if(count($emails)>=12)break;}}
    if(preg_match_all('/href=["\x27]tel:([+0-9().\s-]{7,20})/i',$html,$tm)){foreach(array_unique($tm[1]) as $t){$t=trim($t);if($t!==''&&!in_array($t,$phones,true))$phones[]=$t;if(count($phones)>=6)break;}}
    if(preg_match_all('/href=["\x27]([^"\x27#]+)["\x27]/i',$html,$lm)){
     foreach($lm[1] as $href){
      if(preg_match('/^(mailto:|tel:|javascript:|data:|#)/i',$href))continue;
      if(strpos($href,'//')===0)$href=$scheme.':'.$href;elseif(isset($href[0])&&$href[0]==='/')$href=$root.$href;elseif(!preg_match('#^https?://#i',$href))$href=$root.'/'.ltrim($href,'/');
      $hh=parse_url($href,PHP_URL_HOST);
      if(preg_match('#(facebook|instagram|linkedin|youtube|twitter|tiktok|yelp|pinterest|x)\.[a-z]#i',(string)$hh)){$sk=preg_replace('/\..*/','',preg_replace('/^www\./','',(string)$hh));if($sk!==''&&!isset($soc[$sk])&&count($soc)<10){$soc[$sk]=$hn;}}
      if(preg_match('/\.pdf($|\?)/i',$href)){if(count($pdfs)<25&&!in_array($hn,$pdfs,true)){$pdfs[]=$hn;}}
      if($hh!==$host)continue;
      if(preg_match('/\.(jpe?g|png|gif|svg|webp|pdf|zip|mp4|mp3|css|js|ico|woff2?|ttf|eot|xml|rss)($|\?)/i',$href))continue;
      $hn=strtok($href,'#');if(!isset($seen[$hn])&&count($queue)<$max*3)$queue[]=$hn;
     }
    }
    if($delay)usleep($delay*1000);
   }
   if(preg_match('/(chat-?bubble|chatbox|chat-?launcher|live-?chat|data-chat|messenger)/i',$blob)){$mk=2;}
   if(preg_match('/((mon|tue|wed|thu|fri|sat|sun)[a-z]*\s*[:–\-]?\s*\d{1,2}(:\d{2})?\s*(am|pm)?[\s\S]{0,30}?(am|pm))/i',$content,$hm)){$hours=trim(substr($hm[1],0,80));}
   return array('pages'=>$pages,'emails'=>array_slice($emails,0,12),'phones'=>array_slice($phones,0,6),'platform'=>$plat,'chat_markers'=>$mk,'host'=>$host,'robots_disallow'=>count($dis),'pdfs'=>$pdfs,'socials'=>array_values($soc),'faq'=>$faq,'services'=>array_slice($services,0,40),'hours'=>$hours,'content'=>substr($content,0,9000),'kb_chars'=>strlen($content));
  case 'shot':
   // SELF-HOSTED SCREENSHOT (headless Chromium) + framable verdict. $0 / we own it.
   $u=isset($p['url'])?$p['url']:'';$pid=isset($p['prospect'])?(int)$p['prospect']:0;
   if($u===''||$pid<=0){return array('note'=>'shot:no_url');}
   if(!function_exists('shell_exec')){return array('shot'=>'no_shell','framable'=>1);}
   $framable=1;
   $ch=curl_init($u);curl_setopt_array($ch,array(CURLOPT_HEADER=>true,CURLOPT_RETURNTRANSFER=>true,CURLOPT_FOLLOWLOCATION=>true,CURLOPT_MAXREDIRS=>3,CURLOPT_TIMEOUT=>15,CURLOPT_USERAGENT=>'Mozilla/5.0 (compatible; TuaniBot/1.0)'));
   $resp=(string)curl_exec($ch);$hsize=(int)curl_getinfo($ch,CURLINFO_HEADER_SIZE);curl_close($ch);
   $hdr=strtolower(substr($resp,0,$hsize));
   if(preg_match('/x-frame-options:\s*(deny|sameorigin)/',$hdr)){$framable=0;}
   if(preg_match('/content-security-policy:[^\n]*frame-ancestors/',$hdr)&&!preg_match('/frame-ancestors[^;\n]*\*/',$hdr)){$framable=0;}
   // IFRAME-FIRST: if the site PERMITS framing, the demo shows a live iframe
   // (primary) — skip the screenshot entirely (we won't display it). Only
   // non-framable sites need a screenshot (plan B).
   if($framable){ api('shot',array('token'=>$token,'prospect'=>$pid,'framable'=>1,'img'=>'')); return array('shot'=>'framable_iframe','framable'=>1,'prospect'=>$pid); }
   $png='/tmp/tncshot_'.$pid.'.png';$jpg='/tmp/tncshot_'.$pid.'.jpg';@unlink($png);@unlink($jpg);
   $chrome='';foreach(array('chromium-headless','chromium','chromium-browser','google-chrome-stable','google-chrome','chrome','headless-chromium') as $c){$w=trim((string)@shell_exec('command -v '.$c.' 2>/dev/null'));if($w){$chrome=$w;break;}}
   $bin='';
   if($chrome!==''){
    @shell_exec(escapeshellarg($chrome).' --headless --disable-gpu --no-sandbox --hide-scrollbars --force-device-scale-factor=1 --window-size=1000,700 --screenshot='.escapeshellarg($png).' --timeout=20000 '.escapeshellarg($u).' 2>/dev/null');
    if(is_file($png)){
     $conv=trim((string)@shell_exec('command -v convert 2>/dev/null'));
     if($conv!==''){@shell_exec(escapeshellarg($conv).' '.escapeshellarg($png).' -resize 1280x900^ -gravity north -extent 1280x900 -quality 72 '.escapeshellarg($jpg).' 2>/dev/null');if(is_file($jpg)){$bin=(string)file_get_contents($jpg);}}
     if($bin===''){$bin=(string)file_get_contents($png);}
    }
   }
   if($bin===''){$wk=trim((string)@shell_exec('command -v wkhtmltoimage 2>/dev/null'));if($wk!==''){@shell_exec(escapeshellarg($wk).' --width 1000 --height 700 --quality 62 -f jpg '.escapeshellarg($u).' '.escapeshellarg($jpg).' 2>/dev/null');if(is_file($jpg)){$bin=(string)file_get_contents($jpg);}}}
   @unlink($png);@unlink($jpg);
   $img=$bin!==''?base64_encode($bin):'';
   // DIRECT upload of the image (single small POST to the proven /fleet/shot
   // endpoint). The job RESULT stays tiny (no image through Redis/bridge) so it
   // never chokes the results channel.
   $up=api('shot',array('token'=>$token,'prospect'=>$pid,'framable'=>$framable,'img'=>$img));
   $stored=(is_array($up)&&!empty($up['stored']))?1:0;
   return array('shot'=>($img!==''?'captured':'no_capture'),'stored'=>$stored,'bytes'=>strlen($bin),'framable'=>$framable,'chrome'=>($chrome!==''?'1':'0'),'prospect'=>$pid);
  case 'everify':
   // TRIPLE-VALIDATION LAYER 3: SMTP RCPT probe. Connect the MX, ask if the
   // mailbox exists. 250/251=deliverable, 550/551/553=hard-no, else unknown
   // (greylisting etc. — never treated as a hard fail). $0 / no AI.
   $em=strtolower(trim(isset($p['email'])?$p['email']:''));$pid=isset($p['prospect'])?(int)$p['prospect']:0;
   if(!$em||strpos($em,'@')===false){return array('everify'=>'bad_input');}
   $dom=substr(strrchr($em,'@'),1);$mxs=array();
   if(function_exists('getmxrr')){@getmxrr($dom,$mxs,$wts);if($mxs&&isset($wts)){array_multisort($wts,$mxs);}}
   if(!$mxs){$mxs=array($dom);}
   $verdict='unknown';$detail='';
   foreach(array_slice($mxs,0,2) as $mx){
    $fp=@fsockopen($mx,25,$en,$es,8);if(!$fp){continue;}
    stream_set_timeout($fp,8);
    $rd=function()use($fp){$o='';while(($l=fgets($fp,512))!==false){$o.=$l;if(strlen($l)<4||$l[3]!=='-'){break;}}return $o;};
    $rd();fputs($fp,"EHLO mail.lionclickmedia.com\r\n");$rd();
    fputs($fp,"MAIL FROM:<probe@lionclickmedia.com>\r\n");$rd();
    fputs($fp,"RCPT TO:<".$em.">\r\n");$r=$rd();
    fputs($fp,"QUIT\r\n");fclose($fp);
    $cd=(int)substr($r,0,3);$detail=trim(substr($r,0,80));
    if($cd===250||$cd===251){$verdict='ok';break;}
    if($cd===550||$cd===551||$cd===553){$verdict='no';break;}
    $verdict='soft';break;
   }
   return array('everify'=>$verdict,'detail'=>$detail,'email'=>$em,'prospect'=>$pid);
  default: return array('note'=>'unknown job type, reported for brain-side handling');
 }}
$WBUILD='__TNC_WBUILD__';
$lasthit=array();$beat=0;$idle=0;$rfail=0;$alerted=false;
$use_redis=($redis&&rconn());
if($use_redis){
 while(true){
  if(rcmd('SETEX','tnc:hb:'.$worker,'90','1')===null){$rfail++;rdrop();}else{$rfail=0;}
  if($rfail>=3){ // Redis dropped: ALERT the brain once, then fall to direct mode (never silent).
   api('heartbeat',array('token'=>$token,'node'=>$node,'lanes'=>(int)(getenv('TNC_LANES')?:1),'meta'=>'v2-redis-down/'.$WBUILD));
   $alerted=true;rdrop();$use_redis=false;break;
  }
  $j=rcmd('BLPOP','tnc:jobs','5');
  if($j===null){$rfail++;rdrop();continue;}
  if(is_array($j)&&isset($j[1])){
   $job=json_decode($j[1],true);
   if(is_array($job)&&isset($job['id'])){
    $h=isset($job['payload']['url'])?parse_url($job['payload']['url'],PHP_URL_HOST):'';
    if($h&&isset($lasthit[$h])&&(microtime(true)-$lasthit[$h])<1.2){usleep(1200000);}
    $data=run_job($job);if($h){$lasthit[$h]=microtime(true);}
    if(rcmd('LPUSH','tnc:results',json_encode(array('job_id'=>$job['id'],'success'=>true,'data'=>$data)))===null){
     // Redis died after we did the work — deliver the result directly so it is never lost.
     api('result',array('token'=>$token,'job_id'=>$job['id'],'success'=>true,'data'=>$data));
    }
   }
  }
 }
}
if(!$use_redis){
 api('register',array('token'=>$token,'node'=>$node,'lanes'=>(int)(getenv('TNC_LANES')?:1),'meta'=>($alerted?'v2-direct-fallback/':'v2/').$WBUILD));
 while(true){
  if((time()-$beat)>30){api('heartbeat',array('token'=>$token,'node'=>$node,'lanes'=>(int)(getenv('TNC_LANES')?:1),'meta'=>($alerted?'v2-direct-fallback/':'v2/').$WBUILD));$beat=time();
   if($redis&&rconn()){ // Redis is back — reconnect into bridge mode.
    $alerted=false;$rfail=0;$use_redis=true;
   }}
  if($use_redis){break;} // hand control back to the redis loop on next process restart.
  $r=api('pull',array('token'=>$token,'node'=>$node,'worker'=>$worker,'n'=>3));
  $jobs=!empty($r['jobs'])?$r['jobs']:array();
  if($jobs){$idle=0;
   foreach($jobs as $job){
    $h=isset($job['payload']['url'])?parse_url($job['payload']['url'],PHP_URL_HOST):'';
    if($h&&isset($lasthit[$h])&&(microtime(true)-$lasthit[$h])<1.2){usleep(1200000);}
    api('renew',array('token'=>$token,'job_id'=>$job['id']));
    $data=run_job($job);if($h){$lasthit[$h]=microtime(true);}
    api('result',array('token'=>$token,'job_id'=>$job['id'],'success'=>true,'data'=>$data));
   }
  }else{$idle=min($idle+1,4);$base=array(4,4,8,16,30);sleep($base[$idle]+random_int(0,3));}
 }
}
PHPEOF

echo "== [4/7] Bridge daemon (brain <-> Redis, batched) =="
cat > "$DIR/bridge.php" <<'PHPEOF'
<?php
/* TuaniChat bridge: keeps the local Redis buffer fed (batch pulls, 300s lease),
 * flushes results in batches, sends ONE aggregated node heartbeat. */
$brain=getenv('TNC_BRAIN');$token=getenv('TNC_TOKEN');$node=getenv('TNC_NODE')?:'fleet-node';
function rconn(){static $s=null;if($s)return $s;$s=@fsockopen('127.0.0.1',6379,$e,$m,3);if($s&&getenv('TNC_REDIS_PASS')){fwrite($s,"*2\r\n\$4\r\nAUTH\r\n\$".strlen(getenv('TNC_REDIS_PASS'))."\r\n".getenv('TNC_REDIS_PASS')."\r\n");fgets($s);}return $s;}
function rcmd(){$a=func_get_args();$s=rconn();if(!$s)return null;$o='*'.count($a)."\r\n";foreach($a as $p){$o.='$'.strlen($p)."\r\n".$p."\r\n";}fwrite($s,$o);return rread($s);}
function rread($s){$l=fgets($s);if($l===false)return null;$t=$l[0];$l=trim(substr($l,1));
 if($t==='+'||$t===':')return $l;if($t==='-')return null;
 if($t==='$'){$n=(int)$l;if($n<0)return null;$d=stream_get_contents($s,$n+2);return substr($d,0,$n);}
 if($t==='*'){$n=(int)$l;$r=array();for($i=0;$i<$n;$i++){$r[]=rread($s);}return $r;}return null;}
function api($op,$body){global $brain,$token;$url=$brain.$op;
 foreach($body as $k=>$v){if(!is_array($v)&&strlen((string)$v)<=200){$url.='&'.rawurlencode($k).'='.rawurlencode($v);}}
 $ch=curl_init($url);curl_setopt_array($ch,array(CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>json_encode($body),
  CURLOPT_HTTPHEADER=>array('Content-Type: application/json','X-TNC-Token: '.$token),
  CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>30,CURLOPT_USERAGENT=>'Mozilla/5.0 (compatible; TuaniFleet/2.0)'));
 $out=curl_exec($ch);curl_close($ch);return json_decode((string)$out,true);}
$beat=0;
while(true){
 $alive=rcmd('KEYS','tnc:hb:*');$lanes=is_array($alive)?count($alive):0;
 if((time()-$beat)>25){api('heartbeat',array('token'=>$token,'node'=>$node,'lanes'=>$lanes,'meta'=>'v2-bridge'));$beat=time();}
 // flush results — SIZE-AWARE: batch small results, but post any large
 // (image-bearing) result on its OWN POST so it never blows post_max_size.
 $small=array();$did=0;
 for($i=0;$i<50;$i++){$r=rcmd('RPOP','tnc:results');if($r===null)break;$d=json_decode($r,true);if(!$d)continue;$did++;
  if(strlen($r)>40000){ if($small){api('results',array('token'=>$token,'items'=>json_encode($small)));$small=array();} api('results',array('token'=>$token,'items'=>json_encode(array($d)))); }
  else{ $small[]=$d; if(count($small)>=20){api('results',array('token'=>$token,'items'=>json_encode($small)));$small=array();} }
 }
 if($small){api('results',array('token'=>$token,'items'=>json_encode($small)));}
 $items=$did?array(1):array();
 // keep the buffer fed: target 2 jobs per live worker
 $buf=(int)rcmd('LLEN','tnc:jobs');
 if($lanes>0&&$buf<$lanes*2){
  $r=api('pull',array('token'=>$token,'node'=>$node,'worker'=>'bridge-'.$node,'n'=>25,'lease'=>300));
  if(!empty($r['jobs'])){foreach($r['jobs'] as $j){rcmd('LPUSH','tnc:jobs',json_encode($j));}}
  elseif(!$items){sleep(4);}
 }
 usleep(700000);
}
PHPEOF

cat > "$DIR/fleet.env" <<ENVEOF
TNC_BRAIN=$BRAIN
TNC_TOKEN=$TOKEN
TNC_NODE=$NODE
TNC_LANES=$WORKERS
TNC_POI_DB=${TNC_POI_DB:-/opt/tuanichat-osm/poi.db}
$([ $REDIS_OK -eq 1 ] && echo "TNC_REDIS=127.0.0.1:6379")
$([ $REDIS_OK -eq 1 ] && [ -n "$REDIS_PASS" ] && echo "TNC_REDIS_PASS=$REDIS_PASS")
ENVEOF
chmod 600 "$DIR/fleet.env"

echo "== [5/7] systemd units =="
cat > /etc/systemd/system/tnc-fleet@.service <<UNITEOF
[Unit]
Description=TuaniChat fleet worker %i
After=network-online.target
[Service]
EnvironmentFile=$DIR/fleet.env
Environment=TNC_WORKER=%i
ExecStart=$PHPBIN $DIR/worker.php
Restart=always
RestartSec=5
Nice=10
[Install]
WantedBy=multi-user.target
UNITEOF
if [ $REDIS_OK -eq 1 ]; then
cat > /etc/systemd/system/tnc-bridge.service <<UNITEOF
[Unit]
Description=TuaniChat fleet bridge (brain <-> local Redis)
After=network-online.target redis.service
[Service]
EnvironmentFile=$DIR/fleet.env
ExecStart=$PHPBIN $DIR/bridge.php
Restart=always
RestartSec=5
[Install]
WantedBy=multi-user.target
UNITEOF
fi
systemctl daemon-reload

echo "== [6/7] Starting $WORKERS workers $([ $REDIS_OK -eq 1 ] && echo '+ bridge') =="
# DURABLE FIX: kill ANY worker process still running OLD code so every instance
# respawns onto the worker.php we just wrote (systemd Restart=always brings them
# back). Without this, a re-run can leave stale workers serving old job logic.
pkill -f "$DIR/worker.php" 2>/dev/null || true
sleep 1
i=1
while [ "$i" -le "$WORKERS" ]; do
  systemctl enable "tnc-fleet@$i" >/dev/null 2>&1
  systemctl restart "tnc-fleet@$i" >/dev/null 2>&1
  i=$((i+1))
done
# Prune instances ABOVE the requested count (left over from a larger prior run).
for u in $(systemctl list-units 'tnc-fleet@*' --all --no-legend 2>/dev/null | awk '{print $1}'); do
  num=$(echo "$u" | sed 's/[^0-9]//g')
  if [ -n "$num" ] && [ "$num" -gt "$WORKERS" ]; then
    systemctl stop "$u" >/dev/null 2>&1; systemctl disable "$u" >/dev/null 2>&1
  fi
done
[ $REDIS_OK -eq 1 ] && { systemctl enable tnc-bridge >/dev/null 2>&1; systemctl restart tnc-bridge >/dev/null 2>&1; }

echo "== [6b/7] Self-updater (no more manual re-runs) =="
echo "$WBUILD" > "$DIR/build.txt"
cat > "$DIR/updater.sh" <<UPDEOF
#!/bin/bash
# TuaniChat fleet SELF-UPDATER (hardened): polls the brain for the current code
# version; on change, integrity-checks the new code, backs up last-known-good,
# applies it, health-checks, and AUTO-ROLLS-BACK if the new build fails — so a
# bad build can never take the fleet down. Heartbeats itself (watchdog) + logs
# every update to the brain. Future code changes deploy with ZERO manual SSH.
DIR="$DIR"; TOKEN="$TOKEN"; REST="$REST"; W="$WORKERS"; PHPBIN="$PHPBIN"; NODE="$NODE"
log(){ curl -s --max-time 15 -H "X-TNC-Token: \$TOKEN" -H "Content-Type: application/json" -d "{\"node\":\"\$NODE\",\"event\":\"\$1\",\"from\":\"\$2\",\"to\":\"\$3\"}" "\$REST/update-log" >/dev/null 2>&1; }
health(){ local r; r=\$(systemctl list-units 'tnc-fleet@*' --state=running --no-legend 2>/dev/null | wc -l); [ "\$r" -ge 1 ] || return 1; "\$PHPBIN" -l "\$DIR/worker.php" >/dev/null 2>&1 || return 1; return 0; }
while true; do
  # WATCHDOG: prove the updater is alive every cycle.
  curl -s --max-time 15 -H "X-TNC-Token: \$TOKEN" "\$REST/heartbeat?node=\$NODE&meta=updater-alive" >/dev/null 2>&1
  LOCAL=\$(cat "\$DIR/build.txt" 2>/dev/null || echo none)
  REMOTE=\$(curl -fsS --max-time 20 "\$REST/version?t=\$TOKEN" 2>/dev/null | sed -n 's/.*"wbuild":"\([^"]*\)".*/\1/p')
  if [ -n "\$REMOTE" ] && [ "\$REMOTE" != "\$LOCAL" ]; then
    log "start" "\$LOCAL" "\$REMOTE"
    NEW=\$(curl -fsSL --max-time 60 "\$REST/bootstrap?t=\$TOKEN&cb=\$(date +%s)" 2>/dev/null | base64 -d 2>/dev/null)
    # INTEGRITY: must look like our bootstrap + be non-trivial in size.
    if echo "\$NEW" | grep -q "FLEET BOOTSTRAP" && [ \$(echo "\$NEW" | wc -c) -gt 4000 ]; then
      # LAST-KNOWN-GOOD backup before swap.
      cp -f "\$DIR/worker.php" "\$DIR/worker.php.lkg" 2>/dev/null
      cp -f "\$DIR/bridge.php" "\$DIR/bridge.php.lkg" 2>/dev/null
      echo "\$NEW" | bash -s -- "\$TOKEN" "\$W" > "\$DIR/last-bootstrap.log" 2>&1
      CMETA=\$(grep -c "installed" "\$DIR/last-bootstrap.log" 2>/dev/null || echo 0)
      curl -s --max-time 15 -H "X-TNC-Token: \$TOKEN" "\$REST/heartbeat?node=guardian&meta=bootstrap-components-\$CMETA" >/dev/null 2>&1
      sleep 20
      if health; then
        echo "\$REMOTE" > "\$DIR/build.txt"; log "success" "\$LOCAL" "\$REMOTE"
        curl -s --max-time 15 -H "X-TNC-Token: \$TOKEN" "\$REST/heartbeat?node=\$NODE&meta=updated-\$REMOTE" >/dev/null 2>&1
      else
        # AUTO-ROLLBACK to last-known-good.
        [ -f "\$DIR/worker.php.lkg" ] && cp -f "\$DIR/worker.php.lkg" "\$DIR/worker.php"
        [ -f "\$DIR/bridge.php.lkg" ] && cp -f "\$DIR/bridge.php.lkg" "\$DIR/bridge.php"
        pkill -f "\$DIR/worker.php" 2>/dev/null
        i=1; while [ "\$i" -le "\$W" ]; do systemctl restart "tnc-fleet@\$i" >/dev/null 2>&1; i=\$((i+1)); done
        systemctl restart tnc-bridge >/dev/null 2>&1
        log "rollback" "\$REMOTE" "\$LOCAL"
        curl -s --max-time 15 -H "X-TNC-Token: \$TOKEN" "\$REST/heartbeat?node=\$NODE&meta=rolled-back-from-\$REMOTE" >/dev/null 2>&1
      fi
    else
      log "integrity-fail" "\$LOCAL" "\$REMOTE"
    fi
  fi
  sleep 180
done
UPDEOF
chmod +x "$DIR/updater.sh"
chmod +x "$DIR/updater.sh"
cat > /etc/systemd/system/tnc-updater.service <<UNITEOF
[Unit]
Description=TuaniChat fleet self-updater
After=network-online.target
[Service]
ExecStart=/bin/bash $DIR/updater.sh
Restart=always
RestartSec=10
[Install]
WantedBy=multi-user.target
UNITEOF
systemctl daemon-reload
systemctl enable tnc-updater >/dev/null 2>&1
# START (not restart) so a bootstrap triggered BY the updater never kills the in-flight update.
systemctl is-active --quiet tnc-updater || systemctl start tnc-updater >/dev/null 2>&1

sleep 5

echo "== [6b2/7] One-time stale-queue flush (zombie payload copies) =="
if [ ! -f "$DIR/.qflush-1203" ]; then
  RPASS=$(grep -o 'requirepass [^ ]*' /etc/redis.conf /etc/redis/redis.conf 2>/dev/null | head -1 | awk '{print $2}')
  if [ -n "$RPASS" ]; then redis-cli -a "$RPASS" DEL tnc:jobs >/dev/null 2>&1; else redis-cli DEL tnc:jobs >/dev/null 2>&1; fi
  touch "$DIR/.qflush-1203"; echo "  local job queue flushed"
fi
echo "== [6c/7] COMPONENT AUTO-DEPLOY (zero-SSH: brain-hosted daemons) =="
# The brain hosts deployable components; this phase pulls + installs them as
# root. New components ship via a plugin update + build bump — NO user SSH.
pip3 install -q websocket-client 2>/dev/null || pip3 install -q --break-system-packages websocket-client 2>/dev/null || true
for COMP in lic-hunter ct-hunter; do
  CDIR="/opt/tuanichat-$COMP"; mkdir -p "$CDIR"
  curl -fsS --max-time 60 "$REST/component?name=$COMP&t=$TOKEN" 2>/dev/null | base64 -d > "$CDIR/$COMP.py.new" 2>/dev/null
  if [ ! -s "$CDIR/$COMP.py.new" ]; then echo "  $COMP: fetch FAILED (skipping)"; curl -s --max-time 15 -H "X-TNC-Token: $TOKEN" "$REST/heartbeat?node=guardian&meta=fetch-failed-$COMP" >/dev/null 2>&1; rm -f "$CDIR/$COMP.py.new"; continue; fi

  if ! grep -q "TuaniChat" "$CDIR/$COMP.py.new" 2>/dev/null; then echo "  $COMP: integrity FAILED"; rm -f "$CDIR/$COMP.py.new"; continue; fi
  mv -f "$CDIR/$COMP.py.new" "$CDIR/$COMP.py"; chmod +x "$CDIR/$COMP.py"
  curl -s --max-time 15 -H "X-TNC-Token: $TOKEN" "$REST/heartbeat?node=guardian&meta=installed-$COMP" >/dev/null 2>&1
  if [ "$COMP" = "lic-hunter" ]; then
    cat > /etc/systemd/system/tnc-lic.service <<'LICEOF'
[Unit]
Description=TuaniChat licensing-board lead puller (auto-deployed)
[Service]
Type=oneshot
ExecStart=/usr/bin/python3 /opt/tuanichat-lic-hunter/lic-hunter.py
LICEOF
    cat > /etc/systemd/system/tnc-lic.timer <<'LICTEOF'
[Unit]
Description=Nightly licensing-board pull
[Timer]
OnBootSec=3min
OnCalendar=*-*-* 03:30:00
Persistent=true
[Install]
WantedBy=timers.target
LICTEOF
    systemctl daemon-reload; systemctl enable --now tnc-lic.timer >/dev/null 2>&1
    systemctl start tnc-lic.service >/dev/null 2>&1 &   # fire first pull NOW (async)
    sleep 2; systemctl is-active tnc-lic.timer >/dev/null 2>&1 && curl -s --max-time 15 -H "X-TNC-Token: $TOKEN" "$REST/heartbeat?node=lic-hunter&meta=timer-active" >/dev/null 2>&1
    echo "  lic-hunter: installed + first pull started"
  else
    cat > /etc/systemd/system/tnc-ct.service <<'CTEOF'
[Unit]
Description=TuaniChat Fresh-Launch Radar (CertStream, auto-deployed)
After=network-online.target
[Service]
ExecStart=/usr/bin/python3 /opt/tuanichat-ct-hunter/ct-hunter.py
Restart=always
RestartSec=10
[Install]
WantedBy=multi-user.target
CTEOF
    systemctl daemon-reload; systemctl enable tnc-ct.service >/dev/null 2>&1
    systemctl restart tnc-ct.service >/dev/null 2>&1
    sleep 2; systemctl is-active tnc-ct.service >/dev/null 2>&1 && curl -s --max-time 15 -H "X-TNC-Token: $TOKEN" "$REST/heartbeat?node=ct-hunter&meta=service-active" >/dev/null 2>&1 || curl -s --max-time 15 -H "X-TNC-Token: $TOKEN" "$REST/heartbeat?node=guardian&meta=ct-hunter-FAILED-$(journalctl -u tnc-ct -n1 --no-pager -o cat 2>/dev/null | tr -cd 'a-zA-Z0-9._-' | tail -c 60)" >/dev/null 2>&1
    echo "  ct-hunter: installed + streaming"
  fi
done
echo "== [6c2/7] Migration Phase 1 (zero-SSH read-only parity) =="
if [ ! -f /opt/tuanichat-mig/.phase1-done ]; then
  curl -fsS --max-time 60 "$REST/component?name=mig-phase1&t=$TOKEN" 2>/dev/null | base64 -d > /opt/tuanichat-mig-phase1.py 2>/dev/null
  if grep -q "TuaniChat" /opt/tuanichat-mig-phase1.py 2>/dev/null; then
    TNC_TOKEN="$TOKEN" TNC_REST="$REST" python3 /opt/tuanichat-mig-phase1.py >/opt/tuanichat-mig.log 2>&1 &
    echo "  mig-phase1: launched (read-only parity, reports to dashboard)"
  fi
fi
echo "== [6d/7] Screenshot capture binary (plan-B renders) =="
if ! command -v chromium >/dev/null 2>&1 && ! command -v chromium-browser >/dev/null 2>&1 && ! command -v google-chrome >/dev/null 2>&1 && ! command -v wkhtmltoimage >/dev/null 2>&1; then
  ( yum -y install chromium 2>/dev/null || apt-get -y install chromium-browser 2>/dev/null || apt-get -y install chromium 2>/dev/null ) >/dev/null 2>&1
  if command -v chromium >/dev/null 2>&1 || command -v chromium-browser >/dev/null 2>&1 || command -v wkhtmltoimage >/dev/null 2>&1; then
    echo "  capture binary: INSTALLED"
  else
    echo "  capture binary: NOT AVAILABLE via package manager (shots stay iframe-first; screenshots skipped)"
    curl -s --max-time 15 -H "X-TNC-Token: $TOKEN" "$REST/heartbeat?node=$NODE&meta=no-capture-binary" >/dev/null 2>&1
  fi
else
  echo "  capture binary: present"
fi
echo "== [6e/7] A.T.L.A.S./J.A.R.V.I.S. engine install (GATED, snapshot+verify, stop-on-fail) =="
if [ ! -f /opt/tuanichat-jarvis/.installed ]; then
  HB(){ curl -s --max-time 15 -H "X-TNC-Token: $TOKEN" "$REST/heartbeat?node=atlas-install&meta=$1" >/dev/null 2>&1; }
  LOG(){ curl -s --max-time 15 -H "X-TNC-Token: $TOKEN" -H "Content-Type: application/json" -d "{\"node\":\"atlas-install\",\"event\":\"$1\",\"from\":\"$2\",\"to\":\"$3\"}" "$REST/update-log" >/dev/null 2>&1; }
  # ---- PRE-SNAPSHOT (record state we must NOT disturb) ----
  SNAP_REDIS=$(systemctl is-active redis 2>/dev/null || echo unknown)
  SNAP_POI=$([ -f /opt/tuanichat-osm/poi.db ] && echo present || echo absent)
  SNAP_NODE=$(node -v 2>/dev/null || echo none)
  LOG "preinstall-snapshot" "redis=$SNAP_REDIS poi=$SNAP_POI" "node=$SNAP_NODE"
  echo "  snapshot: redis=$SNAP_REDIS poi=$SNAP_POI node=$SNAP_NODE"
  # ---- INSTALL engines only if missing (root; apt or yum) ----
  if ! command -v node >/dev/null 2>&1 || [ "$(node -v 2>/dev/null | sed 's/v\([0-9]*\).*/\1/')" -lt 18 ] 2>/dev/null; then
    ( curl -fsSL https://rpm.nodesource.com/setup_20.x 2>/dev/null | bash - && yum install -y nodejs ) >/dev/null 2>&1 || \
    ( curl -fsSL https://deb.nodesource.com/setup_20.x 2>/dev/null | bash - && apt-get install -y nodejs ) >/dev/null 2>&1 || \
    ( yum install -y nodejs >/dev/null 2>&1 || apt-get install -y nodejs >/dev/null 2>&1 )
  fi
  if ! command -v psql >/dev/null 2>&1; then
    ( yum install -y postgresql-server postgresql >/dev/null 2>&1 ) || ( apt-get install -y postgresql >/dev/null 2>&1 )
  fi
  # ---- POST-VERIFY (must-pass: node>=18, redis untouched, poi intact) ----
  NODEV=$(node -v 2>/dev/null | sed 's/v\([0-9]*\).*/\1/'); NODEV=${NODEV:-0}
  NOW_REDIS=$(systemctl is-active redis 2>/dev/null || echo unknown)
  NOW_POI=$([ -f /opt/tuanichat-osm/poi.db ] && echo present || echo absent)
  FAIL=""
  [ "$NODEV" -ge 18 ] 2>/dev/null || FAIL="node<18($NODEV)"
  [ "$SNAP_REDIS" != "active" ] || [ "$NOW_REDIS" = "active" ] || FAIL="redis-disturbed"
  [ "$SNAP_POI" != "present" ] || [ "$NOW_POI" = "present" ] || FAIL="poi-missing"
  if [ -n "$FAIL" ]; then
    LOG "install-verify-FAILED" "$FAIL" "STOP-no-cascade"
    echo "  VERIFY FAILED: $FAIL — stopping engine phase, nothing further touched."
  else
    LOG "install-verify-pass" "node=$NODEV redis=$NOW_REDIS" "poi=$NOW_POI"
    # ---- POSTGRES bring-up + ramp (graceful: only if psql present + ramp provided) ----
    PGOK=no
    if command -v psql >/dev/null 2>&1; then
      ( [ -x /usr/bin/postgresql-setup ] && postgresql-setup --initdb >/dev/null 2>&1 ); systemctl enable --now postgresql >/dev/null 2>&1
      sleep 3
      if (command -v pg_isready >/dev/null 2>&1 && pg_isready -p 5432 >/dev/null 2>&1) || ss -ltn 2>/dev/null | grep -q ':5432'; then PGOK=yes; fi
      if [ "$PGOK" = yes ]; then
        sudo -u postgres psql -tc "SELECT 1 FROM pg_database WHERE datname='tuanichat_atlas'" 2>/dev/null | grep -q 1 || sudo -u postgres createdb tuanichat_atlas >/dev/null 2>&1
        RAMP=$(curl -fsS --max-time 30 "$REST/ramp?t=$TOKEN" 2>/dev/null)
        if [ -n "$RAMP" ] && echo "$RAMP" | grep -qi "create\|insert\|alter"; then echo "$RAMP" | sudo -u postgres psql -d tuanichat_atlas >/dev/null 2>&1 && LOG "ramp-applied" "atlas" "ok"; else LOG "ramp-deferred" "no-sql-served" "skip"; fi
      fi
    fi
    [ "$PGOK" = yes ] && HB "postgres-5432-up" || HB "postgres-deferred"
    # ---- JARVIS module (zero-dep node) as managed systemd service ----
    mkdir -p /opt/tuanichat-jarvis
    curl -fsS --max-time 60 "$REST/jarvis-bundle?t=$TOKEN" 2>/dev/null | base64 -d > /opt/tuanichat-jarvis/bundle.tar.gz 2>/dev/null
    if [ -s /opt/tuanichat-jarvis/bundle.tar.gz ]; then
      tar xzf /opt/tuanichat-jarvis/bundle.tar.gz -C /opt/tuanichat-jarvis 2>/dev/null
      cat > /etc/systemd/system/tnc-jarvis.service <<JVEOF
[Unit]
Description=TuaniChat J.A.R.V.I.S. Intelligence Core
After=network-online.target
[Service]
WorkingDirectory=/opt/tuanichat-jarvis
Environment=JARVIS_MODE=live
Environment=PORT=8787
Environment=TNC_BRAIN=$REST
Environment=TNC_TOKEN=$TOKEN
ExecStart=/usr/bin/node /opt/tuanichat-jarvis/src/server.js
Restart=always
RestartSec=10
[Install]
WantedBy=multi-user.target
JVEOF
      systemctl daemon-reload; systemctl enable --now tnc-jarvis >/dev/null 2>&1; sleep 2
      if systemctl is-active tnc-jarvis >/dev/null 2>&1; then
        touch /opt/tuanichat-jarvis/.installed; LOG "jarvis-service-up" "node=$NODEV" "active"; HB "jarvis-active"
        echo "  jarvis: tnc-jarvis.service ACTIVE"
      else
        LOG "jarvis-service-FAILED" "$(journalctl -u tnc-jarvis -n1 --no-pager -o cat 2>/dev/null | tr -cd 'a-zA-Z0-9._ -' | tail -c 50)" "stopped"
        echo "  jarvis: service failed to start (logged, no cascade)"
      fi
    else
      LOG "jarvis-bundle-FAILED" "empty-fetch" "-"
    fi
  fi
fi
echo "== [7/7] Self-check =="
RUNNING=$(systemctl list-units 'tnc-fleet@*' --state=running --no-legend 2>/dev/null | wc -l)
HB=$(curl -s -A "Mozilla/5.0 (compatible; TuaniFleet/2.0)" -H "X-TNC-Token: $TOKEN" "${BRAIN}heartbeat&node=$NODE&lanes=$WORKERS&meta=v2")
echo "   Workers running: $RUNNING / $WORKERS   Bridge: $([ $REDIS_OK -eq 1 ] && systemctl is-active tnc-bridge || echo n/a)"
echo "   Brain heartbeat: $HB"
echo "   Load: $(cat /proc/loadavg | cut -d' ' -f1-3)   RAM: $(free -m | awk '/Mem:/{printf "%s/%sMB", $3, $2}')"
if [ "$RUNNING" -ge 1 ] && echo "$HB" | grep -q '"ok":true'; then
  echo "SUCCESS: fleet v2 online ($([ $REDIS_OK -eq 1 ] && echo 'Redis bridge mode' || echo 'direct mode'))."
else
  echo "PARTIAL: journalctl -u tnc-fleet@1 -n 30"
fi

EOS;
	}

	/** Shared fleet secret, generated once. Read it via GET /admin/fleet. */
	public static function token() {
		$t = (string) get_option( 'tnc_fleet_token' );
		if ( '' === $t ) {
			$t = wp_generate_password( 40, false );
			update_option( 'tnc_fleet_token', $t, false );
		}
		return $t;
	}

	/** Token from custom header (WAF-safe) OR query param (t/token) fallback. */
	private static function req_token( $req ) {
		if ( isset( $_SERVER['HTTP_X_TNC_TOKEN'] ) ) {
			return sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_TNC_TOKEN'] ) );
		}
		$t = (string) $req->get_param( 'token' );
		return '' !== $t ? $t : (string) $req->get_param( 't' );
	}

	private static function auth( $req ) {
		return hash_equals( self::token(), self::req_token( $req ) );
	}

	private static function table() {
		global $wpdb;
		return $wpdb->prefix . 'tnc_fleet_jobs';
	}

	/** Legacy reader kept ONLY for one-time migration in maybe_upgrade(). */
	public static function migrate_option_jobs() {
		global $wpdb;
		$old = get_option( 'tnc_fleet_jobs', array() );
		if ( is_array( $old ) && $old ) {
			foreach ( $old as $j ) {
				if ( isset( $j['status'] ) && 'queued' === $j['status'] ) {
					$wpdb->insert( self::table(), array(
						'job_key' => $j['id'], 'job_type' => $j['type'], 'priority' => 5,
						'payload' => wp_json_encode( $j['payload'] ), 'status' => 'queued',
						'created' => isset( $j['created'] ) ? (int) $j['created'] : time(),
					) );
				}
			}
		}
		delete_option( 'tnc_fleet_jobs' );
	}

	/** Brain-side enqueue (table queue; lower priority number = served LAST — default 5, discovery 7, deep-enrich 3). */
	public static function enqueue( $type, $payload, $priority = 5 ) {
		global $wpdb;
		$id = 'j' . wp_rand( 100000, 999999 ) . dechex( time() % 65536 );
		$wpdb->insert( self::table(), array(
			'job_key'  => $id,
			'job_type' => sanitize_key( $type ),
			'priority' => max( 1, min( 9, (int) $priority ) ),
			'payload'  => wp_json_encode( $payload ),
			'status'   => 'queued',
			'created'  => time(),
		) );
		return $id;
	}

	/** Diagnostics: most-recent jobs of a type, with truncated result. */
	/** ONE-TIME graveyard resurrection: dead shot/sitecrawl/enrich jobs died to
	 * the short-lease bug, not bad jobs. Requeue them once with fresh tries now
	 * that per-type leases are correct. Safe to call repeatedly (option flag). */
	public static function resurrect_dead( $flag = 'tnc_dead_resurrected_1185' ) {
		if ( get_option( $flag ) ) { return 0; }
		global $wpdb;
		$n = $wpdb->query( "UPDATE " . self::table() . " SET status='queued', tries=0, worker='', lease_until=0 WHERE status='dead' AND job_type IN ('shot','sitecrawl','enrich','poi_query')" );
		update_option( $flag, time(), false );
		return (int) $n;
	}

	public static function recent_jobs( $type, $n = 3 ) {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare(
			'SELECT job_key, status, tries, worker, result, created, done_at FROM ' . self::table() .
			' WHERE job_type = %s ORDER BY id DESC LIMIT %d', sanitize_key( $type ), (int) $n ), ARRAY_A );
		$out = array();
		foreach ( (array) $rows as $r ) {
			$out[] = array(
				'job'    => $r['job_key'],
				'status' => $r['status'],
				'tries'  => (int) $r['tries'],
				'worker' => $r['worker'],
				'result' => is_string( $r['result'] ) ? substr( $r['result'], 0, 900 ) : null,
				'age'    => $r['created'] ? ( time() - (int) $r['created'] ) : null,
			);
		}
		return $out;
	}

	public static function register( $req ) {
		if ( ! self::auth( $req ) ) {
			return new WP_Error( 'tnc_auth', 'Bad token.', array( 'status' => 403 ) );
		}
		self::touch_node( $req );
		return rest_ensure_response( array( 'ok' => true, 'brain' => home_url(), 'lease_ttl' => self::LEASE_TTL ) );
	}

	/** Atomically claim queued jobs from the table (re-queueing dead leases first). */
	public static function pull( $req ) {
		if ( ! self::auth( $req ) ) {
			return new WP_Error( 'tnc_auth', 'Bad token.', array( 'status' => 403 ) );
		}
		self::touch_node( $req );
		global $wpdb;
		$tbl  = self::table();
		$now  = time();
		$want = max( 1, min( 25, (int) $req->get_param( 'n' ) ) );
		$wkr  = sanitize_text_field( (string) $req->get_param( 'worker' ) );
		// SELF-HEAL: dead leases back to queued (fail-fast cap at 3 tries).
		$wpdb->query( $wpdb->prepare( "UPDATE $tbl SET status = IF(tries >= 3, 'dead', 'queued'), worker = '' WHERE status = 'leased' AND lease_until < %d", $now ) );
		// Atomic claim: stamp rows with a unique marker, then read them back.
		$ttl  = max( self::LEASE_TTL, min( 600, (int) $req->get_param( 'lease' ) ) );
		$mark = 'c' . $wkr . '-' . wp_rand( 1000, 9999 );
		$wpdb->query( $wpdb->prepare(
			"UPDATE $tbl SET status = 'leased', worker = %s, lease_until = %d, tries = tries + 1 WHERE status = 'queued' ORDER BY priority DESC, id ASC LIMIT %d",
			$mark, $now + $ttl, $want
		) );
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT job_key, job_type, payload FROM $tbl WHERE worker = %s AND status = 'leased'", $mark ), ARRAY_A );
		if ( $rows ) {
			$wpdb->query( $wpdb->prepare( "UPDATE $tbl SET worker = %s WHERE worker = %s", $wkr, $mark ) );
			// PER-TYPE LEASE TTL (root-cause fix for the dead-job graveyard): in
			// bridge mode workers can't renew leases (only the bridge talks to the
			// brain), and slow jobs (150-page sitecrawl, chrome screenshots) sit in
			// local Redis far past a short lease -> blind requeue x3 -> dead. Give
			// slow types leases that match their real runtime.
			$wpdb->query( $wpdb->prepare(
				"UPDATE $tbl SET lease_until = %d + (CASE job_type WHEN 'sitecrawl' THEN 1800 WHEN 'shot' THEN 900 WHEN 'enrich' THEN 600 ELSE 300 END) WHERE worker = %s AND status = 'leased'",
				$now, $wkr
			) );
		}
		$mine = array();
		foreach ( (array) $rows as $r ) {
			$mine[] = array( 'id' => $r['job_key'], 'type' => $r['job_type'], 'payload' => json_decode( (string) $r['payload'], true ) );
		}
		return rest_ensure_response( array( 'ok' => true, 'jobs' => $mine, 'job' => $mine ? $mine[0] : null ) );
	}

	public static function renew( $req ) {
		if ( ! self::auth( $req ) ) {
			return new WP_Error( 'tnc_auth', 'Bad token.', array( 'status' => 403 ) );
		}
		global $wpdb;
		// HARD LEASE-AGE CAP: a renew can never immortalize a job. Anything still
		// leased 2h after creation is lost work — it expires and the pull-time
		// sweep reclaims it instantly (requeue, then dead after 3 tries). This
		// makes the zombie-queue class of stall structurally impossible.
		$wpdb->query( $wpdb->prepare(
			'UPDATE ' . self::table() . " SET lease_until = %d WHERE job_key = %s AND status = 'leased' AND created > %d",
			time() + self::LEASE_TTL, sanitize_text_field( (string) $req->get_param( 'job_id' ) ), time() - 2 * HOUR_IN_SECONDS
		) );
		return rest_ensure_response( array( 'ok' => true ) );
	}

	public static function result( $req ) {
		if ( ! self::auth( $req ) ) {
			return new WP_Error( 'tnc_auth', 'Bad token.', array( 'status' => 403 ) );
		}
		self::store_result( sanitize_text_field( (string) $req->get_param( 'job_id' ) ), (bool) $req->get_param( 'success' ), $req->get_param( 'data' ) );
		return rest_ensure_response( array( 'ok' => true ) );
	}

	/** Batch results from the Redis bridge: one POST flushes many job results. */
	public static function results_batch( $req ) {
		if ( ! self::auth( $req ) ) {
			return new WP_Error( 'tnc_auth', 'Bad token.', array( 'status' => 403 ) );
		}
		$items = $req->get_param( 'items' );
		if ( is_string( $items ) ) {
			$items = json_decode( wp_unslash( $items ), true );
		}
		$n = 0;
		foreach ( (array) $items as $it ) {
			if ( ! empty( $it['job_id'] ) ) {
				self::store_result( sanitize_text_field( $it['job_id'] ), ! empty( $it['success'] ), isset( $it['data'] ) ? $it['data'] : null );
				$n++;
			}
		}
		return rest_ensure_response( array( 'ok' => true, 'stored' => $n ) );
	}

	/** Persist a self-hosted screenshot (base64 JPEG) for a prospect + framable verdict. Returns stored URL or ''. */
	public static function save_shot( $pid, $b64, $framable = null ) {
		$pid = (int) $pid;
		if ( $pid <= 0 || ! class_exists( 'TNC_Prospects' ) ) { return ''; }
		$p = TNC_Prospects::get( $pid );
		if ( ! $p ) { return ''; }
		$cd = is_array( $p['crawl_data'] ) ? $p['crawl_data'] : array();
		if ( ! isset( $cd['extracted'] ) || ! is_array( $cd['extracted'] ) ) { $cd['extracted'] = array(); }
		if ( null !== $framable ) { $cd['extracted']['framable'] = (bool) (int) $framable; }
		$url = '';
		if ( is_string( $b64 ) && '' !== $b64 ) {
			$bin = base64_decode( $b64, true );
			if ( false !== $bin && strlen( $bin ) > 3000 ) {
				$up  = wp_upload_dir();
				$dir = trailingslashit( $up['basedir'] ) . 'tnc-shots';
				if ( ! is_dir( $dir ) ) { wp_mkdir_p( $dir ); }
				if ( false !== file_put_contents( $dir . '/p' . $pid . '.jpg', $bin ) ) { // phpcs:ignore
					$url = trailingslashit( $up['baseurl'] ) . 'tnc-shots/p' . $pid . '.jpg';
					$cd['extracted']['screenshot_local'] = $url;
					$cd['extracted']['shot_ts'] = time();
				}
			}
		}
		TNC_Prospects::update( $pid, array( 'crawl_data' => wp_json_encode( $cd ) ) );
		if ( ! get_option( 'tnc_cap_shot' ) ) { update_option( 'tnc_cap_shot', 1, false ); }
		if ( '' !== $url ) {
			$hr = (int) floor( time() / 3600 ); $u = get_option( 'tnc_lh_shot_up', array() );
			$n = ( is_array( $u ) && isset( $u['hr'] ) && (int) $u['hr'] === $hr ) ? (int) $u['n'] + 1 : 1;
			update_option( 'tnc_lh_shot_up', array( 'hr' => $hr, 'n' => $n ), false );
		}
		return $url;
	}

	private static function store_result( $job_key, $ok, $data ) {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT id, job_type, payload, tries FROM ' . self::table() . ' WHERE job_key = %s', $job_key ), ARRAY_A );
		if ( ! $row ) {
			return;
		}
		// Legacy v1 workers answer unknown types with a note — re-queue those so
		// v2 agents (or the brain fallback) pick them up instead of losing them.
		$is_unknown = is_array( $data ) && isset( $data['note'] ) && false !== strpos( (string) $data['note'], 'unknown job type' );
		$status     = $ok && ! $is_unknown ? 'done' : ( (int) $row['tries'] >= 3 ? 'dead' : 'queued' );
		$wpdb->update( self::table(), array(
			'status'  => $status,
			'result'  => wp_json_encode( $data ),
			'done_at' => 'done' === $status ? time() : 0,
		), array( 'id' => (int) $row['id'] ) );
		// PUSH-BASED COMPLETION: enrich results flow straight into Lead Hunter.
		if ( 'done' === $status && 'enrich' === $row['job_type'] && class_exists( 'TNC_Leadhunter' ) ) {
			$payload = json_decode( (string) $row['payload'], true );
			if ( is_array( $payload ) && ! empty( $payload['prospect'] ) ) {
				try {
					TNC_Leadhunter::ingest_enrich_result( (int) $payload['prospect'], is_array( $data ) ? $data : array() );
				} catch ( \Throwable $e ) {
					update_option( 'tnc_watchdog_err', 'ingest_enrich: ' . $e->getMessage(), false );
				}
			}
		}
		// Capability discovery: a real sitecrawl result proves the fleet runs the
		// new worker (so the brain can safely mass-enqueue deep crawls).
		if ( 'done' === $status && 'sitecrawl' === $row['job_type'] && is_array( $data ) && isset( $data['pages'] ) ) {
			if ( ! get_option( 'tnc_cap_sitecrawl' ) ) { update_option( 'tnc_cap_sitecrawl', 1, false ); }
		}
		// PUSH-BASED COMPLETION: self-hosted screenshot delivered via the results
		// channel (reliable in bridge mode) -> store it + set framable.
		if ( 'done' === $status && 'shot' === $row['job_type'] && is_array( $data ) && ! empty( $data['prospect'] ) ) {
			try { self::save_shot( (int) $data['prospect'], isset( $data['img'] ) ? (string) $data['img'] : '', isset( $data['framable'] ) ? $data['framable'] : null ); }
			catch ( \Throwable $e ) { update_option( 'tnc_watchdog_err', 'save_shot: ' . $e->getMessage(), false ); }
		}
		// PUSH-BASED COMPLETION: deep site crawl -> enrich the prospect record.
		if ( 'done' === $status && 'sitecrawl' === $row['job_type'] && class_exists( 'TNC_Leadhunter' ) ) {
			$payload = json_decode( (string) $row['payload'], true );
			if ( is_array( $payload ) && ! empty( $payload['prospect'] ) ) {
				try { TNC_Leadhunter::ingest_sitecrawl_result( (int) $payload['prospect'], is_array( $data ) ? $data : array() ); }
				catch ( \Throwable $e ) { update_option( 'tnc_watchdog_err', 'ingest_sitecrawl: ' . $e->getMessage(), false ); }
			}
		}
		// TRIPLE-VALIDATION: SMTP probe verdicts flow back into the prospect.
		if ( 'done' === $status && 'everify' === $row['job_type'] && is_array( $data ) && class_exists( 'TNC_Leadhunter' ) ) {
			try { TNC_Leadhunter::ingest_everify_result( $data ); }
			catch ( \Throwable $e ) { update_option( 'tnc_watchdog_err', 'everify: ' . $e->getMessage(), false ); }
		}
		// PUSH-BASED COMPLETION: local POI-DB discovery results -> shared staging.
		if ( 'done' === $status && 'poi_query' === $row['job_type'] && class_exists( 'TNC_Leadhunter' ) ) {
			$payload = json_decode( (string) $row['payload'], true );
			try {
				TNC_Leadhunter::ingest_poi_result( is_array( $payload ) ? $payload : array(), is_array( $data ) ? $data : array() );
			} catch ( \Throwable $e ) {
				update_option( 'tnc_watchdog_err', 'ingest_poi: ' . $e->getMessage(), false );
			}
		}
	}

	public static function heartbeat( $req ) {
		if ( ! self::auth( $req ) ) {
			return new WP_Error( 'tnc_auth', 'Bad token.', array( 'status' => 403 ) );
		}
		self::touch_node( $req );
		// LEAD HUNTER HEARTBEAT GUARDIAN: the discovery loop must NEVER stop.
		// Piggybacks on fleet heartbeats (seconds apart) so it runs even when
		// WP cron stalls. Throttled internally to once a minute.
		if ( class_exists( 'TNC_Leadhunter' ) ) {
			try { TNC_Leadhunter::guardian_tick(); } catch ( \Throwable $e ) { update_option( 'tnc_watchdog_err', 'lh_guardian: ' . $e->getMessage(), false ); }
		}
		return rest_ensure_response( array( 'ok' => true ) );
	}

	private static function touch_node( $req ) {
		$nodes = get_option( 'tnc_fleet_nodes', array() );
		if ( ! is_array( $nodes ) ) {
			$nodes = array();
		}
		$name = sanitize_text_field( (string) $req->get_param( 'node' ) );
		if ( '' === $name ) {
			return;
		}
		// LAST-KNOWN PRESERVATION (root cause of the cockpit 0-flicker): a
		// heartbeat that omits lanes/ppm (e.g. a bare cron curl) must NOT zero
		// the stored counts — absent param = keep last-known value.
		$prev  = isset( $nodes[ $name ] ) && is_array( $nodes[ $name ] ) ? $nodes[ $name ] : array();
		$lanes = $req->get_param( 'lanes' );
		$ppm   = $req->get_param( 'ppm' );
		$nodes[ $name ] = array(
			'last_seen' => time(),
			'lanes'     => null === $lanes || '' === $lanes ? ( isset( $prev['lanes'] ) ? (int) $prev['lanes'] : 0 ) : max( 0, (int) $lanes ),
			'ppm'       => null === $ppm || '' === $ppm ? ( isset( $prev['ppm'] ) ? (int) $prev['ppm'] : 0 ) : max( 0, (int) $ppm ),
			'meta'      => sanitize_text_field( (string) $req->get_param( 'meta' ) ),
		);
		if ( false !== strpos( (string) $req->get_param( 'meta' ), 'v2' ) ) {
			update_option( 'tnc_fleet_agent_v2', time(), false ); // v2 agents online -> fleet enrichment unlocks.
		}
		update_option( 'tnc_fleet_nodes', $nodes, false );
	}

	/**
	 * Cockpit snapshot: nodes + queue counts. Flips the panel live automatically.
	 * NO-FLICKER CONTRACT: a node keeps reporting its last-known lane count
	 * until it is truly OFFLINE (> NODE_OFFLINE). Stale dev nodes (test-local
	 * or anything silent > NODE_PRUNE) are removed from the list entirely.
	 */
	public static function status() {
		$nodes  = get_option( 'tnc_fleet_nodes', array() );
		$out    = array();
		$now    = time();
		$pruned = false;
		if ( ! is_array( $nodes ) ) {
			$nodes = array();
		}
		foreach ( $nodes as $name => $n ) {
			$age = $now - (int) $n['last_seen'];
			// PRUNE: legacy local test node + anything silent for > 24 h.
			if ( 'test-local' === $name || $age > self::NODE_PRUNE ) {
				unset( $nodes[ $name ] );
				$pruned = true;
				continue;
			}
			$state = $age < self::NODE_STALE ? 'online' : ( $age < self::NODE_OFFLINE ? 'stale' : 'offline' );
			$out[] = array(
				'node'   => $name,
				'age'    => $age,
				'online' => 'offline' !== $state,
				'state'  => $state,
				'lanes'  => (int) $n['lanes'],
				'ppm'    => (int) $n['ppm'],
			);
		}
		if ( $pruned ) {
			update_option( 'tnc_fleet_nodes', $nodes, false );
		}
		global $wpdb;
		$counts = array( 'queued' => 0, 'running' => 0, 'done' => 0, 'dead' => 0 );
		foreach ( (array) $wpdb->get_results( 'SELECT status, COUNT(*) n FROM ' . self::table() . ' GROUP BY status', ARRAY_A ) as $r ) {
			$k = 'leased' === $r['status'] ? 'running' : $r['status'];
			if ( isset( $counts[ $k ] ) ) {
				$counts[ $k ] += (int) $r['n'];
			}
		}
		$workers_total = 0;
		$ppm_total     = 0;
		$offline       = array();
		foreach ( $out as $n ) {
			if ( 'offline' !== $n['state'] ) {
				$workers_total += $n['lanes'];
				$ppm_total     += $n['ppm'];
			} else {
				$offline[] = $n['node'];
			}
		}
		return array(
			'nodes'         => $out,
			'jobs'          => $counts,
			'workers_total' => $workers_total,
			'ppm_total'     => $ppm_total,
			'offline_nodes' => $offline,
		);
	}

	/**
	 * FLEET-OFFLINE ALERT: heartbeat age > NODE_OFFLINE flags the node on the
	 * cockpit AND emails the notification address — once per offline episode;
	 * clears (with a recovery email) when it returns. Runs every minute from
	 * TNC_Workers::heartbeat().
	 */
	public static function check_alerts() {
		$nodes = get_option( 'tnc_fleet_nodes', array() );
		if ( ! is_array( $nodes ) ) {
			return;
		}
		$alerted = get_option( 'tnc_fleet_alerted', array() );
		if ( ! is_array( $alerted ) ) {
			$alerted = array();
		}
		$now     = time();
		$changed = false;
		$to      = TNC_Settings::recipients( 'system' );
		if ( empty( $to ) ) {
			$to = array( 'mike@lionclickmedia.com' );
		}
		foreach ( $nodes as $name => $n ) {
			if ( 'test-local' === $name ) {
				continue;
			}
			$age = $now - (int) $n['last_seen'];
			if ( $age > self::NODE_OFFLINE && empty( $alerted[ $name ] ) ) {
				$alerted[ $name ] = $now;
				$changed          = true;
				TNC_Emails::send(
					$to,
					'[TuaniChat ALERT] Fleet node OFFLINE: ' . $name,
					'<p><strong>Fleet node ' . esc_html( $name ) . ' has stopped heartbeating.</strong></p>'
					. '<p>Last heartbeat: ' . esc_html( round( $age / 60 ) ) . ' minutes ago &middot; last-known lanes: ' . (int) $n['lanes'] . '.</p>'
					. '<p>Its queued jobs re-lease automatically, but throughput is reduced until the node returns. '
					. 'Check the VPS: <code>systemctl list-units \'tnc-fleet@*\' --state=running</code></p>',
					'transactional'
				);
			} elseif ( $age <= self::NODE_OFFLINE && ! empty( $alerted[ $name ] ) ) {
				$down = $now - (int) $alerted[ $name ];
				unset( $alerted[ $name ] );
				$changed = true;
				TNC_Emails::send(
					$to,
					'[TuaniChat OK] Fleet node back ONLINE: ' . $name,
					'<p><strong>Fleet node ' . esc_html( $name ) . ' is heartbeating again</strong> (was flagged offline ~' . esc_html( round( $down / 60 ) ) . ' min).</p>',
					'transactional'
				);
			}
		}
		if ( $changed ) {
			update_option( 'tnc_fleet_alerted', $alerted, false );
		}
	}
}

/** Minimal request shim so admin-ajax can reuse the REST handlers unchanged. */
class TNC_Fleet_Req {
	private $json = null;
	/** ROOT-CAUSE FIX (23h stall): the bridge/worker POST results as a JSON body
	 * (Content-Type: application/json), which PHP does NOT put into $_REQUEST.
	 * Only params <=200 chars were duplicated into the URL — so every substantive
	 * result (POI rows, emails, crawls) decoded to null, was acked ok:true, and
	 * destroyed. This class now parses the JSON body like WP_REST_Request does. */
	public function get_param( $k ) {
		if ( isset( $_REQUEST[ $k ] ) ) { return wp_unslash( $_REQUEST[ $k ] ) ; } // phpcs:ignore WordPress.Security.NonceVerification
		if ( null === $this->json ) {
			$raw        = file_get_contents( 'php://input' );
			$this->json = is_string( $raw ) && '' !== $raw ? json_decode( $raw, true ) : array();
			if ( ! is_array( $this->json ) ) { $this->json = array(); }
		}
		return isset( $this->json[ $k ] ) ? $this->json[ $k ] : null;
	}
	public function get_method() {
		return isset( $_SERVER['REQUEST_METHOD'] ) ? strtoupper( (string) $_SERVER['REQUEST_METHOD'] ) : 'GET';
	}
}
