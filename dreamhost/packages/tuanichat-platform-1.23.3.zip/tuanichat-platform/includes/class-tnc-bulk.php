<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Bulk Demo Generation: CSV import → staggered WP-Cron queue → results/export.
 * One crawl at a time, staggered, so the host and target sites are never hammered.
 */
class TNC_Bulk {

	const HOOK     = 'tnc_bulk_tick';
	const MAX_ROWS = 200;

	public static function init() {
		add_action( self::HOOK, array( __CLASS__, 'tick' ), 10, 2 );
	}

	public static function lanes() {
		return max( 1, min( 3, (int) TNC_Settings::get( 'bulk_lanes', 2 ) ) );
	}

	/** Acquire a free crawl lane (transient lock). Returns lane number or 0. */
	private static function acquire_lane() {
		for ( $i = 1; $i <= self::lanes(); $i++ ) {
			if ( ! get_transient( 'tnc_bulk_lane_' . $i ) ) {
				set_transient( 'tnc_bulk_lane_' . $i, time(), 4 * MINUTE_IN_SECONDS );
				return $i;
			}
		}
		return 0;
	}

	public static function stagger() {
		return max( 30, min( 900, (int) TNC_Settings::get( 'bulk_stagger', 150 ) ) );
	}

	private static function host_of( $url ) {
		$h = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
		return preg_replace( '/^www\./', '', $h );
	}

	/** Existing prospect domains for dedupe. */
	private static function existing_hosts() {
		global $wpdb;
		$urls  = $wpdb->get_col( 'SELECT website_url FROM ' . TNC_Prospects::table() );
		$hosts = array();
		foreach ( $urls as $u ) {
			$h = self::host_of( $u );
			if ( $h ) {
				$hosts[ $h ] = true;
			}
		}
		return $hosts;
	}

	/**
	 * Import normalized rows. Each: company_name, website_url, industry, contact_name, contact_email.
	 * Returns: batch_id, created, skipped (dupes), invalid[] (row + reason).
	 */
	public static function import( $rows ) {
		if ( ! is_array( $rows ) || empty( $rows ) ) {
			return new WP_Error( 'tnc_bulk', 'No rows to import.' );
		}
		$rows     = array_slice( $rows, 0, self::MAX_ROWS );
		$existing = self::existing_hosts();
		$batch_id = 'b' . gmdate( 'ymdHis' ) . wp_rand( 100, 999 );
		$created  = 0;
		$skipped  = 0;
		$invalid  = array();

		foreach ( $rows as $i => $row ) {
			$company = isset( $row['company_name'] ) ? sanitize_text_field( $row['company_name'] ) : '';
			$url     = isset( $row['website_url'] ) ? trim( (string) $row['website_url'] ) : '';
			if ( '' !== $url && ! preg_match( '#^https?://#i', $url ) ) {
				$url = 'https://' . $url;
			}
			$url  = esc_url_raw( $url );
			$host = self::host_of( $url );
			if ( ! $host || false === strpos( $host, '.' ) ) {
				$invalid[] = array( 'row' => $i + 1, 'company' => $company, 'reason' => 'Invalid website URL' );
				continue;
			}
			if ( isset( $existing[ $host ] ) ) {
				$skipped++;
				continue;
			}
			$existing[ $host ] = true; // in-file dedupe too.

			$id = TNC_Prospects::create( array(
				'company_name'  => $company ? $company : $host,
				'website_url'   => $url,
				'industry'      => isset( $row['industry'] ) ? $row['industry'] : 'other',
				'contact_name'  => isset( $row['contact_name'] ) ? $row['contact_name'] : '',
				'contact_email' => isset( $row['contact_email'] ) ? $row['contact_email'] : '',
				'status'        => 'queued',
			) );
			if ( is_wp_error( $id ) ) {
				$invalid[] = array( 'row' => $i + 1, 'company' => $company, 'reason' => $id->get_error_message() );
				continue;
			}
			TNC_Prospects::update( $id, array( 'batch_id' => $batch_id ) );
			$created++;
		}

		if ( $created > 0 ) {
			update_option( 'tnc_batch_' . $batch_id, array(
				'id'       => $batch_id,
				'total'    => $created,
				'notified' => 0,
				'started'  => current_time( 'mysql' ),
			), false );
			update_option( 'tnc_last_batch', $batch_id, false );
			wp_schedule_single_event( time() + 2, self::HOOK, array( $batch_id, wp_rand() ) );
			if ( self::lanes() > 1 && $created > 1 ) {
				wp_schedule_single_event( time() + 4, self::HOOK, array( $batch_id, wp_rand() ) ); // second lane.
			}
			spawn_cron();
			// True concurrency: fire one loopback worker per lane immediately.
			$spawn_n = min( self::lanes(), $created );
			for ( $i = 0; $i < $spawn_n; $i++ ) {
				TNC_Workers::spawn( 'bulk', array( 'batch' => $batch_id ) );
			}
		}

		return array(
			'batch_id' => $created > 0 ? $batch_id : '',
			'created'  => $created,
			'skipped'  => $skipped,
			'invalid'  => $invalid,
		);
	}

	/** Cron: process ONE queued prospect per lane, then schedule the next tick (staggered). */
	public static function tick( $batch_id, $seq = 0 ) {
		global $wpdb;
		$batch_id = sanitize_key( $batch_id );
		$state    = get_option( 'tnc_batch_' . $batch_id );
		if ( ! is_array( $state ) ) {
			return;
		}

		// Lane lock: at most N prospect crawls run concurrently platform-wide.
		$lane = self::acquire_lane();
		if ( ! $lane ) {
			wp_schedule_single_event( time() + 45, self::HOOK, array( $batch_id, wp_rand() ) );
			return;
		}
		$lock = 'tnc_bulk_lane_' . $lane;

		$next_id = (int) $wpdb->get_var( $wpdb->prepare(
			'SELECT id FROM ' . TNC_Prospects::table() . " WHERE batch_id = %s AND status = 'queued' ORDER BY id ASC LIMIT 1",
			$batch_id
		) );

		if ( ! $next_id ) {
			delete_transient( $lock );
			self::maybe_finalize( $batch_id, $state );
			return;
		}

		// Atomic claim — prevents two lanes grabbing the same row.
		$claimed = $wpdb->query( $wpdb->prepare(
			'UPDATE ' . TNC_Prospects::table() . " SET status = 'crawling', crawl_state = 'running' WHERE id = %d AND status = 'queued'",
			$next_id
		) );
		if ( ! $claimed ) {
			delete_transient( $lock );
			wp_schedule_single_event( time() + 5, self::HOOK, array( $batch_id, wp_rand() ) );
			return;
		}

		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 280 );
		}
		set_transient( $lock, time(), 4 * MINUTE_IN_SECONDS ); // refresh lane lease.

		$p       = TNC_Prospects::get( $next_id );
		$crawler = new TNC_Crawler();
		$crawl   = $crawler->crawl( $p['website_url'], 'demo' );

		if ( is_wp_error( $crawl ) ) {
			TNC_Prospects::update( $next_id, array(
				'status'      => 'error',
				'crawl_state' => 'failed',
				'last_error'  => sanitize_text_field( $crawl->get_error_message() ),
			) );
		} else {
			TNC_KB::ingest_crawl( $next_id, $crawl );
			$crawl['pages'] = array_keys( $crawl['pages'] ); // KB has the content — keep the row light.
			$updates = array(
				'crawl_data'  => wp_json_encode( $crawl ),
				'platform'    => $crawl['platform'],
				'crawl_state' => 'done',
				'status'      => 'demo_created',
				'last_error'  => '',
			);
			if ( empty( $p['company_name'] ) && ! empty( $crawl['extracted']['company_name'] ) ) {
				$updates['company_name'] = $crawl['extracted']['company_name'];
			}
			TNC_Prospects::update( $next_id, $updates );

			$p2 = TNC_Prospects::get( $next_id );
			list( $score, $breakdown ) = TNC_Outreach::score( $p2 );
			TNC_Prospects::update( $next_id, array( 'score' => $score, 'score_breakdown' => wp_json_encode( $breakdown ) ) );

			// Outreach kit: FREE template engine by default (zero AI cost).
			$kit = TNC_Outreach::template_kit( TNC_Prospects::get( $next_id ) );
			if ( is_wp_error( $kit ) ) { // non-fatal: demo is still ready.
				TNC_Prospects::update( $next_id, array( 'last_error' => 'Outreach templates: ' . sanitize_text_field( $kit->get_error_message() ) ) );
			}
			// Smart starter questions — AI, only if a key is configured.
			if ( '' !== TNC_Settings::get( 'api_key' ) ) {
				TNC_Outreach::generate_starters( TNC_Prospects::get( $next_id ) );
			}
		}

		delete_transient( $lock );

		// More queued? Stagger the next crawl. Otherwise finalize.
		$remaining = (int) $wpdb->get_var( $wpdb->prepare(
			'SELECT COUNT(*) FROM ' . TNC_Prospects::table() . " WHERE batch_id = %s AND status = 'queued'",
			$batch_id
		) );
		if ( $remaining > 0 ) {
			wp_schedule_single_event( time() + self::stagger(), self::HOOK, array( $batch_id, wp_rand() ) );
		} else {
			self::maybe_finalize( $batch_id, get_option( 'tnc_batch_' . $batch_id ) );
		}
	}

	private static function maybe_finalize( $batch_id, $state ) {
		if ( ! is_array( $state ) || ! empty( $state['notified'] ) ) {
			return;
		}
		$counts = self::batch_counts( $batch_id );
		if ( $counts['queued'] > 0 || $counts['crawling'] > 0 ) {
			return; // still working.
		}
		$state['notified'] = 1;
		$state['finished'] = current_time( 'mysql' );
		update_option( 'tnc_batch_' . $batch_id, $state, false );

		$to = TNC_Settings::recipients( 'crawl' );
		if ( $to ) {
			TNC_Emails::send(
				$to,
				sprintf( '[TuaniChat] Batch complete — %d of %d demos ready%s', $counts['ready'], $counts['total'], $counts['errors'] ? ', ' . $counts['errors'] . ' errors' : '' ),
				TNC_Emails::batch_complete( $batch_id, $counts )
			);
		}
	}

	public static function batch_counts( $batch_id ) {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare(
			'SELECT status, COUNT(*) c FROM ' . TNC_Prospects::table() . ' WHERE batch_id = %s GROUP BY status',
			$batch_id
		), ARRAY_A );
		$out = array( 'total' => 0, 'ready' => 0, 'queued' => 0, 'crawling' => 0, 'errors' => 0 );
		foreach ( $rows as $r ) {
			$c = (int) $r['c'];
			$out['total'] += $c;
			if ( 'queued' === $r['status'] ) { $out['queued'] += $c; }
			elseif ( 'crawling' === $r['status'] ) { $out['crawling'] += $c; }
			elseif ( 'error' === $r['status'] ) { $out['errors'] += $c; }
			else { $out['ready'] += $c; }
		}
		return $out;
	}

	/** First "Subject:" line of the cold email, if present. */
	public static function cold_subject( $kit ) {
		if ( ! is_array( $kit ) || empty( $kit['cold_email'] ) ) {
			return '';
		}
		if ( preg_match( '/^\s*Subject:\s*(.+)$/mi', $kit['cold_email'], $m ) ) {
			return trim( $m[1] );
		}
		return '';
	}

	/** Rows for the results view / export. */
	public static function batch_rows( $batch_id ) {
		$prospects = TNC_Prospects::query( array( 'batch' => $batch_id ) );
		$rows      = array();
		foreach ( $prospects as $p ) {
			$kit    = is_array( $p['outreach_json'] ) ? $p['outreach_json'] : null;
			$rows[] = array(
				'id'            => $p['id'],
				'company_name'  => $p['company_name'],
				'website_url'   => $p['website_url'],
				'industry'      => $p['industry'],
				'contact_name'  => $p['contact_name'],
				'contact_email' => $p['contact_email'],
				'status'        => $p['status'],
				'platform'      => $p['platform'],
				'score'         => $p['score'],
				'last_error'    => isset( $p['last_error'] ) ? $p['last_error'] : '',
				'demo_url'      => $p['demo_slug'] ? home_url( '/demo/' . $p['demo_slug'] . '/' ) : '',
				'linkedin'      => $kit && ! empty( $kit['linkedin_message'] ) ? $kit['linkedin_message'] : '',
				'cold_subject'  => self::cold_subject( $kit ),
			);
		}
		return $rows;
	}

	/** Recent batches for the picker. */
	public static function recent_batches() {
		global $wpdb;
		$ids = $wpdb->get_col(
			'SELECT DISTINCT batch_id FROM ' . TNC_Prospects::table() . " WHERE batch_id <> '' ORDER BY id DESC LIMIT 10"
		);
		$out = array();
		foreach ( $ids as $bid ) {
			$c     = self::batch_counts( $bid );
			$state = get_option( 'tnc_batch_' . $bid );
			$out[] = array(
				'id'      => $bid,
				'started' => is_array( $state ) && isset( $state['started'] ) ? $state['started'] : '',
				'counts'  => $c,
			);
		}
		return $out;
	}
}
