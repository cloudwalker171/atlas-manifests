<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Email Previews: permanent admin gallery of every branded template rendered
 * live with sample data, plus "send me this one" / "send all" (staggered so
 * DreamHost mail is never burst-flagged). DESIGN-review tool — deliverability
 * comes later with Brevo.
 */
class TNC_Previews {

	const CRON = 'tnc_send_preview';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 11 );
		add_action( 'admin_post_tnc_send_preview', array( __CLASS__, 'handle_send' ) );
		add_action( self::CRON, array( __CLASS__, 'cron_send' ), 10, 2 );
	}

	public static function menu() {
		add_submenu_page( 'tnc-dashboard', 'Email Previews', 'Email Previews', 'manage_options', 'tnc-emails', array( __CLASS__, 'render_page' ) );
	}

	/** Sample prospects for the 10 target industries (real demo companies where they exist). */
	private static function industries() {
		return array(
			array( 'Legal (Personal Injury)', 'Dolman Law Group', 'AI Case Intake Assistant', 'car accidents, slip and fall, medical malpractice', 52 ),
			array( 'Dental', 'Bright Smile Dental Studio', 'AI Patient Intake Assistant', 'implants, Invisalign, emergency dentistry', 24 ),
			array( 'Med Spa', 'Glow Aesthetics Med Spa', 'AI Booking Assistant', 'Botox, laser facials, body contouring', 31 ),
			array( 'Plastic Surgery', 'Coastal Plastic Surgery', 'AI Consultation Assistant', 'rhinoplasty, breast augmentation, liposuction', 28 ),
			array( 'HVAC', 'Howard Air & Plumbing', 'AI Estimate Capture Assistant', 'AC repair, heating installs, plumbing', 50 ),
			array( 'Roofing', 'Summit Ridge Roofing', 'AI Estimate Capture Assistant', 'roof replacement, storm damage repair, inspections', 22 ),
			array( 'Solar', 'SunPeak Solar', 'AI Estimate Assistant', 'residential solar installs, battery storage, EV chargers', 19 ),
			array( 'Plumbing', 'BlueLine Plumbing', 'AI After-Hours Dispatcher', 'emergency plumbing, water heaters, repiping', 26 ),
			array( 'Real Estate', 'Harbor Realty Group', 'AI Lead Capture Assistant', 'home valuations, buyer tours, new listings', 35 ),
			array( 'Ecommerce', 'Madre Forte', 'AI Shopping Assistant', 'best-sellers, sizing help, shipping and returns', 20 ),
		);
	}

	/** First real prospect with a live demo. Previews must NEVER fabricate links. */
	private static function sample_prospect() {
		static $sp = false;
		if ( false === $sp ) {
			$sp = null;
			foreach ( TNC_Prospects::query( array() ) as $p ) {
				if ( ! empty( $p['demo_slug'] ) ) {
					$sp = $p;
					break;
				}
			}
		}
		return $sp;
	}

	/** A REAL clickable demo URL for previews (fix: fabricated sample slugs 404'd). */
	private static function sample_demo_url() {
		$sp = self::sample_prospect();
		return $sp ? home_url( '/demo/' . $sp['demo_slug'] . '/' ) : home_url( '/' );
	}

	/** Plain-text cold outreach sample (outreach is deliberately unbranded text). */
	private static function outreach_text( $ind ) {
		list( $label, $company, $assistant, $services, $pages ) = $ind;
		return "Subject: A working {$assistant} for {$company} (private demo inside)\n\n"
			. "Hi there,\n\n"
			. "I was on {$company}'s website and noticed there's no way for a visitor with a question at 9pm to get an answer. They bounce, usually to a competitor.\n\n"
			. "We built a working preview from {$pages} pages of your own website. It already answers real questions about {$services}.\n\n"
			. "It greets visitors, answers from your actual content, and hands you qualified leads 24/7.\n\n"
			. "See it live on your own site here (private link, just for you):\n"
			. self::sample_demo_url() . "\n\n"
			. "Worth two minutes. It is your website with the assistant already working.\n\n"
			. "The TuaniChat team\nTuaniLabs";
	}

	/**
	 * Presents plain-text mail as a clean email. INTERNAL ANNOTATIONS NEVER
	 * APPEAR HERE: anything explanatory lives in the gallery page chrome only,
	 * because this exact HTML is what gets sent.
	 */
	private static function plain_preview( $label, $text ) {
		return '<!doctype html><html><body style="margin:0;background:#FFFFFF;padding:24px;">'
			. '<div style="max-width:600px;margin:0 auto;font-family:Georgia,serif;font-size:14px;color:#1F2430;white-space:pre-wrap;line-height:1.7;">' . esc_html( $text ) . '</div>'
			. '</body></html>';
	}

	/** Full catalog: key => array( label, group ). */
	public static function catalog() {
		$cat = array();
		foreach ( self::industries() as $i => $ind ) {
			$cat[ 'outreach_' . $i ] = array( 'Cold outreach: ' . $ind[0], 'Outreach by industry' );
		}
		$cat['welcome']      = array( 'Welcome / thank you for signing up', 'Lifecycle' );
		$cat['anniv6']       = array( '6-month anniversary gratitude', 'Lifecycle' );
		$cat['anniv12']      = array( '1-year anniversary gratitude', 'Lifecycle' );
		$cat['lead']         = array( 'Packaged lead notification', 'Transactional' );
		$cat['speed']        = array( 'Speed-to-lead auto-reply (to the lead)', 'Transactional' );
		$cat['digest']       = array( 'Weekly digest', 'Lifecycle' );
		$cat['batch']        = array( 'Bulk batch complete report', 'System' );
		$cat['decision']     = array( 'Sitemap size decision alert (plain)', 'System' );
		return $cat;
	}

	/** Build one preview: returns array( subject, html ). */
	public static function build( $key ) {
		$r = self::build_raw( $key );
		return array( TNC_Emails::style_scrub( $r[0] ), TNC_Emails::style_scrub( $r[1] ) );
	}

	private static function build_raw( $key ) {
		$sp = self::sample_prospect();
		$co = $sp ? $sp['company_name'] : 'Howard Air & Plumbing';
		if ( 0 === strpos( $key, 'outreach_' ) ) {
			$inds = self::industries();
			$i    = (int) substr( $key, 9 );
			$ind  = isset( $inds[ $i ] ) ? $inds[ $i ] : $inds[0];
			return array( 'Cold outreach: ' . $ind[0], self::plain_preview( $ind[0], self::outreach_text( $ind ) ) );
		}
		switch ( $key ) {
			case 'welcome':
				return array( 'Welcome to TuaniChat', TNC_Emails::welcome( $co ) );
			case 'anniv6':
				return array( 'Thank you for 6 months with TuaniChat', TNC_Emails::anniversary( $co, 6, array( 'conversations' => 1184, 'leads' => 47, 'revenue' => 38500, 'after_hours' => 19 ) ) );
			case 'anniv12':
				return array( 'Thank you for 1 year with TuaniChat', TNC_Emails::anniversary( $co, 12, array( 'conversations' => 2630, 'leads' => 102, 'revenue' => 81250, 'after_hours' => 44 ) ) );
			case 'lead':
				$prospect = array( 'id' => $sp ? (int) $sp['id'] : 0, 'company_name' => $co, 'score' => 72, 'demo_slug' => $sp ? $sp['demo_slug'] : '' );
				$lead     = array( 'name' => 'Sarah Mitchell', 'email' => 'sarah.m@example.com', 'phone' => '(602) 555-0147', 'message' => 'AC stopped cooling this afternoon, two-story house in Scottsdale, would like someone out this week.' );
				return array( 'New lead: ' . $co . ', from Sarah Mitchell', TNC_Emails::lead_notification( $prospect, $lead ) );
			case 'speed':
				return array( 'We received your inquiry: ' . $co, TNC_Emails::speed_to_lead( 'Sarah', $co, 'AC not cooling, two-story home in Scottsdale, hoping for a visit this week. Urgency: high (summer heat).' ) );
			case 'digest':
				return array( 'Your weekly TuaniChat digest', TNC_Emails::weekly_digest( $co, array( 'period' => 'May 28 to Jun 4', 'conversations' => '86', 'leads' => '14', 'capture_rate' => '16%', 'after_hours' => '6', 'top_questions' => array( 'How much is an AC tune-up?', 'Do you offer weekend appointments?', 'Is my unit still under warranty?' ) ) ) );
			case 'batch':
				return array( 'Batch complete: 9 of 10 demos ready', TNC_Emails::batch_complete( 'b260605sample', array( 'total' => 10, 'ready' => 9, 'errors' => 1 ) ) );
			case 'decision':
				return array( 'Decision needed: Allbirds has 812 pages', self::plain_preview( 'System alert (plain text)', "The sitemap for https://www.allbirds.com lists ~812 pages, more than the 500-page cap.\n\nThe deep crawl is PAUSED until you choose:\n- Crawl top 500 (priority pages)\n- Crawl all 812\n- Cancel\n\nDecide here: " . admin_url( 'admin.php?page=tnc-prospects' ) ) );
		}
		return array( 'Unknown template', '<p>Unknown template.</p>' );
	}

	/** Send one preview now. */
	public static function cron_send( $key, $to ) {
		list( $subject, $html ) = self::build( sanitize_key( $key ) );
		$subject = TNC_Emails::style_scrub( $subject );
		$html    = TNC_Emails::style_scrub( $html );
		TNC_Emails::send( sanitize_email( $to ), '[PREVIEW] ' . $subject, $html );
	}

	public static function handle_send() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'tnc_preview' ) ) {
			wp_die( 'Not allowed.' );
		}
		$key = isset( $_POST['template'] ) ? sanitize_key( $_POST['template'] ) : '';
		$to  = isset( $_POST['to'] ) ? sanitize_email( wp_unslash( $_POST['to'] ) ) : '';
		if ( ! $to ) {
			$to = 'mike@lionclickmedia.com';
		}
		$count = 0;
		if ( 'all' === $key ) {
			$i = 0;
			foreach ( array_keys( self::catalog() ) as $k ) {
				if ( 0 === $i ) {
					self::cron_send( $k, $to ); // first one immediately.
				} else {
					wp_schedule_single_event( time() + ( $i * 90 ), self::CRON, array( $k, $to ) ); // ~90s apart — no spam burst.
				}
				$i++;
				$count++;
			}
			spawn_cron();
		} elseif ( $key ) {
			self::cron_send( $key, $to );
			$count = 1;
		}
		wp_safe_redirect( admin_url( 'admin.php?page=tnc-emails&sent=' . $count . '&to=' . rawurlencode( $to ) ) );
		exit;
	}

	public static function render_page() {
		$to_default = 'mike@lionclickmedia.com';
		$sent       = isset( $_GET['sent'] ) ? (int) $_GET['sent'] : 0;
		echo '<div class="wrap" style="max-width:1100px;">';
		echo '<h1 style="font-weight:800;">TuaniChat — Email Previews</h1>';
		echo '<p style="max-width:760px;">Every template rendered live with sample data. Send any of them to your real inbox to review the design. <strong>Sending identity:</strong> all platform mail goes out From <code>tuanichat@chat.lionclickmedia.com</code> (the SPF/DMARC-aligned subdomain &mdash; the root domain is Outlook-only with hard-fail SPF and must NEVER be used as From on our servers) with Reply-To your inbox. Sends are paced ~90 seconds apart; DKIM via a proper relay (Brevo / VPS Postfix) is the remaining deliverability upgrade. Outreach templates are deliberately plain text with no branding (personal-looking emails get far more replies); what you see in each card is exactly what gets sent, nothing more.</p>';
		if ( $sent ) {
			echo '<div class="notice notice-success"><p>' . ( $sent > 1 ? esc_html( $sent ) . ' previews queued (paced ~90s apart) to ' : 'Preview sent to ' ) . esc_html( isset( $_GET['to'] ) ? sanitize_email( wp_unslash( $_GET['to'] ) ) : '' ) . '. First one should arrive within a minute.</p></div>';
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="margin:16px 0;padding:16px;background:#fff;border:1px solid #e2e2e6;border-radius:10px;display:flex;gap:12px;align-items:center;flex-wrap:wrap;">';
		wp_nonce_field( 'tnc_preview' );
		echo '<input type="hidden" name="action" value="tnc_send_preview"><input type="hidden" name="template" value="all">';
		echo '<label><strong>Send to:</strong></label> <input type="email" name="to" value="' . esc_attr( $to_default ) . '" style="min-width:280px;">';
		echo '<button class="button button-primary button-hero">Send ALL previews to my email</button>';
		echo '<span style="color:#666;">' . count( self::catalog() ) . ' templates &middot; arrives over ~' . (int) ceil( count( self::catalog() ) * 1.5 ) . ' minutes</span></form>';

		$group = '';
		foreach ( self::catalog() as $key => $meta ) {
			if ( $meta[1] !== $group ) {
				$group = $meta[1];
				echo '<h2 style="margin-top:28px;text-transform:uppercase;letter-spacing:1px;font-size:13px;color:#666;">' . esc_html( $group ) . '</h2>';
			}
			list( $subject, $html ) = self::build( $key );
			echo '<div style="background:#fff;border:1px solid #e2e2e6;border-radius:12px;margin-bottom:18px;overflow:hidden;">';
			echo '<div style="display:flex;align-items:center;gap:14px;padding:12px 18px;border-bottom:1px solid #eee;">';
			echo '<strong style="flex:1;">' . esc_html( $meta[0] ) . '</strong>';
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="margin:0;display:flex;gap:8px;">';
			wp_nonce_field( 'tnc_preview' );
			echo '<input type="hidden" name="action" value="tnc_send_preview"><input type="hidden" name="template" value="' . esc_attr( $key ) . '">';
			echo '<input type="hidden" name="to" value="' . esc_attr( $to_default ) . '">';
			echo '<button class="button">Send me this one</button></form></div>';
			echo '<iframe srcdoc="' . esc_attr( $html ) . '" style="width:100%;height:420px;border:0;background:#F4F4F7;" loading="lazy" sandbox></iframe>';
			echo '</div>';
		}
		echo '</div>';
	}
}
