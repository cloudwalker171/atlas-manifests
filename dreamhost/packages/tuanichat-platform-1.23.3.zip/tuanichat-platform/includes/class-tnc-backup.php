<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * BACKUP HARDENING (3-2-1 posture). Brain-side backup engine:
 *  - Nightly ~2:30 AM site time: pre-generates a full backup tar.gz =
 *    SQL dump of every tnc_ table + the plugin source + meta.json.
 *  - Token-gated export endpoint (admin-ajax, anonymous-safe like the fleet):
 *    the VPS nightly-mirror script (/backup/export) pulls it offsite.
 *      status:   ...admin-ajax.php?action=tnc_backup&op=status&token=BACKUP_TOKEN
 *      export:   ...admin-ajax.php?action=tnc_backup&op=export&token=BACKUP_TOKEN
 *      generate: ...admin-ajax.php?action=tnc_backup&op=generate&token=BACKUP_TOKEN
 *  - Retention: last 7 daily + last 4 weekly (Monday builds). Tier-0/free.
 *  - Versioned pre-deploy snapshots: before any Replace-upload overwrites the
 *    live plugin, the current version is zipped to .../versions/ (rollback to
 *    any prior version, forever).
 *  - LOUD FAILURE: backup failed or >36 h stale -> cockpit flag + email alert
 *    (a backup that silently stops is worse than none).
 * Uses its OWN secret (tnc_backup_token) — never the fleet token.
 */
class TNC_Backup {

	const STALE_AFTER = 129600; // 36 h in seconds.

	public static function init() {
		add_action( 'wp_ajax_nopriv_tnc_backup', array( __CLASS__, 'ajax' ) );
		add_action( 'wp_ajax_tnc_backup', array( __CLASS__, 'ajax' ) );
		add_action( 'tnc_nightly_backup', array( __CLASS__, 'cron_generate' ) );
		if ( ! wp_next_scheduled( 'tnc_nightly_backup' ) ) {
			wp_schedule_event( self::next_230am(), 'daily', 'tnc_nightly_backup' );
		}
		// Versioned pre-deploy snapshot: fires before an upload Replace overwrites us.
		add_filter( 'upgrader_pre_install', array( __CLASS__, 'pre_deploy_snapshot' ), 10, 2 );
	}

	/** Own secret, generated once. Read it on the Workers cockpit. */
	public static function token() {
		$t = (string) get_option( 'tnc_backup_token' );
		if ( '' === $t ) {
			$t = wp_generate_password( 40, false );
			update_option( 'tnc_backup_token', $t, false );
		}
		return $t;
	}

	private static function next_230am() {
		$next = strtotime( 'today 02:30', current_time( 'timestamp' ) );
		if ( $next <= current_time( 'timestamp' ) ) {
			$next = strtotime( 'tomorrow 02:30', current_time( 'timestamp' ) );
		}
		// Convert site-time to UTC epoch for the scheduler.
		return $next - ( (int) ( get_option( 'gmt_offset' ) * HOUR_IN_SECONDS ) );
	}

	/** Private storage dir (random suffix, .htaccess-denied; export streams via PHP). */
	private static function dir() {
		$up   = wp_upload_dir();
		$key  = (string) get_option( 'tnc_backup_dirkey' );
		if ( '' === $key ) {
			$key = wp_generate_password( 12, false, false );
			update_option( 'tnc_backup_dirkey', $key, false );
		}
		$dir = trailingslashit( $up['basedir'] ) . 'tnc-backups-' . $key;
		if ( ! is_dir( $dir ) ) {
			wp_mkdir_p( $dir . '/versions' );
			@file_put_contents( $dir . '/.htaccess', "Require all denied\nDeny from all\n" );
			@file_put_contents( $dir . '/index.html', '' );
		}
		return $dir;
	}

	public static function ajax() {
		$tok = isset( $_SERVER['HTTP_X_TNC_TOKEN'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_TNC_TOKEN'] ) )
			: ( isset( $_REQUEST['token'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['token'] ) ) : '' );
		if ( ! hash_equals( self::token(), $tok ) ) {
			status_header( 403 );
			wp_send_json( array( 'ok' => false, 'error' => 'forbidden' ) );
		}
		$op = isset( $_REQUEST['op'] ) ? sanitize_key( wp_unslash( $_REQUEST['op'] ) ) : 'status';
		switch ( $op ) {
			case 'generate':
				$res = self::generate();
				wp_send_json( $res );
				break;
			case 'export':
				$st = self::status_summary();
				if ( empty( $st['file'] ) || ! file_exists( $st['file'] ) ) {
					// Self-heal: generate on demand if nothing pre-built yet.
					$res = self::generate();
					$st  = self::status_summary();
					if ( empty( $st['file'] ) || ! file_exists( $st['file'] ) ) {
						status_header( 503 );
						wp_send_json( array( 'ok' => false, 'error' => 'no backup available', 'gen' => $res ) );
					}
				}
				nocache_headers();
				header( 'Content-Type: application/gzip' );
				header( 'Content-Disposition: attachment; filename="' . basename( $st['file'] ) . '"' );
				header( 'Content-Length: ' . filesize( $st['file'] ) );
				header( 'X-TNC-Backup-SHA256: ' . hash_file( 'sha256', $st['file'] ) );
				readfile( $st['file'] );
				exit;
			case 'status':
			default:
				$st = self::status_summary();
				unset( $st['file'] ); // never leak server paths.
				wp_send_json( array( 'ok' => true ) + $st );
		}
	}

	/** Cron entry: generate + retention + alert bookkeeping. Never fatals. */
	public static function cron_generate() {
		try {
			self::generate();
		} catch ( \Throwable $e ) {
			self::record( false, 0, '', $e->getMessage() );
		}
	}

	/** Build the nightly tar.gz: tnc_ tables SQL + plugin source + meta. */
	public static function generate() {
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 280 );
		}
		if ( function_exists( 'wp_raise_memory_limit' ) ) {
			wp_raise_memory_limit( 'admin' );
		}
		try {
			$dir   = self::dir();
			$stamp = gmdate( 'Y-m-d' );
			$tar   = $dir . '/tnc-backup-' . $stamp . '.tar';
			$gz    = $tar . '.gz';
			@unlink( $tar );
			@unlink( $gz );

			if ( ! class_exists( 'PharData' ) ) {
				self::record( false, 0, '', 'PharData unavailable' );
				return array( 'ok' => false, 'error' => 'PharData unavailable' );
			}
			$phar = new PharData( $tar );
			$phar->addFromString( 'db/tnc-tables.sql', self::dump_sql() );
			$phar->addFromString( 'meta.json', wp_json_encode( array(
				'site'       => home_url(),
				'generated'  => gmdate( 'c' ),
				'wp'         => get_bloginfo( 'version' ),
				'tnc'        => TNC_VERSION,
			) ) );
			// Plugin source, byte-exact.
			$src  = WP_PLUGIN_DIR . '/tuanichat-platform';
			$real = realpath( $src );
			if ( $real && is_dir( $real ) ) {
				$it = new RecursiveIteratorIterator(
					new RecursiveDirectoryIterator( $real, FilesystemIterator::SKIP_DOTS ),
					RecursiveIteratorIterator::LEAVES_ONLY
				);
				foreach ( $it as $f ) {
					if ( $f->isFile() ) {
						$rel = 'plugin/tuanichat-platform/' . str_replace( '\\', '/', ltrim( substr( $f->getRealPath(), strlen( $real ) ), '/\\' ) );
						$phar->addFile( $f->getRealPath(), $rel );
					}
				}
			}
			$phar->compress( Phar::GZ );
			unset( $phar );
			@unlink( $tar ); // keep only the .gz.

			if ( ! file_exists( $gz ) ) {
				self::record( false, 0, '', 'gz not produced' );
				return array( 'ok' => false, 'error' => 'gz not produced' );
			}
			self::retention( $dir );
			self::record( true, filesize( $gz ), $gz, '' );
			return array( 'ok' => true, 'size' => filesize( $gz ), 'name' => basename( $gz ) );
		} catch ( \Throwable $e ) {
			self::record( false, 0, '', $e->getMessage() );
			return array( 'ok' => false, 'error' => $e->getMessage() );
		}
	}

	/** Plain SQL dump (CREATE + INSERTs) of every {$prefix}tnc_ table. */
	private static function dump_sql() {
		global $wpdb;
		$sql    = "-- TuaniChat backup " . gmdate( 'c' ) . "\nSET NAMES utf8mb4;\n";
		$tables = $wpdb->get_col( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $wpdb->prefix . 'tnc_' ) . '%' ) );
		foreach ( (array) $tables as $t ) {
			$create = $wpdb->get_row( 'SHOW CREATE TABLE `' . $t . '`', ARRAY_N ); // phpcs:ignore
			$sql   .= "\nDROP TABLE IF EXISTS `$t`;\n" . $create[1] . ";\n";
			$offset = 0;
			while ( true ) {
				$rows = $wpdb->get_results( "SELECT * FROM `$t` LIMIT 200 OFFSET $offset", ARRAY_A ); // phpcs:ignore
				if ( ! $rows ) {
					break;
				}
				foreach ( $rows as $r ) {
					$vals = array();
					foreach ( $r as $v ) {
						$vals[] = is_null( $v ) ? 'NULL' : "'" . esc_sql( $v ) . "'";
					}
					$sql .= "INSERT INTO `$t` VALUES (" . implode( ',', $vals ) . ");\n";
				}
				$offset += 200;
			}
		}
		return $sql;
	}

	/** Keep last 7 dailies + last 4 weeklies (Monday builds). */
	private static function retention( $dir ) {
		$files = glob( $dir . '/tnc-backup-*.tar.gz' );
		if ( ! $files ) {
			return;
		}
		rsort( $files ); // newest first (date-stamped names sort naturally).
		$keep = array();
		$daily = 0;
		$weekly = 0;
		foreach ( $files as $f ) {
			$is_monday = preg_match( '/tnc-backup-(\d{4}-\d{2}-\d{2})/', basename( $f ), $m )
				&& '1' === gmdate( 'N', strtotime( $m[1] ) );
			if ( $daily < 7 ) {
				$keep[ $f ] = true;
				$daily++;
				if ( $is_monday ) {
					$weekly++;
				}
			} elseif ( $is_monday && $weekly < 4 ) {
				$keep[ $f ] = true;
				$weekly++;
			}
		}
		foreach ( $files as $f ) {
			if ( empty( $keep[ $f ] ) ) {
				@unlink( $f );
			}
		}
	}

	private static function record( $ok, $size, $file, $err ) {
		update_option( 'tnc_backup_status', array(
			'last_run' => time(),
			'last_ok'  => $ok ? time() : (int) self::opt( 'last_ok' ),
			'ok'       => (bool) $ok,
			'size'     => (int) $size,
			'file'     => (string) $file,
			'error'    => (string) $err,
		), false );
	}

	private static function opt( $k ) {
		$s = get_option( 'tnc_backup_status', array() );
		return is_array( $s ) && isset( $s[ $k ] ) ? $s[ $k ] : '';
	}

	/** For the cockpit Backups card + the export endpoint. */
	public static function status_summary() {
		$s = get_option( 'tnc_backup_status', array() );
		$s = is_array( $s ) ? $s : array();
		$last_ok = isset( $s['last_ok'] ) ? (int) $s['last_ok'] : 0;
		return array(
			'last_run'  => isset( $s['last_run'] ) ? (int) $s['last_run'] : 0,
			'last_ok'   => $last_ok,
			'ok'        => ! empty( $s['ok'] ),
			'size'      => isset( $s['size'] ) ? (int) $s['size'] : 0,
			'error'     => isset( $s['error'] ) ? (string) $s['error'] : '',
			'age'       => $last_ok ? ( time() - $last_ok ) : null,
			'stale'     => ! $last_ok || ( time() - $last_ok ) > self::STALE_AFTER,
			'file'      => isset( $s['file'] ) ? (string) $s['file'] : '',
			'versions'  => count( (array) glob( self::dir() . '/versions/*.zip' ) ),
		);
	}

	/**
	 * LOUD FAILURE: failed or >36 h-stale backup -> email once per episode.
	 * Called every minute from TNC_Workers::heartbeat() via watchdog.
	 */
	public static function check_alerts() {
		$st = self::status_summary();
		// Grace: don't alarm before the very first scheduled run has had a chance.
		if ( ! $st['last_run'] && ! get_option( 'tnc_backup_token_seen' ) ) {
			update_option( 'tnc_backup_token_seen', time(), false );
			return;
		}
		$bad     = ( $st['last_run'] && ! $st['ok'] ) || $st['stale'];
		$flag    = (int) get_option( 'tnc_backup_alerted', 0 );
		$to      = TNC_Settings::recipients( 'system' );
		if ( empty( $to ) ) {
			$to = array( 'mike@lionclickmedia.com' );
		}
		if ( $bad && ! $flag ) {
			// Only alert once the install is old enough to have had a nightly window.
			$seen = (int) get_option( 'tnc_backup_token_seen', 0 );
			if ( ! $st['last_run'] && $seen && ( time() - $seen ) < DAY_IN_SECONDS + self::STALE_AFTER ) {
				return;
			}
			update_option( 'tnc_backup_alerted', time(), false );
			$why = $st['last_run'] && ! $st['ok']
				? 'Last backup run FAILED: ' . ( $st['error'] ? $st['error'] : 'unknown error' )
				: 'Last successful backup is ' . ( $st['last_ok'] ? round( ( time() - $st['last_ok'] ) / 3600 ) . ' h old' : 'MISSING' ) . ' (>36 h threshold)';
			TNC_Emails::send(
				$to,
				'[TuaniChat ALERT] Backup problem on the brain',
				'<p><strong>' . esc_html( $why ) . '.</strong></p><p>A backup that silently stops is worse than none. Check the Workers cockpit &rarr; Backups card, or force one: <code>...admin-ajax.php?action=tnc_backup&amp;op=generate&amp;token=&hellip;</code></p>',
				'transactional'
			);
		} elseif ( ! $bad && $flag ) {
			update_option( 'tnc_backup_alerted', 0, false );
			TNC_Emails::send( $to, '[TuaniChat OK] Backups healthy again', '<p>The nightly backup is current again.</p>', 'transactional' );
		}
	}

	/**
	 * VERSIONED PRE-DEPLOY BACKUP: before WordPress overwrites this plugin
	 * (Replace-upload), zip the live version to .../versions/ for rollback.
	 */
	public static function pre_deploy_snapshot( $response, $hook_extra ) {
		$pkg = isset( $hook_extra['type'] ) ? $hook_extra['type'] : '';
		if ( 'plugin' !== $pkg ) {
			return $response;
		}
		try {
			$src  = WP_PLUGIN_DIR . '/tuanichat-platform';
			$real = realpath( $src );
			if ( ! $real || ! is_dir( $real ) || ! class_exists( 'ZipArchive' ) ) {
				return $response;
			}
			$dest = self::dir() . '/versions/tnc-pre-' . TNC_VERSION . '-' . gmdate( 'Ymd-His' ) . '.zip';
			if ( glob( self::dir() . '/versions/tnc-pre-' . TNC_VERSION . '-*.zip' ) ) {
				return $response; // this exact version is already snapshotted.
			}
			$zip = new ZipArchive();
			if ( true !== $zip->open( $dest, ZipArchive::CREATE ) ) {
				return $response;
			}
			$it = new RecursiveIteratorIterator(
				new RecursiveDirectoryIterator( $real, FilesystemIterator::SKIP_DOTS ),
				RecursiveIteratorIterator::LEAVES_ONLY
			);
			foreach ( $it as $f ) {
				if ( $f->isFile() ) {
					$zip->addFile( $f->getRealPath(), 'tuanichat-platform/' . str_replace( '\\', '/', ltrim( substr( $f->getRealPath(), strlen( $real ) ), '/\\' ) ) );
				}
			}
			$zip->close();
		} catch ( \Throwable $e ) {
			// Snapshot is best-effort; never block a deploy.
			update_option( 'tnc_watchdog_err', 'pre_deploy_snapshot: ' . $e->getMessage(), false );
		}
		return $response;
	}
}
