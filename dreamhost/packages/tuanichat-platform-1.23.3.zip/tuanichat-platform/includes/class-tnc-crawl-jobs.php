<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Batch crawl engine for full-site crawls (WP-Cron + loopback workers).
 * Profiles: demo (sync, fast) / full (batched). Hard cap 500; bigger sites
 * pause on a decision gate (top 500 / all N / cancel).
 * Self-chaining + watchdog-resumable: a deep crawl can never silently stall.
 */
class TNC_Crawl_Jobs {

	const HARD_CAP    = 500;
	const SITEMAP_MAX = 1000; // absolute ceiling for "Crawl all N".
	const HOOK        = 'tnc_crawl_batch';
	const STALL_SECS  = 150;  // no progress for this long => stalled.

	public static function init() {
		add_action( self::HOOK, array( __CLASS__, 'process_batch' ), 10, 1 );
	}

	public static function state_key( $prospect_id ) {
		return 'tnc_crawlq_' . (int) $prospect_id;
	}

	public static function cap_for_profile( $profile ) {
		if ( 'full' === $profile ) {
			$cap = (int) TNC_Settings::get( 'crawl_full_pages', 200 );
		} else {
			$cap = (int) TNC_Settings::get( 'crawl_max_pages', 25 );
		}
		return max( 1, min( self::HARD_CAP, $cap ) );
	}

	/** Queue a full-site batched crawl. Returns true | array(decision=>true) | WP_Error. */
	public static function enqueue( $prospect_id, $profile = 'full' ) {
		$p = TNC_Prospects::get( $prospect_id );
		if ( ! $p || empty( $p['website_url'] ) ) {
			return new WP_Error( 'tnc_nourl', 'Prospect or website URL missing.' );
		}

		$cap     = self::cap_for_profile( $profile );
		$crawler = new TNC_Crawler();
		$prep    = $crawler->prepare( $p['website_url'], $cap );
		if ( is_wp_error( $prep ) ) {
			return $prep;
		}

		$discovered = (int) $prep['total_discovered'];
		$queue_all  = isset( $prep['queue_all'] ) ? $prep['queue_all'] : $prep['queue'];

		// DECISION GATE: sitemap bigger than the hard cap — pause and ask the owner.
		if ( $discovered > self::HARD_CAP ) {
			$state = array(
				'profile'     => $profile,
				'cap'         => $cap,
				'platform'    => $prep['platform'],
				'home_html'   => $prep['home_html'],
				'home_url'    => $prep['home_url'],
				'home_record' => $prep['home_record'],
				'queue_all'   => array_slice( $queue_all, 0, self::SITEMAP_MAX ),
				'discovered'  => $discovered,
				'awaiting'    => 1,
				'created'     => time(),
			);
			update_option( self::state_key( $prospect_id ), $state, false );
			TNC_Prospects::update( $prospect_id, array(
				'crawl_state'    => 'decision',
				'crawl_progress' => wp_json_encode( array( 'fetched' => 0, 'total' => $discovered, 'ts' => time() ) ),
				'platform'       => $prep['platform'],
			) );
			self::decision_email( $p, $discovered );
			return array( 'decision' => true, 'discovered' => $discovered );
		}

		// Over the profile cap but under the gate: crawl top-priority pages, notify.
		if ( $discovered > $cap ) {
			$to = TNC_Settings::recipients( 'crawl' );
			if ( $to ) {
				wp_mail(
					$to,
					'[TuaniChat] Crawl cap reached — ' . ( $p['company_name'] ? $p['company_name'] : $p['website_url'] ),
					sprintf(
						"Site %s has ~%d discoverable pages. Crawling the top %d by priority (hard cap %d).\n\nProspect: %s",
						$p['website_url'],
						$discovered,
						$cap,
						self::HARD_CAP,
						admin_url( 'admin.php?page=tnc-prospects&prospect=' . $p['id'] )
					)
				);
			}
		}

		$state = array(
			'profile'    => $profile,
			'cap'        => $cap,
			'platform'   => $prep['platform'],
			'home_html'  => $prep['home_html'],
			'queue'      => $prep['queue'],
			'pages'      => array( $prep['home_url'] => $prep['home_record'] ),
			'errors'     => array(),
			'total'      => min( $cap, count( $prep['queue'] ) + 1 ),
			'discovered' => $discovered,
			'started'    => time(),
			'last_tick'  => time(),
		);
		update_option( self::state_key( $prospect_id ), $state, false );

		TNC_Prospects::update( $prospect_id, array(
			'crawl_state'    => 'running',
			'crawl_progress' => wp_json_encode( array( 'fetched' => 1, 'total' => $state['total'], 'ts' => time() ) ),
			'platform'       => $prep['platform'],
		) );

		self::kick( $prospect_id );
		return true;
	}

	/** Owner email for the >cap decision gate. */
	private static function decision_email( $p, $discovered ) {
		$to = TNC_Settings::recipients( 'crawl' );
		if ( ! $to ) {
			return;
		}
		wp_mail(
			$to,
			'[TuaniChat] Decision needed — ' . ( $p['company_name'] ? $p['company_name'] : $p['website_url'] ) . ' has ' . $discovered . ' pages',
			sprintf(
				"The sitemap for %s lists ~%d pages — more than the %d-page cap.\n\nThe deep crawl is PAUSED until you choose:\n- Crawl top %d (priority pages)\n- Crawl all %d\n- Cancel\n\nDecide here: %s",
				$p['website_url'],
				$discovered,
				self::HARD_CAP,
				self::HARD_CAP,
				$discovered,
				admin_url( 'admin.php?page=tnc-prospects&prospect=' . $p['id'] )
			)
		);
	}

	/** Resolve a paused size decision. $choice: top500 | all | cancel. */
	public static function decide( $prospect_id, $choice ) {
		$prospect_id = (int) $prospect_id;
		$state       = get_option( self::state_key( $prospect_id ) );
		if ( ! is_array( $state ) || empty( $state['awaiting'] ) ) {
			return new WP_Error( 'tnc_nodecision', 'No pending crawl decision for this prospect.' );
		}
		if ( 'cancel' === $choice ) {
			delete_option( self::state_key( $prospect_id ) );
			TNC_Prospects::update( $prospect_id, array( 'crawl_state' => 'idle', 'crawl_progress' => '' ) );
			TNC_Prospects::audit( $prospect_id, 'Deep crawl cancelled at the size gate (' . (int) $state['discovered'] . ' pages discovered)', 'manual', 'verified' );
			return array( 'cancelled' => true );
		}
		$all   = isset( $state['queue_all'] ) ? $state['queue_all'] : array();
		$cap   = 'all' === $choice ? min( count( $all ) + 1, self::SITEMAP_MAX ) : self::HARD_CAP;
		$queue = array_slice( $all, 0, max( 0, $cap - 1 ) );
		$run   = array(
			'profile'    => $state['profile'],
			'cap'        => $cap,
			'platform'   => $state['platform'],
			'home_html'  => $state['home_html'],
			'queue'      => $queue,
			'pages'      => array( $state['home_url'] => $state['home_record'] ),
			'errors'     => array(),
			'total'      => count( $queue ) + 1,
			'discovered' => $state['discovered'],
			'started'    => time(),
			'last_tick'  => time(),
		);
		update_option( self::state_key( $prospect_id ), $run, false );
		TNC_Prospects::update( $prospect_id, array(
			'crawl_state'    => 'running',
			'crawl_progress' => wp_json_encode( array( 'fetched' => 1, 'total' => $run['total'], 'ts' => time() ) ),
		) );
		TNC_Prospects::audit( $prospect_id, 'Size gate decision: ' . ( 'all' === $choice ? 'crawl ALL ' . $run['total'] : 'crawl top ' . $cap ) . ' pages', 'manual', 'verified' );
		self::kick( $prospect_id );
		return array( 'started' => true, 'total' => $run['total'] );
	}

	/** Schedule + spawn the next batch — self-chaining, never traffic-dependent. */
	public static function kick( $prospect_id, $delay = 0 ) {
		wp_schedule_single_event( time() + max( 0, (int) $delay ), self::HOOK, array( (int) $prospect_id ) );
		spawn_cron();
		TNC_Workers::spawn( 'deep', array( 'prospect' => (int) $prospect_id ) );
	}

	/** Resume a stalled/stuck deep crawl (UI button + watchdog). */
	public static function resume( $prospect_id ) {
		try {
			return self::do_resume( (int) $prospect_id );
		} catch ( \Throwable $e ) {
			update_option( 'tnc_last_resume_err', $e->getMessage() . ' @ ' . basename( $e->getFile() ) . ':' . $e->getLine(), false );
			return new WP_Error( 'tnc_fatal', 'Resume failed: ' . $e->getMessage() . ' @ ' . basename( $e->getFile() ) . ':' . $e->getLine() );
		}
	}

	private static function do_resume( $prospect_id ) {
		$prospect_id = (int) $prospect_id;
		$state       = get_option( self::state_key( $prospect_id ) );
		if ( ! is_array( $state ) ) {
			return new WP_Error( 'tnc_nostate', 'No crawl in progress — start a new deep crawl.' );
		}
		if ( ! empty( $state['awaiting'] ) ) {
			return new WP_Error( 'tnc_decision', 'This crawl is paused on the size decision.' );
		}
		delete_transient( 'tnc_deep_lock_' . $prospect_id ); // clear a dead worker's lock.
		// Deliberately NO state rewrite here: re-serializing a near-complete crawl
		// state (10MB+) can exhaust memory in REST/AJAX contexts. kick() is enough —
		// the next batch refreshes last_tick itself.
		TNC_Prospects::audit( $prospect_id, 'Deep crawl resumed at ' . ( isset( $state['pages'] ) ? count( $state['pages'] ) : 0 ) . '/' . ( isset( $state['total'] ) ? $state['total'] : '?' ) . ' pages', 'watchdog', 'verified' );
		self::kick( $prospect_id );
		return array( 'resumed' => true );
	}

	/**
	 * Is this prospect's deep crawl stalled? CHEAP by design: reads the ts in
	 * the crawl_progress column — never loads the (potentially huge) state.
	 */
	public static function stalled( $p ) {
		if ( ! is_array( $p ) || ! isset( $p['crawl_state'] ) || 'running' !== $p['crawl_state'] ) {
			return false;
		}
		$pr = isset( $p['crawl_progress'] ) ? $p['crawl_progress'] : null;
		if ( is_string( $pr ) ) {
			$pr = json_decode( $pr, true );
		}
		$tick = is_array( $pr ) && isset( $pr['ts'] ) ? (int) $pr['ts'] : 0;
		if ( ! $tick ) {
			return true; // running with no progress timestamp = wedged.
		}
		return ( time() - $tick ) > self::STALL_SECS;
	}

	/** Cron/worker callback: process one batch, then chain or finalize. */
	public static function process_batch( $prospect_id ) {
		$prospect_id = (int) $prospect_id;
		$state       = get_option( self::state_key( $prospect_id ) );
		if ( ! is_array( $state ) || ! empty( $state['awaiting'] ) ) {
			return;
		}

		// One worker per prospect; a dead worker's lock self-expires.
		$lock = 'tnc_deep_lock_' . $prospect_id;
		if ( get_transient( $lock ) ) {
			return;
		}
		set_transient( $lock, time(), 3 * MINUTE_IN_SECONDS );

		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 120 );
		}
		if ( function_exists( 'wp_raise_memory_limit' ) ) {
			wp_raise_memory_limit( 'admin' ); // big crawl states need headroom to (de)serialize.
		}
		ignore_user_abort( true );

		// Shrink-on-load: heal oversized pre-fix states (150KB/page html blobs).
		if ( ! empty( $state['pages'] ) && empty( $state['shrunk'] ) ) {
			foreach ( $state['pages'] as $u => $rec ) {
				if ( isset( $rec['html'] ) && strlen( $rec['html'] ) > 25000 ) {
					$state['pages'][ $u ]['html'] = substr( $rec['html'], 0, 25000 );
				}
				if ( isset( $rec['text'] ) && strlen( $rec['text'] ) > 14000 ) {
					$state['pages'][ $u ]['text'] = mb_substr( $rec['text'], 0, 12000 );
				}
			}
			$state['shrunk'] = 1;
		}

		$batch_size = max( 2, min( 15, (int) TNC_Settings::get( 'crawl_batch_size', 6 ) ) );
		$crawler    = new TNC_Crawler();
		$done       = 0;
		$t0         = time();

		while ( $done < $batch_size && ! empty( $state['queue'] ) && count( $state['pages'] ) < $state['cap'] ) {
			if ( ( time() - $t0 ) > 60 ) {
				break; // batch time budget — one slow site can never wedge the chain.
			}
			$url = array_shift( $state['queue'] );
			if ( isset( $state['pages'][ $url ] ) ) {
				continue;
			}
			usleep( 250000 );
			$rec = $crawler->fetch_page( $url ); // hard curl timeout per page inside.
			if ( is_wp_error( $rec ) ) {
				$state['errors'][] = array( 'url' => $url, 'error' => $rec->get_error_message() );
			} else {
				$state['pages'][ $url ] = $rec;
			}
			$done++;
		}

		$finished           = empty( $state['queue'] ) || count( $state['pages'] ) >= $state['cap'];
		$state['last_tick'] = time();
		update_option( self::state_key( $prospect_id ), $state, false );
		TNC_Prospects::update( $prospect_id, array(
			'crawl_progress' => wp_json_encode( array( 'fetched' => count( $state['pages'] ), 'total' => $state['total'], 'ts' => time() ) ),
		) );
		TNC_Workers::bump_rate( $done );
		delete_transient( $lock );

		if ( ! $finished ) {
			self::kick( $prospect_id, 2 ); // schedule + loopback spawn: chain continues with zero traffic.
			return;
		}

		self::finalize( $prospect_id, $state );
	}

	private static function finalize( $prospect_id, $state ) {
		$crawler = new TNC_Crawler();
		$crawl   = $crawler->assemble( $state['pages'], $state['home_html'], $state['platform'], $state['errors'] );

		TNC_KB::ingest_crawl( $prospect_id, $crawl );
		$crawl['pages'] = array_keys( $crawl['pages'] ); // KB has the content — the row stays light.

		$updates = array(
			'crawl_data'  => wp_json_encode( $crawl ),
			'platform'    => $crawl['platform'],
			'crawl_state' => 'done',
		);
		$p = TNC_Prospects::get( $prospect_id );
		if ( $p ) {
			if ( empty( $p['company_name'] ) && ! empty( $crawl['extracted']['company_name'] ) ) {
				$updates['company_name'] = $crawl['extracted']['company_name'];
			}
			if ( 'new' === $p['status'] ) {
				$updates['status'] = 'demo_created';
			}
		}
		TNC_Prospects::update( $prospect_id, $updates );

		$p2 = TNC_Prospects::get( $prospect_id );
		if ( $p2 ) {
			list( $score, $breakdown ) = TNC_Outreach::score( $p2 );
			TNC_Prospects::update( $prospect_id, array( 'score' => $score, 'score_breakdown' => wp_json_encode( $breakdown ) ) );
		}

		TNC_Outreach::queue_starters( $prospect_id );
		delete_option( self::state_key( $prospect_id ) );
		delete_transient( 'tnc_deep_lock_' . $prospect_id );
	}
}
