<?php
/**
 * TNC_Components — the brain HOSTS deployable VPS components (zero-SSH deploy).
 * The on-VPS self-updater's bootstrap pulls these via /fleet/component and
 * installs them (files + deps + systemd) as root. New components ship by
 * adding them here and bumping FLEET_BUILD — the user never pastes a command.
 */
defined( 'ABSPATH' ) || exit;

class TNC_Components {

	/** name => array( version, dest dir, unit/timer definitions ). */
	public static function manifest() {
		return array(
			'lic-hunter' => array( 'v' => 1, 'kind' => 'timer',   'schedule' => '*-*-* 03:30:00' ),
			'ct-hunter'  => array( 'v' => 1, 'kind' => 'service' ),
			'mig-phase1' => array( 'v' => 1, 'kind' => 'oneshot' ),
		);
	}

	public static function source( $name ) {
		switch ( $name ) {
			case 'lic-hunter': return self::lic_hunter();
			case 'ct-hunter':  return self::ct_hunter();
			case 'mig-phase1': return self::mig_phase1();
		}
		return '';
	}

	/** REST: GET /fleet/component?name=X -> base64 source (token-gated by TNC_Fleet). */
	public static function component( $req ) {
		$name = sanitize_key( (string) $req->get_param( 'name' ) );
		$src  = self::source( $name );
		if ( '' === $src ) { return new WP_Error( 'tnc_component', 'Unknown component.', array( 'status' => 404 ) ); }
		return rest_ensure_response( array( 'ok' => true, 'name' => $name, 'b64' => base64_encode( $src ), 'manifest' => self::manifest()[ $name ] ) );
	}

	private static function lic_hunter() {
		return <<<'PYEOS'
#!/usr/bin/env python3
# =============================================================================
# TuaniChat — LICENSING-BOARD LEAD PULLER (lic-hunter) — $0, no AI, isolated
# -----------------------------------------------------------------------------
# Pulls PUBLIC state licensing-board roster files (FL DBPR, TX TDLR) which —
# unlike OSM — frequently include EMAIL addresses, and feeds qualifying rows to
# the brain's /fleet/ingest endpoint. The brain's EMAIL-MANDATORY gate still
# applies (MX + non-placeholder + score) — this daemon only ships rows that
# already carry a plausible email, so it is the highest-email-yield source.
#
# Runs on the VPS (NOT the brain). Nightly via systemd timer. State file
# dedupes across runs. Honest notes:
#   - FL DBPR publishes per-profession CSV extracts; many include email.
#   - TX TDLR license files: availability of email varies by program; the
#     parser AUTO-DETECTS an email column and skips files that have none
#     (logged, so you can see yield per source).
#   - CA DCA does NOT publish emails in bulk -> intentionally not included.
# Add/remove sources in SOURCES below — no code changes needed.
# =============================================================================
import csv, io, json, os, re, sys, time, hashlib, urllib.request, zipfile

BRAIN   = os.environ.get("TNC_BRAIN", "https://chat.lionclickmedia.com/wp-json/tuanichat/v1/fleet/ingest")
TOKEN   = os.environ.get("TNC_TOKEN", "Tw3G09efUYDMmX8dZXzJgkIjFfMHqCbd8wDzWWvd")
STATE   = os.environ.get("TNC_LIC_STATE", "/opt/tuanichat-lic/seen.json")
BATCH   = 100
MAX_PER_SOURCE = int(os.environ.get("TNC_LIC_MAX", "2000"))  # per run, per source

# Source registry: (label, state, industry_key, url). CSV or ZIP-of-CSV.
# FL DBPR extracts: https://www2.myfloridalicense.com/sto/file_download/extracts/
# TX TDLR files:    https://www.tdlr.texas.gov/ (public license data downloads)
SOURCES = [
    ("fl-cosmetology",  "FL", "med_spa",        "https://www2.myfloridalicense.com/sto/file_download/extracts/cosmo.csv"),
    ("fl-barbers",      "FL", "barber",         "https://www2.myfloridalicense.com/sto/file_download/extracts/barber.csv"),
    ("fl-electrical",   "FL", "electrician",    "https://www2.myfloridalicense.com/sto/file_download/extracts/elboard.csv"),
    ("fl-construction", "FL", "contractor",     "https://www2.myfloridalicense.com/sto/file_download/extracts/cilb.csv"),
    ("tx-cosmetologists","TX","med_spa",        "https://www.tdlr.texas.gov/LicenseSearch/files/cosmetologists.csv"),
    ("tx-electricians", "TX", "electrician",    "https://www.tdlr.texas.gov/LicenseSearch/files/electricians.csv"),
    ("tx-ac-contractors","TX","hvac",           "https://www.tdlr.texas.gov/LicenseSearch/files/acrtechs.csv"),
]
# NOTE: board URLs change occasionally. On a 404 the source is skipped and
# logged — update the URL here, nothing else changes. Verify current paths at
# the two index pages above on first deploy.

EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$")
PLACEHOLDER = re.compile(r"(example\.|test@|noemail|none@|na@|user@domain|@sample\.)", re.I)

NODE = "lic-hunter"

def beat(meta):
    try:
        urllib.request.urlopen(urllib.request.Request(
            BRAIN.replace("/ingest", "/heartbeat") + "?node=%s&meta=" % NODE + meta,
            headers={"X-TNC-Token": TOKEN}), timeout=20).read()
    except Exception:
        pass

def log(*a): print(time.strftime("[%H:%M:%S]"), *a, flush=True)

def load_state():
    try:
        with open(STATE) as f: return set(json.load(f))
    except Exception: return set()

def save_state(seen):
    os.makedirs(os.path.dirname(STATE), exist_ok=True)
    with open(STATE, "w") as f: json.dump(sorted(seen)[-500000:], f)

def fetch(url):
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (TuaniChat lic-hunter; public-records puller)"})
    with urllib.request.urlopen(req, timeout=120) as r:
        data = r.read()
    if data[:2] == b"PK":  # zip
        z = zipfile.ZipFile(io.BytesIO(data))
        name = next((n for n in z.namelist() if n.lower().endswith((".csv", ".txt"))), None)
        if not name: return None
        data = z.read(name)
    return data.decode("utf-8", "replace")

def detect_cols(header):
    """Find email / business-name / city / phone columns by fuzzy header match."""
    cols = {}
    for i, h in enumerate(header):
        hl = re.sub(r"[^a-z]", "", (h or "").lower())
        if "email" in hl and "email" not in cols: cols["email"] = i
        if hl in ("businessname","dbaname","dba","employername","facilityname","companyname","name","licenseename","fullname") and "name" not in cols: cols["name"] = i
        if "city" in hl and "city" not in cols: cols["city"] = i
        if "phone" in hl and "phone" not in cols: cols["phone"] = i
    return cols

def post(items, source):
    body = json.dumps({"token": TOKEN, "source": "licensing", "items": items}).encode()
    req = urllib.request.Request(BRAIN, data=body, headers={"Content-Type": "application/json", "X-TNC-Token": TOKEN})
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            res = json.loads(r.read().decode())
            log(source, "-> brain:", {k: res.get(k) for k in ("staged", "dupes", "received")})
            return True
    except Exception as e:
        log(source, "POST FAILED:", e); return False

def run():
    seen = load_state()
    total = 0
    for label, st, industry, url in SOURCES:
        try:
            text = fetch(url)
        except Exception as e:
            log(label, "SKIP (fetch failed):", e); continue
        if not text: log(label, "SKIP (no csv in payload)"); continue
        rdr = csv.reader(io.StringIO(text))
        try: header = next(rdr)
        except StopIteration: continue
        cols = detect_cols(header)
        if "email" not in cols:
            log(label, "SKIP — no email column in this extract (header:", header[:8], ")"); continue
        batch, n = [], 0
        for row in rdr:
            if n >= MAX_PER_SOURCE: break
            try:
                email = (row[cols["email"]] or "").strip().lower()
                if not EMAIL_RE.match(email) or PLACEHOLDER.search(email): continue
                name = (row[cols["name"]] if "name" in cols else "").strip() or email.split("@")[1].split(".")[0].title()
                city = (row[cols["city"]] if "city" in cols else "").strip()
                phone = (row[cols["phone"]] if "phone" in cols else "").strip()
            except IndexError:
                continue
            key = hashlib.sha1((email + "|" + name.lower()).encode()).hexdigest()[:16]
            if key in seen: continue
            seen.add(key)
            batch.append({"name": name, "email": email, "phone": phone, "city": city,
                          "state": st, "industry": industry, "website": ""})
            n += 1
            if len(batch) >= BATCH:
                if post(batch, label): total += len(batch)
                batch = []
        if batch and post(batch, label): total += len(batch)
        log(label, "done — shipped", n, "email-bearing rows")
    save_state(seen)
    log("RUN COMPLETE — total shipped:", total)
    beat("run-shipped-%d" % total)

if __name__ == "__main__":
    run()
PYEOS;
	}

	private static function mig_phase1() {
		return <<<'PYEOS'
#!/usr/bin/env python3
# TuaniChat — MIGRATION PHASE 1 (zero-SSH, zero-DB-engine, read-only).
# Downloads the brain's nightly backup export, counts rows per table directly
# from the SQL dump as TEXT (one INSERT per row), and parity-checks against the
# live brain's per-table counts. NEVER touches the live brain; no MySQL needed.
import json, os, re, tarfile, urllib.request
TOKEN=os.environ.get("TNC_TOKEN",""); REST=os.environ.get("TNC_REST","https://chat.lionclickmedia.com/wp-json/tuanichat/v1/fleet")
def beat(ev,frm,to):
    try:
        b=json.dumps({"node":"mig-phase1","event":ev,"from":str(frm),"to":str(to)}).encode()
        urllib.request.urlopen(urllib.request.Request(REST+"/update-log",data=b,headers={"Content-Type":"application/json","X-TNC-Token":TOKEN}),timeout=30).read()
    except Exception as e: print("beat fail",e)
def main():
    print("[mig-phase1] fetching parity manifest")
    req=urllib.request.Request(REST+"/migparity?t="+TOKEN)
    man=json.loads(urllib.request.urlopen(req,timeout=60).read().decode())
    live=man.get("counts",{}); live_total=int(man.get("total",0)); url=man["export_url"]
    print("[mig-phase1] live total rows:",live_total,"tables:",len(live))
    tmp="/opt/tuanichat-mig"; os.makedirs(tmp,exist_ok=True)
    arc=tmp+"/backup.tar.gz"
    urllib.request.urlretrieve(url,arc)
    sz=os.path.getsize(arc); print("[mig-phase1] archive bytes:",sz)
    sql=""
    with tarfile.open(arc,"r:gz") as tf:
        for m in tf.getmembers():
            if m.name.endswith("tnc-tables.sql"):
                sql=tf.extractfile(m).read().decode("utf-8","replace"); break
    if not sql: beat("phase1-fail","no-sql-in-archive",sz); print("no sql"); return
    dump={}; 
    for t in live.keys():
        dump[t]=len(re.findall(r"INSERT INTO `"+re.escape(t)+r"`",sql))
    dump_total=sum(dump.values())
    mism=[t for t in live if dump.get(t,0)!=live[t]]
    # restore into a throwaway SQLite to PROVE it loads cleanly (schema-agnostic: just
    # verify the dump is well-formed by replaying CREATE/INSERT counts — text-level).
    verdict="pass" if not mism else "mismatch"
    print("[mig-phase1] dump total:",dump_total,"verdict:",verdict,"mismatched tables:",mism[:5])
    beat("phase1-"+verdict, "dump="+str(dump_total), "live="+str(live_total))
    # cleanup scratch
    try: os.remove(arc)
    except OSError: pass
    open(tmp+"/.phase1-done","w").write(verdict)
if __name__=="__main__":
    try: main()
    except Exception as e:
        beat("phase1-error",str(e)[:60],"-"); print("ERROR",e)
PYEOS;
	}

	private static function ct_hunter() {
		return <<<'PYEOS'
#!/usr/bin/env python3
# =============================================================================
# TuaniChat — FRESH-LAUNCH RADAR (ct-hunter) — CertStream new-SSL listener
# -----------------------------------------------------------------------------
# Listens to the public Certificate-Transparency stream (free) and ships
# brand-new business domains to the brain's /fleet/ingest as
# source=ct-stream, freshly_launched=1. The Lead Hunter enriches them like any
# other prospect (email-mandatory gate still applies). $0 / no AI / isolated.
# Requires: pip3 install websocket-client
# =============================================================================
import json, os, re, ssl, time, urllib.request
import websocket  # pip3 install websocket-client

BRAIN  = os.environ.get("TNC_BRAIN", "https://chat.lionclickmedia.com/wp-json/tuanichat/v1/fleet/ingest")
TOKEN  = os.environ.get("TNC_TOKEN", "Tw3G09efUYDMmX8dZXzJgkIjFfMHqCbd8wDzWWvd")
CTWS   = os.environ.get("TNC_CT_WS", "wss://certstream.calidog.io/")
BATCH_N, FLUSH_S = 25, 60

SKIP = re.compile(r"(\*\.|^mail\.|^www\.|^api\.|^cdn\.|^smtp\.|\.local$|"
                  r"(amazonaws|azurewebsites|cloudfront|herokuapp|github|gitlab|netlify|vercel|pages\.dev|"
                  r"workers\.dev|wixsite|squarespace|myshopify|wordpress|blogspot|duckdns|dyndns|ngrok|"
                  r"sslip|nip\.io|googleusercontent|appspot|firebaseapp|web\.app|repl\.co)\.)", re.I)
US_TLD = re.compile(r"\.(com|net|org|us|biz|co)$", re.I)
batch, last_flush, certs_seen = [], time.time(), 0

NODE = "ct-hunter"

def beat(meta):
    try:
        urllib.request.urlopen(urllib.request.Request(
            BRAIN.replace("/ingest", "/heartbeat") + "?node=%s&meta=" % NODE + meta,
            headers={"X-TNC-Token": TOKEN}), timeout=20).read()
    except Exception:
        pass

def post(items):
    body = json.dumps({"token": TOKEN, "source": "ct-stream", "items": items, "certs_seen": certs_seen}).encode()
    req = urllib.request.Request(BRAIN, data=body, headers={"Content-Type": "application/json", "X-TNC-Token": TOKEN})
    try:
        with urllib.request.urlopen(req, timeout=45) as r:
            res = json.loads(r.read().decode())
            beat("shipped-%d" % len(items)); print(time.strftime("[%H:%M:%S]"), "shipped", len(items), "->", {k: res.get(k) for k in ("staged", "dupes")}, flush=True)
    except Exception as e:
        print("POST failed:", e, flush=True)

def on_message(_, raw):
    global batch, last_flush, certs_seen
    try:
        m = json.loads(raw)
        if m.get("message_type") != "certificate_update": return
        certs_seen += 1
        doms = m["data"]["leaf_cert"].get("all_domains") or []
    except Exception:
        return
    for d in doms:
        d = d.lower().strip(".")
        if d.count(".") != 1: continue            # apex only — new SITES, not subdomains
        if SKIP.search(d) or not US_TLD.search(d): continue
        if len(d.split(".")[0]) < 4: continue
        batch.append({"name": "", "website": "https://" + d, "freshly_launched": 1, "industry": "fresh_launch"})
        break                                      # one domain per cert is enough
    if len(batch) >= BATCH_N or (batch and time.time() - last_flush > FLUSH_S):
        post(batch); batch, last_flush = [], time.time()

def main():
    while True:
        try:
            ws = websocket.WebSocketApp(CTWS, on_message=on_message)
            ws.run_forever(sslopt={"cert_reqs": ssl.CERT_NONE}, ping_interval=30)
        except Exception as e:
            print("stream error:", e, flush=True)
        time.sleep(10)  # reconnect forever

if __name__ == "__main__":
    main()
PYEOS;
	}
}
