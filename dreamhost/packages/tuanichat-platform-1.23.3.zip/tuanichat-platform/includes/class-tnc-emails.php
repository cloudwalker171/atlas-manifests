<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Branded HTML email engine — header/footer partials + per-type bodies.
 * Email-safe: tables only, fully inline styles, bulletproof buttons, no
 * flexbox/grid/external images. Renders in Gmail/Outlook/Apple Mail/mobile.
 *
 * NOTE (by design): cold OUTREACH emails do NOT use these templates — they
 * stay plain, human-looking text to maximize replies. This engine is for
 * SYSTEM/transactional mail only (lead notifications, batch reports, etc.).
 */
class TNC_Emails {

	const VIOLET  = '#7C3AED';
	const FUCHSIA = '#D946EF';
	const DARK    = '#0E0E12';
	const TEXT    = '#1F2430';
	const MUTED   = '#6B7280';
	const BG      = '#F4F4F7';

	/** Shared shell: gradient header bar + wordmark, white card body, branded footer. */
	private static function wrap( $title, $preheader, $body_html ) {
		$fonts = "font-family:Inter,-apple-system,'Segoe UI',Roboto,Helvetica,Arial,sans-serif";
		return '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
			. '<title>' . esc_html( $title ) . '</title></head>'
			. '<body style="margin:0;padding:0;background-color:' . self::BG . ';">'
			. '<div style="display:none;max-height:0;overflow:hidden;">' . esc_html( $preheader ) . '</div>'
			. '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color:' . self::BG . ';">'
			. '<tr><td align="center" style="padding:28px 12px;">'
			. '<table role="presentation" width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;">'
			// Gradient accent bar.
			. '<tr><td style="height:5px;background:linear-gradient(90deg,' . self::VIOLET . ',' . self::FUCHSIA . ');background-color:' . self::VIOLET . ';border-radius:14px 14px 0 0;font-size:0;line-height:0;">&nbsp;</td></tr>'
			// Dark header with wordmark.
			. '<tr><td style="background-color:' . self::DARK . ';padding:22px 32px;">'
			. '<table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr>'
			. '<td style="' . $fonts . ';font-size:20px;font-weight:800;color:#FFFFFF;letter-spacing:-0.5px;">Tuani<span style="color:#A78BFA;">Chat</span>'
			. ' <span style="font-size:10px;font-weight:600;color:#9CA3AF;letter-spacing:2px;">BY TUANILABS</span></td>'
			. '<td align="right" style="' . $fonts . ';font-size:18px;color:' . self::FUCHSIA . ';">&#10022;</td>'
			. '</tr></table></td></tr>'
			// Body card.
			. '<tr><td style="background-color:#FFFFFF;padding:32px;border-radius:0 0 14px 14px;border:1px solid #E8E8EE;border-top:none;">' . $body_html . '</td></tr>'
			// Footer.
			. '<tr><td align="center" style="' . $fonts . ';padding:20px 12px;font-size:12px;color:' . self::MUTED . ';">'
			. 'Powered by <strong style="color:' . self::VIOLET . ';">TuaniChat</strong>, TuaniLabs LLC'
			. '</td></tr>'
			. '</table></td></tr></table></body></html>';
	}

	/** Bulletproof button: table-based, solid bg, padded link. */
	private static function button( $text, $url, $color = self::VIOLET ) {
		$fonts = "font-family:Inter,-apple-system,'Segoe UI',Roboto,Helvetica,Arial,sans-serif";
		return '<table role="presentation" cellpadding="0" cellspacing="0" style="margin:8px 0;"><tr>'
			. '<td align="center" bgcolor="' . $color . '" style="border-radius:999px;">'
			. '<a href="' . esc_url( $url ) . '" target="_blank" style="' . $fonts . ';display:inline-block;padding:13px 30px;font-size:14px;font-weight:600;color:#FFFFFF;text-decoration:none;border-radius:999px;">' . esc_html( $text ) . '</a>'
			. '</td></tr></table>';
	}

	private static function row( $label, $value_html ) {
		$fonts = "font-family:Inter,-apple-system,'Segoe UI',Roboto,Helvetica,Arial,sans-serif";
		return '<tr><td style="' . $fonts . ';padding:9px 0;font-size:12px;color:' . self::MUTED . ';text-transform:uppercase;letter-spacing:1px;width:130px;vertical-align:top;border-bottom:1px solid #F0F0F4;">' . esc_html( $label ) . '</td>'
			. '<td style="' . $fonts . ';padding:9px 0;font-size:14px;color:' . self::TEXT . ';border-bottom:1px solid #F0F0F4;">' . $value_html . '</td></tr>';
	}

	/**
	 * MAIL DELIVERABILITY (root-cause fix, v1.5.2):
	 * lionclickmedia.com publishes DMARC p=reject with no sp= tag, so the
	 * reject policy inherits to chat.lionclickmedia.com. Receivers (the
	 * mailbox is Microsoft 365 per MX) REJECT any mail whose envelope-from
	 * (Return-Path) domain is not aligned with the From domain. WordPress's
	 * default From (wordpress@chat...) is fine, but PHP mail() on shared
	 * hosting uses the server account as envelope-from -> SPF unaligned ->
	 * DMARC fail -> silent reject (not even spam). Fix: force BOTH the From
	 * and the envelope Sender to an address on the SPF-authorized chat
	 * subdomain, and keep a ledger of every wp_mail result for diagnosis.
	 */
	public static function init() {
		add_filter( 'wp_mail_from', array( __CLASS__, 'mail_from' ), 99 );
		add_filter( 'wp_mail_from_name', array( __CLASS__, 'mail_from_name' ), 99 );
		add_action( 'phpmailer_init', array( __CLASS__, 'align_envelope' ), 99 );
		add_action( 'wp_mail_failed', array( __CLASS__, 'on_fail' ) );
	}

	/** Sender on the SPF-aligned subdomain the site actually lives on. */
	public static function sender_address() {
		$host = strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
		return 'tuanichat@' . preg_replace( '/^www\./', '', $host );
	}

	public static function mail_from( $from ) {
		// Rewrite only WP's default — never stomp an intentionally-set From.
		return ( 0 === strpos( (string) $from, 'wordpress@' ) ) ? self::sender_address() : $from;
	}

	public static function mail_from_name( $name ) {
		return ( 'WordPress' === $name ) ? 'TuaniChat' : $name;
	}

	const DKIM_SELECTOR = 'tnc1';

	public static function dkim_domain() {
		$host = strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
		return preg_replace( '/^www\./', '', $host );
	}

	public static function align_envelope( $phpmailer ) {
		// DMARC alignment: Return-Path domain must match the From domain.
		$phpmailer->Sender = self::sender_address();

		// DKIM: PHPMailer signs natively with OUR keypair — no host cooperation
		// needed. Gated on the public key being verified in DNS first, because
		// a signature whose record is missing scores worse than no signature.
		$dkim = false;
		$priv = (string) get_option( 'tnc_dkim_private', '' );
		if ( $priv && get_option( 'tnc_dkim_dns_ok' ) ) {
			$phpmailer->DKIM_domain         = self::dkim_domain();
			$phpmailer->DKIM_selector       = self::DKIM_SELECTOR;
			$phpmailer->DKIM_private_string = $priv;
			$phpmailer->DKIM_identity       = $phpmailer->From;
			$phpmailer->DKIM_passphrase     = '';
			$dkim = true;
		}

		update_option( 'tnc_last_mail_from', array(
			'from'   => $phpmailer->From,
			'sender' => $phpmailer->Sender,
			'dkim'   => $dkim ? 1 : 0,
			'ts'     => gmdate( 'Y-m-d H:i:s' ) . ' UTC',
		), false );
	}

	/** Generate (once) the 2048-bit DKIM keypair; returns the DNS record to publish. */
	public static function dkim_setup() {
		if ( ! function_exists( 'openssl_pkey_new' ) ) {
			return new WP_Error( 'tnc_no_openssl', 'OpenSSL unavailable on this host.' );
		}
		$priv = (string) get_option( 'tnc_dkim_private', '' );
		if ( '' === $priv ) {
			$res = openssl_pkey_new( array(
				'private_key_bits' => 2048,
				'private_key_type' => OPENSSL_KEYTYPE_RSA,
			) );
			if ( ! $res || ! openssl_pkey_export( $res, $priv ) ) {
				return new WP_Error( 'tnc_keygen', 'Key generation failed.' );
			}
			$det = openssl_pkey_get_details( $res );
			update_option( 'tnc_dkim_private', $priv, false );
			update_option( 'tnc_dkim_public', $det['key'], false );
		}
		return self::dkim_status();
	}

	/** Check DNS for the published key; arm signing when it matches. */
	public static function dkim_status() {
		$pub = (string) get_option( 'tnc_dkim_public', '' );
		if ( '' === $pub ) {
			return array( 'keypair' => false, 'signing' => false );
		}
		$p      = preg_replace( '/-----[^-]+-----|\s+/', '', $pub );
		$host   = self::DKIM_SELECTOR . '._domainkey.' . self::dkim_domain();
		$value  = 'v=DKIM1; k=rsa; p=' . $p;
		$dns_ok = false;
		$recs   = function_exists( 'dns_get_record' ) ? @dns_get_record( $host, DNS_TXT ) : array();
		if ( is_array( $recs ) ) {
			foreach ( $recs as $r ) {
				$txt = isset( $r['txt'] ) ? preg_replace( '/\s+/', '', $r['txt'] ) : '';
				if ( $txt && false !== strpos( $txt, substr( preg_replace( '/\s+/', '', $p ), 0, 60 ) ) ) {
					$dns_ok = true;
					break;
				}
			}
		}
		update_option( 'tnc_dkim_dns_ok', $dns_ok ? 1 : 0, false );
		return array(
			'keypair'        => true,
			'selector'       => self::DKIM_SELECTOR,
			'dns_record'     => array( 'type' => 'TXT', 'host' => $host, 'value' => $value ),
			'dns_ok'         => $dns_ok,
			'signing'        => (bool) $dns_ok,
		);
	}



	public static function on_fail( $error ) {
		self::log( array(
			'event' => 'wp_mail_failed',
			'error' => $error->get_error_message(),
		) );
	}

	/** STYLE SCRUB (binding rule): no em/en dashes or gimmicky emojis in ANY
	 * outgoing email, including dynamic data (transcripts, notes, site text). */
	public static function style_scrub( $text ) {
		$text = str_replace( array( " \xE2\x80\x94 ", "\xE2\x80\x94", " \xE2\x80\x93 ", "\xE2\x80\x93", '&mdash;', '&ndash;' ), array( ', ', ', ', ' to ', '-', ', ', '-' ), (string) $text );
		return str_replace( array( "\xE2\x9A\xA1", "\xF0\x9F\x94\xA5", "\xE2\x9A\xA0", "\xE2\x9C\xA8", '&#9889;' ), '', $text );
	}

	/** Rolling 50-entry mail ledger (autoload off). */
	public static function log( $entry ) {
		$log = get_option( 'tnc_mail_log', array() );
		if ( ! is_array( $log ) ) {
			$log = array();
		}
		$entry['t'] = gmdate( 'Y-m-d H:i:s' ) . ' UTC';
		array_unshift( $log, $entry );
		update_option( 'tnc_mail_log', array_slice( $log, 0, 50 ), false );
	}

	public static function send( $to, $subject, $html, $type = 'notification' ) {
		// STREAM ROUTING: every message goes through its stream's identity.
		$ident = TNC_Mail_Streams::route( $type );
		if ( ! $ident ) {
			self::log( array( 'event' => 'blocked_no_identity', 'stream' => $type, 'subject' => mb_substr( (string) $subject, 0, 60 ) ) );
			return false; // no active identity for this stream (e.g. cold) — never mis-route.
		}
		if ( ! TNC_Mail_Streams::within_cap( $ident ) ) {
			self::log( array( 'event' => 'blocked_daily_cap', 'identity' => $ident['id'], 'subject' => mb_substr( (string) $subject, 0, 60 ) ) );
			return false;
		}
		$ok      = false;
		$headers = array( 'Content-Type: text/html; charset=UTF-8' );
		$reply   = (array) TNC_Settings::recipients( 'system' );
		if ( ! empty( $reply[0] ) ) {
			$headers[] = 'Reply-To: ' . $reply[0];
		}
		$subject = self::style_scrub( $subject );
		$html    = self::style_scrub( $html );
		foreach ( (array) $to as $addr ) {
			if ( $addr ) {
				// GLOBAL SUPPRESSION: honored on every non-transactional stream.
				if ( 'transactional' !== $type && TNC_Mail_Streams::suppressed( $addr ) ) {
					self::log( array( 'event' => 'skipped_suppressed', 'to' => $addr, 'stream' => $type ) );
					continue;
				}
				$r = wp_mail( $addr, $subject, $html, $headers );
				self::log( array(
					'event'   => 'send',
					'to'      => $addr,
					'subject' => mb_substr( (string) $subject, 0, 90 ),
					'ok'      => $r ? 1 : 0,
				) );
				$ok = $r || $ok;
			}
		}
		return $ok;
	}

	/**
	 * THE PAYOFF EMAIL: packaged lead notification — summary card, qualified
	 * details, recent transcript, source + timestamp, dashboard CTA.
	 */
	public static function lead_notification( $prospect, $lead ) {
		global $wpdb;
		$fonts = "font-family:Inter,-apple-system,'Segoe UI',Roboto,Helvetica,Arial,sans-serif";

		$score     = (int) $prospect['score'];
		$score_bg  = $score >= 65 ? '#DCFCE7' : ( $score >= 35 ? '#FEF9C3' : '#F1F5F9' );
		$score_fg  = $score >= 65 ? '#166534' : ( $score >= 35 ? '#854D0E' : '#475569' );
		$demo_url  = home_url( '/demo/' . $prospect['demo_slug'] . '/' );
		$admin_url = admin_url( 'admin.php?page=tnc-prospects&prospect=' . $prospect['id'] );

		$body  = '<h1 style="' . $fonts . ';margin:0 0 6px;font-size:21px;color:' . self::TEXT . ';letter-spacing:-0.4px;">New lead from your TuaniChat Assistant</h1>';
		$body .= '<p style="' . $fonts . ';margin:0 0 22px;font-size:14px;color:' . self::MUTED . ';">Captured on the demo for <strong>' . esc_html( $prospect['company_name'] ) . '</strong>. Here is everything, packaged.</p>';

		// Lead summary card.
		$body .= '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color:#FAFAFC;border:1px solid #ECECF2;border-radius:12px;"><tr><td style="padding:20px 24px;">';
		$body .= '<table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr>'
			. '<td style="' . $fonts . ';font-size:17px;font-weight:700;color:' . self::TEXT . ';">' . esc_html( $lead['name'] ? $lead['name'] : 'New visitor lead' ) . '</td>'
			. '<td align="right"><span style="' . $fonts . ';display:inline-block;background-color:' . $score_bg . ';color:' . $score_fg . ';font-size:12px;font-weight:700;padding:4px 12px;border-radius:999px;">Lead score ' . $score . '</span></td></tr></table>';
		$body .= '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin-top:10px;">';
		if ( ! empty( $lead['email'] ) ) {
			$body .= self::row( 'Email', '<a href="mailto:' . esc_attr( $lead['email'] ) . '" style="color:' . self::VIOLET . ';text-decoration:none;font-weight:600;">' . esc_html( $lead['email'] ) . '</a>' );
		}
		if ( ! empty( $lead['phone'] ) ) {
			$body .= self::row( 'Phone', '<a href="tel:' . esc_attr( preg_replace( '/[^\d+]/', '', $lead['phone'] ) ) . '" style="color:' . self::VIOLET . ';text-decoration:none;font-weight:600;">' . esc_html( $lead['phone'] ) . '</a>' );
		}
		if ( ! empty( $lead['message'] ) ) {
			$body .= self::row( 'Their need', esc_html( $lead['message'] ) );
		}
		$body .= self::row( 'Captured', esc_html( current_time( 'mysql' ) ) );
		$body .= self::row( 'Source page', '<a href="' . esc_url( $demo_url ) . '" style="color:' . self::VIOLET . ';text-decoration:none;">' . esc_html( $demo_url ) . '</a>' );
		$body .= '</table></td></tr></table>';

		// Recent conversation (best-effort transcript from the exchange log).
		$rows = $wpdb->get_results( $wpdb->prepare(
			'SELECT question, answer, created_at FROM ' . $wpdb->prefix . 'tnc_exchanges WHERE prospect_id = %d ORDER BY id DESC LIMIT 6',
			$prospect['id']
		), ARRAY_A );
		if ( $rows ) {
			$body .= '<h2 style="' . $fonts . ';margin:26px 0 10px;font-size:13px;color:' . self::MUTED . ';text-transform:uppercase;letter-spacing:1.5px;">Recent conversation</h2>';
			foreach ( array_reverse( $rows ) as $r ) {
				$body .= '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin-bottom:8px;"><tr><td style="padding:10px 14px;background-color:#F4F1FE;border-radius:10px;' . $fonts . ';font-size:13px;color:' . self::TEXT . ';"><strong style="color:' . self::VIOLET . ';">Visitor:</strong> ' . esc_html( mb_substr( $r['question'], 0, 300 ) ) . '</td></tr>'
					. '<tr><td style="padding:10px 14px;' . $fonts . ';font-size:13px;color:' . self::MUTED . ';"><strong>Assistant:</strong> ' . esc_html( mb_substr( $r['answer'], 0, 300 ) ) . '</td></tr></table>';
			}
		}

		$body .= '<div style="margin-top:24px;">' . self::button( 'View lead in your dashboard', $admin_url ) . '</div>';
		$body .= '<p style="' . $fonts . ';margin:14px 0 0;font-size:12px;color:' . self::MUTED . ';">Tip: leads contacted within 5 minutes convert dramatically better. This one is hot.</p>';

		return self::wrap(
			'New lead: ' . $prospect['company_name'],
			( $lead['name'] ? $lead['name'] : 'A visitor' ) . ' just left their details with your assistant.',
			$body
		);
	}

	/** Branded batch-complete report. */
	public static function batch_complete( $batch_id, $counts ) {
		$fonts = "font-family:Inter,-apple-system,'Segoe UI',Roboto,Helvetica,Arial,sans-serif";
		$url   = admin_url( 'admin.php?page=tnc-bulk&batch=' . $batch_id );
		$cell  = function ( $n, $label, $color ) use ( $fonts ) {
			return '<td align="center" style="padding:14px 6px;background-color:#FAFAFC;border:1px solid #ECECF2;border-radius:10px;">'
				. '<div style="' . $fonts . ';font-size:26px;font-weight:800;color:' . $color . ';">' . (int) $n . '</div>'
				. '<div style="' . $fonts . ';font-size:10px;color:' . self::MUTED . ';text-transform:uppercase;letter-spacing:1.5px;">' . esc_html( $label ) . '</div></td>';
		};
		$body  = '<h1 style="' . $fonts . ';margin:0 0 6px;font-size:21px;color:' . self::TEXT . ';">Your demo batch is ready</h1>';
		$body .= '<p style="' . $fonts . ';margin:0 0 20px;font-size:14px;color:' . self::MUTED . ';">' . (int) $counts['ready'] . ' of ' . (int) $counts['total'] . ' demos generated' . ( $counts['errors'] ? ', ' . (int) $counts['errors'] . ' errors' : '' ) . '.</p>';
		$body .= '<table role="presentation" width="100%" cellpadding="0" cellspacing="6"><tr>'
			. $cell( $counts['total'], 'In batch', self::TEXT )
			. $cell( $counts['ready'], 'Demos ready', '#15803D' )
			. $cell( $counts['errors'], 'Errors', $counts['errors'] ? '#B91C1C' : self::MUTED )
			. '</tr></table>';
		$body .= '<div style="margin-top:22px;">' . self::button( 'Review & export for outreach', $url ) . '</div>';
		return self::wrap( 'Batch complete', $counts['ready'] . ' demos ready for outreach.', $body );
	}

	/** Welcome / thank-you-for-signing-up email. */
	public static function welcome( $company ) {
		$fonts = "font-family:Inter,-apple-system,'Segoe UI',Roboto,Helvetica,Arial,sans-serif";
		$body  = '<h1 style="' . $fonts . ';margin:0 0 6px;font-size:22px;color:' . self::TEXT . ';letter-spacing:-0.4px;">Welcome aboard, ' . esc_html( $company ) . ' &#127881;</h1>';
		$body .= '<p style="' . $fonts . ';margin:0 0 18px;font-size:14px;color:' . self::MUTED . ';line-height:1.7;">Your 24/7 AI intake assistant is being prepared. From today, every visitor with a question gets an instant answer, and every interested visitor becomes a lead in your inbox, day or night.</p>';
		$steps = array(
			array( '1', 'We train your assistant', 'It learns from your own website (services, pricing, FAQs) so it answers like someone on your team.' ),
			array( '2', 'You review &amp; approve', 'A private preview link shows it working on your site before anything goes live.' ),
			array( '3', 'Live within 24 hours', 'One small snippet on your site and your assistant starts capturing leads around the clock.' ),
		);
		foreach ( $steps as $s ) {
			$body .= '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin-bottom:10px;"><tr>'
				. '<td width="44" valign="top"><div style="' . $fonts . ';width:32px;height:32px;line-height:32px;text-align:center;background-color:#F4F1FE;color:' . self::VIOLET . ';font-weight:800;border-radius:999px;font-size:14px;">' . $s[0] . '</div></td>'
				. '<td style="' . $fonts . ';font-size:14px;color:' . self::TEXT . ';"><strong>' . $s[1] . '</strong><br><span style="color:' . self::MUTED . ';font-size:13px;">' . $s[2] . '</span></td></tr></table>';
		}
		$body .= '<div style="margin-top:22px;">' . self::button( 'Open your dashboard', admin_url() ) . '</div>';
		$body .= '<p style="' . $fonts . ';margin:16px 0 0;font-size:12px;color:' . self::MUTED . ';">Questions? Just reply to this email. A real human reads every one.</p>';
		return self::wrap( 'Welcome to TuaniChat', 'Your 24/7 AI intake assistant is on the way.', $body );
	}

	/** Anniversary gratitude email (6 or 12 months) with the client's real numbers. */
	public static function anniversary( $company, $months, $stats ) {
		$fonts = "font-family:Inter,-apple-system,'Segoe UI',Roboto,Helvetica,Arial,sans-serif";
		$title = 12 === (int) $months ? 'One year together &#127881;' : (int) $months . ' months together &#128153;';
		$body  = '<h1 style="' . $fonts . ';margin:0 0 6px;font-size:22px;color:' . self::TEXT . ';letter-spacing:-0.4px;">' . $title . '</h1>';
		$body .= '<p style="' . $fonts . ';margin:0 0 22px;font-size:14px;color:' . self::MUTED . ';line-height:1.7;">Thank you, ' . esc_html( $company ) . '. While you focused on your business, your assistant was on duty every single night, weekend and holiday. Here is what it captured for you:</p>';
		$cell = function ( $n, $label ) use ( $fonts ) {
			return '<td align="center" style="padding:18px 8px;background-color:#FAFAFC;border:1px solid #ECECF2;border-radius:12px;">'
				. '<div style="' . $fonts . ';font-size:28px;font-weight:800;color:' . self::VIOLET . ';">' . esc_html( $n ) . '</div>'
				. '<div style="' . $fonts . ';font-size:10px;color:' . self::MUTED . ';text-transform:uppercase;letter-spacing:1.5px;">' . esc_html( $label ) . '</div></td>';
		};
		$body .= '<table role="presentation" width="100%" cellpadding="0" cellspacing="6"><tr>'
			. $cell( number_format_i18n( (int) $stats['conversations'] ), 'Conversations' )
			. $cell( number_format_i18n( (int) $stats['leads'] ), 'Leads captured' )
			. $cell( '$' . number_format_i18n( (int) $stats['revenue'] ), 'Revenue you marked Won' )
			. '</tr></table>';
		$body .= '<p style="' . $fonts . ';margin:22px 0 0;font-size:14px;color:' . self::TEXT . ';line-height:1.7;">' . (int) $stats['after_hours'] . ' of those leads arrived <strong>outside business hours</strong>, conversations that would have gone to voicemail. Here is to the next ' . ( 12 === (int) $months ? 'year' : (int) $months . ' months' ) . '.</p>';
		$body .= '<p style="' . $fonts . ';margin:14px 0 0;font-size:13px;color:' . self::MUTED . ';">The TuaniChat team</p>';
		return self::wrap( 'Thank you for ' . (int) $months . ' months with TuaniChat', 'A look at what your assistant captured for you.', $body );
	}

	/** Speed-to-lead: instant branded auto-reply TO the captured lead. */
	public static function speed_to_lead( $lead_name, $company, $summary ) {
		$fonts = "font-family:Inter,-apple-system,'Segoe UI',Roboto,Helvetica,Arial,sans-serif";
		$body  = '<h1 style="' . $fonts . ';margin:0 0 6px;font-size:21px;color:' . self::TEXT . ';">We received your inquiry' . ( $lead_name ? ', ' . esc_html( $lead_name ) : '' ) . ' &#9989;</h1>';
		$body .= '<p style="' . $fonts . ';margin:0 0 18px;font-size:14px;color:' . self::MUTED . ';line-height:1.7;">Thanks for reaching out to <strong>' . esc_html( $company ) . '</strong>. Your details are already with the team and a real person will follow up shortly.</p>';
		if ( $summary ) {
			$body .= '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color:#FAFAFC;border:1px solid #ECECF2;border-radius:12px;"><tr><td style="padding:16px 20px;' . $fonts . ';font-size:13px;color:' . self::TEXT . ';line-height:1.7;"><strong style="font-size:11px;color:' . self::MUTED . ';text-transform:uppercase;letter-spacing:1.5px;">What we noted</strong><br>' . esc_html( $summary ) . '</td></tr></table>';
		}
		$body .= '<p style="' . $fonts . ';margin:18px 0 0;font-size:13px;color:' . self::MUTED . ';">If anything is urgent, call us directly. Otherwise, sit tight: you are in the queue.</p>';
		return self::wrap( 'We received your inquiry: ' . $company, 'A real person will follow up shortly.', $body );
	}

	/** Weekly digest for a client: the week's numbers, simply and beautifully. */
	public static function weekly_digest( $company, $stats ) {
		$fonts = "font-family:Inter,-apple-system,'Segoe UI',Roboto,Helvetica,Arial,sans-serif";
		$body  = '<h1 style="' . $fonts . ';margin:0 0 6px;font-size:21px;color:' . self::TEXT . ';">Your week with TuaniChat</h1>';
		$body .= '<p style="' . $fonts . ';margin:0 0 20px;font-size:14px;color:' . self::MUTED . ';">' . esc_html( $company ) . ' &middot; ' . esc_html( $stats['period'] ) . '</p>';
		$cell = function ( $n, $label, $color ) use ( $fonts ) {
			return '<td align="center" style="padding:16px 6px;background-color:#FAFAFC;border:1px solid #ECECF2;border-radius:12px;">'
				. '<div style="' . $fonts . ';font-size:24px;font-weight:800;color:' . $color . ';">' . esc_html( $n ) . '</div>'
				. '<div style="' . $fonts . ';font-size:10px;color:' . self::MUTED . ';text-transform:uppercase;letter-spacing:1.2px;">' . esc_html( $label ) . '</div></td>';
		};
		$body .= '<table role="presentation" width="100%" cellpadding="0" cellspacing="6"><tr>'
			. $cell( $stats['conversations'], 'Conversations', self::TEXT )
			. $cell( $stats['leads'], 'New leads', '#15803D' )
			. $cell( $stats['capture_rate'], 'Capture rate', self::VIOLET )
			. $cell( $stats['after_hours'], 'After hours', self::FUCHSIA )
			. '</tr></table>';
		if ( ! empty( $stats['top_questions'] ) ) {
			$body .= '<h2 style="' . $fonts . ';margin:24px 0 8px;font-size:13px;color:' . self::MUTED . ';text-transform:uppercase;letter-spacing:1.5px;">Top visitor questions</h2>';
			foreach ( $stats['top_questions'] as $q ) {
				$body .= '<div style="' . $fonts . ';padding:9px 14px;margin-bottom:6px;background-color:#F4F1FE;border-radius:10px;font-size:13px;color:' . self::TEXT . ';">&ldquo;' . esc_html( $q ) . '&rdquo;</div>';
			}
		}
		$body .= '<div style="margin-top:22px;">' . self::button( 'Open your dashboard', admin_url() ) . '</div>';
		return self::wrap( 'Your weekly TuaniChat digest', $stats['leads'] . ' new leads this week.', $body );
	}
}
