<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Prospect score + AI outreach kit generator.
 */
class TNC_Outreach {

	const STARTERS_HOOK = 'tnc_gen_starters';

	public static function init() {
		add_action( self::STARTERS_HOOK, array( __CLASS__, 'cron_generate_starters' ), 10, 1 );
	}

	/** Queue async smart-starter generation after a crawl (non-blocking, key required). */
	public static function queue_starters( $prospect_id ) {
		if ( '' === TNC_Settings::get( 'api_key' ) ) {
			return;
		}
		wp_schedule_single_event( time() + 3, self::STARTERS_HOOK, array( (int) $prospect_id, wp_rand() ) );
		spawn_cron();
	}

	public static function cron_generate_starters( $prospect_id ) {
		$p = TNC_Prospects::get( (int) $prospect_id );
		if ( $p ) {
			self::generate_starters( $p );
		}
	}

	/**
	 * Smart starter questions: 3 visitor questions + 3 guided choices grounded
	 * in the prospect's crawled knowledge. Stored as theme overrides (editable
	 * in the Widget tab). Falls back silently to presets when no key.
	 */
	public static function generate_starters( $prospect ) {
		if ( '' === TNC_Settings::get( 'api_key' ) ) {
			return new WP_Error( 'tnc_no_key', 'No API key configured — industry preset questions stay in use until you add your Anthropic key in Settings.' );
		}
		$crawl = $prospect['crawl_data'];
		$ex    = is_array( $crawl ) && isset( $crawl['extracted'] ) ? $crawl['extracted'] : array();
		if ( empty( $ex ) ) {
			return new WP_Error( 'tnc_nocrawl', 'Crawl the website first — smart questions are grounded in the crawl.' );
		}
		$industry = TNC_Settings::industries()[ $prospect['industry'] ] ?? 'business';
		$facts    = array(
			'Business: ' . ( $prospect['company_name'] ? $prospect['company_name'] : 'n/a' ),
			'Industry: ' . $industry,
			'Hero: ' . ( ! empty( $ex['hero'] ) ? $ex['hero'] : 'n/a' ),
			'Description: ' . ( ! empty( $ex['description'] ) ? $ex['description'] : 'n/a' ),
			'Services found on their site: ' . ( ! empty( $ex['services'] ) ? implode( '; ', array_slice( $ex['services'], 0, 10 ) ) : 'n/a' ),
			'FAQ questions on their site: ' . ( ! empty( $ex['faqs'] ) ? implode( ' | ', array_slice( wp_list_pluck( $ex['faqs'], 'q' ), 0, 6 ) ) : 'n/a' ),
			'Locations: ' . ( ! empty( $ex['locations'] ) ? implode( ' | ', $ex['locations'] ) : 'n/a' ),
		);

		$system = 'You write the opening question chips for an AI intake assistant installed on a specific business\'s website. Output STRICT JSON only, no fences: {"starters":["...","...","..."],"choices":["...","...","..."]}. "starters": exactly 3 questions a REAL visitor of THIS business would tap — grounded in their actual services/FAQs/offers, high purchase intent, each 8 words or fewer, answerable from the business info given. Never invent services they do not offer. "choices": exactly 3 first-person guided options for the widget\'s opening screen (e.g. "I\'d like a free estimate"), 9 words or fewer, the last one a catch-all like "I have a different question".';

		$result = TNC_Anthropic::complete( $system, array( array( 'role' => 'user', 'content' => implode( "
", $facts ) . "

Generate the JSON now." ) ), array( 'max_tokens' => 300, 'temperature' => 0.5 ) );
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		TNC_Prospects::log_usage( $prospect['id'], 'starters', 'starters', $result['model'], $result['input_tokens'], $result['output_tokens'] );

		$json = json_decode( trim( preg_replace( '/^```(?:json)?|```$/m', '', $result['text'] ) ), true );
		if ( ! is_array( $json ) || empty( $json['starters'] ) || ! is_array( $json['starters'] ) ) {
			return new WP_Error( 'tnc_parse', 'AI response could not be parsed. Try again.' );
		}
		$clean = function ( $list ) {
			$out = array();
			foreach ( array_slice( (array) $list, 0, 3 ) as $q ) {
				$q = sanitize_text_field( mb_substr( (string) $q, 0, 90 ) );
				if ( '' !== $q ) {
					$out[] = $q;
				}
			}
			return $out;
		};
		$starters = $clean( $json['starters'] );
		$choices  = isset( $json['choices'] ) ? $clean( $json['choices'] ) : array();
		if ( count( $starters ) < 2 ) {
			return new WP_Error( 'tnc_parse', 'AI returned too few questions. Try again.' );
		}

		$ov = is_array( $prospect['theme_overrides'] ) ? $prospect['theme_overrides'] : array();
		$ov['starters'] = $starters;
		if ( count( $choices ) >= 2 ) {
			$ov['choices'] = $choices;
		}
		TNC_Prospects::update( $prospect['id'], array( 'theme_overrides' => wp_json_encode( $ov ) ) );

		return array( 'starters' => $starters, 'choices' => $choices );
	}

	/**
	 * AI-PERSONALIZED OPENING LINE (toggle, default OFF).
	 * COST RULES (binding): Haiku model; generated ONCE per prospect and cached
	 * PERMANENTLY (never regenerated, dedupe applies); lean distilled input
	 * only, never the full KB; every generation metered in the usage ledger
	 * (dollar metering + spend caps read it). Off = pure free templates.
	 */
	public static function ai_opener( $prospect, $force = false ) {
		if ( ! $force && ! (int) TNC_Settings::get( 'outreach_ai_opener', 0 ) ) {
			return array( 'opener' => '', 'cached' => false, 'skipped' => 'toggle_off' );
		}
		$key    = 'tnc_ai_opener_' . (int) $prospect['id'];
		$cached = get_option( $key );
		if ( is_array( $cached ) && ! empty( $cached['opener'] ) ) {
			return array( 'opener' => $cached['opener'], 'cached' => true, 'meta' => $cached );
		}
		if ( '' === TNC_Settings::get( 'api_key' ) ) {
			return array( 'opener' => '', 'cached' => false, 'skipped' => 'no_key' );
		}
		$crawl = $prospect['crawl_data'];
		$ex    = is_array( $crawl ) && isset( $crawl['extracted'] ) ? $crawl['extracted'] : array();
		// LEAN INPUT: distilled site summary only.
		$facts = array(
			'Company: ' . $prospect['company_name'],
			'Industry: ' . ( TNC_Settings::industries()[ $prospect['industry'] ] ?? 'business' ),
			'Services: ' . ( ! empty( $ex['services'] ) ? implode( '; ', array_slice( (array) $ex['services'], 0, 3 ) ) : 'n/a' ),
			'About: ' . mb_substr( (string) ( ! empty( $ex['description'] ) ? $ex['description'] : ( isset( $ex['hero'] ) ? $ex['hero'] : '' ) ), 0, 300 ),
			'Trust: ' . ( ! empty( $ex['trust_signals'] ) ? implode( ', ', array_slice( (array) $ex['trust_signals'], 0, 3 ) ) : 'n/a' ),
		);
		$model  = (string) TNC_Settings::get( 'opener_model', 'claude-haiku-4-5-20251001' );
		$system = 'You write ONE personalized opening line for a cold email to a local business owner. Max 28 words. Reference one SPECIFIC real detail from the facts (a service, credential, or claim from their own website). Conversational and respectful, no flattery cliches, no buzzwords. STYLE: no em dashes, no en dashes, no emojis, no quotation marks. Output the line only, nothing else.';
		$result = TNC_Anthropic::complete( $system, array( array( 'role' => 'user', 'content' => implode( "\n", $facts ) ) ), array( 'max_tokens' => 80, 'temperature' => 0.7, 'model' => $model ) );
		if ( is_wp_error( $result ) ) {
			return array( 'opener' => '', 'cached' => false, 'skipped' => $result->get_error_code() );
		}
		// DOLLAR METERING: same ledger as chat; spend caps govern this spend.
		TNC_Prospects::log_usage( $prospect['id'], 'opener', 'opener', $result['model'], $result['input_tokens'], $result['output_tokens'] );
		$line = trim( str_replace( array( '"', "\u{2014}", "\u{2013}" ), array( '', ',', ',' ), $result['text'] ) );
		$line = trim( preg_replace( '/\s+/', ' ', $line ) );
		$meta = array( 'opener' => $line, 'model' => $result['model'], 'in' => (int) $result['input_tokens'], 'out' => (int) $result['output_tokens'], 't' => gmdate( 'Y-m-d H:i:s' ) . ' UTC' );
		update_option( $key, $meta, false ); // PERMANENT cache, never regenerated.
		return array( 'opener' => $line, 'cached' => false, 'meta' => $meta );
	}

	/** 0–100 score from crawl signals. Returns [score, breakdown[]]. */
	public static function score( $prospect ) {
		$crawl = $prospect['crawl_data'];
		$ex    = is_array( $crawl ) && isset( $crawl['extracted'] ) ? $crawl['extracted'] : array();
		$bd    = array();
		$score = 0;

		$add = function ( $pts, $label, $hit ) use ( &$score, &$bd ) {
			if ( $hit ) {
				$score += $pts;
				$bd[]   = array( 'label' => $label, 'points' => $pts );
			}
		};

		$platform = isset( $crawl['platform'] ) ? $crawl['platform'] : '';
		$add( 15, 'Easy install platform (' . $platform . ')', in_array( $platform, array( 'wordpress', 'shopify' ), true ) );
		$add( 5,  'Platform detected (' . $platform . ')', $platform && ! in_array( $platform, array( 'wordpress', 'shopify', '' ), true ) );

		$angle      = self::pitch_angle( $ex );
		$has_chat   = 'none' !== $angle['type'];
		$chat_conf  = ! empty( $ex['chat_confidence'] ) ? $ex['chat_confidence'] : 'needs_review';
		$add( 20, 'VERIFIED no chat/intake widget — greenfield', ! $has_chat && 'verified_absent' === $chat_conf );
		$add( 12, 'Probable greenfield (code scan clean — pending visual verification)', ! $has_chat && ! empty( $ex ) && 'verified_absent' !== $chat_conf );
		$add( 10, 'Basic chat detected (' . $angle['provider'] . ') — no AI intake; displacement opportunity', $has_chat && 'basic' === $angle['grade'] );
		$add( 2,  'AI-grade chat in place (' . $angle['provider'] . ') — competitive displacement only', $has_chat && 'ai' === $angle['grade'] && 'tuanichat' !== $angle['type'] );
		$add( 0,  'Existing TuaniChat customer', 'tuanichat' === $angle['type'] );

		$high_value = in_array( $prospect['industry'], array( 'personal_injury', 'law_general', 'med_spa', 'plastic_surgery', 'dental', 'roofing', 'hvac' ), true );
		$add( 15, 'High-value niche (' . $prospect['industry'] . ')', $high_value );
		$add( 8,  'Target niche (' . $prospect['industry'] . ')', ! $high_value && 'other' !== $prospect['industry'] );

		$add( 10, 'Phone number visible (call-driven business)', ! empty( $ex['phones'] ) );
		$add( 8,  'Contact forms present (lead-gen oriented)', ! empty( $ex['forms_present'] ) );
		$add( 10, 'Multiple service pages found (' . count( isset( $ex['services'] ) ? $ex['services'] : array() ) . ')', ! empty( $ex['services'] ) && count( $ex['services'] ) >= 3 );
		$add( 5,  'Physical location(s) listed', ! empty( $ex['locations'] ) );
		$add( 7,  'Marketing pixels present (paying for traffic)', ! empty( $ex['pixels'] ) );
		$add( 8,  'Weak after-hours capture (no chat + no 24/7 mention)', ! $has_chat && empty( $ex['hours_listed'] ) && ! empty( $ex ) );
		$add( 5,  'Strong CTAs present (conversion-focused)', ! empty( $ex['ctas'] ) );
		$add( 4,  'Trust signals to leverage', ! empty( $ex['trust_signals'] ) );

		$score = max( 0, min( 100, $score ) );
		$bd[]  = array( 'label' => 'Pitch angle: ' . $angle['angle'] . ( $angle['provider'] ? ' (' . $angle['provider'] . ')' : '' ), 'points' => 0 );
		return array( $score, $bd );
	}

	/**
	 * Pitch angle from Chat Detection v2 results:
	 * greenfield (no chat) | displacement (basic chat) | competitive (AI-grade) | customer (TuaniChat).
	 */
	public static function pitch_angle( $ex ) {
		$provider = ! empty( $ex['chat_widget'] ) ? $ex['chat_widget'] : '';
		$type     = ! empty( $ex['chat_type'] ) ? $ex['chat_type'] : ( $provider ? 'provider' : 'none' );
		$grade    = ! empty( $ex['chat_grade'] ) ? $ex['chat_grade'] : ( $provider ? 'basic' : 'none' );
		if ( 'tuanichat' === $type ) {
			$angle = 'customer';
		} elseif ( 'none' === $type ) {
			$angle = 'greenfield';
		} elseif ( 'ai' === $grade ) {
			$angle = 'competitive';
		} else {
			$angle = 'displacement';
		}
		return array( 'angle' => $angle, 'provider' => $provider, 'type' => $type, 'grade' => $grade );
	}



	/** Per-industry economics for ROI anchoring in outreach copy. */
	private static function econ( $industry ) {
		$m = array(
			'personal_injury' => array( 'unit' => 'signed case', 'value' => '$25,000+', 'assistant' => 'AI Case Intake Specialist' ),
			'law_general'     => array( 'unit' => 'new matter', 'value' => '$8,000+', 'assistant' => 'AI Case Intake Specialist' ),
			'med_spa'         => array( 'unit' => 'new client', 'value' => '$1,200+', 'assistant' => '24/7 Booking Assistant' ),
			'plastic_surgery' => array( 'unit' => 'procedure', 'value' => '$9,000+', 'assistant' => 'AI Consultation Assistant' ),
			'dental'          => array( 'unit' => 'new patient', 'value' => '$1,800+', 'assistant' => 'AI Patient Intake Assistant' ),
			'roofing'         => array( 'unit' => 'job', 'value' => '$10,000+', 'assistant' => 'After-Hours Estimate Assistant' ),
			'hvac'            => array( 'unit' => 'job', 'value' => '$1,200+', 'assistant' => 'After-Hours Dispatcher' ),
			'local_services'  => array( 'unit' => 'job', 'value' => '$500+', 'assistant' => 'AI Lead Capture Assistant' ),
			'ecommerce'       => array( 'unit' => 'order', 'value' => '$85+', 'assistant' => 'AI Shopping Assistant' ),
			'other'           => array( 'unit' => 'sale', 'value' => '$500+', 'assistant' => 'AI Lead Capture Assistant' ),
		);
		return isset( $m[ $industry ] ) ? $m[ $industry ] : $m['other'];
	}

	/**
	 * FREE outreach kit: merges real crawl findings into proven templates.
	 * Zero AI cost — the default everywhere. AI personalization is opt-in.
	 */
	public static function template_kit( $prospect ) {
		$crawl = $prospect['crawl_data'];
		if ( ! is_array( $crawl ) || empty( $crawl['extracted'] ) ) {
			return new WP_Error( 'tnc_nocrawl', 'Crawl the website first — the outreach kit is built from crawl data.' );
		}
		$ex       = $crawl['extracted'];
		$company  = $prospect['company_name'] ? $prospect['company_name'] : wp_parse_url( $prospect['website_url'], PHP_URL_HOST );
		$industry = TNC_Settings::industries()[ $prospect['industry'] ] ?? 'business';
		$demo_url = home_url( '/demo/' . $prospect['demo_slug'] . '/' );
		$contact  = $prospect['contact_name'] ? $prospect['contact_name'] : 'there';
		$angle    = self::pitch_angle( $ex );
		$partner  = 'partner' === TNC_Settings::get( 'outreach_identity', 'tuanichat' );
		$pages    = ! empty( $crawl['page_count'] ) ? (int) $crawl['page_count'] : 0;
		$services = ! empty( $ex['services'] ) ? array_slice( (array) $ex['services'], 0, 3 ) : array();
		$svc_line = $services ? implode( ', ', $services ) : 'your services';
		$signoff  = $partner ? "The Lion Click Media team\n(in partnership with TuaniChat)" : "The TuaniChat team\nTuaniLabs";
		$intro    = $partner ? "We're Lion Click Media. We've partnered with TuaniChat to bring AI intake to local businesses." : '';

		if ( 'displacement' === $angle['angle'] ) {
			$hook = "I noticed {$company} runs {$angle['provider']} on the site. It pops up, but it can't answer questions from your website content, qualify a visitor, or capture a lead at 2am.";
			$gap  = "Your current chat ({$angle['provider']}) pops up, but it can't answer from your website content or qualify visitors after hours.";
		} elseif ( 'competitive' === $angle['angle'] ) {
			$hook = "I noticed {$company} already uses {$angle['provider']}. It's capable, but not specialized for {$industry} or trained on your own pages the way a dedicated intake assistant is.";
			$gap  = "Your current platform ({$angle['provider']}) is capable, but it isn't specialized for {$industry} or trained on your own pages.";
		} else {
			$hook = "I was on {$company}'s website and noticed there's no way for a visitor with a question at 9pm to get an answer. They bounce, usually to a competitor.";
			$gap  = "There's no intake assistant on the site, so visitors with questions after hours have no way to get answers. They leave.";
		}
		$proof = $pages
			? "We built a working preview from {$pages} pages of your own website. It already answers real questions about {$svc_line}."
			: "We built a working preview from your own website. It already answers real questions about {$svc_line}.";

		$eco  = self::econ( $prospect['industry'] );
		$book = esc_url( (string) TNC_Settings::get( 'cta_booking_url', '' ) );
		$op   = self::ai_opener( $prospect );
		$lead_line = ! empty( $op['opener'] ) ? $op['opener'] : $hook;
		$cold = "Subject: {$company}: your website after 6pm\n\nHi {$contact},\n\n{$lead_line}\n\nHere's the math that made me write: roughly a third of visitor questions come in after hours. At one {$eco['unit']} worth {$eco['value']}, even ONE saved lead a month changes the year.\n\nSo instead of pitching, we built it: {$proof} It captures the visitor's name, number and need, then hands you the lead while they're still on your site.\n\nSee it working on your own website (private link, only you have it):\n{$demo_url}\n\nIf you like it, it's live within 24 hours. No contract, and you keep every lead either way." . ( $book ? "\n\nPrefer to talk it through? Grab any time that suits you: {$book}" : '' ) . ( $intro ? "\n\n{$intro}" : '' ) . "\n\n{$signoff}\n\nP.S. The preview answers real questions about {$svc_line}. Try asking it something hard.\n\nIf this isn't relevant, just reply 'no thanks' and I won't follow up.";

		$follow = "Subject: Re: {$company}: your website after 6pm\n\nHi {$contact},\n\nKeeping this short: the private preview of {$company}'s own {$eco['assistant']} is still live:\n{$demo_url}\n\nIt answers from your real website content, so most owners test it with their hardest customer question first. That's the fun part.\n\nOne {$eco['unit']} at {$eco['value']} pays for years of this. Live within 24 hours if you want it; if not, I'll take the preview down next week, no hard feelings." . ( $book ? "\n\nOr book a quick call: {$book}" : '' ) . "\n\n{$signoff}";

		$li = "Hi {$contact}, I built {$company} a working {$eco['assistant']} preview: your actual website, answering real visitor questions from your own content, capturing leads 24/7. Two minutes to see. Want the private link?";

		$lines   = array();
		$lines[] = "What we found on {$company}'s website:";
		if ( $services ) {
			$lines[] = '- ' . count( (array) $ex['services'] ) . " services clearly presented, including {$svc_line}.";
		}
		if ( ! empty( $ex['trust_signals'] ) ) {
			$lines[] = '- Strong trust signals worth leveraging: ' . implode( ', ', array_slice( (array) $ex['trust_signals'], 0, 4 ) ) . '.';
		}
		if ( ! empty( $ex['phones'] ) ) {
			$lines[] = "- Phone-driven business: {$ex['phones'][0]} is front and center, so calls clearly matter to you.";
		}
		if ( ! empty( $ex['pricing'] ) ) {
			$lines[] = '- ' . count( (array) $ex['pricing'] ) . ' published prices. Visitors clearly want answers about cost before they call.';
		}
		$lines[] = '- ' . $gap;
		$lines[] = '- After hours, calls and forms go unanswered. That is exactly where leads leak.';
		$lines[] = '';
		$lines[] = $pages
			? "The private demo shows the fix: an AI intake assistant trained on {$pages} pages of your own website, answering visitor questions and capturing qualified leads 24/7. See it live: {$demo_url}"
			: "The private demo shows the fix: an AI intake assistant trained on your own website, answering visitor questions and capturing qualified leads 24/7. See it live: {$demo_url}";
		$audit = implode( "\n", $lines );

		$kit = array(
			'cold_email'       => sanitize_textarea_field( $cold ),
			'follow_up_email'  => sanitize_textarea_field( $follow ),
			'linkedin_message' => sanitize_textarea_field( $li ),
			'audit_text'       => sanitize_textarea_field( $audit ),
			'mode'             => 'template',
			'generated_at'     => current_time( 'mysql' ),
		);
		TNC_Prospects::update( $prospect['id'], array( 'outreach_json' => wp_json_encode( $kit ) ) );
		return $kit;
	}

	/** Generate cold email, follow-up, LinkedIn message, audit text via AI. */
	public static function generate_kit( $prospect ) {
		$crawl = $prospect['crawl_data'];
		if ( ! is_array( $crawl ) || empty( $crawl['extracted'] ) ) {
			return new WP_Error( 'tnc_nocrawl', 'Crawl the website first — the outreach kit is generated from crawl data.' );
		}
		$ex       = $crawl['extracted'];
		$company  = $prospect['company_name'] ? $prospect['company_name'] : wp_parse_url( $prospect['website_url'], PHP_URL_HOST );
		$industry = TNC_Settings::industries()[ $prospect['industry'] ] ?? 'business';
		$demo_url = home_url( '/demo/' . $prospect['demo_slug'] . '/' );
		$contact  = $prospect['contact_name'] ? $prospect['contact_name'] : 'there';

		$facts   = array();
		$facts[] = 'Company: ' . $company;
		$facts[] = 'Industry: ' . $industry;
		$facts[] = 'Website: ' . $prospect['website_url'];
		$facts[] = 'Platform: ' . ( isset( $crawl['platform'] ) ? $crawl['platform'] : 'unknown' );
		$angle   = self::pitch_angle( $ex );
		$facts[] = 'Existing chat widget: ' . ( $angle['provider'] ? $angle['provider'] . ' (' . $angle['type'] . ', grade: ' . $angle['grade'] . ')' : 'NONE detected' );
		$facts[] = 'PITCH ANGLE: ' . $angle['angle'];
		$facts[] = 'Services found: ' . ( ! empty( $ex['services'] ) ? implode( '; ', array_slice( $ex['services'], 0, 8 ) ) : 'n/a' );
		$facts[] = 'Locations: ' . ( ! empty( $ex['locations'] ) ? implode( ' | ', $ex['locations'] ) : 'n/a' );
		$facts[] = 'Phone visible: ' . ( ! empty( $ex['phones'] ) ? implode( ', ', $ex['phones'] ) : 'no' );
		$facts[] = 'Forms present: ' . ( ! empty( $ex['forms_present'] ) ? 'yes' : 'no' );
		$facts[] = 'Trust signals: ' . ( ! empty( $ex['trust_signals'] ) ? implode( ', ', $ex['trust_signals'] ) : 'n/a' );
		$facts[] = 'Marketing pixels: ' . ( ! empty( $ex['pixels'] ) ? implode( ', ', $ex['pixels'] ) : 'none detected' );
		$facts[] = 'Description: ' . ( ! empty( $ex['description'] ) ? $ex['description'] : 'n/a' );

		$angle_rule = 'greenfield' === $angle['angle']
			? 'ANGLE: greenfield — they have NO chat at all. Lead with the missed after-hours leads and unanswered visitor questions.'
			: ( 'displacement' === $angle['angle']
				? 'ANGLE: displacement — they already use ' . $angle['provider'] . '. Name it and contrast concretely: it pops up, but it cannot answer questions from their website content, qualify visitors, or capture leads while they sleep ("You are using ' . $angle['provider'] . ', here is what it cannot do"). Never trash-talk; stay factual.'
				: 'ANGLE: competitive — they run an AI-capable platform (' . $angle['provider'] . '). Lead with specialization for their industry, faster setup and per-site pricing; be respectful of the incumbent.' );

		$identity_rule = 'partner' === TNC_Settings::get( 'outreach_identity', 'tuanichat' )
			? ' SENDER IDENTITY: you write as Lion Click Media, a digital agency that has PARTNERED WITH TuaniChat — introduce TuaniChat as the AI intake technology Lion Click installs and manages for clients (e.g. \"we\'ve partnered with TuaniChat to bring this to local businesses\"). Sign off as the Lion Click team.'
			: '';
		$system = $angle_rule . $identity_rule . ' You are a top-tier B2B copywriter for TuaniLabs, makers of TuaniChat — an AI Intake Assistant (NOT a chatbot) that turns website visitors into qualified leads 24/7. You write personalized, non-salesy, specific outreach based on real findings from the prospect\'s website. Voice: confident, helpful, concrete, zero fluff, no buzzwords like "revolutionize". Never invent facts not in the provided data. STYLE RULES (hard): never use em dashes or en dashes anywhere, use commas or periods instead; never use emojis of any kind. Output STRICT JSON only, no markdown fences, with keys: cold_email (with subject line on first line as "Subject: ..."), follow_up_email, linkedin_message, audit_text. The linkedin_message must be under 60 words, casual, no links pitch — just tease the private demo. The audit_text is a 150-250 word "what we found on your website" summary written to the prospect: strengths first (trust signals, services), then gaps (no intake assistant / after-hours capture, etc.), then how the private demo fixes it. The cold email: 120-170 words, references 2-3 specific findings, one CTA: view their private demo at ' . $demo_url . '. Address the contact as ' . $contact . '.';

		$user = "Prospect findings:\n" . implode( "\n", $facts ) . "\n\nGenerate the JSON now.";

		$result = TNC_Anthropic::complete( $system, array( array( 'role' => 'user', 'content' => $user ) ), array( 'max_tokens' => 1600, 'temperature' => 0.6 ) );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		TNC_Prospects::log_usage( $prospect['id'], 'outreach', 'outreach', $result['model'], $result['input_tokens'], $result['output_tokens'] );

		$text = $result['text'];
		// Strip accidental code fences.
		$text = preg_replace( '/^```(?:json)?|```$/m', '', $text );
		$kit  = json_decode( trim( $text ), true );
		if ( ! is_array( $kit ) || empty( $kit['cold_email'] ) ) {
			return new WP_Error( 'tnc_parse', 'AI response could not be parsed. Try again.' );
		}

		$kit = array(
			'cold_email'       => sanitize_textarea_field( $kit['cold_email'] ),
			'follow_up_email'  => sanitize_textarea_field( isset( $kit['follow_up_email'] ) ? $kit['follow_up_email'] : '' ),
			'linkedin_message' => sanitize_textarea_field( isset( $kit['linkedin_message'] ) ? $kit['linkedin_message'] : '' ),
			'audit_text'       => sanitize_textarea_field( isset( $kit['audit_text'] ) ? $kit['audit_text'] : '' ),
			'mode'             => 'ai',
			'generated_at'     => current_time( 'mysql' ),
		);

		TNC_Prospects::update( $prospect['id'], array( 'outreach_json' => wp_json_encode( $kit ) ) );
		return $kit;
	}
}
