<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Worker dispatcher: true concurrency on shared hosting via non-blocking
 * loopback requests, a self-healing watchdog (bulk lanes + deep crawls), and
 * a token-authed 1-minute system-cron heartbeat so nothing ever depends on
 * site traffic. Tracks crawl throughput (pages/min) for the Workers panel.
 */
class TNC_Workers {

	const ACTION    = 'tnc_worker';
	const HEARTBEAT = 'tnc_heartbeat';

	public static function init() {
		add_action( 'wp_ajax_' . self::ACTION, array( __CLASS__, 'handle' ) );
		add_action( 'wp_ajax_nopriv_' . self::ACTION, array( __CLASS__, 'handle' ) );
		add_action( 'wp_ajax_' . self::HEARTBEAT, array( __CLASS__, 'heartbeat' ) );
		add_action( 'wp_ajax_nopriv_' . self::HEARTBEAT, array( __CLASS__, 'heartbeat' ) );
		add_action( 'tnc_watchdog', array( __CLASS__, 'watchdog' ) );
		if ( ! wp_next_scheduled( 'tnc_watchdog' ) ) {
			wp_schedule_event( time() + 120, 'hourly', 'tnc_watchdog' );
		}
	}

	public static function token() {
		$t = get_option( 'tnc_worker_secret' );
		if ( ! $t ) {
			$t = wp_generate_password( 40, false, false );
			update_option( 'tnc_worker_secret', $t, false );
		}
		return $t;
	}

	/** The URL a 1-minute system cron should hit. */
	public static function heartbeat_url() {
		return admin_url( 'admin-ajax.php?action=' . self::HEARTBEAT . '&token=' . self::token() );
	}

	/** Fire-and-forget loopback: one extra PHP process runs the worker now. */
	public static function spawn( $type, $args = array() ) {
		wp_remote_post( admin_url( 'admin-ajax.php' ), array(
			'timeout'   => 0.01,
			'blocking'  => false,
			'sslverify' => false,
			'body'      => array(
				'action' => self::ACTION,
				'token'  => self::token(),
				'type'   => sanitize_key( $type ),
				'args'   => wp_json_encode( $args ),
			),
		) );
	}

	public static function handle() {
		$token = isset( $_POST['token'] ) ? sanitize_text_field( wp_unslash( $_POST['token'] ) ) : '';
		if ( ! hash_equals( self::token(), $token ) ) {
			wp_die( '', '', array( 'response' => 403 ) );
		}
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 280 );
		}
		if ( function_exists( 'wp_raise_memory_limit' ) ) {
			wp_raise_memory_limit( 'admin' );
		}
		ignore_user_abort( true );
		$type = isset( $_POST['type'] ) ? sanitize_key( wp_unslash( $_POST['type'] ) ) : '';
		$args = isset( $_POST['args'] ) ? json_decode( sanitize_text_field( wp_unslash( $_POST['args'] ) ), true ) : array();
		$args = is_array( $args ) ? $args : array();

		switch ( $type ) {
			case 'bulk':
				if ( ! empty( $args['batch'] ) ) {
					TNC_Bulk::tick( $args['batch'], wp_rand() );
				}
				break;
			case 'deep':
				if ( ! empty( $args['prospect'] ) ) {
					TNC_Crawl_Jobs::process_batch( (int) $args['prospect'] );
				}
				break;
			case 'lh':
				if ( ! empty( $args['batch'] ) ) {
					TNC_Leadhunter::tick( sanitize_key( $args['batch'] ) );
				}
				break;
			case 'starters':
				if ( ! empty( $args['prospect'] ) ) {
					TNC_Outreach::cron_generate_starters( (int) $args['prospect'] );
				}
				break;
		}
		wp_die( 'ok' );
	}

	/**
	 * System-cron heartbeat (every minute): records liveness, resumes anything
	 * stalled, and runs due WP-Cron events — no site traffic required, ever.
	 */
	public static function heartbeat() {
		$token = isset( $_REQUEST['token'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['token'] ) ) : '';
		if ( ! hash_equals( self::token(), $token ) ) {
			wp_die( '', '', array( 'response' => 403 ) );
		}
		ignore_user_abort( true );
		if ( function_exists( 'wp_raise_memory_limit' ) ) {
			wp_raise_memory_limit( 'admin' );
		}
		update_option( 'tnc_heartbeat_last', time(), false );
		try {
			TNC_Fleet::check_alerts();   // fleet node offline > 5 min -> flag + email.
			TNC_Backup::check_alerts();  // backup failed or > 36 h stale -> email.
			if ( class_exists( 'TNC_Leadhunter' ) ) { TNC_Leadhunter::loop_tick(); } // always-on hunting loop.
		} catch ( \Throwable $e ) {
			update_option( 'tnc_watchdog_err', 'alerts: ' . $e->getMessage(), false );
		}
		try {
			self::watchdog();
		} catch ( \Throwable $e ) {
			update_option( 'tnc_watchdog_err', $e->getMessage() . ' @ ' . basename( $e->getFile() ) . ':' . $e->getLine(), false );
		}
		try {
			spawn_cron();
		} catch ( \Throwable $e ) {
			update_option( 'tnc_watchdog_err', 'spawn_cron: ' . $e->getMessage(), false );
		}
		wp_die( 'ok' );
	}

	/** Self-healing: resume bulk lanes AND stalled deep crawls. */
	public static function watchdog() {
		global $wpdb;

		// 1) Bulk: queued work but no active lane => respawn.
		$batch = $wpdb->get_var(
			'SELECT batch_id FROM ' . TNC_Prospects::table() . " WHERE status = 'queued' AND batch_id <> '' ORDER BY id ASC LIMIT 1"
		);
		if ( $batch ) {
			$active = 0;
			for ( $i = 1; $i <= TNC_Bulk::lanes(); $i++ ) {
				if ( get_transient( 'tnc_bulk_lane_' . $i ) ) {
					$active++;
				}
			}
			if ( 0 === $active ) {
				self::spawn( 'bulk', array( 'batch' => $batch ) );
			}
		}

		// 2) Deep crawls: any prospect marked running with stale progress => resume.
		$ids = $wpdb->get_col( 'SELECT id FROM ' . TNC_Prospects::table() . " WHERE crawl_state = 'running'" );
		foreach ( $ids as $id ) {
			$id    = (int) $id;
			$state = get_option( TNC_Crawl_Jobs::state_key( $id ) );
			if ( ! is_array( $state ) ) {
				TNC_Prospects::update( $id, array(
					'crawl_state' => 'failed',
					'last_error'  => 'Crawl state lost — start the deep crawl again.',
				) );
				continue;
			}
			if ( ! empty( $state['awaiting'] ) ) {
				continue; // paused on the size decision, not stalled.
			}
			$tick = isset( $state['last_tick'] ) ? (int) $state['last_tick'] : ( isset( $state['started'] ) ? (int) $state['started'] : 0 );
			if ( ( time() - $tick ) > TNC_Crawl_Jobs::STALL_SECS ) {
				try {
					TNC_Crawl_Jobs::resume( $id );
				} catch ( \Throwable $e ) {
					update_option( 'tnc_watchdog_err', $e->getMessage() . ' @ ' . basename( $e->getFile() ) . ':' . $e->getLine(), false );
				}
			}
		}
	}

	/** Rolling pages/min counter (minute buckets, last ~10 min). */
	public static function bump_rate( $pages ) {
		$pages = (int) $pages;
		if ( $pages < 1 ) {
			return;
		}
		$m    = (int) floor( time() / 60 );
		$rate = get_option( 'tnc_rate', array() );
		if ( ! is_array( $rate ) ) {
			$rate = array();
		}
		$rate[ $m ] = ( isset( $rate[ $m ] ) ? (int) $rate[ $m ] : 0 ) + $pages;
		foreach ( array_keys( $rate ) as $k ) {
			if ( (int) $k < $m - 10 ) {
				unset( $rate[ $k ] );
			}
		}
		update_option( 'tnc_rate', $rate, false );
	}

	public static function pages_per_min() {
		$m    = (int) floor( time() / 60 );
		$rate = get_option( 'tnc_rate', array() );
		if ( ! is_array( $rate ) ) {
			return 0;
		}
		$sum = 0;
		for ( $i = 0; $i < 3; $i++ ) {
			$sum += isset( $rate[ $m - $i ] ) ? (int) $rate[ $m - $i ] : 0;
		}
		return round( $sum / 3, 1 );
	}

	/** Status for the admin Workers panel. */
	public static function status() {
		global $wpdb;
		$lanes = array();
		for ( $i = 1; $i <= TNC_Bulk::lanes(); $i++ ) {
			$lanes[] = array( 'lane' => $i, 'active' => (bool) get_transient( 'tnc_bulk_lane_' . $i ) );
		}
		$ppm  = self::pages_per_min();
		$deep = array();
		$rows = $wpdb->get_results(
			'SELECT id, company_name, crawl_state, crawl_progress FROM ' . TNC_Prospects::table() . " WHERE crawl_state IN ('running','decision')",
			ARRAY_A
		);
		foreach ( (array) $rows as $r ) {
			$pr      = json_decode( (string) $r['crawl_progress'], true );
			$fetched = is_array( $pr ) && isset( $pr['fetched'] ) ? (int) $pr['fetched'] : 0;
			$total   = is_array( $pr ) && isset( $pr['total'] ) ? (int) $pr['total'] : 0;
			$deep[]  = array(
				'id'      => (int) $r['id'],
				'name'    => $r['company_name'],
				'state'   => $r['crawl_state'],
				'fetched' => $fetched,
				'total'   => $total,
				'stalled' => TNC_Crawl_Jobs::stalled( array( 'id' => $r['id'], 'crawl_state' => $r['crawl_state'] ) ),
				'eta_min' => ( $ppm > 0 && $total > $fetched && 'running' === $r['crawl_state'] ) ? max( 1, (int) round( ( $total - $fetched ) / $ppm ) ) : null,
			);
		}
		$hb = (int) get_option( 'tnc_heartbeat_last', 0 );
		$diag = array_filter( array(
			'watchdog' => (string) get_option( 'tnc_watchdog_err', '' ),
			'resume'   => (string) get_option( 'tnc_last_resume_err', '' ),
		) );
		return array(
			'diag'          => $diag,
			'lanes'         => $lanes,
			'queued'        => (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . TNC_Prospects::table() . " WHERE status = 'queued'" ),
			'crawling'      => (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . TNC_Prospects::table() . " WHERE status = 'crawling'" ),
			'pages_per_min' => $ppm,
			'heartbeat_age' => $hb ? ( time() - $hb ) : null,
			'deep'          => $deep,
		);
	}
}
