<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * TUANIMAIL FOUNDATION — multi-identity / multi-stream sending architecture.
 *
 * Core doctrine (binding):
 *  - Reputation is ISOLATED per stream. Streams never share an identity:
 *      transactional  — lead alerts, receipts, system mail (highest trust)
 *      notification   — digests, anniversaries, marketing to existing clients
 *      cold           — outreach. ALWAYS a fully SEPARATE DOMAIN (never a
 *                       subdomain of the brand). Inactive until one exists.
 *  - The ROOT brand domain is NEVER a From on our servers (lionclickmedia.com
 *    is Outlook-only with hard-fail SPF; same rule will apply to tuanilabs.com).
 *  - Each identity carries its own SPF/DKIM/DMARC, warmup state and daily cap.
 *  - IP rule encoded: do NOT spread low volume across many IPs/domains —
 *    add identities only when volume justifies them.
 */
class TNC_Mail_Streams {

	const OPT = 'tnc_mail_identities';

	/** Default per-ISP throttle map (msgs/hour) — Intelligence Core tunes later. */
	public static function isp_throttles() {
		$o = get_option( 'tnc_isp_throttles' );
		return is_array( $o ) ? $o : array(
			'gmail.com'      => 60,
			'googlemail.com' => 60,
			'outlook.com'    => 30,
			'hotmail.com'    => 30,
			'live.com'       => 30,
			'yahoo.com'      => 40,
			'aol.com'        => 40,
			'default'        => 80,
		);
	}

	/** Identity registry, seeded with the live SPF-aligned DreamHost identity. */
	public static function identities() {
		$ids = get_option( self::OPT );
		if ( ! is_array( $ids ) || empty( $ids ) ) {
			$host = preg_replace( '/^www\./', '', strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) ) );
			$ids  = array(
				array(
					'id'       => 'dh-transactional',
					'streams'  => array( 'transactional', 'notification' ), // shared until a second identity exists.
					'domain'   => $host,
					'from'     => 'tuanichat@' . $host,
					'selector' => 'tnc1',
					'warmup'   => 'established', // DreamHost shared IP carries existing reputation.
					'daily_cap' => 200,           // conservative shared-host ceiling.
					'active'   => true,
					'notes'    => 'DreamHost shared, SPF-aligned envelope. DKIM pending DNS record.',
				),
				array(
					'id'       => 'cold-outreach',
					'streams'  => array( 'cold' ),
					'domain'   => '',  // REQUIRES a separate purchased domain — user decision ($ cost).
					'from'     => '',
					'selector' => 'tnc1',
					'warmup'   => 'unprovisioned',
					'daily_cap' => 0,
					'active'   => false,
					'notes'    => 'COLD STREAM HARD RULE: separate domain only, never the brand. Inactive until provisioned + warmed.',
				),
			);
			update_option( self::OPT, $ids, false );
		}
		return $ids;
	}

	/** Route a message type to its sending identity (or null = blocked). */
	public static function route( $type ) {
		$type = in_array( $type, array( 'transactional', 'notification', 'cold' ), true ) ? $type : 'notification';
		foreach ( self::identities() as $ident ) {
			if ( ! empty( $ident['active'] ) && in_array( $type, (array) $ident['streams'], true ) ) {
				return $ident;
			}
		}
		return null; // no active identity for this stream — sending is blocked, never mis-routed.
	}

	/** Per-identity daily cap governor. Returns true when within cap. */
	public static function within_cap( $ident ) {
		$cap = isset( $ident['daily_cap'] ) ? (int) $ident['daily_cap'] : 0;
		if ( $cap <= 0 ) {
			return false;
		}
		$key   = 'tnc_ms_' . $ident['id'] . '_' . gmdate( 'Ymd' );
		$count = (int) get_transient( $key );
		if ( $count >= $cap ) {
			return false;
		}
		set_transient( $key, $count + 1, DAY_IN_SECONDS );
		return true;
	}

	/**
	 * VERIFICATION PIPELINE (free tier): syntax -> MX -> disposable -> role ->
	 * optional cautious SMTP RCPT probe with catch-all detection. Big providers
	 * (Gmail/Microsoft/Yahoo/iCloud) are honestly marked unverifiable at the
	 * mailbox level, they accept-all or block probes, so we never false-flag
	 * them. Mailbox certainty for those needs a paid API (future option, OFF).
	 * Returns: verdict verified|risky|role|unverifiable|invalid, class
	 * personal|role, checks[].
	 */
	public static function verify_address( $email, $probe = null ) {
		$checks = array();
		$email  = strtolower( trim( (string) $email ) );
		if ( ! filter_var( $email, FILTER_VALIDATE_EMAIL ) ) {
			return array( 'verdict' => 'invalid', 'class' => '', 'checks' => array( 'syntax_fail' ) );
		}
		$checks[] = 'syntax_ok';
		list( $local, $domain ) = explode( '@', $email, 2 );

		$has_mx = function_exists( 'checkdnsrr' ) && ( checkdnsrr( $domain, 'MX' ) || checkdnsrr( $domain, 'A' ) );
		if ( ! $has_mx ) {
			return array( 'verdict' => 'invalid', 'class' => '', 'checks' => array_merge( $checks, array( 'no_mx' ) ) );
		}
		$checks[] = 'mx_ok';

		$disposable = array( 'mailinator.com', 'guerrillamail.com', '10minutemail.com', 'tempmail.com', 'yopmail.com', 'sharklasers.com', 'trashmail.com', 'getnada.com', 'temp-mail.org', 'fakeinbox.com' );
		if ( in_array( $domain, $disposable, true ) ) {
			return array( 'verdict' => 'invalid', 'class' => '', 'checks' => array_merge( $checks, array( 'disposable' ) ) );
		}

		$roles = array( 'info', 'admin', 'support', 'sales', 'contact', 'office', 'hello', 'team', 'billing', 'noreply', 'no-reply', 'postmaster', 'webmaster', 'abuse', 'enquiries', 'inquiries', 'help', 'service', 'frontdesk', 'reception', 'bookings', 'appointments' );
		$class = in_array( $local, $roles, true ) ? 'role' : 'personal';

		// Big providers: mailbox-level existence is unverifiable for free, by design.
		$big = array( 'gmail.com', 'googlemail.com', 'outlook.com', 'hotmail.com', 'live.com', 'msn.com', 'yahoo.com', 'aol.com', 'icloud.com', 'me.com' );
		if ( in_array( $domain, $big, true ) ) {
			return array( 'verdict' => 'role' === $class ? 'role' : 'unverifiable', 'class' => $class, 'checks' => array_merge( $checks, array( 'big_provider_no_probe' ) ) );
		}

		// Optional cautious SMTP RCPT probe (default OFF; rate-limited; never
		// from a dedicated sending IP since shared hosts mask the origin anyway).
		if ( null === $probe ) {
			$probe = (bool) TNC_Settings::get( 'verify_smtp_probe', 0 );
		}
		if ( $probe && function_exists( 'fsockopen' ) && (int) get_transient( 'tnc_probe_count_' . gmdate( 'YmdH' ) ) < 30 ) {
			set_transient( 'tnc_probe_count_' . gmdate( 'YmdH' ), (int) get_transient( 'tnc_probe_count_' . gmdate( 'YmdH' ) ) + 1, HOUR_IN_SECONDS );
			$result = self::smtp_probe( $email, $domain );
			$checks = array_merge( $checks, $result['checks'] );
			if ( 'invalid' === $result['verdict'] ) {
				return array( 'verdict' => 'invalid', 'class' => $class, 'checks' => $checks );
			}
			if ( 'verified' === $result['verdict'] && empty( $result['catch_all'] ) ) {
				return array( 'verdict' => 'role' === $class ? 'role' : 'verified', 'class' => $class, 'checks' => $checks );
			}
		}

		return array( 'verdict' => 'role' === $class ? 'role' : 'risky', 'class' => $class, 'checks' => $checks );
	}

	/** Cautious RCPT probe + catch-all detection. Soft-fails to unverifiable. */
	private static function smtp_probe( $email, $domain ) {
		$mx = array();
		if ( function_exists( 'getmxrr' ) ) {
			getmxrr( $domain, $mx );
		}
		$host = $mx ? $mx[0] : $domain;
		$fp   = @fsockopen( $host, 25, $errno, $errstr, 5 );
		if ( ! $fp ) {
			return array( 'verdict' => 'unverifiable', 'checks' => array( 'probe_no_connect' ) );
		}
		stream_set_timeout( $fp, 5 );
		$say = function ( $cmd ) use ( $fp ) {
			if ( null !== $cmd ) {
				fwrite( $fp, $cmd . "\r\n" );
			}
			$line = fgets( $fp, 512 );
			return (int) substr( (string) $line, 0, 3 );
		};
		$out = array( 'verdict' => 'unverifiable', 'checks' => array(), 'catch_all' => false );
		if ( 220 === $say( null ) && 250 === $say( 'EHLO ' . wp_parse_url( home_url(), PHP_URL_HOST ) ) && 250 === $say( 'MAIL FROM:<verify@' . wp_parse_url( home_url(), PHP_URL_HOST ) . '>' ) ) {
			$code = $say( 'RCPT TO:<' . $email . '>' );
			if ( 250 === $code ) {
				$rand = $say( 'RCPT TO:<zz' . wp_rand( 100000, 999999 ) . 'probe@' . $domain . '>' );
				$out['catch_all'] = ( 250 === $rand );
				$out['verdict']   = 'verified';
				$out['checks'][]  = $out['catch_all'] ? 'rcpt_ok_catch_all' : 'rcpt_ok';
			} elseif ( $code >= 500 ) {
				$out['verdict']  = 'invalid';
				$out['checks'][] = 'rcpt_rejected';
			} else {
				$out['checks'][] = 'rcpt_inconclusive';
			}
		}
		fwrite( $fp, "QUIT\r\n" );
		fclose( $fp );
		return $out;
	}

	/** Contact ranking: personal > role, verified > risky. For Lead Hunter. */
	public static function rank_contacts( $contacts ) {
		$scored = array();
		foreach ( (array) $contacts as $c ) {
			$v = self::verify_address( isset( $c['email'] ) ? $c['email'] : '' , false );
			$c['class']   = $v['class'];
			$c['verdict'] = $v['verdict'];
			$c['rank']    = ( 'personal' === $v['class'] ? 100 : 40 ) + ( 'verified' === $v['verdict'] ? 20 : ( 'invalid' === $v['verdict'] ? -100 : 0 ) );
			$scored[]     = $c;
		}
		usort( $scored, function ( $a, $b ) { return $b['rank'] - $a['rank']; } );
		return $scored;
	}

	/* ---------------- SUPPRESSION + ONE-CLICK UNSUB ---------------- */

	public static function suppressed( $email ) {
		$l = (array) get_option( 'tnc_suppression', array() );
		return in_array( strtolower( trim( (string) $email ) ), $l, true );
	}

	public static function suppress( $email, $reason = 'unsubscribe' ) {
		$e = strtolower( trim( (string) $email ) );
		if ( ! $e ) {
			return;
		}
		$l = (array) get_option( 'tnc_suppression', array() );
		if ( ! in_array( $e, $l, true ) ) {
			$l[] = $e;
			update_option( 'tnc_suppression', $l, false );
		}
		TNC_Emails::log( array( 'event' => 'suppressed', 'to' => $e, 'reason' => $reason ) );
	}

	public static function unsub_token( $email ) {
		return substr( hash_hmac( 'sha256', 'unsub:' . strtolower( trim( (string) $email ) ), wp_salt( 'auth' ) ), 0, 20 );
	}

	/* ---------------- INBOUND REPLY MANAGEMENT ---------------- */

	/** Classify an inbound reply. */
	public static function classify_reply( $text ) {
		$t = strtolower( (string) $text );
		if ( preg_match( '/unsubscribe|remove me|take me off|stop emailing/', $t ) ) {
			return 'unsubscribe';
		}
		if ( preg_match( '/out of (the )?office|auto.?reply|on vacation|annual leave|maternity|paternity|back on/', $t ) ) {
			return 'ooo';
		}
		if ( preg_match( '/not interested|no thanks|no thank you|we already have|not a fit|pass for now/', $t ) ) {
			return 'not_interested';
		}
		if ( preg_match( '/interested|sounds good|tell me more|how much|pricing|price|call me|book|demo|let\'s talk|set up a time/', $t ) ) {
			return 'interested';
		}
		return 'other';
	}

	/**
	 * Inbound reply intake (fed by webhook now, IMAP poll or Brevo inbound later):
	 * pause the sender's sequence, classify, suppress on unsubscribe, surface in
	 * the unified inbox, alert on interest. A send-only system is half a system.
	 */
	public static function inbound( $from, $subject, $text ) {
		$from  = sanitize_email( $from );
		$class = self::classify_reply( $subject . ' ' . $text );

		// Auto-pause any sequence for this sender, on ANY reply.
		$paused = (array) get_option( 'tnc_paused_senders', array() );
		if ( $from && ! in_array( $from, $paused, true ) ) {
			$paused[] = $from;
			update_option( 'tnc_paused_senders', $paused, false );
		}
		if ( 'unsubscribe' === $class ) {
			self::suppress( $from, 'reply_unsubscribe' );
		}

		$inbox = (array) get_option( 'tnc_inbox', array() );
		array_unshift( $inbox, array(
			't'       => gmdate( 'Y-m-d H:i:s' ) . ' UTC',
			'from'    => $from,
			'subject' => mb_substr( sanitize_text_field( (string) $subject ), 0, 120 ),
			'class'   => $class,
			'snippet' => mb_substr( sanitize_textarea_field( (string) $text ), 0, 280 ),
		) );
		update_option( 'tnc_inbox', array_slice( $inbox, 0, 200 ), false );

		if ( 'interested' === $class ) {
			$to = TNC_Settings::recipients( 'leads' );
			if ( $to ) {
				TNC_Emails::send( $to, 'Reply received (interested): ' . $from, '<p style="font-family:Arial,sans-serif;font-size:14px;">An outreach recipient replied with interest.</p><p style="font-family:Arial,sans-serif;font-size:14px;"><strong>From:</strong> ' . esc_html( $from ) . '<br><strong>Subject:</strong> ' . esc_html( $subject ) . '</p><blockquote style="font-family:Georgia,serif;font-size:14px;border-left:3px solid #7C5CFC;padding-left:12px;color:#1F2430;">' . esc_html( mb_substr( $text, 0, 600 ) ) . '</blockquote>', 'transactional' );
			}
		}
		return $class;
	}

	public static function sequence_paused( $email ) {
		return in_array( strtolower( trim( (string) $email ) ), (array) get_option( 'tnc_paused_senders', array() ), true );
	}

	/** ISP throttle for a recipient (msgs/hour) — used by the send queue. */
	public static function throttle_for( $email ) {
		$domain = strtolower( (string) substr( strrchr( (string) $email, '@' ), 1 ) );
		$map    = self::isp_throttles();
		return isset( $map[ $domain ] ) ? (int) $map[ $domain ] : (int) $map['default'];
	}

	/** Status snapshot for admin/diagnostics. */
	public static function status() {
		$out = array();
		foreach ( self::identities() as $ident ) {
			$key   = 'tnc_ms_' . $ident['id'] . '_' . gmdate( 'Ymd' );
			$out[] = array(
				'id'        => $ident['id'],
				'streams'   => $ident['streams'],
				'from'      => $ident['from'],
				'active'    => (bool) $ident['active'],
				'warmup'    => $ident['warmup'],
				'daily_cap' => (int) $ident['daily_cap'],
				'sent_today' => (int) get_transient( $key ),
				'notes'     => $ident['notes'],
			);
		}
		return $out;
	}
}
