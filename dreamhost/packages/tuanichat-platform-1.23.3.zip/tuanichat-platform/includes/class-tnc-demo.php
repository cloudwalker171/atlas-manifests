<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Private demo pages: /demo/{slug}. Noindex, unguessable slug.
 * v1.4: "Your Website" preview — mock browser window (live iframe when the
 * site allows framing, else a brand-styled mock) with the floating launcher
 * (industry icon + animated ring + brand colors) opening the chat panel.
 */
class TNC_Demo {

	public static function init() {
		add_action( 'init', array( __CLASS__, 'add_rewrite' ) );
		add_filter( 'query_vars', array( __CLASS__, 'query_vars' ) );
		add_action( 'template_redirect', array( __CLASS__, 'maybe_render' ) );
	}

	public static function add_rewrite() {
		add_rewrite_rule( '^demo/([A-Za-z0-9-]+)/?$', 'index.php?tnc_demo=$matches[1]', 'top' );
	}

	public static function query_vars( $vars ) {
		$vars[] = 'tnc_demo';
		return $vars;
	}

	public static function maybe_render() {
		$slug = get_query_var( 'tnc_demo' );
		// 301: old long-token URLs -> the new short form (links already sent never break).
		$aliases = get_option( 'tnc_demo_aliases', array() );
		if ( $slug && is_array( $aliases ) && isset( $aliases[ $slug ] ) ) {
			wp_redirect( home_url( '/demo/' . $aliases[ $slug ] . '/' ), 301 );
			exit;
		}
		if ( ! $slug ) {
			return;
		}
		$prospect = TNC_Prospects::get_by_slug( sanitize_text_field( $slug ) );
		if ( ! $prospect ) {
			status_header( 404 );
			nocache_headers();
			echo '<!doctype html><title>Not found</title><p>Demo not found.</p>';
			exit;
		}
		header( 'X-Robots-Tag: noindex, nofollow', true );
		nocache_headers();
		self::render( $prospect );
		exit;
	}

	private static function audit_items( $prospect ) {
		$crawl = $prospect['crawl_data'];
		$ex    = is_array( $crawl ) && isset( $crawl['extracted'] ) ? $crawl['extracted'] : array();
		$items = array();

		$angle = TNC_Outreach::pitch_angle( $ex );
		if ( 'greenfield' === $angle['angle'] ) {
			$items[] = array( 'gap', 'No chat or intake assistant detected — visitors with questions after hours have no way to get answers, so they bounce to a competitor.' );
		} elseif ( 'displacement' === $angle['angle'] ) {
			$items[] = array( 'gap', 'Basic chat detected (' . $angle['provider'] . ') — no AI intake or qualification: it cannot answer questions from your website content or capture qualified leads after hours.' );
		} elseif ( 'competitive' === $angle['angle'] ) {
			$items[] = array( 'gap', $angle['provider'] . ' detected — capable, but not specialized for your industry or trained on your website the way this assistant is.' );
		} else {
			$items[] = array( 'found', 'TuaniChat already detected on your site — this preview shows your latest configuration.' );
		}
		$items[] = array( 'gap', 'After-hours gap: calls and forms go unanswered nights and weekends. An intake assistant answers and captures leads 24/7.' );
		if ( ! empty( $ex['services'] ) ) {
			$items[] = array( 'found', count( $ex['services'] ) . ' services found and loaded into this assistant: ' . implode( ', ', array_slice( $ex['services'], 0, 5 ) ) . ( count( $ex['services'] ) > 5 ? '…' : '' ) );
		}
		if ( ! empty( $ex['trust_signals'] ) ) {
			$items[] = array( 'found', 'Trust signals we can leverage: ' . implode( ', ', array_slice( $ex['trust_signals'], 0, 5 ) ) );
		}
		if ( ! empty( $ex['phones'] ) ) {
			$items[] = array( 'found', 'Phone-driven business (' . $ex['phones'][0] . ') — the assistant hands hot leads straight to your phone line.' );
		}
		if ( ! empty( $ex['brand']['primary'] ) ) {
			$items[] = array( 'found', 'Your brand palette was detected and applied to the assistant automatically.' );
		}
		if ( ! empty( $crawl['page_count'] ) ) {
			$items[] = array( 'found', $crawl['page_count'] . ' pages of your website were analyzed to train this demo.' );
		}
		return $items;
	}


	/**
	 * Per-industry ROI economics (conservative, prospect-editable on the demo).
	 * deal = default avg value, close = default close/sign rate %, visitors = default monthly traffic.
	 */
	private static function roi_model( $industry ) {
		// CONSERVATIVE small-local-business defaults — err LOW, never inflate.
		// 'visitors' = realistic monthly traffic for a SINGLE-LOCATION local
		// business (low hundreds, not thousands). Prospects can slide up to their
		// real numbers. 'close' = share of captured inquiries that convert.
		$m = array(
			'personal_injury' => array( 'deal' => 8000,  'deal_min' => 2000, 'deal_max' => 100000, 'deal_step' => 1000, 'close' => 8,  'label' => 'Avg signed case value', 'assistant' => 'AI Case Intake Assistant', 'visitors' => 500 ),
			'law_general'     => array( 'deal' => 3500,  'deal_min' => 800,  'deal_max' => 50000, 'deal_step' => 500, 'close' => 10, 'label' => 'Avg matter value', 'assistant' => 'AI Case Intake Assistant', 'visitors' => 400 ),
			'med_spa'         => array( 'deal' => 600,   'deal_min' => 150,  'deal_max' => 5000, 'deal_step' => 50, 'close' => 25, 'label' => 'Avg client value', 'assistant' => 'AI Booking Assistant', 'visitors' => 500 ),
			'plastic_surgery' => array( 'deal' => 6000,  'deal_min' => 1500, 'deal_max' => 25000, 'deal_step' => 500, 'close' => 12, 'label' => 'Avg procedure value', 'assistant' => 'AI Consultation Assistant', 'visitors' => 400 ),
			'dental'          => array( 'deal' => 900,   'deal_min' => 300,  'deal_max' => 8000, 'deal_step' => 100, 'close' => 30, 'label' => 'New patient value', 'assistant' => 'AI Patient Intake Assistant', 'visitors' => 450 ),
			'roofing'         => array( 'deal' => 8000,  'deal_min' => 1500, 'deal_max' => 30000, 'deal_step' => 500, 'close' => 20, 'label' => 'Avg job value', 'assistant' => 'AI Estimate Capture Assistant', 'visitors' => 350 ),
			'hvac'            => array( 'deal' => 800,   'deal_min' => 200,  'deal_max' => 10000, 'deal_step' => 100, 'close' => 25, 'label' => 'Avg job value (blended)', 'assistant' => 'AI Estimate Capture Assistant', 'visitors' => 450 ),
			'plumbing'        => array( 'deal' => 500,   'deal_min' => 150,  'deal_max' => 8000, 'deal_step' => 50, 'close' => 25, 'label' => 'Avg job value', 'assistant' => 'AI Estimate Capture Assistant', 'visitors' => 400 ),
			'solar'           => array( 'deal' => 12000, 'deal_min' => 4000, 'deal_max' => 40000, 'deal_step' => 1000, 'close' => 8,  'label' => 'Avg install value', 'assistant' => 'AI Estimate Capture Assistant', 'visitors' => 400 ),
			'real_estate'     => array( 'deal' => 6000,  'deal_min' => 1000, 'deal_max' => 30000, 'deal_step' => 500, 'close' => 8,  'label' => 'Avg commission', 'assistant' => 'AI Lead Capture Assistant', 'visitors' => 500 ),
			'local_services'  => array( 'deal' => 350,   'deal_min' => 100,  'deal_max' => 5000, 'deal_step' => 50, 'close' => 25, 'label' => 'Avg job value', 'assistant' => 'AI Lead Capture Assistant', 'visitors' => 350 ),
			'ecommerce'       => array( 'deal' => 65,    'deal_min' => 15,   'deal_max' => 500, 'deal_step' => 5, 'close' => 40, 'label' => 'Avg order value', 'assistant' => 'AI Shopping Assistant', 'visitors' => 2500 ),
			'other'           => array( 'deal' => 400,   'deal_min' => 100,  'deal_max' => 10000, 'deal_step' => 50, 'close' => 20, 'label' => 'Avg sale value', 'assistant' => 'AI Lead Capture Assistant', 'visitors' => 400 ),
		);
		return isset( $m[ $industry ] ) ? $m[ $industry ] : $m['other'];
	}

	public static function render( $prospect ) {
		$theme    = TNC_Themes::for_prospect( $prospect );
		$company  = $prospect['company_name'] ? $prospect['company_name'] : 'Your Business';
		$token    = TNC_Chat::demo_token( $prospect['demo_slug'] );
		$rest     = esc_url_raw( rest_url( TNC_REST_NS ) );
		$activate = TNC_Settings::get( 'cta_activate_url', '' );
		$urgency  = TNC_Settings::get( 'cta_urgency_text', 'Live within 24 hours' );
		$go_url   = $activate ? $activate : '#tncLead';
		$call     = TNC_Settings::get( 'cta_call_url', '' );
		$audit    = self::audit_items( $prospect );
		$crawl    = $prospect['crawl_data'];
		$ex       = is_array( $crawl ) && isset( $crawl['extracted'] ) ? $crawl['extracted'] : array();
		// CANVAS SAFETY (P0): NEVER live-iframe an unverified/arbitrary site — a
		// bad discovered website_url (e.g. a franchise/aggregator URL) must not
		// render as the prospect's site. Only DEEP-CRAWLED prospects (which carry
		// an explicit framable verdict) may iframe. For everyone else: show a
		// screenshot of THEIR OWN stored domain only when the site was verified
		// reachable; otherwise the branded mock. No example.com / no random site.
		$lh_meta  = is_array( $crawl ) && isset( $crawl['lh'] ) ? $crawl['lh'] : array();
		$site_ok  = isset( $lh_meta['site_ok'] ) ? $lh_meta['site_ok'] : null;
		$framable = isset( $ex['framable'] ) ? (bool) $ex['framable'] : false; // never iframe raw leads.
		$hero     = ! empty( $ex['hero'] ) ? $ex['hero'] : ( ! empty( $ex['description'] ) ? wp_trim_words( $ex['description'], 12 ) : 'Welcome to ' . $company );
		$site_url = $prospect['website_url'] ? $prospect['website_url'] : '';
		$icon_svg = TNC_Themes::icon_svg( $theme['icon'] );
		$domain   = $site_url ? preg_replace( '/^www\./', '', (string) wp_parse_url( $site_url, PHP_URL_HOST ) ) : '';
		$bad_site = $site_url && class_exists( 'TNC_Leadhunter' ) && TNC_Leadhunter::bad_domain( (string) wp_parse_url( $site_url, PHP_URL_HOST ) );
		if ( $bad_site ) { $framable = false; }
		// CACHED screenshot shows instantly. Otherwise we NEVER block on a live
		// screenshot — the branded mock paints in <1s and a live mShots render is
		// attempted async in JS with a hard timeout, swapping in only if a real
		// (full-size) image arrives. $shot_async is background-only, never eager.
		$shot       = ! empty( $ex['screenshot_local'] ) ? $ex['screenshot_local'] : ( ! empty( $ex['screenshot'] ) ? $ex['screenshot'] : '' );
		$shot_async = ( '' === $shot && $site_url && false !== $site_ok && ! $bad_site )
			? 'https://s0.wp.com/mshots/v1/' . rawurlencode( $site_url ) . '?w=1280&h=900' : '';
		if ( '' === $site_url ) { $site_url = home_url( '/' ); } // bbar label only; never iframed.
		$ovr      = is_array( $prospect['theme_overrides'] ) ? $prospect['theme_overrides'] : array();
		$ao       = ! empty( $ovr['autoopen'] ) ? (int) $ovr['autoopen'] : (int) TNC_Settings::get( 'demo_autoopen_secs', 6 );
		$ao       = max( 3, min( 10, $ao ? $ao : 6 ) );
		$helper   = TNC_Settings::get( 'lead_form_helper', 'Leave your details and we\'ll set it up for you — typically live within 24 hours.' );
		$roi      = self::roi_model( $prospect['industry'] );
		// DEFAULT LAUNCHER = ROTATING RING (the Lion Click signature: conic brand
		// ring spinning clockwise). Per-industry premium defaults below; all 5
		// variants stay selectable per prospect via the 'launcher' override.
		$lmap     = array( 'med_spa' => 'breathe', 'plastic_surgery' => 'breathe', 'dental' => 'breathe', 'personal_injury' => 'glow', 'law_general' => 'glow', 'hvac' => 'glow', 'roofing' => 'glow', 'local_services' => 'glow' );
		// Glow rotating-ring launcher is the DEFAULT (binding widget rule); the
		// industry map + all variants remain selectable via the 'launcher' override.
		$launch   = ! empty( $ovr['launcher'] ) ? sanitize_key( $ovr['launcher'] ) : 'ring';
		unset( $lmap );
		$ind_lbl  = TNC_Settings::industries()[ $prospect['industry'] ] ?? 'industry';
		$nstats   = array();
		if ( ! empty( $crawl['page_count'] ) ) { $nstats[] = $crawl['page_count'] . ' pages analyzed'; }
		if ( ! empty( $ex['services'] ) ) { $nstats[] = count( $ex['services'] ) . ' services found'; }
		if ( ! empty( $ex['pricing'] ) ) { $nstats[] = count( $ex['pricing'] ) . ' prices verified'; }
		$nstats[] = '24/7 instant responses'; // Client-facing value framing only — internal sales metrics (score etc.) never render here.
		$advanced = ( 'advanced' === $theme['widget_mode'] );
		$panelcls  = ( isset( $theme['panel'] ) && 'light' === $theme['panel'] ) ? ' light' : '';
		$panelcls .= ( isset( $theme['fx'] ) && 'grid' === $theme['fx'] ) ? ' fx-grid' : '';
		$avring    = ! empty( $theme['avatar_ring'] ) ? $theme['avatar_ring'] : '';
		$radmap   = array( 'pill' => '999px', 'rounded' => '14px', 'sharp' => '7px' );
		$radius   = isset( $radmap[ $theme['radius'] ?? 'rounded' ] ) ? $radmap[ $theme['radius'] ?? 'rounded' ] : '14px';
		// Enhanced cohesive palette (v1.16.1 engine) — drives the Intercom-grade widget.
		$pal = isset( $theme['palette'] ) && is_array( $theme['palette'] ) ? $theme['palette'] : array();
		$P = function ( $k, $d ) use ( $pal ) { return ! empty( $pal[ $k ] ) ? $pal[ $k ] : $d; };
		$p_hover = $P( 'hover', $theme['accent'] ); $p_grad2 = $P( 'grad2', $theme['accent2'] );
		$p_tint = $P( 'tint', '#eef2ff' ); $p_tintd = $P( 'tint_dark', '#161a26' );
		$p_text = $P( 'text', '#ffffff' ); $p_border = $P( 'border', 'rgba(255,255,255,.1)' ); $p_glow = $P( 'glow', $theme['accent'] );

		$cfg = array(
			'rest'          => $rest,
			'slug'          => $prospect['demo_slug'],
			'token'         => $token,
			'greeting'      => $theme['greeting'],
			'starters'      => $theme['starters'],
			'accent'        => $theme['accent'],
			'accent2'       => $theme['accent2'],
			'name'          => $theme['widget_name'],
			'company'       => $company,
			'mode'          => $theme['widget_mode'],
			'btnStyle'      => $theme['button_style'],
			'agentName'     => $theme['agent_name'],
			'agentSubtitle' => $theme['agent_subtitle'],
			'sectionTitle'  => $theme['section_title'],
			'avatar'        => $theme['agent_avatar'],
			'choices'       => $theme['choices'],
			'autoOpen'      => $ao,
			'openMode'      => $theme['open_mode'],
			'framable'      => (bool) $framable,
			'shotAsync'     => $shot_async,
			'metaMode'      => isset( $theme['msg_meta'] ) ? $theme['msg_meta'] : 'minimal', // minimal (avatar only) | full | none
			'siteUrl'       => $site_url,
			'roi'           => $roi,
			'ctaChip'       => $call ? array( 'label' => 'Book a call', 'url' => $call ) : null,
		);
		?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title><?php echo esc_html( $company ); ?> — Private AI Intake Demo | TuaniChat</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<style>
:root{--bg:#050505;--text:#E4E4E7;--muted:#9CA3AF;--violet:#7C3AED;--violet-h:#6D28D9;--fuchsia:#D946EF;--g1:#A78BFA;--g2:#E879F9;--card:rgba(255,255,255,0.02);--border:rgba(255,255,255,0.05);--accent:<?php echo esc_html( $theme['accent'] ); ?>;--accent2:<?php echo esc_html( $theme['accent2'] ); ?>;--ring:<?php echo esc_html( $theme['ring'] ); ?>;--p-hover:<?php echo esc_html( $p_hover ); ?>;--p-grad2:<?php echo esc_html( $p_grad2 ); ?>;--p-tint:<?php echo esc_html( $p_tint ); ?>;--p-tintd:<?php echo esc_html( $p_tintd ); ?>;--p-text:<?php echo esc_html( $p_text ); ?>;--p-border:<?php echo esc_html( $p_border ); ?>;--p-glow:<?php echo esc_html( $p_glow ); ?>;--cp-rad:<?php echo esc_html( $radius ); ?>}
*{box-sizing:border-box;margin:0;padding:0}
body{background:var(--bg);color:var(--text);font-family:'Inter',system-ui,sans-serif;font-weight:400;line-height:1.6;overflow-x:hidden}
.orb{position:fixed;border-radius:50%;filter:blur(110px);opacity:.16;pointer-events:none;z-index:0;animation:float 14s ease-in-out infinite}
.orb1{width:520px;height:520px;background:var(--violet);top:-160px;left:-120px}
.orb2{width:420px;height:420px;background:var(--fuchsia);bottom:-140px;right:-100px;animation-delay:-7s}
body::before{content:'';position:fixed;inset:0;pointer-events:none;z-index:0;background-image:linear-gradient(rgba(255,255,255,0.018) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,0.018) 1px,transparent 1px);background-size:56px 56px;-webkit-mask-image:radial-gradient(ellipse 90% 60% at 50% 0%,#000 30%,transparent 75%);mask-image:radial-gradient(ellipse 90% 60% at 50% 0%,#000 30%,transparent 75%)}
@keyframes float{0%,100%{transform:translate(0,0)}50%{transform:translate(40px,-30px)}}
.nav{position:sticky;top:0;z-index:50;background:rgba(5,5,5,0.8);backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);border-bottom:1px solid var(--border);padding:16px 28px;display:flex;justify-content:space-between;align-items:center}
.logo{font-weight:800;font-size:18px;letter-spacing:-.02em}
.logo .grad{background:linear-gradient(90deg,var(--g1),var(--g2));-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent}
.badge{font-size:12px;color:var(--muted);border:1px solid var(--border);border-radius:999px;padding:6px 14px;background:var(--card)}
.wrap{position:relative;z-index:1;max-width:1180px;margin:0 auto;padding:28px 24px 80px}
.hero{text-align:center;margin-bottom:20px}
.hero .pre{display:inline-flex;align-items:center;gap:8px;font-size:11px;font-weight:600;color:var(--muted);border:1px solid rgba(255,255,255,.1);background:rgba(255,255,255,.02);border-radius:999px;padding:7px 18px;margin-bottom:22px;letter-spacing:.14em;text-transform:uppercase}
.hero .pre::before{content:'';width:6px;height:6px;border-radius:50%;background:var(--violet);box-shadow:0 0 8px rgba(124,58,237,.8)}
h1{font-weight:700;font-size:clamp(26px,3.8vw,42px);letter-spacing:-.03em;line-height:1.1;margin-bottom:10px}
h1 .grad{background:linear-gradient(90deg,var(--g1),var(--g2));-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent}
.hero p{color:var(--muted);max-width:640px;margin:0 auto;font-size:15px}
.statrow{display:flex;gap:10px;justify-content:center;flex-wrap:wrap;margin-top:14px}
.schip{font-size:12px;font-weight:600;letter-spacing:.04em;color:var(--text);border:1px solid rgba(255,255,255,.1);background:rgba(255,255,255,.03);backdrop-filter:blur(8px);border-radius:999px;padding:7px 16px}
.schip::before{content:'✓ ';color:#34D399}
/* ---- Mock browser window ---- */
.bwin{border:1px solid rgba(255,255,255,.09);border-radius:18px;overflow:hidden;box-shadow:0 24px 80px rgba(0,0,0,.55),0 0 60px rgba(124,58,237,.10);margin-bottom:32px;background:#0B0B0E}
.bbar{display:flex;align-items:center;gap:14px;padding:11px 16px;background:#16161B;border-bottom:1px solid rgba(255,255,255,.06)}
.dots{display:flex;gap:7px}
.dots i{width:11px;height:11px;border-radius:50%}
.dots i:nth-child(1){background:#FF5F57}.dots i:nth-child(2){background:#FEBC2E}.dots i:nth-child(3){background:#28C840}
.burl{flex:1;max-width:520px;margin:0 auto;background:rgba(255,255,255,.06);border-radius:8px;padding:5px 14px;font-size:12.5px;color:#B8B8C0;text-align:center;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.bview{position:relative;height:clamp(480px,calc(100vh - 330px),660px);background:linear-gradient(160deg,color-mix(in srgb,var(--accent) 14%,#0e1018),#0b0d14);overflow:hidden}
/* GUARANTEED CANVAS (P0): the branded mock is the PERMANENT bottom layer — it is
   always present and never hidden, so even if BOTH the iframe and the screenshot
   fail, the user sees a polished branded background, never blank. The screenshot
   (z2) and a verified iframe (z3) only OVERLAY the mock once they truly paint. */
.mock{position:absolute;inset:0;z-index:1;overflow:hidden;background:#FBFBF9;color:#1F2430;display:flex;flex-direction:column}
.bshot{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;object-position:top center;display:none;background:#fff;z-index:2}
.bframe{position:absolute;inset:0;width:100%;height:100%;border:0;display:none;background:#fff;z-index:3}
.mhead{display:flex;align-items:center;justify-content:space-between;padding:18px 30px;background:#fff;border-bottom:3px solid var(--accent);box-shadow:0 1px 8px rgba(0,0,0,.05)}
.mlogo{display:flex;align-items:center;gap:10px;font-weight:800;font-size:19px;letter-spacing:-.02em;color:var(--accent)}
.mlogo img{max-height:40px;max-width:170px;object-fit:contain}
.mnav{display:flex;gap:22px}
.mnav i{display:block;width:54px;height:9px;border-radius:5px;background:#E2E2DC}
.mhero{padding:54px 30px 40px;text-align:center;background:linear-gradient(160deg,color-mix(in srgb,var(--accent) 10%,#FBFBF9),color-mix(in srgb,var(--accent2) 7%,#FBFBF9))}
.mh1{font-size:clamp(22px,3.2vw,36px);font-weight:800;letter-spacing:-.02em;color:#23262E;max-width:680px;margin:0 auto 14px;line-height:1.2}
.mbtn{display:inline-block;background:var(--accent);color:#fff;font-weight:600;font-size:14px;border-radius:10px;padding:11px 26px;margin-top:6px}
.mnote{font-size:11px;color:#9A9A92;margin-top:14px;letter-spacing:.06em;text-transform:uppercase}
.mrow{display:grid;grid-template-columns:repeat(3,1fr);gap:20px;padding:26px 30px;flex:1}
.mcard{background:#fff;border:1px solid #ECECE6;border-radius:12px;box-shadow:0 2px 10px rgba(0,0,0,.04);position:relative;overflow:hidden;min-height:90px}
.mcard::before{content:'';position:absolute;top:16px;left:16px;width:34px;height:34px;border-radius:9px;background:color-mix(in srgb,var(--accent) 16%,#fff)}
.mcard::after{content:'';position:absolute;top:62px;left:16px;right:16px;height:8px;border-radius:4px;background:#EFEFE9;box-shadow:0 16px 0 #F3F3EE}
/* ---- Floating launcher ---- */
.launcher{position:absolute;bottom:24px;right:24px;z-index:30;width:62px;height:62px;border-radius:50%;cursor:pointer;border:1.5px solid var(--accent);color:#fff;display:flex;align-items:center;justify-content:center;background:radial-gradient(circle at 50% 38%,color-mix(in srgb,var(--accent) 24%,transparent),transparent 60%),linear-gradient(180deg,#0e0e14,#0a0a0d);box-shadow:0 0 0 1px color-mix(in srgb,var(--accent) 30%,transparent),0 0 22px color-mix(in srgb,var(--accent) 45%,transparent),0 8px 30px rgba(0,0,0,.55);transition:transform .2s,opacity .25s}
.launcher:hover{transform:scale(1.06)}
.launcher.hide{opacity:0;pointer-events:none;transform:scale(.6)}
.launcher svg{width:27px;height:27px;position:relative;z-index:2;filter:drop-shadow(0 0 6px color-mix(in srgb,var(--accent) 55%,transparent))}
/* concentric glowing rings (Lion Click / Luna signature): a slow spinning
   partial arc + a soft inner ring, over a breathing brand-color halo. */
.launcher .ring{content:'';position:absolute;inset:-6px;border-radius:50%;border:2px solid transparent;border-top-color:var(--accent);border-right-color:color-mix(in srgb,var(--accent) 45%,transparent);opacity:.95;filter:drop-shadow(0 0 5px color-mix(in srgb,var(--accent) 60%,transparent));animation:tncSpin 3.2s linear infinite;pointer-events:none}
.launcher .ring2{content:'';position:absolute;inset:6px;border-radius:50%;border:1px solid color-mix(in srgb,var(--accent) 30%,transparent);pointer-events:none}

@keyframes tncSpin{100%{transform:rotate(360deg)}}
/* ---- Chat panel inside the mock window ---- */
.chatwrap{position:absolute;bottom:24px;right:24px;z-index:40;width:384px;max-width:calc(100% - 32px);height:560px;max-height:calc(100% - 44px);opacity:0;transform:translateY(18px) scale(.98);pointer-events:none;transition:opacity .28s ease,transform .28s ease}
.chatwrap.open{opacity:1;transform:none;pointer-events:auto}
/* ============ INTERCOM-GRADE WIDGET (v1.16.2) — dark glass, rich brand palette ============ */
.chat{display:flex;flex-direction:column;height:100%;border-radius:22px;overflow:hidden;border:1px solid rgba(255,255,255,.09);background:linear-gradient(180deg,#12151f,#0c0e16);box-shadow:0 30px 80px rgba(0,0,0,.62),0 2px 0 rgba(255,255,255,.04) inset,0 0 60px color-mix(in srgb,var(--p-glow) 14%,transparent);position:relative}
.chat::before{content:'';position:absolute;top:0;left:0;right:0;height:120px;pointer-events:none;background:radial-gradient(120% 100% at 50% 0,color-mix(in srgb,var(--accent) 22%,transparent),transparent 70%);opacity:.7}
.chat-head{padding:16px 18px 14px;display:flex;align-items:center;gap:12px;border-bottom:1px solid rgba(255,255,255,.07);background:linear-gradient(180deg,color-mix(in srgb,var(--accent) 16%,transparent),transparent);position:relative;z-index:1}
.chat-dot{width:40px;height:40px;border-radius:50%;background:linear-gradient(140deg,var(--accent),var(--p-grad2));display:flex;align-items:center;justify-content:center;font-weight:700;color:var(--p-text);box-shadow:0 0 0 2px color-mix(in srgb,var(--accent) 40%,transparent),0 6px 18px color-mix(in srgb,var(--p-glow) 50%,transparent);flex:0 0 auto;font-size:17px}
.chat-head .t{font-weight:700;font-size:14.5px;color:#F4F6FB;letter-spacing:-.01em;line-height:1.2}
.chat-head .sub{font-size:11.5px;color:#9AA3B8;margin-top:1px}
.chat-head .s{font-size:11px;color:#34D399;display:flex;align-items:center;gap:6px;margin-top:3px}
.chat-head .s::before{content:'';width:7px;height:7px;border-radius:50%;background:#34D399;box-shadow:0 0 8px #34D399;animation:pulse 2s infinite}
.chat-head .hcol{display:flex;flex-direction:column;min-width:0}
@keyframes pulse{50%{opacity:.4}}
.chat-head.adv{flex-direction:column;align-items:center;position:relative;gap:3px;padding:18px 52px 14px}
.hd-ic{position:absolute;top:13px;background:rgba(255,255,255,.06);border:none;color:#C7CCDA;font-size:15px;line-height:1;cursor:pointer;border-radius:9px;padding:6px 10px;transition:.18s;font-family:inherit;z-index:2}
.hd-ic:hover{background:rgba(255,255,255,.14);color:#fff}
.hd-ic.back{left:10px}.hd-ic.close{right:10px}
.avatar{width:44px;height:44px;border-radius:50%;object-fit:cover;display:flex;align-items:center;justify-content:center}
.avatar.mark{background:linear-gradient(140deg,var(--accent),var(--p-grad2));color:var(--p-text);font-weight:700;font-size:18px;box-shadow:0 0 0 2px color-mix(in srgb,var(--accent) 40%,transparent),0 6px 20px color-mix(in srgb,var(--p-glow) 50%,transparent)}
<?php if ( $avring ) : ?>.chat-head.adv .avatar{box-shadow:0 0 0 2.5px <?php echo esc_html( $avring ); ?>,0 0 24px color-mix(in srgb,<?php echo esc_html( $avring ); ?> 55%,transparent)}<?php endif; ?>
.chat.fx-grid{border-color:color-mix(in srgb,var(--accent) 40%,transparent);box-shadow:0 30px 80px rgba(0,0,0,.6),0 0 46px color-mix(in srgb,var(--p-glow) 26%,transparent)}
.chat.fx-grid .chat-body{background-image:linear-gradient(color-mix(in srgb,var(--accent) 6%,transparent) 1px,transparent 1px),linear-gradient(90deg,color-mix(in srgb,var(--accent) 6%,transparent) 1px,transparent 1px);background-size:26px 26px}
.chat-head.adv .t{font-weight:700;font-size:15px;text-align:center;color:#F4F6FB}
.chat-head.adv .s2{font-size:11.5px;color:#9AA3B8;text-align:center}
.chat-body{flex:1;overflow-y:auto;padding:18px 16px;display:flex;flex-direction:column;gap:11px;position:relative;z-index:1}
.chat-body::-webkit-scrollbar{width:8px}.chat-body::-webkit-scrollbar-thumb{background:rgba(255,255,255,.1);border-radius:99px}
.msg{max-width:84%;padding:11px 15px;border-radius:18px;font-size:13.5px;line-height:1.5;white-space:pre-wrap;word-wrap:break-word;letter-spacing:.005em}
.msg.bot{background:#1b1f2b;border:1px solid rgba(255,255,255,.07);color:#E7EAF3;border-bottom-left-radius:6px;align-self:flex-start;box-shadow:0 2px 10px rgba(0,0,0,.3)}
.msg.user{background:linear-gradient(140deg,var(--accent),var(--p-grad2));color:var(--p-text);border-bottom-right-radius:6px;align-self:flex-end;box-shadow:0 4px 16px color-mix(in srgb,var(--p-glow) 40%,transparent)}
.msg.typing{color:#9AA3B8;font-style:italic;background:#171a24}
.sect{text-align:center;font-weight:700;font-size:15px;letter-spacing:-.01em;margin:12px 0 4px;color:#F4F6FB}
.choices{display:flex;flex-direction:column;align-items:flex-end;gap:9px;padding:6px 0 4px}
.choice{font-family:inherit;font-size:13px;font-weight:600;letter-spacing:.01em;cursor:pointer;border-radius:999px;padding:10px 17px;max-width:86%;width:auto;text-align:center;transition:transform .15s,box-shadow .2s,filter .2s,background .2s;line-height:1.4}
.choices .choice,.choices.style-solid .choice{background:linear-gradient(140deg,var(--accent),var(--p-grad2));color:var(--p-text);border:none;box-shadow:0 4px 14px color-mix(in srgb,var(--p-glow) 38%,transparent)}
.choices .choice:hover{transform:translateY(-1px);filter:brightness(1.07);box-shadow:0 6px 22px color-mix(in srgb,var(--p-glow) 55%,transparent)}
.choices.style-outline .choice{background:color-mix(in srgb,var(--accent) 14%,transparent);color:#EAF0FF;border:1px solid color-mix(in srgb,var(--accent) 55%,transparent);box-shadow:0 0 14px color-mix(in srgb,var(--p-glow) 18%,transparent)}
.choices.style-outline .choice:hover{background:var(--accent);color:var(--p-text);border-color:var(--accent);box-shadow:0 4px 18px color-mix(in srgb,var(--p-glow) 45%,transparent)}
.attr{font-size:10.5px;color:#7a8198;margin-top:5px;opacity:.9}
.fadein{animation:tncFade .3s ease both}
@keyframes tncFade{from{opacity:0;transform:translateY(8px) scale(.98)}to{opacity:1;transform:none}}
/* Light-site variant kept premium but on the SAME Intercom dark architecture (chosen reference is dark). */
.chat.light{background:linear-gradient(180deg,#12151f,#0c0e16);border-color:rgba(255,255,255,.09)}
.chat.light .chat-head .t,.chat.light .sect,.chat.light .chat-head.adv .t{color:#F4F6FB}
.chat.light .chat-head.adv .s2,.chat.light .attr,.chat.light .msg.typing{color:#9AA3B8}
.chat.light .msg.bot{background:#1b1f2b;border-color:rgba(255,255,255,.07);color:#E7EAF3}
.chat.light .chat-input input{background:rgba(255,255,255,.05);border-color:rgba(255,255,255,.1);color:#E7EAF3}
.starters{display:flex;flex-direction:column;align-items:flex-end;gap:9px;padding:4px 16px 12px}
.starters button{font-family:inherit;font-size:13px;font-weight:600;letter-spacing:.01em;color:#EAF0FF;text-align:center;width:auto;max-width:86%;background:color-mix(in srgb,var(--accent) 14%,transparent);border:1px solid color-mix(in srgb,var(--accent) 55%,transparent);border-radius:999px;padding:10px 17px;cursor:pointer;transition:transform .15s,box-shadow .2s,filter .2s,background .2s;line-height:1.4;box-shadow:0 0 14px color-mix(in srgb,var(--p-glow) 16%,transparent)}
.starters button:hover{transform:translateY(-1px);background:var(--accent);color:var(--p-text);border-color:var(--accent);box-shadow:0 5px 20px color-mix(in srgb,var(--p-glow) 48%,transparent)}
.starters.style-solid button{background:linear-gradient(140deg,var(--accent),var(--p-grad2));color:var(--p-text);border:none;box-shadow:0 4px 14px color-mix(in srgb,var(--p-glow) 38%,transparent)}
.starters.style-solid button:hover{filter:brightness(1.07)}
.chat-input{display:flex;gap:8px;padding:13px 14px;border-top:1px solid rgba(255,255,255,.07);background:rgba(255,255,255,.015);position:relative;z-index:1}
.chat-input input{flex:1;font-family:inherit;font-size:13.5px;color:#E7EAF3;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:999px;padding:11px 17px;outline:none;transition:border-color .18s,box-shadow .18s}
.chat-input input::placeholder{color:#7a8198}
.chat-input input:focus{border-color:var(--accent);box-shadow:0 0 0 3px color-mix(in srgb,var(--accent) 22%,transparent)}
.btn{font-family:inherit;font-weight:700;font-size:13.5px;color:var(--p-text);background:linear-gradient(140deg,var(--accent),var(--p-grad2));border:none;border-radius:999px;padding:10px 20px;cursor:pointer;transition:transform .15s,box-shadow .2s,filter .2s;box-shadow:0 4px 14px color-mix(in srgb,var(--p-glow) 38%,transparent)}
.btn:hover{transform:translateY(-1px);filter:brightness(1.07);box-shadow:0 6px 24px color-mix(in srgb,var(--p-glow) 60%,transparent)}
.btn.ghost{background:transparent;border:1px solid color-mix(in srgb,var(--accent) 55%,transparent);color:#EAF0FF;box-shadow:none}
.btn.ghost:hover{background:color-mix(in srgb,var(--accent) 14%,transparent);box-shadow:0 0 22px color-mix(in srgb,var(--p-glow) 30%,transparent)}
.btn:disabled{opacity:.5;cursor:default;box-shadow:none}
/* below-preview grid */
.grid{display:grid;grid-template-columns:1fr 1fr;gap:28px;align-items:start}
@media(max-width:920px){.grid{grid-template-columns:1fr}.bview{height:min(64vh,560px)}.chatwrap{bottom:12px;right:12px}}
.card{background:var(--card);border:1px solid var(--border);border-radius:24px;padding:28px;backdrop-filter:blur(8px)}
.card h2{font-weight:700;font-size:20px;letter-spacing:-.02em;margin-bottom:6px}
.card .sub{color:var(--muted);font-size:14px;margin-bottom:18px}
.audit-item{display:flex;gap:12px;padding:12px 0;border-bottom:1px solid var(--border);font-size:14px}
.audit-item:last-child{border-bottom:none}
.audit-ic{flex:0 0 auto;width:26px;height:26px;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:14px}
.audit-ic.gap{background:rgba(244,63,94,.12);color:#FB7185}
.audit-ic.found{background:rgba(52,211,153,.1);color:#34D399}
.lead input,.lead textarea{width:100%;font-family:inherit;font-size:14px;color:var(--text);background:rgba(255,255,255,0.04);border:1px solid var(--border);border-radius:14px;padding:12px 16px;outline:none;margin-bottom:12px}
.lead input:focus,.lead textarea:focus{border-color:rgba(124,58,237,.5)}
.lead textarea{min-height:80px;resize:vertical}
.lead .ok{color:#34D399;font-size:14px;padding:10px 0}
.lead .err{color:#FB7185;font-size:13px;padding:6px 0}
.ctas{display:flex;gap:14px;flex-wrap:wrap;justify-content:center;margin-top:44px}
.foot{text-align:center;color:var(--muted);font-size:13px;margin-top:54px}
.foot a{color:var(--g1);text-decoration:none}
/* ---- ROI calculator: the value-proof showpiece ---- */
.roi{margin-top:28px}
.roi-grid{display:grid;grid-template-columns:1fr 1fr;gap:30px;align-items:center;margin-top:6px}
@media(max-width:920px){.roi-grid{grid-template-columns:1fr}}
.roi-row{margin-bottom:18px}
.roi-row label{display:flex;justify-content:space-between;font-size:13px;color:var(--muted);margin-bottom:8px;font-weight:500}
.roi-row label b{color:var(--text);font-weight:700;font-variant-numeric:tabular-nums}
.roi-row input[type=range]{width:100%;-webkit-appearance:none;appearance:none;height:6px;border-radius:999px;background:linear-gradient(90deg,var(--accent) var(--fill,50%),rgba(255,255,255,.08) var(--fill,50%));outline:none}
.roi-row input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;width:20px;height:20px;border-radius:50%;background:linear-gradient(135deg,var(--accent),var(--accent2));box-shadow:0 2px 10px rgba(0,0,0,.45),0 0 14px color-mix(in srgb,var(--accent) 55%,transparent);cursor:pointer;border:2px solid rgba(255,255,255,.85)}
.roi-row input[type=range]::-moz-range-thumb{width:20px;height:20px;border-radius:50%;background:linear-gradient(135deg,var(--accent),var(--accent2));cursor:pointer;border:2px solid rgba(255,255,255,.85)}
.roi-out{text-align:center;padding:18px 10px;border:1px solid color-mix(in srgb,var(--accent) 25%,transparent);border-radius:20px;background:radial-gradient(ellipse 90% 80% at 50% 100%,color-mix(in srgb,var(--accent) 9%,transparent),transparent)}
.roi-lbl{font-size:11px;font-weight:600;letter-spacing:.14em;text-transform:uppercase;color:var(--muted)}
.roi-mo{font-size:26px;font-weight:700;color:var(--text);font-variant-numeric:tabular-nums;margin-top:4px}
.roi-hero{font-size:clamp(42px,5.4vw,64px);font-weight:800;letter-spacing:-.02em;line-height:1.05;margin-top:4px;font-variant-numeric:tabular-nums;background:linear-gradient(90deg,color-mix(in srgb,var(--accent) 75%,#fff),color-mix(in srgb,var(--accent2) 75%,#fff));-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;filter:drop-shadow(0 0 22px color-mix(in srgb,var(--accent) 55%,transparent));animation:roiPulse 2.6s ease-in-out infinite}
@keyframes roiPulse{0%,100%{filter:drop-shadow(0 0 16px color-mix(in srgb,var(--accent) 45%,transparent))}50%{filter:drop-shadow(0 0 40px color-mix(in srgb,var(--accent) 80%,transparent))}}
.roi-assume{font-size:12px;color:var(--muted);margin-top:16px;line-height:1.6;border-top:1px solid var(--border);padding-top:14px}
@media (prefers-reduced-motion: reduce){.roi-hero{animation:none}}
/* Sticky "Go Live" CTA — conversion driver, premium pulse */
.golive{position:fixed;bottom:18px;left:50%;transform:translateX(-50%);z-index:90;display:flex;align-items:center;gap:14px;background:rgba(10,10,14,.88);backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);border:1px solid rgba(124,58,237,.4);border-radius:999px;padding:10px 12px 10px 22px;box-shadow:0 14px 50px rgba(0,0,0,.5),0 0 34px rgba(124,58,237,.22)}
.golive .gl-note{font-size:12px;color:var(--muted);white-space:nowrap}
.golive .gl-note b{color:#34D399;font-weight:600}
.gl-btn{position:relative;display:inline-block;font-weight:700;font-size:14.5px;color:#fff;text-decoration:none;background:linear-gradient(135deg,var(--violet),var(--fuchsia));border-radius:999px;padding:13px 26px;white-space:nowrap;animation:glPulse 2.4s ease-in-out infinite;transition:transform .15s}
.gl-btn:hover{transform:scale(1.04)}
.gl-sec{font-size:13px;font-weight:600;color:var(--g1);text-decoration:none;border:1px solid rgba(124,58,237,.5);border-radius:999px;padding:11px 20px;white-space:nowrap;transition:.2s}
.gl-sec:hover{background:rgba(124,58,237,.12)}
@keyframes glPulse{0%,100%{box-shadow:0 0 0 0 rgba(217,70,239,.45),0 0 24px rgba(124,58,237,.45)}50%{box-shadow:0 0 0 9px rgba(217,70,239,0),0 0 34px rgba(124,58,237,.6)}}
@media (prefers-reduced-motion: reduce){.gl-btn{animation:none}.orb{animation:none}.launcher{animation:none}.launcher .ring,.launcher .ring2{animation:none}}
@media (max-width:720px){.golive{left:0;right:0;bottom:0;transform:none;border-radius:0;justify-content:center;padding:10px 12px;border-left:none;border-right:none;border-bottom:none}.golive .gl-note{display:none}.gl-sec{display:none}.gl-btn{width:100%;text-align:center}.wrap{padding:20px 14px 120px}.bview{height:min(72vh,540px)}.chatwrap{bottom:10px;right:10px;max-width:calc(100% - 20px);height:min(520px,calc(100% - 20px))}.launcher{bottom:14px;right:14px;width:58px;height:58px}.hero .pre{margin-bottom:14px}}
.wrap{padding-bottom:140px}
/* ==== v1.6 BUGATTI LAYOUT: value-first grid + sticky engagement rail ==== */
html{scrollbar-color:color-mix(in srgb,var(--accent) 45%,#0B0B0E) transparent;scrollbar-width:thin}
::-webkit-scrollbar{width:9px;height:9px}
::-webkit-scrollbar-track{background:transparent}
::-webkit-scrollbar-thumb{background:color-mix(in srgb,var(--accent) 38%,#1a1a22);border-radius:99px;border:2px solid rgba(0,0,0,.35);background-clip:padding-box}
::-webkit-scrollbar-thumb:hover{background:color-mix(in srgb,var(--accent) 70%,#1a1a22)}
.main{display:grid;grid-template-columns:minmax(0,1fr) 336px;gap:22px;align-items:start;margin-top:6px}
.rail{position:sticky;top:78px;display:flex;flex-direction:column;gap:16px}
.rail .card{padding:22px;border-radius:20px}
.rail h2{font-size:17px}
.cta-card{border-color:color-mix(in srgb,var(--accent) 32%,transparent);background:linear-gradient(168deg,color-mix(in srgb,var(--accent) 11%,transparent),var(--card));box-shadow:0 0 34px color-mix(in srgb,var(--accent) 12%,transparent)}
.cta-card .urg{display:flex;align-items:center;gap:8px;font-size:12.5px;font-weight:600;color:#34D399;margin-bottom:12px}
.cta-card .urg::before{content:'';width:8px;height:8px;border-radius:50%;background:#34D399;box-shadow:0 0 10px #34D399;animation:pulse 2s infinite}
.cta-card .btn{width:100%;text-align:center;padding:13px 20px;font-size:14.5px}
.cta-card .btn.ghost{margin-top:10px}
.railfoot{text-align:center;font-size:11.5px;color:var(--muted);padding:2px 6px}
.railfoot a{color:var(--g1);text-decoration:none}
.main .roi{margin:0 0 22px}
.main .roi-hero{font-size:clamp(38px,4.6vw,56px)}
.main .roi-grid{gap:24px}
@media(max-width:980px){.main{grid-template-columns:1fr}.rail{position:static}}
/* ==== widget v1.9: teaser bubble (Lion Click DNA) + message meta (Intercom DNA) ==== */
.tnc-teaser{position:absolute;bottom:100px;right:24px;z-index:29;max-width:270px;background:rgba(13,14,22,.96);border:1px solid color-mix(in srgb,var(--ring) 45%,transparent);border-radius:14px 14px 4px 14px;padding:12px 30px 12px 14px;font-size:12.5px;line-height:1.5;color:var(--text);box-shadow:0 10px 34px rgba(0,0,0,.45),0 0 22px color-mix(in srgb,var(--ring) 28%,transparent);cursor:pointer;opacity:0;transform:translateY(8px);transition:opacity .35s,transform .35s}
.tnc-teaser.show{opacity:1;transform:none}
.tnc-teaser .tx-close{position:absolute;top:6px;right:8px;background:none;border:none;color:var(--muted);font-size:13px;cursor:pointer;padding:2px}
.chat.light~.tnc-teaser{background:#fff;color:#1F2430;border-color:rgba(0,0,0,.1)}
.msg-meta{font-size:10.5px;color:var(--muted);margin-top:4px;letter-spacing:.02em}
.msg.user .msg-meta,.umeta{text-align:right;align-self:flex-end;font-size:10.5px;color:var(--muted);margin:-4px 2px 2px 0}
.chat.light .msg-meta,.chat.light .umeta{color:#6B7280}
/* ==== widget DNA: typing dots, bubble avatars, accent chip, glow input ==== */
.tdots{display:inline-flex;gap:4px;align-items:center;padding:3px 1px}
.tdots i{width:7px;height:7px;border-radius:50%;background:color-mix(in srgb,var(--accent) 78%,#fff);animation:tdb 1.15s ease-in-out infinite}
.tdots i:nth-child(2){animation-delay:.15s}.tdots i:nth-child(3){animation-delay:.3s}
@keyframes tdb{0%,60%,100%{transform:translateY(0);opacity:.4}30%{transform:translateY(-4px);opacity:1}}
.brow{display:flex;gap:8px;align-items:flex-end;max-width:88%;align-self:flex-start}
.brow .msg{max-width:100%}
.bav{flex:0 0 24px;width:24px;height:24px;border-radius:50%;background:linear-gradient(135deg,var(--accent),var(--accent2));color:#fff;font-size:11px;display:flex;align-items:center;justify-content:center;margin-bottom:3px;overflow:hidden;box-shadow:0 0 10px color-mix(in srgb,var(--accent) 40%,transparent)}
.bav img{width:100%;height:100%;object-fit:cover}
.chip-accent{font-family:inherit;font-size:13px;cursor:pointer;border-radius:var(--cp-rad);padding:9px 16px;line-height:1.45;background:linear-gradient(135deg,var(--accent2),var(--accent)) !important;color:#fff !important;border:none !important;font-weight:700 !important;box-shadow:0 2px 14px color-mix(in srgb,var(--accent2) 40%,transparent) !important}
.chat-body{scrollbar-width:thin;scrollbar-color:color-mix(in srgb,var(--accent) 40%,transparent) transparent}
.chat-body::-webkit-scrollbar{width:6px}
.chat-body::-webkit-scrollbar-thumb{background:color-mix(in srgb,var(--accent) 40%,transparent);border:none}
.chat-input input:focus{border-color:var(--accent);box-shadow:0 0 0 3px color-mix(in srgb,var(--accent) 20%,transparent),0 0 16px color-mix(in srgb,var(--accent) 28%,transparent)}
.chat-input .btn{background:linear-gradient(135deg,var(--accent),var(--accent2));padding:10px 18px}
/* ==== 5 animated launchers (reduced-motion safe) ==== */
.launcher.l-breathe .ring,.launcher.l-breathe .ring2,.launcher.l-bounce .ring,.launcher.l-bounce .ring2,.launcher.l-orbit .ring2,.launcher.l-pulse .ring,.launcher.l-pulse .ring2,.launcher.l-static .ring,.launcher.l-static .ring2{display:none}
/* LION CLICK SIGNATURE (DEFAULT): brand ring spinning CLOCKWISE around the icon (no pulse). */
.launcher.l-ring .ring{display:block;inset:-6px;border:2.5px solid transparent;border-top-color:var(--ring);border-right-color:color-mix(in srgb,var(--ring) 45%,transparent);animation:tncSpin 3.2s linear infinite;filter:drop-shadow(0 0 6px color-mix(in srgb,var(--ring) 65%,transparent))}
.launcher.l-ring .ring2{display:block;inset:5px;border:1px solid color-mix(in srgb,var(--ring) 30%,transparent)}
.launcher.l-ring{box-shadow:0 8px 28px rgba(0,0,0,.45),0 0 26px color-mix(in srgb,var(--ring) 45%,transparent)}
.launcher.l-pulse{animation:lpulse 2s ease-in-out infinite}
@keyframes lpulse{0%,100%{box-shadow:0 8px 28px rgba(0,0,0,.4),0 0 0 0 color-mix(in srgb,var(--ring) 55%,transparent)}50%{box-shadow:0 8px 28px rgba(0,0,0,.4),0 0 0 12px color-mix(in srgb,var(--ring) 0%,transparent)}}
.launcher.l-static{box-shadow:0 8px 26px rgba(0,0,0,.45),0 0 18px color-mix(in srgb,var(--ring) 28%,transparent)}
@media (prefers-reduced-motion:reduce){.launcher.l-ring .ring{animation:none}.launcher.l-pulse{animation:none}}
@keyframes lspin{to{transform:rotate(360deg)}}
@media (prefers-reduced-motion:reduce){.launcher.l-ring::before{animation:none}}
.launcher.l-glow{animation:lglow 2.2s ease-in-out infinite}
@keyframes lglow{0%,100%{box-shadow:0 8px 28px rgba(0,0,0,.4),0 0 18px color-mix(in srgb,var(--ring) 60%,transparent),0 0 34px color-mix(in srgb,var(--accent2) 30%,transparent)}50%{box-shadow:0 8px 30px rgba(0,0,0,.4),0 0 34px color-mix(in srgb,var(--ring) 100%,transparent),0 0 72px color-mix(in srgb,var(--accent2) 60%,transparent)}}
.launcher.l-breathe{animation:lbreathe 3s ease-in-out infinite}
@keyframes lbreathe{0%,100%{transform:scale(1)}50%{transform:scale(1.09)}}
.launcher.l-orbit .ring{inset:-7px;border:2.5px solid transparent;border-top-color:var(--ring);animation:lorbit 1.6s linear infinite}
@keyframes lorbit{to{transform:rotate(360deg)}}
.launcher.l-bounce{animation:lbounce 2.8s cubic-bezier(.36,.07,.19,.97) infinite}
@keyframes lbounce{0%,78%,100%{transform:translateY(0)}84%{transform:translateY(-10px)}90%{transform:translateY(0)}95%{transform:translateY(-4px)}}
@media (prefers-reduced-motion:reduce){.launcher{animation:none !important}.tdots i{animation:none}.cta-card .urg::before{animation:none}}
</style>
</head>
<body>
<div class="orb orb1"></div><div class="orb orb2"></div>
<nav class="nav">
	<div class="logo">Tuani<span class="grad">Chat</span> <span style="font-weight:400;color:var(--muted);font-size:13px">by TuaniLabs</span></div>
	<div class="badge">Private demo — prepared for <?php echo esc_html( $company ); ?></div>
</nav>
<div class="wrap">
	<div class="hero">
		<span class="pre">Private demo · Built from your live website</span>
		<h1>See TuaniChat live on<br><span class="grad"><?php echo esc_html( $domain ? $domain : $company ); ?></span></h1>
		<p>Your website with your own AI Intake Assistant installed. It answers from your actual content and turns visitors into leads, 24/7.</p>
		<?php if ( $nstats ) : ?>
		<div class="statrow">
			<?php foreach ( $nstats as $st ) : ?><span class="schip"><?php echo esc_html( $st ); ?></span><?php endforeach; ?>
		</div>
		<?php endif; ?>
	</div>

	<div class="main">
		<div class="colL">
			<div class="card roi" id="tncRoi">
				<h2>What could your <?php echo esc_html( $roi['assistant'] ); ?> capture?</h2>
				<div class="sub">Based on <?php echo esc_html( $ind_lbl ); ?> averages. Drag the sliders to your numbers.</div>
				<div class="roi-grid">
					<div>
						<div class="roi-row"><label>Monthly website visitors <b id="roiVisVal"></b></label><input type="range" id="roiVis" min="100" max="20000" step="100" value="<?php echo (int) $roi['visitors']; ?>"></div>
						<div class="roi-row"><label><?php echo esc_html( $roi['label'] ); ?> <b id="roiDealVal"></b></label><input type="range" id="roiDeal" min="<?php echo (int) $roi['deal_min']; ?>" max="<?php echo (int) $roi['deal_max']; ?>" step="<?php echo (int) $roi['deal_step']; ?>" value="<?php echo (int) $roi['deal']; ?>"></div>
						<div class="roi-row"><label>Close / sign rate <b id="roiCloseVal"></b></label><input type="range" id="roiClose" min="5" max="100" step="1" value="<?php echo (int) $roi['close']; ?>"></div>
					</div>
					<div class="roi-out">
						<div class="roi-lbl">Additional revenue / month</div>
						<div class="roi-mo" id="roiMo">$0</div>
						<div class="roi-lbl" style="margin-top:14px">Additional revenue / year</div>
						<div class="roi-hero" id="roiYr">$0</div>
					</div>
				</div>
				<div class="roi-assume">Conservative assumptions: ~3% of visitors have buying intent · ~35% of inquiries arrive after hours or go unanswered today · your <?php echo esc_html( $roi['assistant'] ); ?> captures ~60% of those. Extra leads × close rate × average value.</div>
			</div>

			<div class="bwin">
				<div class="bbar"><span class="dots"><i></i><i></i><i></i></span><span class="burl">🔒 <?php echo esc_html( preg_replace( '#^https?://#', '', untrailingslashit( $site_url ) ) ); ?></span></div>
				<div class="bview" id="tncCanvas">
					<?php // GUARANTEED FLOOR: mock is ALWAYS rendered first and never hidden. ?>
					<div class="mock" id="tncMock">
						<div class="mhead">
							<span class="mlogo">
								<?php if ( ! empty( $theme['logo'] ) ) : ?><img src="<?php echo esc_url( $theme['logo'] ); ?>" alt="<?php echo esc_attr( $company ); ?>"><?php else : ?><?php echo esc_html( $company ); ?><?php endif; ?>
							</span>
							<span class="mnav"><i></i><i></i><i></i><i></i></span>
						</div>
						<div class="mhero">
							<div class="mh1"><?php echo esc_html( $hero ); ?></div>
							<span class="mbtn">Get Started</span>
							<div class="mnote">Preview rendered from your website's content &amp; brand colors</div>
						</div>
						<div class="mrow"><div class="mcard"></div><div class="mcard"></div><div class="mcard"></div></div>
					</div>
					<?php // OVERLAYS (only shown after VERIFIED paint; otherwise the mock floor stays): ?>
					<img class="bshot" id="tncShot"<?php echo $shot ? ' src="' . esc_url( $shot ) . '"' : ''; ?> alt="<?php echo esc_attr( $company ); ?> homepage" loading="eager">
					<?php if ( $framable ) : ?><iframe class="bframe" id="tncFrame" src="<?php echo esc_url( $site_url ); ?>" loading="eager" referrerpolicy="no-referrer" title="<?php echo esc_attr( $company ); ?>"></iframe><?php endif; ?>

					<button class="launcher l-<?php echo esc_attr( $launch ); ?>" id="tncLaunch" aria-label="Open chat" type="button">
						<span class="ring"></span><span class="ring2"></span>
						<?php echo $icon_svg; // phpcs:ignore -- static inline SVG set. ?>
					</button>

					<div class="chatwrap" id="tncPanel">
						<div class="chat<?php echo esc_attr( $panelcls ); ?>">
							<?php if ( $advanced ) : ?>
							<div class="chat-head adv">
								<button class="hd-ic back" id="tncBack" aria-label="Back" type="button">‹</button>
								<?php if ( $theme['agent_avatar'] ) : ?>
								<img class="avatar" src="<?php echo esc_url( $theme['agent_avatar'] ); ?>" alt="<?php echo esc_attr( $theme['agent_name'] ); ?>">
								<?php else : ?>
								<div class="avatar mark">✦</div>
								<?php endif; ?>
								<div class="t"><?php echo esc_html( $theme['agent_name'] ); ?></div>
								<div class="s2"><?php echo esc_html( $theme['agent_subtitle'] ); ?></div>
								<div class="s" style="margin-top:2px"><?php echo esc_html( $theme['status_text'] ); ?></div>
								<button class="hd-ic close" id="tncCloseBtn" aria-label="Close" type="button">✕</button>
							</div>
							<?php else : ?>
							<div class="chat-head">
								<div class="chat-dot">✦</div>
								<div style="flex:1;min-width:0">
									<div class="t"><?php echo esc_html( $company ); ?> <?php echo esc_html( $theme['widget_name'] ); ?></div>
									<div class="s"><?php echo esc_html( $theme['status_text'] ); ?></div>
								</div>
								<button class="hd-ic" id="tncCloseBtn" aria-label="Close" type="button" style="position:static">✕</button>
							</div>
							<?php endif; ?>
							<div class="chat-body" id="tncBody"></div>
							<div class="starters" id="tncStarters"></div>
							<div class="chat-input">
								<input id="tncInput" type="text" placeholder="Ask anything about <?php echo esc_attr( $company ); ?>…" maxlength="1000">
								<button class="btn" id="tncSend">Send</button>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<aside class="rail">
			<div class="card cta-card">
				<?php if ( $urgency ) : ?><div class="urg"><?php echo esc_html( $urgency ); ?></div><?php endif; ?>
				<h2>Hire your 24/7 AI employee</h2>
				<div class="sub">It already knows your business. Activation takes one day.</div>
				<a class="btn" style="text-decoration:none;display:block" href="<?php echo esc_url( $go_url ); ?>">Activate This On My Website</a>
				<?php if ( $call ) : ?><a class="btn ghost" style="text-decoration:none;display:block;text-align:center" href="<?php echo esc_url( $call ); ?>">Book a Setup Call</a><?php endif; ?>
			</div>

			<div class="card lead">
				<h2>Want this on your website?</h2>
				<div class="sub"><?php echo esc_html( $helper ); ?></div>
				<form id="tncLead">
					<input type="text" id="tncLName" placeholder="Your name" maxlength="120">
					<input type="email" id="tncLEmail" placeholder="Email" maxlength="190">
					<input type="tel" id="tncLPhone" placeholder="Phone" maxlength="40">
					<textarea id="tncLMsg" placeholder="Anything we should know? (optional)" maxlength="1000"></textarea>
					<button class="btn" type="submit" style="width:100%">Get My Intake Assistant</button>
					<div id="tncLOut"></div>
				</form>
			</div>

			<div class="card">
				<h2>What we found on your website</h2>
				<div class="sub">From our analysis of your site</div>
				<?php foreach ( $audit as $item ) : ?>
				<div class="audit-item">
					<div class="audit-ic <?php echo esc_attr( $item[0] ); ?>"><?php echo 'gap' === $item[0] ? '!' : '✓'; ?></div>
					<div><?php echo esc_html( $item[1] ); ?></div>
				</div>
				<?php endforeach; ?>
			</div>

			<div class="railfoot">Prepared exclusively for <?php echo esc_html( $company ); ?> · Powered by <a href="https://tuanilabs.com">TuaniChat</a></div>
		</aside>
	</div>

	<div class="foot">This private demo was prepared exclusively for <?php echo esc_html( $company ); ?>. Powered by <a href="https://tuanilabs.com">TuaniChat — TuaniLabs LLC</a>.</div>

	<div class="golive" role="complementary" aria-label="Activate TuaniChat">
		<?php if ( $urgency ) : ?><span class="gl-note"><b>●</b> <?php echo esc_html( $urgency ); ?></span><?php endif; ?>
		<a class="gl-btn" href="<?php echo esc_url( $go_url ); ?>">Go Live with Your AI Assistant</a>
		<?php if ( $call ) : ?><a class="gl-sec" href="<?php echo esc_url( $call ); ?>">Book Setup Call</a><?php endif; ?>
	</div>
</div>

<script>window.TNC_DEMO = <?php echo wp_json_encode( $cfg ); ?>;</script>
<script src="<?php echo esc_url( TNC_PLUGIN_URL . 'public/js/tnc-widget.js?v=' . TNC_VERSION ); ?>"></script>
</body>
</html>
		<?php
	}
}
