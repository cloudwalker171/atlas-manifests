<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Neutral sample prospects — fictional businesses for demos & screenshots.
 * Seeded once (option-guarded). Clearly marked as samples; no crawling needed.
 */
class TNC_Samples {

	public static function maybe_seed() {
		if ( get_option( 'tnc_samples_v3' ) ) {
			return;
		}
		update_option( 'tnc_samples_seeded', 1, false );
		update_option( 'tnc_samples_v2', 1, false );
		update_option( 'tnc_samples_v3', 1, false );
		foreach ( self::definitions() as $def ) {
			self::create_sample( $def );
		}
	}

	private static function definitions() {
		return array(
			array(
				'company'  => 'Summit Law Group',
				'url'      => 'https://summitlawgroup.example',
				'industry' => 'personal_injury',
				'brand'    => array( 'primary' => '', 'secondary' => '', 'logo' => '' ), // industry gold-on-charcoal aesthetic rules.
				'overrides' => array( 'widget_mode' => 'advanced', 'button_style' => 'outline', 'agent_name' => 'Grace', 'choices' => array( 'I was injured in an accident', "I'd like a free consultation", 'I have a different question' ), 'starters' => array( 'Do I have a case?', 'How much is a consultation?', 'What should I do after an accident?' ) ),
				'hero'     => 'Serious Injuries Deserve Serious Advocates',
				'desc'     => 'Summit Law Group is a personal injury firm fighting for accident victims — no fees unless we win.',
				'services' => array( 'Car Accidents', 'Truck Accidents', 'Slip & Fall', 'Medical Malpractice', 'Wrongful Death', 'Workers\' Compensation' ),
				'phone'    => '(555) 014-2200',
				'email'    => 'intake@summitlawgroup.example',
				'location' => '400 Summit Plaza, Suite 900, Denver, CO 80202',
				'trust'    => array( 'Super Lawyers', 'Board-certified', '5-star reviews', 'Awards mentioned' ),
				'kb'       => array(
					array( 'Practice areas', "Summit Law Group represents clients in car accidents, truck accidents, slip and fall injuries, medical malpractice, wrongful death and workers' compensation claims across Colorado. The firm has recovered millions for injured clients and works on contingency — you pay nothing unless we win your case." ),
					array( 'Free consultations', 'Consultations are always free and confidential. An attorney reviews every case personally within 24 hours of your request. Evening and weekend appointments are available, and we can come to you if you are unable to travel.' ),
				),
				'qa'       => array( array( 'Do you charge for a consultation?', 'No — consultations at Summit Law Group are always free and confidential, and we only get paid if we win your case.' ) ),
			),
			array(
				'company'  => 'Apex Roofing Co',
				'url'      => 'https://apexroofingco.example',
				'industry' => 'roofing',
				'brand'    => array( 'primary' => '#C2410C', 'secondary' => '#1F2937', 'logo' => '' ),
				'overrides' => array( 'widget_mode' => 'advanced', 'button_style' => 'solid', 'agent_name' => 'Mike', 'choices' => array( "I'd like a free roof inspection", 'I have storm damage', 'I have a different question' ), 'starters' => array( 'Do you offer free inspections?', 'Do you handle insurance claims?', 'How fast can you start?' ) ),
				'hero'     => "Storm Damage? We've Got You Covered",
				'desc'     => 'Apex Roofing Co provides residential and commercial roofing — repairs, replacement and storm restoration with free inspections.',
				'services' => array( 'Roof Replacement', 'Roof Repair', 'Storm Damage Restoration', 'Gutter Installation', 'Commercial Roofing', 'Free Inspections' ),
				'phone'    => '(555) 014-7300',
				'email'    => 'office@apexroofingco.example',
				'location' => '2180 Industrial Pkwy, Austin, TX 78744',
				'trust'    => array( 'Licensed', 'Insured', 'Certifications', '5-star reviews' ),
				'kb'       => array(
					array( 'Services & service area', 'Apex Roofing Co serves the greater Austin metro with roof replacement, roof repair, storm damage restoration, gutter installation and commercial roofing. Every project starts with a free, no-obligation inspection and a written estimate.' ),
					array( 'Insurance claims help', 'After hail or wind damage, our team documents the damage, meets your insurance adjuster on site and helps you navigate the claim from start to finish. Most storm restoration projects are completed within two weeks of claim approval.' ),
				),
				'qa'       => array( array( 'Do you offer free estimates?', 'Yes — every Apex Roofing project starts with a free inspection and a written, no-obligation estimate.' ) ),
			),
			array(
				'company'  => 'Pearl Dental Studio',
				'url'      => 'https://pearldentalstudio.example',
				'industry' => 'dental',
				'brand'    => array( 'primary' => '#0E7490', 'secondary' => '#155E75', 'logo' => '' ),
				'overrides' => array( 'widget_mode' => 'advanced', 'button_style' => 'solid', 'agent_name' => 'Mia', 'choices' => array( "I'd like to book an appointment", 'Do you take my insurance?', 'I have a different question' ), 'starters' => array( 'Do you accept new patients?', 'Do you offer Invisalign?', 'Is emergency care available?' ) ),
				'hero'     => 'Gentle Dentistry for the Whole Family',
				'desc'     => 'Pearl Dental Studio offers family, cosmetic and emergency dentistry in a calm, modern practice — new patients welcome.',
				'services' => array( 'Cleanings & Exams', 'Invisalign', 'Teeth Whitening', 'Veneers', 'Dental Implants', 'Emergency Dentistry' ),
				'phone'    => '(555) 014-8810',
				'email'    => 'smile@pearldentalstudio.example',
				'location' => '88 Harbor View Dr, Suite 210, San Diego, CA 92101',
				'trust'    => array( 'Board-certified', 'Testimonials', '5-star reviews' ),
				'kb'       => array(
					array( 'Services & new patients', 'Pearl Dental Studio provides cleanings and exams, Invisalign, whitening, veneers, dental implants and same-day emergency dentistry. New patients are always welcome and most PPO insurance plans are accepted.' ),
					array( 'Comfort-first care', 'The studio is designed around anxious patients: noise-cancelling headphones, weighted blankets, sedation options and a gentle, judgment-free team. Evening appointments are available on Tuesdays and Thursdays.' ),
				),
				'qa'       => array( array( 'Do you accept new patients?', 'Yes! Pearl Dental Studio is welcoming new patients — we can usually schedule your first visit within a week.' ) ),
			),
			array(
				'company'  => 'NovaTech Solutions',
				'url'      => 'https://novatechsolutions.example',
				'industry' => 'other',
				'brand'    => array( 'primary' => '#06B6D4', 'secondary' => '#7C3AED', 'logo' => '', 'site_mode' => 'dark', 'vibrancy' => 'vibrant', 'radius' => 'sharp' ),
				'hero'     => 'Autonomous Systems for an Intelligent Future',
				'desc'     => 'NovaTech Solutions builds AI-powered automation and robotics platforms for modern enterprises.',
				'services' => array( 'AI Automation Platform', 'Robotics Integration', 'Computer Vision', 'Predictive Analytics', 'Enterprise Deployment', '24/7 Support' ),
				'phone'    => '(555) 014-9920',
				'email'    => 'hello@novatechsolutions.example',
				'location' => '500 Quantum Way, Floor 12, Seattle, WA 98109',
				'trust'    => array( 'Certifications', 'Awards mentioned', 'Testimonials' ),
				'overrides' => array( 'widget_mode' => 'advanced', 'button_style' => 'outline', 'agent_name' => 'Nova', 'icon' => 'spark', 'radius' => 'sharp', 'fx' => 'grid', 'status_text' => 'Online · replies instantly', 'avatar_ring' => '#D4AF37', 'ring' => '#06B6D4', 'choices' => array( "I'd like a product demo", 'What does NovaTech build?', 'I have a different question' ), 'starters' => array( 'What platforms do you integrate with?', 'How fast is deployment?', 'Can I see a demo?' ) ),
				'kb'       => array(
					array( 'Platform overview', 'The NovaTech AI Automation Platform connects to existing enterprise systems and automates workflows with computer vision, predictive analytics and robotic process integration. Typical deployment takes 4–6 weeks with a dedicated success engineer.' ),
					array( 'Support & onboarding', 'Every NovaTech contract includes 24/7 support, quarterly model retraining and a named success engineer. Demos are available weekly and proof-of-concept pilots run 30 days.' ),
				),
				'qa'       => array( array( 'Can I get a demo?', 'Absolutely — NovaTech runs live product demos every week. Leave your details and the team will book you into the next session.' ) ),
			),
		);
	}

	private static function create_sample( $def ) {
		global $wpdb;
		$existing_id = (int) $wpdb->get_var( $wpdb->prepare(
			'SELECT id FROM ' . TNC_Prospects::table() . ' WHERE company_name = %s',
			$def['company']
		) );
		if ( $existing_id ) {
			// v2 refresh: update flagship overrides + brand on the existing sample.
			if ( ! empty( $def['overrides'] ) ) {
				TNC_Prospects::update( $existing_id, array( 'theme_overrides' => wp_json_encode( $def['overrides'] ) ) );
			}
			$row = TNC_Prospects::get( $existing_id );
			if ( $row && is_array( $row['crawl_data'] ) ) {
				$cd = $row['crawl_data'];
				$cd['extracted']['brand'] = array_merge( array( 'primary' => '', 'secondary' => '', 'logo' => '' ), $def['brand'] );
				TNC_Prospects::update( $existing_id, array( 'crawl_data' => wp_json_encode( $cd ) ) );
			}
			return;
		}
		$id = TNC_Prospects::create( array(
			'company_name' => $def['company'],
			'website_url'  => $def['url'],
			'industry'     => $def['industry'],
			'notes'        => 'SAMPLE — fictional business seeded for demos & screenshots.',
			'status'       => 'demo_created',
		) );
		if ( is_wp_error( $id ) ) {
			return;
		}

		$extracted = array(
			'company_name'  => $def['company'],
			'description'   => $def['desc'],
			'services'      => $def['services'],
			'locations'     => array( $def['location'] ),
			'phones'        => array( $def['phone'] ),
			'emails'        => array( $def['email'] ),
			'faqs'          => array(),
			'ctas'          => array( 'Get Started', 'Contact Us' ),
			'forms_present' => true,
			'trust_signals' => $def['trust'],
			'chat_widget'   => '',
			'pixels'        => array( 'Google Analytics' ),
			'hours_listed'  => false,
			'hero'          => $def['hero'],
			'brand'         => $def['brand'],
			'framable'      => false, // fictional domain — always render the brand mock.
		);
		$crawl = array(
			'platform'   => 'wordpress',
			'pages'      => array(),
			'extracted'  => $extracted,
			'errors'     => array(),
			'crawled_at' => current_time( 'mysql' ),
			'page_count' => 18,
		);
		TNC_Prospects::update( $id, array( 'crawl_data' => wp_json_encode( $crawl ), 'platform' => 'wordpress', 'crawl_state' => 'done' ) );

		// Knowledge base: basics + content + approved Q&A.
		$basics = 'Company: ' . $def['company'] . "\nAbout: " . $def['desc'] . "\nServices/Products: " . implode( '; ', $def['services'] ) . "\nLocations: " . $def['location'] . "\nPhone: " . $def['phone'] . "\nEmail: " . $def['email'] . "\nTrust signals: " . implode( ', ', $def['trust'] );
		TNC_KB::add_chunk( $id, 'basics', 'Company basics', $basics );
		foreach ( $def['kb'] as $chunk ) {
			TNC_KB::add_chunk( $id, 'manual', $chunk[0] . ' (sample)', $chunk[1] );
		}
		foreach ( $def['qa'] as $qa ) {
			TNC_KB::add_chunk( $id, 'qa', 'Q&A', $qa[1], '', $qa[0] );
		}

		if ( ! empty( $def['overrides'] ) ) {
			TNC_Prospects::update( $id, array( 'theme_overrides' => wp_json_encode( $def['overrides'] ) ) );
		}

		$p = TNC_Prospects::get( $id );
		list( $score, $breakdown ) = TNC_Outreach::score( $p );
		TNC_Prospects::update( $id, array( 'score' => $score, 'score_breakdown' => wp_json_encode( $breakdown ) ) );
	}
}
