<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Server-side Anthropic Messages API client. The key never leaves the server.
 */
class TNC_Anthropic {

	/**
	 * @param string $system   System prompt.
	 * @param array  $messages [['role'=>'user'|'assistant','content'=>string], ...]
	 * @param array  $opts     max_tokens, temperature, model.
	 * @return array|WP_Error  ['text'=>string,'input_tokens'=>int,'output_tokens'=>int,'model'=>string]
	 */
	public static function complete( $system, $messages, $opts = array() ) {
		$key = TNC_Settings::get( 'api_key' );
		if ( '' === $key ) {
			return new WP_Error( 'tnc_no_key', 'No API key configured. Add your Anthropic API key in TuaniChat → Settings.' );
		}
		$model    = ! empty( $opts['model'] ) ? $opts['model'] : TNC_Settings::get( 'model', 'claude-haiku-4-5-20251001' );
		$endpoint = untrailingslashit( TNC_Settings::get( 'endpoint_base', 'https://api.anthropic.com' ) ) . '/v1/messages';

		$body = array(
			'model'      => $model,
			'max_tokens' => ! empty( $opts['max_tokens'] ) ? (int) $opts['max_tokens'] : 700,
			'system'     => $system,
			'messages'   => $messages,
		);
		if ( isset( $opts['temperature'] ) ) {
			$body['temperature'] = (float) $opts['temperature'];
		}

		$res = wp_remote_post( $endpoint, array(
			'timeout' => 60,
			'headers' => array(
				'Content-Type'      => 'application/json',
				'x-api-key'         => $key,
				'anthropic-version' => '2023-06-01',
			),
			'body'    => wp_json_encode( $body ),
		) );

		if ( is_wp_error( $res ) ) {
			return new WP_Error( 'tnc_api', 'AI request failed: ' . $res->get_error_message() );
		}
		$code = wp_remote_retrieve_response_code( $res );
		$json = json_decode( wp_remote_retrieve_body( $res ), true );
		if ( 200 !== $code || ! is_array( $json ) ) {
			$msg = isset( $json['error']['message'] ) ? $json['error']['message'] : ( 'HTTP ' . $code );
			return new WP_Error( 'tnc_api', 'AI request failed: ' . $msg );
		}

		$text = '';
		if ( ! empty( $json['content'] ) && is_array( $json['content'] ) ) {
			foreach ( $json['content'] as $block ) {
				if ( isset( $block['type'] ) && 'text' === $block['type'] ) {
					$text .= $block['text'];
				}
			}
		}

		return array(
			'text'          => trim( $text ),
			'input_tokens'  => isset( $json['usage']['input_tokens'] ) ? (int) $json['usage']['input_tokens'] : 0,
			'output_tokens' => isset( $json['usage']['output_tokens'] ) ? (int) $json['usage']['output_tokens'] : 0,
			'model'         => $model,
		);
	}
}
