<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Central chat proxy (the brain, v1) + lead capture. Public REST endpoints
 * used by the thin-client demo widget. Designed so future client widgets on
 * customer sites hit the same endpoints with a license key (Phase 2).
 */
class TNC_Chat {

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	public static function routes() {
		register_rest_route( TNC_REST_NS, '/chat', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'handle_chat' ),
			'permission_callback' => array( __CLASS__, 'verify_demo_token' ),
		) );
		register_rest_route( TNC_REST_NS, '/lead', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'handle_lead' ),
			'permission_callback' => array( __CLASS__, 'verify_demo_token' ),
		) );
	}

	/** HMAC token per demo slug — printed into the demo page only. */
	public static function demo_token( $slug ) {
		return hash_hmac( 'sha256', 'demo:' . $slug, (string) get_option( 'tnc_demo_secret', wp_salt( 'auth' ) ) );
	}

	public static function verify_demo_token( $request ) {
		$slug  = sanitize_text_field( (string) $request->get_param( 'slug' ) );
		$token = sanitize_text_field( (string) $request->get_param( 'token' ) );
		if ( '' === $slug || '' === $token ) {
			return false;
		}
		if ( ! hash_equals( self::demo_token( $slug ), $token ) ) {
			return false;
		}
		return self::rate_limit_ok();
	}

	/** Simple transient rate limiter per IP. */
	private static function rate_limit_ok() {
		$ip    = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '0.0.0.0';
		$key   = 'tnc_rl_' . md5( $ip );
		$count = (int) get_transient( $key );
		$limit = (int) TNC_Settings::get( 'chat_rate_limit', 20 );
		if ( $count >= $limit ) {
			return new WP_Error( 'tnc_rate', 'Too many requests. Please wait a moment.', array( 'status' => 429 ) );
		}
		set_transient( $key, $count + 1, 5 * MINUTE_IN_SECONDS );
		return true;
	}

	public static function handle_chat( $request ) {
		$slug    = sanitize_text_field( (string) $request->get_param( 'slug' ) );
		$session = sanitize_text_field( (string) $request->get_param( 'session' ) );
		$history = $request->get_param( 'messages' );

		$prospect = TNC_Prospects::get_by_slug( $slug );
		if ( ! $prospect ) {
			return new WP_Error( 'tnc_404', 'Demo not found.', array( 'status' => 404 ) );
		}

		// Sanitize history: cap to last 12 turns, strings only.
		$messages = array();
		if ( is_array( $history ) ) {
			foreach ( array_slice( $history, -12 ) as $m ) {
				if ( ! is_array( $m ) || empty( $m['content'] ) || empty( $m['role'] ) ) {
					continue;
				}
				$role       = 'assistant' === $m['role'] ? 'assistant' : 'user';
				$messages[] = array(
					'role'    => $role,
					'content' => mb_substr( sanitize_textarea_field( (string) $m['content'] ), 0, 2000 ),
				);
			}
		}
		if ( empty( $messages ) || 'user' !== end( $messages )['role'] ) {
			return new WP_Error( 'tnc_bad', 'No user message.', array( 'status' => 400 ) );
		}

		// ===== COST GUARD (runs BEFORE any AI spend) =====
		$guard = self::cost_guard( $prospect, $session );
		if ( is_wp_error( $guard ) ) {
			return $guard;
		}

		$last_user = end( $messages )['content'];
		$max_ctx   = (int) TNC_Settings::get( 'max_context', 7000 );
		$context   = TNC_KB::retrieve( $prospect['id'], $last_user, $max_ctx );
		// GUARANTEED LOCATION/CONTACT FACTS: always ground the assistant in the
		// prospect's real location (poi.db city/state + deep-crawl street address/
		// hours) so location/address/hours questions are answered accurately —
		// never "I don't have that." $0 / verbatim, no invention.
		$loc = self::location_facts( $prospect );
		if ( '' !== $loc ) { $context = $loc . "\n\n" . $context; }
		$theme     = TNC_Themes::for_prospect( $prospect );
		$system    = TNC_Compliance::system_prompt( $prospect, $context, $theme );

		$result = TNC_Anthropic::complete( $system, $messages, array( 'max_tokens' => 500, 'temperature' => 0.4 ) );
		if ( is_wp_error( $result ) ) {
			$code = 'tnc_no_key' === $result->get_error_code() ? 503 : 502;
			return new WP_Error( $result->get_error_code(), $result->get_error_message(), array( 'status' => $code ) );
		}

		// MARKDOWN GUARD: visitors must never see raw markdown tokens, even if
		// the model slips. Bold/italic unwrapped, stray tokens stripped.
		$clean = preg_replace( '/\*\*(.+?)\*\*/s', '$1', (string) $result['text'] );
		$clean = preg_replace( '/(?<![\w*])\*([^*\n]+)\*(?![\w*])/', '$1', $clean );
		$clean = str_replace( array( '**', '`', '###', '##' ), '', $clean );
		$result['text'] = trim( $clean );

		TNC_Prospects::log_usage( $prospect['id'], $session, 'chat', $result['model'], $result['input_tokens'], $result['output_tokens'] );

		// Learning Engine substrate: flag likely knowledge gaps for the Phase 3 gaps queue.
		$gap = (bool) preg_match(
			'/(don\'?t have that (information|detail)|i\'?m not sure|i don\'?t know|couldn\'?t find|the team can (follow up|confirm)|don\'?t have specific)/i',
			$result['text']
		);
		TNC_Prospects::log_exchange( $prospect['id'], $session, $last_user, $result['text'], ! $gap, $gap ? 'low' : 'high' );

		// Mark engagement.
		if ( in_array( $prospect['status'], array( 'demo_created', 'demo_sent' ), true ) ) {
			TNC_Prospects::update( $prospect['id'], array( 'status' => 'engaged' ) );
		}

		// LEAD INTENT: the moment the visitor shares contact info in chat, package the lead.
		self::maybe_capture_chat_lead( $prospect, $session, $messages );

		return rest_ensure_response( array( 'reply' => $result['text'] ) );
	}

	/**
	 * COST GUARD: the demo key must never be exposed to runaway cost.
	 * Layered BEFORE the AI call: per-session daily cap (bot/abuse), per-demo
	 * daily cap, and a platform-wide daily ceiling that pauses chat + alerts
	 * once. All limits configurable; degrade is always graceful (friendly
	 * message steering to the lead form — never a raw error, never a dead end).
	 */
	/**
	 * Verbatim LOCATION & CONTACT facts for the assistant — built from the
	 * prospect's real data (poi.db city/state, deep-crawl street address & hours,
	 * phone, site). Guarantees the chat can answer "where are you located / your
	 * address / hours / phone" accurately. $0, no AI, no invention.
	 */
	private static function location_facts( $prospect ) {
		$cd = is_array( $prospect['crawl_data'] ) ? $prospect['crawl_data'] : array();
		$kb = isset( $cd['kb'] ) && is_array( $cd['kb'] ) ? $cd['kb'] : array();
		$company = $prospect['company_name'] ? $prospect['company_name'] : 'This business';
		$lines = array();
		$cityst = trim( (string) ( $prospect['city'] ?? '' ) );
		$st     = trim( (string) ( $prospect['state_abbr'] ?? '' ) );
		if ( $cityst && $st ) { $lines[] = '- City/State: ' . $cityst . ', ' . $st; }
		elseif ( $cityst ) { $lines[] = '- City: ' . $cityst; }
		elseif ( $st ) { $lines[] = '- State: ' . $st; }
		if ( ! empty( $kb['address'] ) ) { $lines[] = '- Street address: ' . sanitize_text_field( $kb['address'] ); }
		if ( ! empty( $kb['hours'] ) )   { $lines[] = '- Hours: ' . sanitize_text_field( $kb['hours'] ); }
		if ( ! empty( $prospect['contact_phone'] ) ) { $lines[] = '- Phone: ' . sanitize_text_field( $prospect['contact_phone'] ); }
		if ( ! empty( $prospect['website_url'] ) ) { $lines[] = '- Website: ' . preg_replace( '#^https?://#', '', untrailingslashit( $prospect['website_url'] ) ); }
		if ( empty( $lines ) ) { return ''; }
		return 'LOCATION & CONTACT (verified facts about ' . $company . ' — answer any location/address/hours/phone question ONLY from these, verbatim):' . "\n" . implode( "\n", $lines );
	}

	private static function cost_guard( $prospect, $session ) {
		$day      = gmdate( 'Ymd' );
		$friendly = 'Our assistant has been very busy today! Leave your details in the form below and the team will follow up with you personally.';

		// 1) Per-session cap (bot/abuse: one visitor cannot loop the AI all day).
		$sk = 'tnc_cg_s_' . md5( $session ) . '_' . $day;
		$sc = (int) get_transient( $sk );
		if ( $sc >= max( 5, (int) TNC_Settings::get( 'chat_session_cap', 40 ) ) ) {
			return new WP_Error( 'tnc_cap_session', $friendly, array( 'status' => 429 ) );
		}
		set_transient( $sk, $sc + 1, DAY_IN_SECONDS );

		// 2) Per-demo daily cap.
		$dk = 'tnc_cg_d_' . (int) $prospect['id'] . '_' . $day;
		$dc = (int) get_transient( $dk );
		if ( $dc >= max( 10, (int) TNC_Settings::get( 'chat_daily_per_demo', 150 ) ) ) {
			return new WP_Error( 'tnc_cap_demo', $friendly, array( 'status' => 429 ) );
		}
		set_transient( $dk, $dc + 1, DAY_IN_SECONDS );

		// 3) Global daily ceiling — pause everything + alert ONCE per day.
		$gk = 'tnc_cg_g_' . $day;
		$gc = (int) get_transient( $gk );
		$gl = max( 20, (int) TNC_Settings::get( 'chat_daily_global', 800 ) );
		if ( $gc >= $gl ) {
			if ( ! get_transient( 'tnc_cg_alerted_' . $day ) ) {
				set_transient( 'tnc_cg_alerted_' . $day, 1, DAY_IN_SECONDS );
				$to = TNC_Settings::recipients( 'system' );
				if ( $to ) {
					wp_mail( $to, '[TuaniChat] Global daily chat ceiling reached (' . $gl . ' messages): chat paused until midnight UTC', "The platform-wide daily chat ceiling was reached, so demo chat is paused to protect your API spend.\n\nRaise the ceiling in TuaniChat → Settings (Chat daily global cap) if this was legitimate traffic, or investigate for abuse if not.\n\nLead capture forms remain fully active on every demo." );
				}
			}
			return new WP_Error( 'tnc_cap_global', $friendly, array( 'status' => 429 ) );
		}
		set_transient( $gk, $gc + 1, DAY_IN_SECONDS );

		return true;
	}

	/**
	 * Detect contact details shared inside the conversation and fire the
	 * packaged-lead email immediately (once per session).
	 */
	private static function maybe_capture_chat_lead( $prospect, $session, $messages ) {
		$skey = 'tnc_chatlead_' . md5( $session );
		if ( get_transient( $skey ) ) {
			return;
		}
		$user_text = '';
		foreach ( $messages as $m ) {
			if ( 'user' === $m['role'] ) {
				$user_text .= ' ' . $m['content'];
			}
		}
		$email = '';
		$phone = '';
		if ( preg_match( '/[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}/i', $user_text, $em ) ) {
			$email = sanitize_email( $em[0] );
		}
		if ( preg_match( '/(\+?\d[\d\s().\-]{7,}\d)/', $user_text, $ph ) ) {
			$digits = preg_replace( '/\D/', '', $ph[1] );
			if ( strlen( $digits ) >= 9 && strlen( $digits ) <= 15 ) {
				$phone = sanitize_text_field( trim( $ph[1] ) );
			}
		}
		if ( '' === $email && '' === $phone ) {
			return; // not enough to package yet.
		}
		$name = '';
		if ( preg_match( '/(?:my name is|i\'?m|this is)\s+([A-Z][a-zA-Z\'\-]+(?:\s+[A-Z][a-zA-Z\'\-]+)?)/', $user_text, $nm ) ) {
			$name = sanitize_text_field( $nm[1] );
		}
		$need = mb_substr( sanitize_textarea_field( trim( $user_text ) ), 0, 600 );
		TNC_Prospects::add_lead( $prospect['id'], $name, $email, $phone, 'Captured in chat: ' . $need );
		set_transient( $skey, 1, DAY_IN_SECONDS );

		$to = TNC_Settings::recipients( 'leads' );
		if ( $to ) {
			$html = TNC_Emails::lead_notification( $prospect, array(
				'name'    => $name,
				'email'   => $email,
				'phone'   => $phone,
				'message' => 'Shared during the chat conversation (transcript below).',
			) );
			TNC_Emails::send( $to, 'New lead (chat): ' . $prospect['company_name'] . ( $name ? ': ' . $name : '' ), $html );
		}
	}

	public static function handle_lead( $request ) {
		$slug     = sanitize_text_field( (string) $request->get_param( 'slug' ) );
		$prospect = TNC_Prospects::get_by_slug( $slug );
		if ( ! $prospect ) {
			return new WP_Error( 'tnc_404', 'Demo not found.', array( 'status' => 404 ) );
		}

		$name    = sanitize_text_field( (string) $request->get_param( 'name' ) );
		$email   = sanitize_email( (string) $request->get_param( 'email' ) );
		$phone   = sanitize_text_field( (string) $request->get_param( 'phone' ) );
		$message = sanitize_textarea_field( (string) $request->get_param( 'message' ) );

		if ( '' === $name && '' === $email && '' === $phone ) {
			return new WP_Error( 'tnc_bad', 'Please provide a name and a way to contact you.', array( 'status' => 400 ) );
		}

		$lead_id = TNC_Prospects::add_lead( $prospect['id'], $name, $email, $phone, $message );

		// Packaged lead notification — branded HTML (the product's payoff email).
		$to = TNC_Settings::recipients( 'leads' );
		if ( $to ) {
			$html = TNC_Emails::lead_notification( $prospect, array(
				'name'    => $name,
				'email'   => $email,
				'phone'   => $phone,
				'message' => $message,
			) );
			TNC_Emails::send( $to, 'New lead: ' . $prospect['company_name'] . ( $name ? ': ' . $name : '' ), $html );
		}

		return rest_ensure_response( array( 'ok' => true, 'lead_id' => $lead_id ) );
	}
}
