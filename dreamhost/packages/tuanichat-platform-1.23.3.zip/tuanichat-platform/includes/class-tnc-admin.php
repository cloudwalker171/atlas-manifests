<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Admin menu, asset loading, page shells. The UI itself is rendered by tnc-admin.js.
 */
class TNC_Admin {

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
	}

	public static function menu() {
		$icon = 'data:image/svg+xml;base64,' . base64_encode( '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="#a7aaad"><path d="M12 2C6.48 2 2 5.94 2 10.8c0 2.78 1.46 5.26 3.74 6.87-.14 1.1-.61 2.62-1.74 3.83 2.22-.18 3.94-1.06 5.06-1.93.95.22 1.94.33 2.94.33 5.52 0 10-3.94 10-8.8S17.52 2 12 2zm-4.5 9.9c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zm4.5 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zm4.5 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5z"/></svg>' );

		add_menu_page( 'TuaniChat', 'TuaniChat', 'manage_options', 'tnc-dashboard', array( __CLASS__, 'render_page' ), $icon, 26 );
		add_submenu_page( 'tnc-dashboard', 'Dashboard', 'Dashboard', 'manage_options', 'tnc-dashboard', array( __CLASS__, 'render_page' ) );
		add_submenu_page( 'tnc-dashboard', 'Prospects', 'Prospects', 'manage_options', 'tnc-prospects', array( __CLASS__, 'render_page' ) );
		add_submenu_page( 'tnc-dashboard', 'Bulk Import', 'Bulk Import', 'manage_options', 'tnc-bulk', array( __CLASS__, 'render_page' ) );
		add_submenu_page( 'tnc-dashboard', 'Workers', 'Workers', 'manage_options', 'tnc-workers', array( __CLASS__, 'render_workers' ) );
		add_submenu_page( 'tnc-dashboard', 'Lead Hunter', 'Lead Hunter', 'manage_options', 'tnc-leadhunter', array( __CLASS__, 'render_leadhunter' ) );
		add_submenu_page( 'tnc-dashboard', 'Settings', 'Settings', 'manage_options', 'tnc-settings', array( __CLASS__, 'render_page' ) );
	}

	private static function is_tnc_screen() {
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
		return in_array( $page, array( 'tnc-dashboard', 'tnc-prospects', 'tnc-bulk', 'tnc-settings' ), true );
	}

	public static function assets( $hook ) {
		if ( ! self::is_tnc_screen() ) {
			return;
		}
		wp_enqueue_style( 'tnc-inter', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap', array(), null );
		wp_enqueue_style( 'tnc-admin', TNC_PLUGIN_URL . 'admin/css/tnc-admin.css', array(), TNC_VERSION );
		wp_enqueue_script( 'tnc-admin', TNC_PLUGIN_URL . 'admin/js/tnc-admin.js', array(), TNC_VERSION, true );

		$page     = sanitize_key( wp_unslash( $_GET['page'] ) );
		$settings = TNC_Settings::all();
		unset( $settings['api_key'] ); // never ship the key to the browser.

		wp_localize_script( 'tnc-admin', 'tncAdmin', array(
			'rest'       => esc_url_raw( rest_url( TNC_REST_NS ) ),
			'nonce'      => wp_create_nonce( 'wp_rest' ),
			'page'       => $page,
			'homeUrl'    => home_url( '/' ),
			'industries' => TNC_Settings::industries(),
			'statuses'   => TNC_Settings::statuses(),
			'settings'   => $settings,
			'maskedKey'  => TNC_Settings::masked_key(),
			'heartbeatUrl' => TNC_Workers::heartbeat_url(),
			'counts'     => TNC_Prospects::counts(),
			'leads'      => TNC_Prospects::recent_leads( 8 ),
			'prospect'   => isset( $_GET['prospect'] ) ? (int) $_GET['prospect'] : 0,
			'batch'      => isset( $_GET['batch'] ) ? sanitize_key( wp_unslash( $_GET['batch'] ) ) : '',
		) );

		// Kill admin notices on our screens for the full-bleed look.
		remove_all_actions( 'admin_notices' );
		remove_all_actions( 'all_admin_notices' );
	}

	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Insufficient permissions.', 'tuanichat' ) );
		}
		echo '<div class="tnc-app" id="tnc-app"><div class="tnc-boot">Loading TuaniChat...</div></div>';
	}

	/** LEAD HUNTER — command center: hero stats + target ring + staging table. */
	public static function render_leadhunter() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Insufficient permissions.', 'tuanichat' ) );
		}
		$cfg = wp_json_encode( array(
			'rest'       => esc_url_raw( rest_url( TNC_REST_NS ) ),
			'nonce'      => wp_create_nonce( 'wp_rest' ),
			'ajaxBase'   => admin_url( 'admin-ajax.php' ),
			'industries' => array( 'med_spa' => 'Med Spa', 'dental' => 'Dental', 'personal_injury' => 'Personal Injury Law', 'law_general' => 'Law Firm (General)', 'plastic_surgery' => 'Plastic Surgery', 'roofing' => 'Roofing', 'hvac' => 'HVAC' ),
		) );
		echo '<script>var TNC_LH = ' . $cfg . ';</script>';
		?>
<style>
#tncLH{--bg:#0E0F1A;--card:#161827;--card2:#1C1F33;--line:#262A45;--vio:#7C5CFC;--vio2:#A78BFA;--grn:#34D399;--amb:#FBBF24;--red:#FB7185;--tx:#EDEEF7;--mut:#8A8FB0;background:var(--bg);margin:20px 20px 20px 0;padding:26px;border-radius:18px;color:var(--tx);font-family:Inter,-apple-system,'Segoe UI',Roboto,sans-serif}
#tncLH *{box-sizing:border-box}
#tncLH h1{color:var(--tx);font-weight:800;font-size:22px;margin:0}
#tncLH .hd{display:flex;align-items:center;gap:14px;margin-bottom:20px}
#tncLH .pulse{width:10px;height:10px;border-radius:50%;background:var(--grn);box-shadow:0 0 0 0 rgba(52,211,153,.6);animation:lhp 2s infinite}
@keyframes lhp{0%{box-shadow:0 0 0 0 rgba(52,211,153,.55)}70%{box-shadow:0 0 0 11px rgba(52,211,153,0)}100%{box-shadow:0 0 0 0 rgba(52,211,153,0)}}
#tncLH .upd{margin-left:auto;font-size:12px;color:var(--mut)}
#tncLH .hero{display:grid;grid-template-columns:280px 1fr;gap:14px;margin-bottom:14px}
@media(max-width:1100px){#tncLH .hero{grid-template-columns:1fr}}
#tncLH .ringcard{background:linear-gradient(160deg,var(--card),var(--card2));border:1px solid var(--line);border-radius:16px;padding:20px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px}
#tncLH .ringwrap{position:relative;width:170px;height:170px}
#tncLH .ringwrap svg{transform:rotate(-90deg)}
#tncLH .ringnum{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center}
#tncLH .ringnum .big{font-size:30px;font-weight:800;line-height:1}
#tncLH .ringnum .sub{font-size:11px;color:var(--mut);margin-top:4px}
#tncLH .tgt{display:flex;gap:6px;align-items:center;font-size:12px;color:var(--mut)}
#tncLH .tgt input{width:90px;background:#10121f;color:var(--tx);border:1px solid var(--line);border-radius:8px;padding:5px 8px;font-size:12px}
#tncLH .tgt button{background:rgba(124,92,252,.18);border:1px solid var(--vio);color:var(--vio2);border-radius:8px;padding:5px 10px;font-size:11px;font-weight:700;cursor:pointer}
#tncLH .tiles{display:grid;grid-template-columns:repeat(auto-fit,minmax(132px,1fr));gap:10px}
#tncLH .tile{background:linear-gradient(160deg,var(--card),var(--card2));border:1px solid var(--line);border-radius:12px;padding:10px 13px;display:flex;flex-direction:column;justify-content:center;min-height:62px}
#tncLH .tile .k{font-size:9.5px;letter-spacing:1.2px;text-transform:uppercase;color:var(--mut);margin-bottom:3px}
#tncLH .tile .v{font-size:21px;font-weight:800;line-height:1.05}
#tncLH .tile .s{font-size:10px;color:var(--mut);margin-top:3px}
#tncLH .huntbar{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:13px 18px;margin-bottom:14px;display:flex;gap:14px;align-items:center;flex-wrap:wrap;font-size:13px}
#tncLH .huntbar .lbl{font-size:10.5px;letter-spacing:1.4px;text-transform:uppercase;color:var(--vio2);font-weight:700}

#tncLH .card,#tncLH .tile,#tncLH .ringcard,#tncLH .huntbar{position:relative;overflow:hidden;animation:lhPow .5s cubic-bezier(.2,.7,.2,1) both}
@keyframes lhPow{0%{opacity:0;transform:translateY(10px) scale(.99);filter:blur(2px)}100%{opacity:1;transform:none;filter:none}}
#tncLH .tiles .tile:nth-child(1){animation-delay:.06s}#tncLH .tiles .tile:nth-child(2){animation-delay:.12s}#tncLH .tiles .tile:nth-child(3){animation-delay:.18s}#tncLH .tiles .tile:nth-child(4){animation-delay:.24s}#tncLH .tiles .tile:nth-child(5){animation-delay:.30s}
#tncLH .card::after{content:'';position:absolute;left:0;right:0;top:0;height:1px;background:linear-gradient(90deg,transparent,rgba(167,139,250,.6),transparent);transform:translateX(-100%);animation:lhScan 7s linear infinite;opacity:.5;pointer-events:none}
@keyframes lhScan{0%{transform:translateX(-100%)}60%,100%{transform:translateX(100%)}}
#tncLH .tile{transition:transform .2s,box-shadow .25s}#tncLH .tile:hover{transform:translateY(-2px);box-shadow:0 6px 22px rgba(124,92,252,.22)}
#tncLH table tbody tr{transition:box-shadow .2s}#tncLH table tbody tr:hover{box-shadow:inset 2px 0 0 var(--vio2),inset 0 0 22px rgba(124,92,252,.07)}
#tncLH #lhLiveFeed,#tncLH #lhEngines{position:relative;overflow:hidden}
#tncLH #lhLiveFeed::before{content:'';position:absolute;inset:0;background:linear-gradient(90deg,transparent,rgba(52,211,153,.10),transparent);transform:translateX(-100%);animation:lhStream 4s linear infinite;pointer-events:none}
@keyframes lhStream{0%{transform:translateX(-100%)}100%{transform:translateX(100%)}}
@media (prefers-reduced-motion:reduce){#tncLH .card,#tncLH .tile,#tncLH .ringcard,#tncLH .huntbar,#tncLH .card::after,#tncLH #lhLiveFeed::before{animation:none!important}#tncLH .card::after{display:none}}

#tncLH .card{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:18px;margin-bottom:14px;max-width:none;min-width:0;box-shadow:none}
#tncLH ::-webkit-scrollbar{width:7px;height:7px}
#tncLH ::-webkit-scrollbar-track{background:transparent}
#tncLH ::-webkit-scrollbar-thumb{background:rgba(124,92,252,.45);border-radius:99px}
#tncLH ::-webkit-scrollbar-thumb:hover{background:rgba(124,92,252,.8)}
#tncLH .funnel{display:flex;gap:0;align-items:stretch;flex-wrap:wrap}
#tncLH .fstage{flex:1;min-width:110px;background:linear-gradient(160deg,var(--card),var(--card2));border:1px solid var(--line);border-radius:12px;padding:12px 14px;margin:4px;position:relative}
#tncLH .fstage .fn{font-size:22px;font-weight:800;line-height:1}
#tncLH .fstage .fl{font-size:10px;letter-spacing:1.2px;text-transform:uppercase;color:var(--mut);margin-top:5px}
#tncLH .fstage .farrow{position:absolute;right:-13px;top:50%;transform:translateY(-50%);color:var(--mut);font-size:16px;z-index:2}
#tncLH .qbar{display:flex;gap:10px;flex-wrap:wrap;align-items:center;font-size:13px}
#tncLH .qchip{padding:4px 12px;border-radius:99px;font-weight:700;font-size:12px}
#tncLH .scrollwrap{max-height:560px;overflow:auto;scrollbar-width:thin;scrollbar-color:rgba(124,92,252,.45) transparent}
#tncLH th{white-space:nowrap}
#tncLH td{white-space:nowrap}
#tncLH td:first-child{white-space:normal;min-width:200px}
#tncLH .card h2{color:var(--vio2);font-size:13px;letter-spacing:1.6px;text-transform:uppercase;margin:0 0 13px;font-weight:700}
#tncLH select,#tncLH input[type=text],#tncLH input[type=number]{background:#10121f;color:var(--tx);border:1px solid var(--line);border-radius:8px;padding:7px 10px;font-size:13px}
#tncLH button.go{background:linear-gradient(90deg,var(--vio),var(--vio2));border:none;color:#fff;font-weight:700;padding:9px 22px;border-radius:9px;cursor:pointer}
#tncLH button.exp{background:rgba(52,211,153,.15);border:1px solid var(--grn);color:var(--grn);font-weight:700;padding:7px 16px;border-radius:9px;cursor:pointer}
#tncLH table{width:100%;border-collapse:collapse;font-size:13px}
#tncLH th{color:var(--mut);text-transform:uppercase;font-size:10.5px;letter-spacing:1.2px;text-align:left;padding:8px 9px;border-bottom:1px solid var(--line);position:sticky;top:0;background:var(--card)}
#tncLH td{padding:8px 9px;border-bottom:1px solid var(--line)}
#tncLH .chip{display:inline-block;padding:2px 10px;border-radius:99px;font-size:11px;font-weight:700}
#tncLH .c-grn{background:rgba(52,211,153,.14);color:var(--grn)}
#tncLH .c-amb{background:rgba(251,191,36,.14);color:var(--amb)}
#tncLH .c-red{background:rgba(251,113,133,.14);color:var(--red)}
#tncLH .c-vio{background:rgba(124,92,252,.16);color:var(--vio2)}
#tncLH .mut{color:var(--mut)}
#tncLH .scorebar{display:inline-block;min-width:34px;text-align:center;border-radius:8px;font-weight:800;padding:3px 8px}
#tncLH .indchips{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px}
#tncLH .indchips .chip{cursor:pointer;border:1px solid transparent}
#tncLH .indchips .chip.on{border-color:var(--vio2)}
#tncLH .maphd{display:flex;align-items:center;gap:12px;margin-bottom:12px}
#tncLH .mapstat{font-size:12px;color:var(--mut)}
#tncLH .metricToggle{margin-left:auto;display:flex;border:1px solid var(--line);border-radius:9px;overflow:hidden}
#tncLH .mt{background:transparent;color:var(--mut);border:0;padding:6px 14px;font-size:12px;font-weight:700;cursor:pointer}
#tncLH .mt.on{background:rgba(124,92,252,.22);color:var(--vio2)}
#tncLH .mapfilters{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px}
#tncLH .mapfilters select{background:#10121f;color:var(--tx);border:1px solid var(--line);border-radius:8px;padding:6px 10px;font-size:12px}
#tncLH .mapgrid{display:grid;grid-template-columns:1fr 300px;gap:14px}
@media(max-width:1100px){#tncLH .mapgrid{grid-template-columns:1fr}}
#tncLH #lhMap{height:470px;border-radius:12px;border:1px solid var(--line);background:#0b0d18;z-index:0}
#tncLH .leaflet-tile-pane{filter:invert(1) hue-rotate(185deg) brightness(.78) contrast(.95) saturate(.9)}
#tncLH .leaflet-container{background:#0b0d18;font-family:inherit}
#tncLH .leaflet-control-attribution{background:rgba(10,12,24,.65)!important;color:#6a6f90!important}
#tncLH .leaflet-control-attribution a{color:#8a8fb0!important}
#tncLH .mapside{display:flex;flex-direction:column;gap:10px}
#tncLH .mst{background:linear-gradient(160deg,var(--card),var(--card2));border:1px solid var(--line);border-radius:12px;padding:12px 14px}
#tncLH .mst .k{font-size:10px;letter-spacing:1.2px;text-transform:uppercase;color:var(--mut)}
#tncLH .mst .v{font-size:22px;font-weight:800;margin-top:3px}
#tncLH .mst .s{font-size:11px;color:var(--mut);margin-top:3px}
#tncLH .toppanel{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:12px 14px}
#tncLH .toppanel .tt{font-size:10.5px;letter-spacing:1.2px;text-transform:uppercase;color:var(--vio2);font-weight:700;margin-bottom:8px}
#tncLH .toprow{display:flex;align-items:center;gap:8px;font-size:12.5px;padding:4px 0;cursor:pointer;border-bottom:1px solid rgba(255,255,255,.04)}
#tncLH .toprow:hover{color:var(--vio2)}
#tncLH .toprow .rk{color:var(--mut);width:18px}
#tncLH .toprow .nm{font-weight:700}
#tncLH .toprow .ct{margin-left:auto;color:var(--mut)}
#tncLH .toprow .qr{color:var(--grn);font-size:11px;width:46px;text-align:right}
#tncLH .freshlist{display:flex;flex-wrap:wrap;gap:6px}
#tncLH .freshlist span{background:rgba(251,191,36,.12);border:1px solid rgba(251,191,36,.4);color:var(--amb);border-radius:20px;padding:3px 10px;font-size:11px}
#tncLH .drill{margin-top:12px;background:var(--card2);border:1px solid var(--line);border-radius:12px;padding:14px;font-size:13px}

/* ===== J.A.R.V.I.S. V2 vibrant palette (official tokens) + live-viz layer ===== */
#tncLH{--vio:#9d8cff;--vio2:#b9a9ff;--grn:#56e39f;--amb:#f5b83d;--red:#ff5d6c;--cyan:#39d8f5;--teal:#4fe3c1}
#tncLH .tile{position:relative;overflow:hidden}
#tncLH .tile .viz{position:absolute;left:0;right:0;bottom:0;width:100%;height:34px;opacity:.9;pointer-events:none}
#tncLH .tile .v{position:relative;z-index:1;background:linear-gradient(90deg,#eaf6ff,#b9a9ff);-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;text-shadow:0 0 18px rgba(57,216,245,.0)}
#tncLH .tile .k{position:relative;z-index:1}#tncLH .tile .s{position:relative;z-index:1}
#tncLH .tile:hover{box-shadow:0 0 22px rgba(57,216,245,.22);border-color:rgba(57,216,245,.4)}
#tncLH .pulse{background:var(--cyan);box-shadow:0 0 0 0 rgba(57,216,245,.6)}
#tncLH .v.bump{animation:lhBump .55s ease-out}
@keyframes lhBump{0%{transform:scale(1.14);filter:drop-shadow(0 0 10px rgba(57,216,245,.8))}100%{transform:none}}
@media (prefers-reduced-motion:reduce){#tncLH .tile .viz{display:none}}

</style>
<div class="wrap" id="tncLH">
	<div class="hd"><span class="pulse"></span><h1>Lead Hunter &middot; Command Center</h1><span class="upd" id="lhUpd">connecting&hellip;</span></div>
	<div id="lhCore" class="huntbar" style="margin-bottom:14px"><span class="lbl">Core systems</span><span class="mut">loading&hellip;</span></div>

	<div class="hero">
		<div class="ringcard">
			<div class="ringwrap">
				<svg width="170" height="170" viewBox="0 0 170 170">
					<circle cx="85" cy="85" r="74" fill="none" stroke="#262A45" stroke-width="13"/>
					<circle id="lhRing" cx="85" cy="85" r="74" fill="none" stroke="url(#lhGrad)" stroke-width="13" stroke-linecap="round" stroke-dasharray="465" stroke-dashoffset="465"/>
					<defs><linearGradient id="lhGrad" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#7C5CFC"/><stop offset="1" stop-color="#A78BFA"/></linearGradient></defs>
				</svg>
				<div class="ringnum"><div class="big" id="lhProg">0</div><div class="sub" id="lhProgSub">of 1,000 today</div></div>
			</div>
			<div class="tgt">Daily target <input type="number" id="lhTarget" min="50" max="100000" step="50"> <button id="lhTargetSave" type="button">SET</button></div>
			<div class="tgt" style="margin-top:8px"><label style="display:flex;align-items:center;gap:6px;cursor:pointer"><input type="checkbox" id="lhAuto"> <strong id="lhAutoLbl">Always-on hunting</strong></label></div>
			<div class="tgt" style="flex-wrap:wrap;justify-content:center">Min score <input type="number" id="lhMinScore" min="0" max="100" step="5" style="width:60px"> <select id="lhRequire" style="background:#10121f;color:var(--tx);border:1px solid var(--line);border-radius:8px;padding:5px 8px;font-size:12px"><option value="email" selected>valid email (required)</option></select> <button id="lhCfgSave" type="button">SAVE</button></div>
		</div>
		<div class="tiles">
			<div class="tile"><canvas class="viz" data-viz="area" id="vzIn"></canvas><div class="k">In Hunter</div><div class="v" id="hIn">&ndash;</div><div class="s">inventory &mdash; drops on promote</div></div>
			<div class="tile"><canvas class="viz" data-viz="spark" id="vzPromo"></canvas><div class="k">Promoted &rarr; Prospects</div><div class="v" id="hPromo">&ndash;</div><div class="s">moved out, ready for outreach</div></div>
			<div class="tile"><canvas class="viz" data-viz="bars" id="vzTotal"></canvas><div class="k">Total discovered</div><div class="v" id="hTotal">&ndash;</div><div class="s">all-time (history retained)</div></div>
			<div class="tile"><canvas class="viz" data-viz="spark" id="vzQual"></canvas><div class="k">Qualified today</div><div class="v" id="hQual">&ndash;</div><div class="s">valid email + score (quality)</div></div>
			<div class="tile"><canvas class="viz" data-viz="ekg" id="vzMin"></canvas><div class="k">Per minute</div><div class="v" id="hMin">&ndash;</div><div class="s">10-min live window</div></div>
			<div class="tile"><canvas class="viz" data-viz="ekg" id="vzHour"></canvas><div class="k">Per hour</div><div class="v" id="hHour">&ndash;</div><div class="s">rolling 60 min</div></div>
			<div class="tile"><canvas class="viz" data-viz="radar" id="vzFleet"></canvas><div class="k">Fleet</div><div class="v" id="hFleet">&ndash;</div><div class="s" id="hFleetS">workers &middot; jobs</div></div>
			<div class="tile"><canvas class="viz" data-viz="ring" id="vzPass"></canvas><div class="k">Pass rate</div><div class="v" id="hPass">&ndash;</div><div class="s">staged / discovered</div></div>
			<div class="tile"><canvas class="viz" data-viz="ring" id="vzFill"></canvas><div class="k">Contact fill</div><div class="v" id="hFill">&ndash;</div><div class="s">enriched w/ email or phone</div></div>
		</div>
	</div>

	<div class="huntbar"><span class="lbl">Hunting now</span><span id="lhState" class="mut">No hunt yet.</span></div>
	<div class="card" id="lhEngines">
		<div class="maphd"><span class="lbl" style="font-size:10.5px;letter-spacing:1.4px;text-transform:uppercase;color:var(--vio2);font-weight:700">Engines &middot; Multi-Channel Command</span><span class="mapstat" id="lhEngStat">&hellip;</span></div>
		<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:12px">
			<div style="border:1px solid var(--line);border-radius:12px;padding:14px;background:linear-gradient(160deg,#161827,#1C1F33)">
				<div style="display:flex;align-items:center;gap:8px;margin-bottom:8px"><span id="engSslDot" style="width:8px;height:8px;border-radius:50%;background:#FB7185"></span><strong style="font-size:13px">REAL-TIME SSL RADAR</strong><span class="mut" style="margin-left:auto;font-size:11px" id="engSslMeta"></span></div>
				<div class="mut" style="font-size:11.5px;margin-bottom:8px">Brand-new businesses detected the moment their SSL goes live &rarr; fed into Lead Hunter.</div>
				<div id="engSslRows" style="font-size:12px"></div>
			</div>
			<div style="border:1px solid var(--line);border-radius:12px;padding:14px;background:linear-gradient(160deg,#161827,#1C1F33)">
				<div style="display:flex;align-items:center;gap:8px;margin-bottom:8px"><span id="engLiDot" style="width:8px;height:8px;border-radius:50%;background:#FB7185"></span><strong style="font-size:13px">SMART LINKEDIN</strong><span class="mut" style="margin-left:auto;font-size:11px" id="engLiMeta"></span></div>
				<div id="engLiBody" style="font-size:12px" class="mut">connecting&hellip;</div>
				<div style="margin-top:8px"><span class="chip c-amb" id="engLiGate">FAIL-CLOSED &middot; GO-LIVE OFF</span></div>
			</div>
			<div style="border:1px solid var(--line);border-radius:12px;padding:14px;background:linear-gradient(160deg,#161827,#1C1F33)">
				<div style="display:flex;align-items:center;gap:8px;margin-bottom:8px"><span id="engSmsDot" style="width:8px;height:8px;border-radius:50%;background:#FB7185"></span><strong style="font-size:13px">SMART TEXT / SMS</strong><span class="mut" style="margin-left:auto;font-size:11px" id="engSmsMeta"></span></div>
				<div id="engSmsBody" style="font-size:12px" class="mut">connecting&hellip;</div>
				<div style="margin-top:8px"><span class="chip c-amb" id="engSmsGate">FAIL-CLOSED &middot; GO-LIVE OFF</span></div>
			</div>
		</div>
	</div>
	<div class="card" style="margin-top:14px"><h2>Pipeline &amp; queue</h2><div id="lhFunnel" class="mut">loading&hellip;</div><div id="lhQueue" style="margin-top:10px"></div></div>

	<div class="card"><h2>Start a hunt</h2>
		<div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center">
			<select id="lhInd"></select>
			<input id="lhArea" type="text" placeholder="Target area (e.g. Beverly Hills, California)" style="min-width:300px">
			<select id="lhCap"><option>20</option><option selected>30</option><option>50</option></select>
			<button class="go" id="lhGo">HUNT</button>
			<span class="mut" id="lhMsg"></span>
		</div>
	</div>

	<div class="card"><h2>Staging table</h2>
		<div id="lhLiveFeed" style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin-bottom:10px;padding:9px 12px;border:1px solid var(--line);border-radius:10px;background:linear-gradient(90deg,rgba(124,92,252,.10),transparent)">
			<span class="lbl" style="font-size:10px;letter-spacing:1.2px;color:#34D399">&#9679; JUST DISCOVERED</span><span class="mut" style="font-size:12px">waiting for next find&hellip;</span>
		</div>
		<div class="indchips" id="lhIndCounts"></div>
		<div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin-bottom:12px">
			<select id="fInd"><option value="">All industries</option></select>
			<input id="fScore" type="number" placeholder="Min score" min="0" max="100" style="width:100px">
			<select id="fChat"><option value="">Chat: any</option><option value="absent">No chat (greenfield)</option><option value="present">Has chat</option></select>
			<label class="mut" style="font-size:12px"><input id="fEmail" type="checkbox"> has email</label>
			<input id="fSearch" type="text" placeholder="Search name / city / domain">
			<select id="fSince"><option value="">Added: any time</option><option value="1h">Last hour</option><option value="today">Today</option><option value="24h">Last 24h</option><option value="7d">Last 7 days</option></select>
			<select id="fSort"><option value="new" selected>Sort: Newest first</option><option value="">Sort: Score</option></select>
			<button class="exp" id="lhExp">EXPORT .XLSX (respects filters)</button>
		</div>
		<div class="scrollwrap"><table>
			<thead><tr><th>Company</th><th>Industry</th><th>Location</th><th>Score</th><th>Platform</th><th>Chat?</th><th>Site</th><th>Email</th><th>Phone</th><th>Status</th><th>Added</th></tr></thead>
			<tbody id="lhRows"><tr><td colspan="11" class="mut">loading&hellip;</td></tr></tbody>
		</table></div>
	</div>
	<div class="card" id="lhMixCard">
		<div class="maphd"><span class="lbl" style="font-size:10.5px;letter-spacing:1.4px;text-transform:uppercase;color:var(--vio2);font-weight:700">Demo Render Mix</span><span class="mapstat" id="lhMixStat">&hellip;</span><span id="lhMixGoal" style="margin-left:auto;font-size:12px"></span></div>
		<div id="lhMixBar" style="display:flex;height:26px;border-radius:8px;overflow:hidden;border:1px solid var(--line);background:#10121f;margin-bottom:10px"></div>
		<div style="display:flex;gap:18px;flex-wrap:wrap;font-size:12.5px">
			<span><i style="display:inline-block;width:11px;height:11px;border-radius:3px;background:#34D399;margin-right:6px;vertical-align:-1px"></i>Live iframe (PRIMARY): <strong id="lhMixIframe">&ndash;</strong></span>
			<span><i style="display:inline-block;width:11px;height:11px;border-radius:3px;background:#7C5CFC;margin-right:6px;vertical-align:-1px"></i>Screenshot (plan B): <strong id="lhMixShot">&ndash;</strong></span>
			<span><i style="display:inline-block;width:11px;height:11px;border-radius:3px;background:#FBBF24;margin-right:6px;vertical-align:-1px"></i>Mock (floor only): <strong id="lhMixMock">&ndash;</strong></span>
			<span class="mut" style="margin-left:auto" id="lhMixUp"></span>
		</div>
	</div>
	<div class="card" id="lhUpdCard">
		<div class="maphd"><span class="lbl" style="font-size:10.5px;letter-spacing:1.4px;text-transform:uppercase;color:var(--vio2);font-weight:700">Fleet Self-Update</span><span class="mapstat" id="lhUpdStat">&hellip;</span><span id="lhUpdBadge" style="margin-left:auto;font-size:12px"></span></div>
		<div class="mut" style="font-size:12px;margin-bottom:8px">Workers auto-poll the brain for new code, integrity-check it, apply it, health-check, and <strong>auto-roll-back</strong> a bad build. No manual SSH for code changes.</div>
		<div id="lhUpdLog" style="font-size:12px;font-family:ui-monospace,monospace"></div>
	</div>
	<div class="card" id="lhMapCard">
		<div class="maphd">
			<span class="lbl" style="font-size:10.5px;letter-spacing:1.4px;text-transform:uppercase;color:var(--vio2);font-weight:700">Live Hunting Heatmap</span>
			<span class="mapstat" id="lhMapStat">loading map&hellip;</span>
			<span class="metricToggle"><button id="lhMVol" class="mt on">Volume</button><button id="lhMQual" class="mt">Quality</button></span>
		</div>
		<div class="mapfilters">
			<select id="gInd"><option value="">All industries</option></select>
			<select id="gSrc"><option value="">All sources</option><option value="osm_local">Local map (poi.db)</option><option value="overpass">Overpass</option><option value="recovery">Recovery</option></select>
			<select id="gDate"><option value="all">All time</option><option value="today">Today</option><option value="7d">Last 7 days</option></select>
			<select id="gStatus"><option value="">Any status</option><option value="discovered">Discovered</option><option value="qualified">Qualified</option><option value="email_ready">Email-ready</option><option value="promoted">Promoted</option></select>
		</div>
		<div class="mapgrid">
			<div id="lhMap"></div>
			<div class="mapside">
				<div class="mst"><div class="k">Mapped leads</div><div class="v" id="lhMapped">&ndash;</div><div class="s" id="lhMappedS"></div></div>
				<div class="mst"><div class="k">Territory coverage</div><div class="v" id="lhCov">&ndash;</div><div class="s" id="lhCovs"></div></div>
				<div class="toppanel"><div class="tt" id="lhTopTitle">Richest hunting grounds</div><div id="lhTop"><div class="mut" style="font-size:12px;color:var(--mut)">&hellip;</div></div></div>
				<div class="toppanel"><div class="tt">Untapped territory (opportunity)</div><div id="lhFresh" class="freshlist"></div></div>
			</div>
		</div>
		<div id="lhDrill" class="drill" style="display:none"></div>
	</div>
</div>
<script>
(function(){
	function esc(s){var d=document.createElement('i');d.textContent=String(s==null?'':s);return d.innerHTML;}
	function fmt(n){return String(n==null?'–':n).replace(/\B(?=(\d{3})+(?!\d))/g,',');}
	var indSel=document.getElementById('lhInd'),fInd=document.getElementById('fInd');
	Object.keys(TNC_LH.industries).forEach(function(k){
		indSel.insertAdjacentHTML('beforeend','<option value="'+k+'">'+esc(TNC_LH.industries[k])+'</option>');
		fInd.insertAdjacentHTML('beforeend','<option value="'+k+'">'+esc(TNC_LH.industries[k])+'</option>');
	});
	function filters(){
		return 'industry='+encodeURIComponent(fInd.value)+'&min_score='+encodeURIComponent(document.getElementById('fScore').value||'')+'&chat='+encodeURIComponent(document.getElementById('fChat').value)+'&has_email='+(document.getElementById('fEmail').checked?'1':'')+'&search='+encodeURIComponent(document.getElementById('fSearch').value)+'&since='+encodeURIComponent(document.getElementById('fSince').value)+'&sort='+encodeURIComponent(document.getElementById('fSort').value);
	}
	function scoreCls(s){return s>=70?'c-grn':(s>=45?'c-amb':'c-vio');}
	var tgtDirty=false;
	document.getElementById('lhTarget').addEventListener('input',function(){tgtDirty=true;});
	document.getElementById('lhTargetSave').addEventListener('click',function(){
		var v=parseInt(document.getElementById('lhTarget').value,10)||1000;
		fetch(TNC_LH.rest+'/admin/lh-target',{method:'POST',credentials:'same-origin',headers:{'X-WP-Nonce':TNC_LH.nonce,'Content-Type':'application/json'},body:JSON.stringify({target:v})})
		.then(function(r){return r.json();}).then(function(){tgtDirty=false;refresh();});
	});
	function saveCfg(extra){var body=Object.assign({min_score:parseInt(document.getElementById('lhMinScore').value,10)||60,require:document.getElementById('lhRequire').value},extra||{});return fetch(TNC_LH.rest+'/admin/lh-settings',{method:'POST',credentials:'same-origin',headers:{'X-WP-Nonce':TNC_LH.nonce,'Content-Type':'application/json'},body:JSON.stringify(body)}).then(function(r){return r.json();}).then(function(){refresh();});}
	document.getElementById('lhCfgSave').addEventListener('click',function(){saveCfg();});
	document.getElementById('lhAuto').addEventListener('change',function(){saveCfg({auto:this.checked?1:0});});
	function refresh(){
		fetch(TNC_LH.rest+'/admin/lh-status',{credentials:'same-origin',headers:{'X-WP-Nonce':TNC_LH.nonce}}).then(function(r){return r.json();}).then(function(d){
			var s=d.state||{},k=d.stats||{};
			document.getElementById('hIn').textContent=fmt(k.in_hunter);
			document.getElementById('hPromo').textContent=fmt(k.promoted);
			document.getElementById('hTotal').textContent=fmt(k.discovered);
			(function(){var fn=k.funnel||{},q=k.queue||{};
				var stages=[['enriching','Enriching'],['discovered','Discovered'],['unqualified','Unqualified'],['awaiting','Awaiting promote'],['promoted','Promoted']];
				var fh='<div class="funnel">';stages.forEach(function(st,i){fh+='<div class="fstage"><div class="fn">'+fmt(fn[st[0]]||0)+'</div><div class="fl">'+st[1]+'</div>'+(i<stages.length-1?'<span class="farrow">&rsaquo;</span>':'')+'</div>';});fh+='</div>';
				document.getElementById('lhFunnel').innerHTML=fh;
				if(k.paused){document.getElementById('lhFunnel').innerHTML+='<div class="mut" style="margin-top:8px;color:var(--amb)">\u23f8 Promotion paused \u2014 qualified leads hold in "awaiting" until you resume.</div>';}
				var qcls=q.backlog?'c-red':(q.queued>0?'c-amb':'c-grn');
				document.getElementById('lhQueue').innerHTML='<div class="qbar"><strong>Fleet job queue:</strong> <span class="qchip '+qcls+'">'+fmt(q.queued||0)+' queued</span> <span class="qchip c-vio">'+fmt(q.running||0)+' in progress</span> <span class="qchip c-grn">'+fmt(q.done||0)+' done</span>'+((q.dead||0)?' <span class="qchip c-red">'+fmt(q.dead)+' dead</span>':'')+(q.backlog?' <span class="qchip c-red">&#9650; BACKLOG BUILDING &middot; ~'+q.eta_min+' min to drain</span>':(q.queued>0?' <span class="mut" style="font-size:12px">~'+q.eta_min+' min to drain</span>':' <span class="mut" style="font-size:12px">keeping up</span>'))+'</div>';
				var rm=k.render_mix||{}; if(rm.total!=null){
					var tt=rm.total||1, seg=function(n,c){var w=Math.round(100*(n||0)/tt); return w>0?'<div title="'+c.t+': '+(n||0)+'" style="width:'+w+'%;background:'+c.b+'"></div>':'';};
					document.getElementById('lhMixBar').innerHTML=seg(rm.iframe,{t:'Live iframe',b:'#34D399'})+seg(rm.screenshot,{t:'Screenshot',b:'#7C5CFC'})+seg(rm.mock,{t:'Mock',b:'#FBBF24'});
					document.getElementById('lhMixIframe').textContent=(rm.iframe||0);
					document.getElementById('lhMixShot').textContent=(rm.screenshot||0);
					document.getElementById('lhMixMock').textContent=(rm.mock||0)+' ('+(rm.mock_pct||0)+'%)';
					document.getElementById('lhMixStat').textContent=(rm.total||0)+' demos · '+(rm.real_pct||0)+'% real-site · '+(rm.iframe_pct||0)+'% live iframe (primary)';
					document.getElementById('lhMixGoal').innerHTML=(rm.on_target?'<span style="color:#34D399;font-weight:700">\u2714 on target</span>':'<span style="color:#FB7185;font-weight:700">below goal</span>')+' <span class="mut">(goal: real \u2265'+(rm.goal_real_pct||80)+'%, mock <'+(rm.goal_mock_pct||20)+'%)</span>';
					document.getElementById('lhMixUp').textContent=(rm.upgraded_this_hour||0)+' upgraded/hr · '+(rm.framable_yes||0)+' framable (live iframe) / '+(rm.framable_no||0)+' blocked\u2192screenshot / '+(rm.framable_unknown||0)+' unchecked';
				}
				(function(){var ul=k.update_log||[],fb=k.fleet_build||'?';
					document.getElementById('lhUpdStat').textContent='fleet build '+fb;
					var rb=ul.filter(function(e){return e.event==='rollback'||e.event==='integrity-fail';}).length;
					document.getElementById('lhUpdBadge').innerHTML=rb?'<span style="color:#FB7185;font-weight:700">\u26a0 '+rb+' rollback/fail</span>':'<span style="color:#34D399;font-weight:700">\u2714 stable</span>';
					if(!ul.length){document.getElementById('lhUpdLog').innerHTML='<span class="mut">No updates yet \u2014 self-updater will log here on the next code change.</span>';}
					else{var col={success:'#34D399',start:'#7C5CFC',rollback:'#FB7185','integrity-fail':'#FB7185'};
						document.getElementById('lhUpdLog').innerHTML=ul.map(function(e){var d=new Date((e.ts||0)*1000);var t=isNaN(d)?'':d.toLocaleString();return '<div style="padding:3px 0;border-bottom:1px solid var(--line)"><span style="color:'+(col[e.event]||'#9aa')+';font-weight:700">'+esc(e.event||'')+'</span> <span class="mut">'+esc(e.from||'?')+'\u2192'+esc(e.to||'?')+' · '+esc(e.node||'')+' · '+esc(t)+'</span></div>';}).join('');}
				})();
			})();
			document.getElementById('hQual').textContent=fmt(k.qual_today);
			(function(){var lp=k.loop||{},co=k.core||{};
				function dot(ok){return '<span style="display:inline-block;width:9px;height:9px;border-radius:50%;background:'+(ok?'var(--grn)':'var(--red)')+';box-shadow:0 0 7px '+(ok?'var(--grn)':'var(--red)')+';margin-right:5px"></span>';}
				var hunterOk=co.hunter==='hunting'&&lp.healthy;var stTxt={off:'OFF',target_met:'target met',active:'HUNTING',all_dupes:'hunting (area covered)',sparse:'hunting (sparse area)',throttled:'throttled — public map limit',error:'error',starting:'starting'}[lp.state]||lp.state;
				var age=lp.age==null?'—':(lp.age<90?lp.age+'s':Math.round(lp.age/60)+'m')+' ago';
				document.getElementById('lhCore').innerHTML='<span class="lbl">Core systems</span> '+dot(hunterOk)+'<strong>Lead Hunter:</strong> '+esc(stTxt)+' <span class="mut">(last hunt '+age+(lp.last_area?' · '+esc(lp.last_area):'')+(lp.last_found!=null?' · found '+lp.last_found+', staged '+lp.last_staged:'')+')</span> &nbsp;|&nbsp; '+dot(co.fleet>0)+'<strong>Fleet:</strong> '+esc(co.fleet)+' online &nbsp;|&nbsp; '+dot(true)+'<strong>Email:</strong> ready';
			})();
			var au=document.getElementById('lhAuto'); if(document.activeElement!==au){au.checked=!!k.auto;} document.getElementById('lhAutoLbl').textContent=k.auto?'Always-on hunting: ON':'Always-on hunting: OFF';
			var ms=document.getElementById('lhMinScore'); if(document.activeElement!==ms&&k.min_score!=null&&!ms.value){ms.value=k.min_score;} if(k.require){document.getElementById('lhRequire').value=k.require;}
			document.getElementById('hMin').textContent=k.per_min==null?'–':k.per_min;
			document.getElementById('hHour').textContent=fmt(k.per_hour);
			document.getElementById('hFleet').textContent=fmt(k.fleet_workers);
			document.getElementById('hFleetS').textContent=fmt(k.fleet_running)+' running · '+fmt(k.fleet_queued)+' queued';
			document.getElementById('hPass').textContent=k.pass_rate==null?'–':k.pass_rate+'%';
			document.getElementById('hFill').textContent=k.fill_rate==null?'–':k.fill_rate+'%';
			var tgt=k.target||1000,q=k.staged_today||0,pct=Math.min(100,Math.round(100*q/tgt));
			document.getElementById('lhProg').textContent=fmt(q);
			document.getElementById('lhProgSub').textContent=pct+'% of '+fmt(tgt)+" · today's haul";
			document.getElementById('lhRing').style.strokeDashoffset=String(465-465*Math.min(1,q/tgt));
			var ti=document.getElementById('lhTarget');
			if(!tgtDirty&&document.activeElement!==ti){ti.value=tgt;}
			var el=document.getElementById('lhState');
			if(!s.batch){el.textContent='No hunt yet.';}
			else{
				el.innerHTML='<span class="chip '+(s.hunting?'c-amb':'c-grn')+'">'+(s.hunting?'HUNTING':'IDLE · LAST')+'</span> &nbsp;'
				+esc((TNC_LH.industries[s.industry]||s.industry)+' · '+s.area)+' (tier '+esc(s.tier)+') &mdash; found <strong>'+esc(s.found)+'</strong> · staged <strong>'+esc(s.staged)+'</strong> · dupes <strong>'+esc(s.dupes)+'</strong> · enriched <strong>'+esc(s.enriched)+'</strong>/'+esc(s.staged)
				+(s.error?' <span class="chip c-red">'+esc(s.error)+'</span>':'');
			}
			window.__lhLast=Date.now();
		}).catch(function(){});
		fetch(TNC_LH.rest+'/admin/lh-list?'+filters(),{credentials:'same-origin',headers:{'X-WP-Nonce':TNC_LH.nonce}}).then(function(r){return r.json();}).then(function(d){
			var rows=d.rows||[],h='';
			rows.forEach(function(r){
				var chat=r.chat==='…'?'<span class="mut">…</span>':(r.chat==='none'?'<span class="chip c-grn">NO CHAT</span>':'<span class="chip c-amb">'+esc(r.chat)+'</span>');
				var site=r.site_ok===null?'<span class="mut">…</span>':(r.site_ok?'<span class="chip c-grn">LIVE</span>':'<span class="chip c-red">DOWN</span>');
				h+='<tr><td><strong>'+esc(r.company_name)+'</strong><div class="mut" style="font-size:11px">'+esc((r.website_url||'').replace(/^https?:\/\/(www\.)?/,''))+'</div></td>'
				+'<td>'+esc(TNC_LH.industries[r.industry]||r.industry)+'</td>'
				+'<td>'+esc(r.city+(r.state_abbr?', '+r.state_abbr:''))+'</td>'
				+'<td><span class="scorebar '+scoreCls(r.score)+'">'+esc(r.score)+'</span></td>'
				+'<td>'+esc(r.platform||'—')+'</td><td>'+chat+'</td><td>'+site+'</td>'
				+'<td>'+(r.contact_email?esc(r.contact_email):'<span class="mut">—</span>')+'</td>'
				+'<td>'+(r.contact_phone?esc(r.contact_phone):'<span class="mut">—</span>')+'</td>'
				+'<td><span class="chip c-vio">'+esc(r.status)+'</span></td>'
				+'<td class="lhAge mut" data-ts="'+esc(r.created_at||'')+'" title="'+esc(r.created_at||'')+' UTC" style="white-space:nowrap;font-size:11.5px">&hellip;</td></tr>';
			});
			document.getElementById('lhRows').innerHTML=h||'<tr><td colspan="11" class="mut">No staged leads match the filters.</td></tr>';
			var bi=d.by_industry||[],ch='';
			bi.forEach(function(b){ch+='<span class="chip c-vio'+(fInd.value===b.industry?' on':'')+'" data-ind="'+esc(b.industry)+'">'+esc(TNC_LH.industries[b.industry]||b.industry)+': '+esc(b.n)+'</span>';});
			var ic=document.getElementById('lhIndCounts');
			ic.innerHTML=ch;
			[].forEach.call(ic.querySelectorAll('.chip'),function(c){c.addEventListener('click',function(){fInd.value=fInd.value===c.dataset.ind?'':c.dataset.ind;refresh();});});
		}).catch(function(){});
	}
	document.getElementById('lhGo').addEventListener('click',function(){
		var msg=document.getElementById('lhMsg');msg.textContent='hunting…';
		fetch(TNC_LH.rest+'/admin/lh-hunt',{method:'POST',credentials:'same-origin',headers:{'X-WP-Nonce':TNC_LH.nonce,'Content-Type':'application/json'},body:JSON.stringify({industry:indSel.value,area:document.getElementById('lhArea').value,cap:document.getElementById('lhCap').value})})
		.then(function(r){return r.json();}).then(function(d){
			msg.textContent=d.ok?('found '+d.found+' · staged '+d.staged+' · dupes blocked '+d.dupes):(d.message||'failed');
			refresh();
		}).catch(function(e){msg.textContent='error: '+e;});
	});
	document.getElementById('lhExp').addEventListener('click',function(){
		window.location=TNC_LH.ajaxBase+'?action=tnc_lh_export&'+filters();
	});
	['fInd','fScore','fChat','fEmail','fSearch'].forEach(function(id){var n=document.getElementById(id);n.addEventListener('change',refresh);n.addEventListener('keyup',refresh);});
	// REAL-TIME TICKER (investor-grade): headline numbers update EVERY SECOND
	// from an ultra-cheap counters endpoint; the heavy deep refresh stays at 5s.
	function ago(d){var t=(Date.now()-d)/1000;if(t<5)return 'just now';if(t<60)return Math.floor(t)+'s ago';if(t<3600)return Math.floor(t/60)+' min ago';if(t<86400)return Math.floor(t/3600)+' hr'+(t<7200?'':'s')+' ago';return Math.floor(t/86400)+' d ago';}
	function tickAges(){document.querySelectorAll('.lhAge').forEach(function(td){var v=td.getAttribute('data-ts');if(!v)return;var d=Date.parse(v.replace(' ','T')+'Z');if(!isNaN(d))td.textContent=ago(d);});}
	function setN(id,v){var el=document.getElementById(id);if(el&&el.textContent!==String(fmt(v))){el.textContent=fmt(v);el.classList.remove('bump');void el.offsetWidth;el.classList.add('bump');}}
	/* ===== LIVE-VIZ LIBRARY (varied, vibrant, GPU-light canvas) ===== */
	var VZ={cyan:'#39d8f5',teal:'#4fe3c1',vio:'#9d8cff',grn:'#56e39f',amb:'#f5b83d'};
	var vzPhase=0; setInterval(function(){vzPhase+=0.08;},40);
	function vzCtx(id){var c=document.getElementById(id);if(!c)return null;var dpr=Math.min(2,window.devicePixelRatio||1);var w=c.clientWidth||160,h=c.clientHeight||34;if(c.width!==w*dpr){c.width=w*dpr;c.height=h*dpr;}var x=c.getContext('2d');x.setTransform(dpr,0,0,dpr,0,0);x.clearRect(0,0,w,h);return {x:x,w:w,h:h};}
	function grad(x,w,a,b){var g=x.createLinearGradient(0,0,w,0);g.addColorStop(0,a);g.addColorStop(1,b);return g;}
	function vzSpark(id,series,col){var o=vzCtx(id);if(!o)return;var x=o.x,w=o.w,h=o.h;var d=(series&&series.length?series:[0]);var mx=Math.max.apply(null,d)||1;var n=d.length;
		x.beginPath();for(var i=0;i<n;i++){var px=n>1?i/(n-1)*w:0,py=h-4-(d[i]/mx)*(h-8);i?x.lineTo(px,py):x.moveTo(px,py);}
		x.strokeStyle=col||VZ.teal;x.lineWidth=2;x.shadowColor=col||VZ.teal;x.shadowBlur=8;x.stroke();
		x.lineTo(w,h);x.lineTo(0,h);x.closePath();x.shadowBlur=0;var g=x.createLinearGradient(0,0,0,h);g.addColorStop(0,(col||VZ.teal)+'55');g.addColorStop(1,'transparent');x.fillStyle=g;x.fill();}
	function vzArea(id,series){vzSpark(id,series,VZ.vio);}
	function vzBars(id,series){var o=vzCtx(id);if(!o)return;var x=o.x,w=o.w,h=o.h;var d=(series&&series.length?series:[0]);var mx=Math.max.apply(null,d)||1;var n=Math.min(d.length,24);var bw=w/n;
		for(var i=0;i<n;i++){var bh=(d[i]/mx)*(h-6)+2;x.fillStyle=grad(x,w,VZ.cyan,VZ.vio);x.shadowColor=VZ.cyan;x.shadowBlur=6;x.fillRect(i*bw+1,h-bh,bw-2,bh);}x.shadowBlur=0;}
	function vzEkg(id){var o=vzCtx(id);if(!o)return;var x=o.x,w=o.w,h=o.h,mid=h/2;x.beginPath();x.moveTo(0,mid);
		for(var px=0;px<w;px++){var t=px/w*6.28*2 - vzPhase*2;var sp=Math.exp(-Math.pow(((px/w*4)%1-0.5)*6,2));var y=mid - Math.sin(t)*2 - sp*(h*0.42)*Math.sin(vzPhase*3+px);x.lineTo(px,y);}
		x.strokeStyle=VZ.grn;x.lineWidth=1.6;x.shadowColor=VZ.grn;x.shadowBlur=7;x.stroke();x.shadowBlur=0;}
	function vzRing(id,pct){var o=vzCtx(id);if(!o)return;var x=o.x,w=o.w,h=o.h;var cx=w-18,cy=h/2,r=12;pct=Math.max(0,Math.min(100,pct||0));
		x.beginPath();x.arc(cx,cy,r,0,6.28);x.strokeStyle='rgba(255,255,255,.08)';x.lineWidth=3;x.stroke();
		x.beginPath();x.arc(cx,cy,r,-1.57,-1.57+6.28*pct/100);x.strokeStyle=VZ.cyan;x.lineWidth=3;x.lineCap='round';x.shadowColor=VZ.cyan;x.shadowBlur=8;x.stroke();x.shadowBlur=0;}
	function vzRadar(id,on){var o=vzCtx(id);if(!o)return;var x=o.x,w=o.w,h=o.h;var cx=w-18,cy=h/2,r=13;
		x.beginPath();x.arc(cx,cy,r,0,6.28);x.strokeStyle='rgba(57,216,245,.18)';x.lineWidth=1;x.stroke();
		var a=vzPhase*1.5;x.beginPath();x.moveTo(cx,cy);x.arc(cx,cy,r,a,a+0.5);x.closePath();var g=x.createRadialGradient(cx,cy,0,cx,cy,r);g.addColorStop(0,(on?VZ.grn:VZ.amb)+'aa');g.addColorStop(1,'transparent');x.fillStyle=g;x.fill();}
	function drawViz(d){
		var sp=(d&&d.spark)||[];
		vzArea('vzIn',sp); vzSpark('vzPromo',sp,VZ.teal); vzBars('vzTotal',sp); vzSpark('vzQual',sp,VZ.grn);
		vzEkg('vzMin'); vzEkg('vzHour'); vzRadar('vzFleet',true);
		var p=(d&&d.p)||{}; var pass=p.total?Math.round(100*(p.staged_today||0)/Math.max(1,p.total)):0;
		vzRing('vzPass',pass); vzRing('vzFill',100);
	}
	setInterval(function(){drawViz(window.__lhTick||{});},90);

	function ticker(){
		fetch(TNC_LH.rest+'/admin/lh-ticker',{credentials:'same-origin',headers:{'X-WP-Nonce':TNC_LH.nonce}}).then(function(r){return r.json();}).then(function(d){
			if(!d||!d.ok)return;window.__lhTick=d;var p=d.p||{},q=d.q||{},m=d.mix||{};
			setN('hIn',p.in_hunter);setN('hPromo',p.promoted);setN('hTotal',p.total);setN('hQual',p.qual_today);setN('lhProg',p.staged_today);
			setN('lhMixIframe',m.iframe);setN('lhMixShot',m.screenshot);
			var mk=document.getElementById('lhMixMock');if(mk){var tt=(m.iframe+m.screenshot+m.mock)||1;mk.textContent=m.mock+' ('+Math.round(100*m.mock/tt)+'%)';}
			window.__lhLast=Date.now();
			if(d.latest&&d.latest.length){
				var lf=document.getElementById('lhLiveFeed');var newest=parseInt(d.latest[0].id,10);
				var html='<span class="lbl" style="font-size:10px;letter-spacing:1.2px;color:#34D399">&#9679; JUST DISCOVERED</span>';
				d.latest.forEach(function(r){var dt=Date.parse(String(r.created_at).replace(' ','T')+'Z');
					html+='<span style="font-size:12px;padding:3px 9px;border:1px solid var(--line);border-radius:999px;background:#10121f">'+esc(r.company_name||'')+' <span class="mut">'+esc(r.city||'')+' &middot; '+(isNaN(dt)?'':ago(dt))+'</span></span>';});
				if(window.__lfMax&&newest>window.__lfMax){lf.style.boxShadow='0 0 18px rgba(52,211,153,.45)';setTimeout(function(){lf.style.boxShadow='none';},900);}
				window.__lfMax=newest;lf.innerHTML=html;
			}
			if(d.engines){var E=d.engines;
				var sd=document.getElementById('engSslDot');if(sd){sd.style.background=E.ssl.live?'#34D399':'#FB7185';sd.style.boxShadow=E.ssl.live?'0 0 8px #34D399':'none';}
				var sm=document.getElementById('engSslMeta');if(sm){sm.textContent=E.ssl.live?'LIVE · streaming':'feed offline — daemon not reporting';}
				var sr=document.getElementById('engSslRows');if(sr){sr.innerHTML=(E.ssl.rows&&E.ssl.rows.length)?E.ssl.rows.map(function(r){var dt=Date.parse(String(r.created_at).replace(' ','T')+'Z');return '<div style="padding:3px 0;border-bottom:1px solid var(--line)">'+esc(r.company_name||r.website_url||'')+' <span class="mut">'+(isNaN(dt)?'':ago(dt))+'</span></div>';}).join(''):'<span class="mut">No SSL detections yet ('+(E.ssl.total||0)+' total). Feed activates when the ct-hunter daemon reports.</span>';}
				function eng(p,dot,meta,body,gate){var e=E[p];if(!e)return;var on=e.status==='active'||e.status==='ready';
					var d2=document.getElementById(dot);if(d2){d2.style.background=on?'#34D399':'#FB7185';}
					var m2=document.getElementById(meta);if(m2){m2.textContent=e.status;}
					var b2=document.getElementById(body);if(b2){b2.innerHTML=(e.status==='not-connected')?'<span class="mut">'+esc(e.note||'')+' — card auto-activates when the engine connects.</span>':('Queue: <strong>'+(e.queue||0)+'</strong> · Sent today: <strong>'+(e.sent_today||0)+'</strong>'+(e.note?' <span class="mut">· '+esc(e.note)+'</span>':''));}
					var g2=document.getElementById(gate);if(g2){if(e.golive){g2.className='chip c-grn';g2.textContent='LIVE · sending enabled';}else{g2.className='chip c-amb';g2.textContent='FAIL-CLOSED · GO-LIVE OFF';}}}
				eng('li','engLiDot','engLiMeta','engLiBody','engLiGate');
				eng('sms','engSmsDot','engSmsMeta','engSmsBody','engSmsGate');
				var es=document.getElementById('lhEngStat');if(es){es.textContent=(E.ssl.live?'SSL live':'SSL offline')+' · LinkedIn '+(E.li.status)+' · SMS '+(E.sms.status);}
			}
		}).catch(function(){});
		tickAges();
	}
	setInterval(function(){if(window.__lhLast){document.getElementById('lhUpd').textContent='● LIVE · real-time (1s)';document.getElementById('lhUpd').style.color='#34D399';}},1000);
	setInterval(ticker,1000);ticker();
	setInterval(refresh,5000);refresh();
	document.getElementById('fSince').addEventListener('change',function(){refresh();});
	document.getElementById('fSort').addEventListener('change',function(){refresh();});
})();
</script>
<script>
(function(){
	var LEAF_CSS='https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.css';
	var LEAF_JS='https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.js';
	var HEAT_JS='https://cdnjs.cloudflare.com/ajax/libs/leaflet.heat/0.2.0/leaflet-heat.js';
	var map,heat,metric='volume',lastCells=[];
	function $(id){return document.getElementById(id);}
	function load(){
		var l=document.createElement('link');l.rel='stylesheet';l.href=LEAF_CSS;document.head.appendChild(l);
		var s1=document.createElement('script');s1.src=LEAF_JS;s1.onload=function(){
			var s2=document.createElement('script');s2.src=HEAT_JS;s2.onload=init;s2.onerror=fail;document.head.appendChild(s2);
		};s1.onerror=fail;document.head.appendChild(s1);
	}
	function fail(){$('lhMapStat').textContent='map library blocked — check network access';}
	function init(){
		try{
			map=L.map('lhMap',{worldCopyJump:true,zoomControl:true,attributionControl:true}).setView([39.5,-98.35],4);
			L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:12,attribution:'&copy; OpenStreetMap'}).addTo(map);
			heat=L.heatLayer([],{radius:24,blur:18,maxZoom:9,minOpacity:.25,max:1.0,gradient:{0.0:'#1b1040',0.3:'#4c2fb0',0.55:'#7C5CFC',0.78:'#A78BFA',1.0:'#34D399'}}).addTo(map);
			map.on('click',drill);
			// industries into filter
			var gi=$('gInd');Object.keys(TNC_LH.industries).forEach(function(k){gi.insertAdjacentHTML('beforeend','<option value="'+k+'">'+TNC_LH.industries[k]+'</option>');});
			['gInd','gSrc','gDate','gStatus'].forEach(function(id){$(id).addEventListener('change',pull);});
			$('lhMVol').addEventListener('click',function(){metric='volume';$('lhMVol').classList.add('on');$('lhMQual').classList.remove('on');$('lhTopTitle').textContent='Richest hunting grounds';pull();});
			$('lhMQual').addEventListener('click',function(){metric='quality';$('lhMQual').classList.add('on');$('lhMVol').classList.remove('on');$('lhTopTitle').textContent='Best-quality grounds (email-ready %)';pull();});
			pull();setInterval(pull,20000);
		}catch(e){$('lhMapStat').textContent='map init error';}
	}
	function qs(){return 'industry='+encodeURIComponent($('gInd').value)+'&source='+encodeURIComponent($('gSrc').value)+'&date='+encodeURIComponent($('gDate').value)+'&status='+encodeURIComponent($('gStatus').value)+'&metric='+metric;}
	function pull(){
		fetch(TNC_LH.rest+'/admin/lh-geo?'+qs(),{credentials:'same-origin',headers:{'X-WP-Nonce':TNC_LH.nonce}}).then(function(r){return r.json();}).then(render).catch(function(){$('lhMapStat').textContent='geo fetch failed';});
	}
	function render(d){
		if(!d||!d.ok){return;}
		lastCells=d.cells||[];
		var mx=d.max||1;var pts=lastCells.map(function(c){return [c.lat,c.lon,Math.max(.08,(c.i||0)/mx)];});
		if(heat){heat.setLatLngs(pts);}
		$('lhMapStat').textContent=(metric==='quality'?'quality view · ':'volume view · ')+lastCells.length+' active cells · live';
		$('lhMapped').textContent=(d.mapped||0).toLocaleString();
		$('lhMappedS').textContent=(d.total||0).toLocaleString()+' leads in filter';
		if(d.coverage){$('lhCov').textContent=d.coverage.pct+'%';$('lhCovs').textContent=d.coverage.hunted_tiles+' / '+d.coverage.total_tiles+' tiles hunted';}
		var top=(metric==='quality'?d.top_quality:d.top_volume)||[];var h='';
		top.forEach(function(t,i){h+='<div class="toprow" data-st="'+t.st+'"><span class="rk">'+(i+1)+'</span><span class="nm">'+t.st+'</span><span class="ct">'+t.n+' leads</span><span class="qr">'+t.qrate+'%</span></div>';});
		$('lhTop').innerHTML=h||'<div style="font-size:12px;color:var(--mut)">No leads in this filter yet.</div>';
		var fr=(d.coverage&&d.coverage.untapped)||[];$('lhFresh').innerHTML=fr.length?fr.map(function(a){return '<span>'+a.split(',')[0]+'</span>';}).join(''):'<span style="background:none;border:0;color:var(--mut)">All territories touched</span>';
	}
	function drill(e){
		if(!lastCells.length){return;}
		var la=e.latlng.lat,lo=e.latlng.lng,n=0,q=0,sc=0,cells=0;
		lastCells.forEach(function(c){if(Math.abs(c.lat-la)<=0.6&&Math.abs(c.lon-lo)<=0.6){n+=c.n;q+=c.q;sc+=(c.avg*c.n);cells++;}});
		var dd=$('lhDrill');
		if(!n){dd.style.display='none';return;}
		dd.style.display='block';
		dd.innerHTML='<strong>Area near '+la.toFixed(2)+', '+lo.toFixed(2)+'</strong> &mdash; <strong style="color:var(--vio2)">'+n+'</strong> leads in '+cells+' cells · <strong style="color:var(--grn)">'+q+'</strong> email-ready ('+(n?Math.round(100*q/n):0)+'%) · avg score '+(n?Math.round(sc/n):0)+'. <span style="color:var(--mut)">Click empty water to clear.</span>';
	}
	if(document.readyState!=='loading'){load();}else{document.addEventListener('DOMContentLoaded',load);}
})();
</script>
		<?php
	}

	/** WORKERS - single operational cockpit. Self-contained page, 5s live refresh. */
	public static function render_workers() {
		$cfg = wp_json_encode( array(
			'rest'     => esc_url_raw( rest_url( TNC_REST_NS ) ),
			'nonce'    => wp_create_nonce( 'wp_rest' ),
			'oneliner' => 'curl -fsSL -A "Mozilla/5.0" "' . admin_url( 'admin-ajax.php' ) . '?action=tnc_fleet&op=bootstrap&t=' . TNC_Fleet::token() . '" | base64 -d | bash',
			'fleetTok' => TNC_Fleet::token(),
			'backupTok' => TNC_Backup::token(),
			'ajaxBase' => admin_url( 'admin-ajax.php' ),
		) );
		echo '<script>var TNC_W = ' . $cfg . ';</script>';
		?>
<style>
#tncW{--bg:#0E0F1A;--card:#161827;--card2:#1C1F33;--line:#262A45;--vio:#7C5CFC;--vio2:#A78BFA;--grn:#34D399;--amb:#FBBF24;--red:#FB7185;--tx:#EDEEF7;--mut:#8A8FB0;background:var(--bg);margin:20px 20px 20px 0;padding:26px;border-radius:18px;color:var(--tx);font-family:Inter,-apple-system,'Segoe UI',Roboto,sans-serif}
#tncW *{box-sizing:border-box}
#tncW ::-webkit-scrollbar{width:8px;height:8px}
#tncW ::-webkit-scrollbar-track{background:transparent}
#tncW ::-webkit-scrollbar-thumb{background:rgba(124,92,252,.45);border-radius:99px}
#tncW ::-webkit-scrollbar-thumb:hover{background:rgba(124,92,252,.8)}
#tncW .hd{display:flex;align-items:center;gap:14px;margin-bottom:22px}
#tncW .hd h1{color:var(--tx);font-weight:800;font-size:22px;margin:0;padding:0}
#tncW .pulse{width:10px;height:10px;border-radius:50%;background:var(--grn);box-shadow:0 0 0 0 rgba(52,211,153,.6);animation:tncwp 2s infinite}
@keyframes tncwp{0%{box-shadow:0 0 0 0 rgba(52,211,153,.55)}70%{box-shadow:0 0 0 11px rgba(52,211,153,0)}100%{box-shadow:0 0 0 0 rgba(52,211,153,0)}}
#tncW .upd{margin-left:auto;font-size:12px;color:var(--mut)}
#tncW .tiles{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin-bottom:18px}
#tncW .tile{background:linear-gradient(160deg,var(--card),var(--card2));border:1px solid var(--line);border-radius:14px;padding:16px}
#tncW .tile .k{font-size:11px;letter-spacing:1.4px;text-transform:uppercase;color:var(--mut);margin-bottom:7px}
#tncW .tile .v{font-size:26px;font-weight:800;line-height:1}
#tncW .tile .s{font-size:11px;color:var(--mut);margin-top:6px}
#tncW .grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}
@media(max-width:1100px){#tncW .grid{grid-template-columns:1fr}}
#tncW .card{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:18px;margin-bottom:14px}
#tncW .card h2{color:var(--vio2);font-size:13px;letter-spacing:1.6px;text-transform:uppercase;margin:0 0 13px;font-weight:700}
#tncW .row{display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid var(--line);font-size:13px}
#tncW .row:last-child{border-bottom:none}
#tncW .chip{display:inline-block;padding:3px 11px;border-radius:99px;font-size:11px;font-weight:700;margin:2px 4px 2px 0}
#tncW .c-grn{background:rgba(52,211,153,.14);color:var(--grn)}
#tncW .c-amb{background:rgba(251,191,36,.14);color:var(--amb)}
#tncW .c-red{background:rgba(251,113,133,.14);color:var(--red)}
#tncW .c-vio{background:rgba(124,92,252,.16);color:var(--vio2)}
#tncW .bar{height:6px;background:var(--line);border-radius:99px;overflow:hidden;margin-top:6px}
#tncW .bar i{display:block;height:100%;background:linear-gradient(90deg,var(--vio),var(--vio2));border-radius:99px}
#tncW .log{max-height:190px;overflow-y:auto;font-size:12px}
#tncW .mut{color:var(--mut)}
#tncW .fleet{opacity:.45;filter:grayscale(.4);position:relative}
#tncW .fleet .lock{position:absolute;top:16px;right:18px;font-size:11px;color:var(--amb);letter-spacing:1px}

#tncW .tile,#tncW .card{position:relative;overflow:hidden;animation:wPow .5s cubic-bezier(.2,.7,.2,1) both}
@keyframes wPow{0%{opacity:0;transform:translateY(10px) scale(.99);filter:blur(2px)}100%{opacity:1;transform:none;filter:none}}
#tncW .tiles .tile:nth-child(1){animation-delay:.05s}#tncW .tiles .tile:nth-child(2){animation-delay:.10s}#tncW .tiles .tile:nth-child(3){animation-delay:.15s}#tncW .tiles .tile:nth-child(4){animation-delay:.20s}#tncW .tiles .tile:nth-child(5){animation-delay:.25s}#tncW .tiles .tile:nth-child(6){animation-delay:.30s}
#tncW .card::after{content:'';position:absolute;left:0;right:0;top:0;height:1px;background:linear-gradient(90deg,transparent,rgba(167,139,250,.6),transparent);transform:translateX(-100%);animation:wScan 8s linear infinite;opacity:.45;pointer-events:none}
@keyframes wScan{0%{transform:translateX(-100%)}60%,100%{transform:translateX(100%)}}
#tncW .tile{transition:transform .2s,box-shadow .25s}#tncW .tile:hover{transform:translateY(-2px);box-shadow:0 6px 22px rgba(124,92,252,.22)}
@media (prefers-reduced-motion:reduce){#tncW .tile,#tncW .card,#tncW .card::after{animation:none!important}#tncW .card::after{display:none}}

</style>
<div class="wrap" id="tncW">
	<div class="hd"><span class="pulse" id="wPulse"></span><h1>Workers &middot; Operational Cockpit</h1><span class="upd" id="wUpd">connecting&hellip;</span></div>
	<div class="tiles" id="wTiles"></div>
	<div class="grid">
		<div>
			<div class="card"><h2>Brain crawl lanes &middot; DreamHost</h2><div class="mut" style="font-size:11px;margin:-7px 0 9px">The brain&rsquo;s own crawl lanes (not the fleet). 0/3 active is normal when nothing is crawling.</div><div id="wBrain"></div></div>
			<div class="card"><h2>Self-heal / watchdog log</h2><div class="log" id="wHeal"></div></div>
			<div class="card" id="wFleetCard"><span class="lock" id="wFleetLock" style="position:absolute;top:16px;right:18px;font-size:11px;color:var(--amb);letter-spacing:1px">PENDING ACCESS</span><h2>FLEET &middot; InterServer workers</h2><div class="mut" style="font-size:11px;margin:-7px 0 9px">The remote worker fleet (separate from the brain&rsquo;s crawl lanes). Scales 40 &rarr; 100.</div><div id="wFleet">
				<div class="row"><span>Nodes online</span><strong>0</strong></div>
				<div class="row"><span>Daemons</span><span class="mut">offline &middot; run the bootstrap via SSH</span></div>
				<div class="row"><span>Hardware ready</span><span class="mut">20 GB RAM &middot; 5 cores &middot; prepaid to 2031</span></div>
				<div class="row"><span>Fleet connect token</span><code style="user-select:all;color:var(--vio2);font-size:11px;word-break:break-all"><?php echo esc_html( TNC_Fleet::token() ); ?></code></div>
				<div class="row" style="display:block"><span>One-line install (paste at the SSH prompt)</span><br><code id="tncOneLiner" style="user-select:all;color:var(--grn);font-size:11px;word-break:break-all;display:block;margin-top:6px;background:rgba(0,0,0,.3);padding:8px 10px;border-radius:8px"></code></div>
				<div class="row" style="display:block"><span>Scale fleet &middot; pick worker count</span> <select id="tncScaleN" style="background:#161827;color:var(--vio2);border:1px solid var(--line);border-radius:6px;padding:3px 8px;margin-left:6px"><option>12</option><option>24</option><option selected>40</option><option>60</option><option>80</option><option>100</option></select><code id="tncScaleCmd" style="user-select:all;color:var(--vio2);font-size:11px;word-break:break-all;display:block;margin-top:6px;background:rgba(0,0,0,.3);padding:8px 10px;border-radius:8px"></code><div class="mut" style="font-size:11px;margin-top:5px">Step up gradually: 40, watch the brain response time in the self-check, then 60 / 80 / 100. Re-running is additive (keeps the workers already running).</div></div>
			</div></div>
		</div>
		<div>
			<div class="card"><h2>Backups &middot; 3-2-1</h2><div id="wBackup"><div class="row"><span class="mut">loading&hellip;</span></div></div></div>
			<div class="card"><h2>Mail engine &middot; identities &amp; streams</h2><div id="wIdent"></div></div>
			<div class="card"><h2>Mail ledger &middot; last events</h2><div class="log" id="wMail"></div></div>
			<div class="card"><h2>Outreach inbox &middot; replies</h2><div id="wInbox"></div></div>
			<div class="card"><h2>Per-ISP throttles (msgs/hr)</h2><div id="wThr"></div></div>
		</div>
	</div>
</div>
<script>
(function(){
	function esc(s){var d=document.createElement('i');d.textContent=String(s==null?'':s);return d.innerHTML;}
	var last=0;
	function age(a){return a<90?['c-grn',a+'s']:(a<180?['c-amb',a+'s']:['c-red',a+'s']);}
	function tile(k,v,s,cls){return '<div class="tile"><div class="k">'+k+'</div><div class="v '+(cls||'')+'" style="'+(cls?'':'color:var(--tx)')+'">'+v+'</div><div class="s">'+(s||'')+'</div></div>';}
	function render(d){
		var w=d.workers||{},hb=Number(w.heartbeat_age||0),hbA=age(hb);
		var lanes=(w.lanes||[]),act=lanes.filter(function(l){return l.active}).length;
		document.getElementById('wTiles').innerHTML=
			tile('Heartbeat','<span class="chip '+hbA[0]+'" style="font-size:20px;padding:5px 14px">'+hbA[1]+'</span>','system cron, 1-min pulse')+
			tile('Brain crawl lanes',act+' / '+lanes.length,'DreamHost &middot; idle = nothing crawling (normal)')+
			(function(){
				/* FLEET TILE (its own tracker, never conflated with brain lanes).
				   NO-0-FLICKER: server keeps last-known lanes through stale (90-300s);
				   we additionally hold the last non-zero snapshot in JS so a single
				   odd poll can never paint a 0. */
				var fl=d.fleet||{}; var wt=Number(fl.workers_total||0);
				var anyNodes=(fl.nodes||[]).length>0; var off=(fl.offline_nodes||[]).length;
				if(wt>0){window.__tncFleetLast={t:Date.now(),wt:wt,ppm:Number(fl.ppm_total||0)};}
				var lastKnown=window.__tncFleetLast||null;
				var show=wt>0?wt:(lastKnown&&(Date.now()-lastKnown.t)<180000?lastKnown.wt:0);
				var sub,cls='';
				if(!anyNodes){sub='no fleet nodes registered yet';}
				else if(off&&!show){sub='OFFLINE &middot; '+off+' node(s) silent &gt;5 min';cls='c-red';}
				else if(off){sub=off+' node(s) OFFLINE &middot; '+Number(fl.ppm_total||0)+' jobs/min';cls='c-amb';}
				else{sub='InterServer &middot; online &middot; '+Number(fl.ppm_total||0)+' jobs/min';}
				return tile('FLEET workers','<span '+(cls?'class="chip '+cls+'" style="font-size:20px;padding:5px 14px"':'')+'>'+show+'</span>',sub);
			})()+
			tile('Pages / min',esc(w.pages_per_min||0),'live crawl throughput')+
			tile('Queue',esc(w.queued||0),'prospects waiting')+
			tile('Crawling',esc(w.crawling||0),'jobs in flight')+
			tile('AI spend today','$'+esc((d.spend&&d.spend.today_usd||0).toFixed?d.spend.today_usd.toFixed(4):d.spend.today_usd),(d.spend?d.spend.today_calls+' calls today &middot; $'+d.spend.total_usd+' / '+d.spend.total_calls+' calls lifetime':''));
		var bh='';
		lanes.forEach(function(l){bh+='<div class="row"><span>Lane '+esc(l.lane)+'</span><span class="chip '+(l.active?'c-grn':'c-vio')+'">'+(l.active?'ACTIVE':'idle')+'</span></div>';});
		(w.deep||[]).forEach(function(dc){bh+='<div class="row"><span>Deep: '+esc(dc.company||dc.id)+'</span><span class="mut">'+esc(dc.progress||'')+'</span></div>';});
		if(!(w.deep||[]).length){bh+='<div class="row"><span class="mut">No deep crawls in flight</span><span class="chip c-grn">ALL CLEAR</span></div>';}
		document.getElementById('wBrain').innerHTML=bh;
		var dg=(w.diag||[]);
		document.getElementById('wHeal').innerHTML=dg.length?dg.map(function(x){return '<div class="row"><span>'+esc(typeof x==='string'?x:JSON.stringify(x))+'</span></div>';}).join(''):'<div class="row"><span class="mut">No healing events</span><span class="chip c-grn">HEALTHY</span></div>';
		var ih='';
		(d.identities||[]).forEach(function(i){var pct=i.daily_cap>0?Math.min(100,Math.round(100*i.sent_today/i.daily_cap)):0;
			ih+='<div class="row" style="display:block"><div style="display:flex;justify-content:space-between"><strong>'+esc(i.from||'(unprovisioned)')+'</strong><span class="chip '+(i.active?'c-grn':'c-amb')+'">'+(i.active?'ACTIVE':'INACTIVE')+'</span></div>'+
			'<div class="mut" style="font-size:11px;margin-top:3px">'+esc((i.streams||[]).join(' + '))+' &middot; warmup: '+esc(i.warmup)+' &middot; '+esc(i.sent_today)+' / '+esc(i.daily_cap)+' today</div>'+
			'<div class="bar"><i style="width:'+pct+'%"></i></div></div>';});
		var dk=d.dkim||{};
		ih+='<div class="row"><span>DKIM signing</span><span class="chip '+(dk.signing?'c-grn':'c-amb')+'">'+(dk.signing?'ON (tnc1)':'KEY READY &middot; DNS PENDING')+'</span></div>';
		document.getElementById('wIdent').innerHTML=ih;
		document.getElementById('wMail').innerHTML=(d.mail_log||[]).map(function(m){
			var ok=m.ok===1||m.ok==='1';
			return '<div class="row"><span>'+esc(m.event)+(m.to?' &rarr; '+esc(m.to):'')+'</span><span class="chip '+(m.event==='wp_mail_failed'?'c-red':(ok?'c-grn':'c-vio'))+'">'+(m.event==='wp_mail_failed'?'FAIL':(ok?'OK':esc(m.event)))+'</span></div>';
		}).join('')||'<div class="row mut">No mail activity yet</div>';
		var ib=d.inbox||{},ch='';
		Object.keys(ib.classes||{}).forEach(function(k){ch+='<span class="chip '+(k==='interested'?'c-grn':(k==='unsubscribe'?'c-red':'c-vio'))+'">'+esc(k)+': '+esc(ib.classes[k])+'</span>';});
		document.getElementById('wInbox').innerHTML='<div class="row"><span>Replies captured</span><strong>'+esc(ib.total||0)+'</strong></div><div class="row"><span>Sequences auto-paused</span><strong>'+esc(ib.paused||0)+'</strong></div><div class="row"><span>Suppressed (unsub)</span><strong>'+esc(ib.suppressed||0)+'</strong></div>'+(ch?'<div style="margin-top:8px">'+ch+'</div>':'');
		var th='';Object.keys(d.throttles||{}).forEach(function(k){th+='<span class="chip c-vio">'+esc(k)+' '+esc(d.throttles[k])+'</span>';});
		document.getElementById('wThr').innerHTML=th;
		/* FLEET TRACKER: once a node has EVER registered, the card never falls
		   back to PENDING ACCESS and never shows 0 on a snapshot gap. States:
		   online (<3 min, green) | stale (3-5 min, amber, last-known counts) |
		   OFFLINE (>5 min, red + banner; the brain also emails the alert). */
		var fl=d.fleet||{nodes:[],jobs:{}};
		var nodes=(fl.nodes||[]);
		var card=document.getElementById('wFleetCard'),lock=document.getElementById('wFleetLock');
		if(nodes.length){
			card.classList.remove('fleet');card.style.opacity='1';card.style.filter='none';
			var off=nodes.filter(function(n){return n.state==='offline'});
			var live=nodes.filter(function(n){return n.state!=='offline'});
			if(off.length&&!live.length){lock.textContent='FLEET OFFLINE';lock.style.color='var(--red)';}
			else if(off.length){lock.textContent='DEGRADED';lock.style.color='var(--amb)';}
			else{lock.textContent='LIVE';lock.style.color='var(--grn)';}
			var fh='';
			if(off.length){fh+='<div class="row" style="background:rgba(251,113,133,.08);border-radius:8px;padding:8px 10px"><span style="color:var(--red);font-weight:700">&#9888; '+off.length+' node(s) heartbeat-silent &gt;5 min &mdash; alert emailed</span><span class="chip c-red">CHECK VPS</span></div>';}
			fh+='<div class="row"><span>Workers (lanes, last-known)</span><strong style="font-size:18px">'+esc(fl.workers_total||0)+'</strong></div>';
			nodes.forEach(function(n){
				var st=n.state==='online'?'<span class="chip c-grn">ONLINE</span>':(n.state==='stale'?'<span class="chip c-amb">STALE '+esc(n.age)+'s</span>':'<span class="chip c-red">OFFLINE '+esc(Math.round(n.age/60))+'m</span>');
				fh+='<div class="row"><span>'+esc(n.node)+'</span><span class="mut">'+esc(n.lanes)+' lanes &middot; beat '+esc(n.age)+'s ago &middot; '+esc(n.ppm)+' ppm '+st+'</span></div>';
			});
			fh+='<div class="row"><span>Throughput</span><span class="mut">'+esc(fl.ppm_total||0)+' jobs/min across fleet</span></div>';
			fh+='<div class="row"><span>Queue</span><span class="mut">'+esc(fl.jobs.queued||0)+' queued &middot; '+esc(fl.jobs.running||0)+' running &middot; '+esc(fl.jobs.done||0)+' done'+((fl.jobs.dead||0)?' &middot; '+esc(fl.jobs.dead)+' dead':'')+'</span></div>';
			document.getElementById('wFleet').innerHTML=fh;
		}else{
			card.classList.add('fleet');lock.textContent='PENDING ACCESS';lock.style.color='var(--amb)';
		}
		/* BACKUPS CARD: last success + status; loud when stale/failed. */
		var bk=d.backup||{};var bkEl=document.getElementById('wBackup');
		if(bkEl){
			var okch=(bk.stale||(bk.last_run&&!bk.ok))?'<span class="chip c-red">'+(bk.last_run&&!bk.ok?'FAILED':'STALE &gt;36H')+'</span>':'<span class="chip c-grn">HEALTHY</span>';
			var when=bk.last_ok?new Date(bk.last_ok*1000).toLocaleString():'never';
			var size=bk.size?(bk.size/1048576).toFixed(2)+' MB':'-';
			bkEl.innerHTML='<div class="row"><span>Status</span>'+okch+'</div>'
			+'<div class="row"><span>Last successful backup</span><span class="mut">'+esc(when)+(bk.age!=null?' ('+Math.round(bk.age/3600)+'h ago)':'')+'</span></div>'
			+'<div class="row"><span>Archive (DB + plugin source)</span><span class="mut">'+esc(size)+' tar.gz &middot; nightly 2:30 AM</span></div>'
			+'<div class="row"><span>Pre-deploy version snapshots</span><span class="mut">'+esc(bk.versions||0)+' kept</span></div>'
			+(bk.error?'<div class="row"><span style="color:var(--red)">'+esc(bk.error)+'</span></div>':'')
			+'<div class="row" style="display:block"><span>Offsite pull (for the VPS nightly mirror)</span><code style="user-select:all;color:var(--vio2);font-size:11px;word-break:break-all;display:block;margin-top:5px;background:rgba(0,0,0,.3);padding:7px 9px;border-radius:8px">'+esc(TNC_W.ajaxBase)+'?action=tnc_backup&amp;op=export&amp;token='+esc(TNC_W.backupTok)+'</code></div>';
		}
		last=Date.now();
	}
	var olEl=document.getElementById('tncOneLiner');if(olEl&&TNC_W.oneliner){olEl.textContent=TNC_W.oneliner;}
	(function(){var sel=document.getElementById('tncScaleN'),out=document.getElementById('tncScaleCmd');
	 if(sel&&out&&TNC_W.fleetTok){var build=function(){var n=sel.value;out.textContent='curl -fsSL -A "Mozilla/5.0" "'+TNC_W.ajaxBase+'?action=tnc_fleet&op=bootstrap&t='+TNC_W.fleetTok+'" | base64 -d | bash -s -- '+TNC_W.fleetTok+' '+n;};sel.addEventListener('change',build);build();}})();
	function tick(){
		fetch(TNC_W.rest+'/admin/cockpit',{credentials:'same-origin',headers:{'X-WP-Nonce':TNC_W.nonce}})
		.then(function(r){return r.json();}).then(render).catch(function(){});
	}
	setInterval(function(){if(last)document.getElementById('wUpd').textContent='● LIVE · real-time (2s)';},1000);
	setInterval(tick,2000);tick();
})();
</script>
		<?php
	}

}
