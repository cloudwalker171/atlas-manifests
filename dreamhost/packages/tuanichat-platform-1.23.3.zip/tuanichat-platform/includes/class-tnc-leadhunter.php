<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * LEAD HUNTER (#36) — MVP loop:
 *   Overpass discovery (affluence-first territory) -> 4-key dedupe ->
 *   fleet-verified site probe (InterServer workers) -> brain enrich
 *   (email/phone) + Chat Detection v5 -> 0-100 score -> staging dashboard
 *   (filters + .xlsx export).
 * Anti-flagging: one Overpass query per hunt, Nominatim geocode (1/hunt),
 * per-host politeness on enrich fetches (every candidate is a distinct
 * domain), fail-fast circuit breaker. DEFERRED (follow-up pass): LinkedIn
 * enrichment, AI openers, throughput benchmarks, visitor geolocation.
 */
class TNC_Leadhunter {

	const CAP_MAX        = 80;
	const BREAKER_FAILS  = 5;  // consecutive enrich failures -> stop the hunt loudly.
	const TICK_BATCH     = 4;  // enriches per background tick (then respawn).
	const LOOP_EVERY     = 60;  // local discovery is $0 (no API limit) -> fire every minute.
	const REVISIT_DAYS   = 5;   // re-hunt a tile only after this many days (coverage cadence).
	const EXPLORE_P      = 25;  // % of hunts that explore fresh/white-space ground.
	const PROMOTE_PER_HR = 600; // capacity-aware promotion throttle (10k/day pacing).

	/* -------------------------------------------------- settings/config -- */

	public static function settings() {
		$d = array(
			'auto'        => 0,                 // always-on loop on/off.
			'target'      => 10000,             // daily qualified target.
			'min_score'   => 60,                // qualification score bar.
			'require'     => 'email', // EMAIL MANDATORY — the non-negotiable floor. LinkedIn/phone are bonus only.
			'review'      => 0,                 // 1 = manual review instead of auto-promote.
			'auto_seq'    => 0,                 // 1 = auto-enter cold sequence after promote (gated on cold channel).
			'promote_cap' => self::PROMOTE_PER_HR,
			'promote_paused' => 0, // P0 kill switch: 1 = no auto-promotion at all.
			'discovery'   => 'auto', // local-map adapter: auto (POI DB when live, else Overpass) | local | overpass.
		);
		$s = get_option( 'tnc_lh_settings', array() );
		$m = array_merge( $d, is_array( $s ) ? $s : array() );
		$m['promote_cap'] = max( (int) $m['promote_cap'], self::PROMOTE_PER_HR ); // stale low caps can't strand leads.
		return $m;
	}

	public static function save_settings( $req ) {
		$s = self::settings();
		foreach ( array( 'auto', 'review', 'auto_seq', 'promote_paused' ) as $k ) {
			if ( null !== $req->get_param( $k ) ) { $s[ $k ] = (int) (bool) $req->get_param( $k ); }
		}
		if ( null !== $req->get_param( 'min_score' ) ) { $s['min_score'] = max( 0, min( 100, (int) $req->get_param( 'min_score' ) ) ); }
		if ( null !== $req->get_param( 'target' ) )    { $s['target'] = max( 50, min( 100000, (int) $req->get_param( 'target' ) ) ); update_option( 'tnc_lh_target', $s['target'], false ); }
		$req_v = $req->get_param( 'require' );
		if ( 'email' === $req_v ) { $s['require'] = 'email'; } // email is mandatory; no looser option.
		$disc = $req->get_param( 'discovery' );
		if ( in_array( $disc, array( 'auto', 'local', 'overpass' ), true ) ) { $s['discovery'] = $disc; }
		update_option( 'tnc_lh_settings', $s, false );
		return rest_ensure_response( array( 'ok' => true, 'settings' => $s ) );
	}

	/**
	 * FULL EMAIL-READINESS AUDIT (repeatable). Disposition every lead_hunter
	 * prospect into exactly one bucket and stamp it on the record:
	 *   ready    — valid MX email + working site + scored + not dup
	 *   fixed    — was missing, enrichment had since filled a valid email
	 *   demoted  — no valid email after retries -> back to hunter as needs_email
	 *   removed  — dead site or duplicate domain/email
	 * Re-runs on a daily schedule AND the same checks are the promote-time gate.
	 */
	public static function audit_contacts( $req = null ) {
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 240 );
		}
		global $wpdb;
		$cfg  = self::settings();
		$floor = (int) $cfg['min_score'];
		$rows = $wpdb->get_results( "SELECT id FROM " . TNC_Prospects::table() . " WHERE source = 'lead_hunter' ORDER BY id ASC", ARRAY_A );
		$tally = array( 'audited' => 0, 'ready' => 0, 'fixed' => 0, 'demoted' => 0, 'removed' => 0 );
		$seen_dom = array(); $seen_em = array();
		foreach ( (array) $rows as $r ) {
			$p  = TNC_Prospects::get( (int) $r['id'] );
			if ( ! $p ) { continue; }
			$tally['audited']++;
			$lh = self::lh( $p );
			$cd = is_array( $p['crawl_data'] ) ? $p['crawl_data'] : array();
			$was_promoted = ! empty( $lh['promoted'] );
			// Bad/franchise/social URL (e.g. subway.com on a salon) -> strip it; the
			// lead now has no real site and cannot promote until a real one is found.
			if ( $p['website_url'] && self::bad_domain( (string) wp_parse_url( $p['website_url'], PHP_URL_HOST ) ) ) {
				$cd['lh']['bad_site'] = $p['website_url'];
				$cd['lh']['site_ok']  = false;
				TNC_Prospects::update( $p['id'], array( 'website_url' => '', 'status' => 'new', 'crawl_data' => wp_json_encode( $cd ) ) );
				$p['website_url'] = ''; $lh = $cd['lh'];
			}
			$dom   = $p['website_url'] ? self::norm_domain( $p['website_url'] ) : '';
			$email = strtolower( (string) $p['contact_email'] );
			$site_ok = isset( $lh['site_ok'] ) ? $lh['site_ok'] : null;
			// No working website at all -> cannot be a prospect (must demote, not 'ready').
			if ( '' === $p['website_url'] ) { $site_ok = false; }

			// REMOVE only true DUPLICATES (same domain/email already kept this pass).
			// A failed or unverified probe never condemns a lead (probes time out) —
			// those drop to needs_recheck below, not 'removed'.
			$dupe = ( $dom && isset( $seen_dom[ $dom ] ) ) || ( $email && isset( $seen_em[ $email ] ) );
			if ( $dupe ) {
				$cd['lh']['bucket'] = 'removed';
				$cd['lh']['promoted'] = 0; $cd['lh']['qualified'] = 0; $cd['lh']['stage'] = 'duplicate';
				TNC_Prospects::update( $p['id'], array( 'status' => 'lost', 'crawl_data' => wp_json_encode( $cd ) ) );
				$tally['removed']++;
				continue;
			}
			if ( $dom ) { $seen_dom[ $dom ] = 1; }

			$valid_email = $email && self::valid_email( $email );
			$scored = (int) $p['score'] >= $floor;
			$enriched = isset( $lh['enrich'] ) && 'done' === $lh['enrich'];
			if ( $valid_email && $scored && $enriched ) { $seen_em[ $email ] = 1; }

			if ( $valid_email && $scored && $enriched ) {
				$cd['lh']['bucket'] = $was_promoted ? 'ready' : 'fixed';
				$cd['lh']['qualified'] = 1; $cd['lh']['promoted'] = 1; $cd['lh']['stage'] = 'promoted';
				if ( 'new' === $p['status'] ) { $cd['lh']['email_ready'] = 1; TNC_Prospects::update( $p['id'], array( 'status' => 'demo_created', 'crawl_data' => wp_json_encode( $cd ) ) ); }
				else { $cd['lh']['email_ready'] = 1; TNC_Prospects::update( $p['id'], array( 'crawl_data' => wp_json_encode( $cd ) ) ); }
				$tally[ $was_promoted ? 'ready' : 'fixed' ]++;
				continue;
			}

			// No valid email -> DEMOTE to hunter as needs_email + queue multi-pass re-enrich.
			$cd['lh']['bucket'] = 'demoted';
			$cd['lh']['promoted'] = 0; $cd['lh']['qualified'] = 0; $cd['lh']['email_ready'] = 0;
			$cd['lh']['stage'] = ! $enriched ? 'needs_enrichment' : ( ! $scored ? 'below_score' : 'needs_email' ); $cd['lh']['enrich'] = 'pending';
			TNC_Prospects::update( $p['id'], array( 'status' => 'new', 'crawl_data' => wp_json_encode( $cd ) ) );
			if ( $was_promoted ) {
				TNC_Prospects::audit( $p['id'], 'DEMOTED (email-readiness audit): no valid email — deep re-enrich queued', 'lead_hunter', 'verified' );
			}
			if ( $p['website_url'] ) {
				$base = untrailingslashit( $p['website_url'] );
				foreach ( array( '', '/contact', '/contact-us', '/about', '/team' ) as $pp ) {
					TNC_Fleet::enqueue( 'enrich', array( 'url' => $base . $pp, 'prospect' => $p['id'], 'deep' => 1, 'sigs' => array_keys( TNC_Crawler::chat_signatures() ) ), 6 );
				}
			}
			$tally['demoted']++;
		}
		update_option( 'tnc_lh_audit', array_merge( $tally, array( 'ts' => time() ) ), false );
		return rest_ensure_response( array( 'ok' => true ) + $tally );
	}

	/** Daily scheduled wrapper. */
	public static function cron_audit() {
		try { self::audit_contacts( null ); } catch ( \Throwable $e ) { update_option( 'tnc_watchdog_err', 'lh_audit: ' . $e->getMessage(), false ); }
	}

	/* ------------------------------------------- qualification + promote -- */

	/** Is this prospect contactable + scored enough to be a real Prospect? */
	public static function qualifies( $p, $cfg = null ) {
		$cfg = $cfg ? $cfg : self::settings();
		$lh  = self::lh( $p );
		$site_ok = isset( $lh['site_ok'] ) ? $lh['site_ok'] : null;
		if ( empty( $p['website_url'] ) || false === $site_ok ) {
			return false; // working website is mandatory.
		}
		if ( (int) $p['score'] < (int) $cfg['min_score'] ) {
			return false;
		}
		// HARD MINIMUM (binding rule #10): a valid EMAIL is mandatory to become a
		// Prospect. No exceptions. Phone alone or LinkedIn alone NEVER qualifies;
		// score never substitutes for a deliverable email.
		return ! empty( $p['contact_email'] ) && self::valid_email( $p['contact_email'] );
	}

	/**
	 * Valid + plausibly-deliverable + NOT a placeholder. Syntax -> junk/placeholder
	 * screen -> MX. A domain with MX is necessary but NOT sufficient: tutorial
	 * placeholders like user@domain.com resolve too, so they are rejected by
	 * pattern BEFORE the MX check. (Fixes the Arizona Allergy user@domain.com leak.)
	 */
	public static function valid_email( $email ) {
		$email = strtolower( trim( (string) $email ) );
		if ( ! is_email( $email ) ) {
			return false;
		}
		if ( self::is_placeholder_email( $email ) ) {
			return false; // textbook/example/placeholder address — never a real business inbox.
		}
		$domain = substr( strrchr( $email, '@' ), 1 );
		if ( '' === $domain || false === strpos( $domain, '.' ) ) {
			return false;
		}
		// MX check (cached per domain, 7 days) — confirms the domain can receive mail.
		$ck = 'tnc_mx_' . md5( $domain );
		$mx = get_transient( $ck );
		if ( false === $mx ) {
			$mx = ( function_exists( 'getmxrr' ) && @getmxrr( $domain, $h ) ) || @checkdnsrr( $domain, 'A' ) ? 1 : 0;
			set_transient( $ck, $mx, 7 * DAY_IN_SECONDS );
		}
		return (bool) $mx;
	}

	/** Placeholder/junk domains that resolve but are never a real business inbox. */
	public static function junk_email_domains() {
		return array(
			'domain.com','domain.tld','domain.name','yourdomain.com','your-domain.com','mydomain.com','domainname.com',
			'example.com','example.org','example.net','example.edu','example.co','example.io','exemple.com',
			'test.com','test.org','test.net','testing.com','tester.com',
			'email.com','e-mail.com','mail.com','myemail.com','youremail.com','your-email.com',
			'sample.com','sample.org','samples.com','demo.com','demosite.com',
			'company.com','yourcompany.com','mycompany.com','companyname.com','business.com','yourbusiness.com',
			'website.com','yourwebsite.com','yoursite.com','site.com','mysite.com','webaddress.com',
			'acme.com','acmecorp.com','foo.com','bar.com','baz.com','abc.com','xyz.com','asdf.com','qwerty.com',
			'none.com','na.com','noemail.com','no-email.com','placeholder.com','changeme.com','change.me',
			'gmail.con','gmial.com','gmai.com','hotmail.con','yahoo.con', // common fat-finger fakes
			'localhost','localhost.localdomain','invalid','test.invalid','localhost.com',
		);
	}

	/** Generic placeholder mailbox local-parts (tutorial "fill me in" addresses). */
	public static function junk_email_localparts() {
		return array(
			'user','users','youruser','example','example1','test','test1','tester','testing','testuser',
			'youremail','your-email','your.email','youremailaddress','email','emailaddress','email-address',
			'name','yourname','your-name','your.name','firstname','lastname','firstname.lastname','first.last',
			'firstlast','fname','lname','sample','demo','placeholder','username','yourusername','mail',
			'john.doe','johndoe','jane.doe','janedoe','johnsmith','john.smith','foo','bar','baz','abc','xyz',
			'none','na','noemail','someone','somebody','anybody','myname','company','yourcompany','business',
		);
	}

	/** True when the address is a placeholder/example/junk pattern (not deliverable-real). */
	public static function is_placeholder_email( $email ) {
		$email = strtolower( trim( (string) $email ) );
		$at = strrpos( $email, '@' );
		if ( false === $at ) { return true; }
		$local  = substr( $email, 0, $at );
		$domain = substr( $email, $at + 1 );
		// 1) junk DOMAIN (exact, or any subdomain of one).
		if ( in_array( $domain, self::junk_email_domains(), true ) ) { return true; }
		foreach ( self::junk_email_domains() as $jd ) {
			if ( substr( $domain, -( strlen( $jd ) + 1 ) ) === '.' . $jd ) { return true; }
		}
		// 2) placeholder LOCAL-PART (exact match of the mailbox name).
		if ( in_array( $local, self::junk_email_localparts(), true ) ) { return true; }
		// 3) legacy/asset/system noise that is never a real business inbox.
		if ( preg_match( '/(sentry|wixpress|@2x|\.(png|jpe?g|gif|svg|webp|js|css)$)/i', $email ) ) { return true; }
		// 4) obvious "name@domain.tld" tutorial shells.
		if ( preg_match( '/@(domain|example|test|sample|yourdomain|company|business|website)\.[a-z]{2,6}$/i', $email ) ) { return true; }
		return false;
	}

	/**
	 * Cross-validation signal: does the email domain plausibly match the
	 * business website domain? Used to PREFER real on-domain addresses; free
	 * mailboxes (gmail etc.) are allowed but flagged lower-confidence rather
	 * than rejected (many legit small businesses use them).
	 */
	public static function email_matches_site( $email, $website ) {
		$email = strtolower( (string) $email );
		$at = strrpos( $email, '@' );
		if ( false === $at ) { return false; }
		$edom = self::norm_domain( 'http://' . substr( $email, $at + 1 ) );
		$sdom = $website ? self::norm_domain( $website ) : '';
		if ( '' === $edom || '' === $sdom ) { return false; }
		return $edom === $sdom || substr( $edom, -( strlen( $sdom ) + 1 ) ) === '.' . $sdom || substr( $sdom, -( strlen( $edom ) + 1 ) ) === '.' . $edom;
	}

	/** Exclusion gate (reputation-protecting): clients, suppression, ledger, dup. */
	private static function excluded( $p ) {
		$dom = $p['website_url'] ? self::norm_domain( $p['website_url'] ) : '';
		$em  = strtolower( (string) $p['contact_email'] );
		$clients = (array) get_option( 'tnc_clients', array() );        // existing paying clients.
		$dnc     = (array) get_option( 'tnc_dnc', array() );            // do-not-contact domains.
		$supp    = (array) get_option( 'tnc_suppression', array() );    // unsubscribed/bounced emails.
		$ledger  = (array) get_option( 'tnc_contact_ledger', array() ); // already-contacted domains.
		if ( $dom && ( in_array( $dom, $clients, true ) || in_array( $dom, $dnc, true ) || isset( $ledger[ $dom ] ) ) ) {
			return 'client/dnc/already-contacted';
		}
		if ( $em && ( in_array( $em, $supp, true ) || isset( $supp[ $em ] ) ) ) {
			return 'suppressed';
		}
		// Dedup: a promoted prospect on the same domain from any other source.
		if ( $dom ) {
			global $wpdb;
			$dupe = (int) $wpdb->get_var( $wpdb->prepare(
				"SELECT COUNT(*) FROM " . TNC_Prospects::table() . " WHERE id <> %d AND website_url LIKE %s AND ( source <> 'lead_hunter' OR status <> 'new' )",
				(int) $p['id'], '%' . $wpdb->esc_like( $dom ) . '%'
			) );
			if ( $dupe > 0 ) {
				return 'duplicate';
			}
		}
		return '';
	}

	private static function promoted_last_hour() {
		global $wpdb;
		return (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM " . TNC_Prospects::table() . " WHERE source = 'lead_hunter' AND status <> 'new' AND updated_at >= %s",
			gmdate( 'Y-m-d H:i:s', time() - 3600 )
		) );
	}

	/**
	 * AUTO-PROMOTE evaluator — called after every enrich completion. Moves a
	 * qualified, non-excluded, high-confidence lead OUT of the hunter pipeline
	 * INTO Prospects (status advances; lh.promoted=1) and triggers a lightweight
	 * demo. Capacity-throttled; retries enrichment before disqualifying; respects
	 * manual-review mode. Below-bar leads stay in the unqualified bucket.
	 */
	public static function evaluate_promote( $prospect_id ) {
		$p = TNC_Prospects::get( $prospect_id );
		if ( ! $p || 'lead_hunter' !== $p['source'] ) {
			return;
		}
		$lh = self::lh( $p );
		if ( ! empty( $lh['promoted'] ) || 'new' !== $p['status'] ) {
			return; // already moved.
		}
		$cfg = self::settings();
		// P0 KILL SWITCH: when paused, NOTHING auto-promotes (leads stay in hunter).
		if ( ! empty( $cfg['promote_paused'] ) ) {
			return;
		}
		$cd  = is_array( $p['crawl_data'] ) ? $p['crawl_data'] : array();

		// #2 ENRICHMENT RETRY: has a website but no contact yet -> deep-retry before dumping.
		$needs_contact = empty( $p['contact_email'] ) && empty( $p['contact_phone'] );
		$tries = isset( $lh['enrich_tries'] ) ? (int) $lh['enrich_tries'] : 0;
		if ( $p['website_url'] && $needs_contact && $tries < 2 ) {
			$cd['lh']['enrich']       = 'pending';
			$cd['lh']['enrich_tries'] = $tries + 1;
			$cd['lh']['deep']         = 1; // signal: also fetch /contact + /about.
			TNC_Prospects::update( $p['id'], array( 'crawl_data' => wp_json_encode( $cd ) ) );
			$base = untrailingslashit( $p['website_url'] );
			foreach ( array( '/contact', '/contact-us', '/about' ) as $pp ) {
				TNC_Fleet::enqueue( 'enrich', array( 'url' => $base . $pp, 'prospect' => $p['id'], 'sigs' => array_keys( TNC_Crawler::chat_signatures() ) ), 4 );
			}
			return;
		}

		// SINGLE HARD CHOKEPOINT (no bypass): valid MX email + score>=floor +
		// enrichment actually ran. Any miss -> stays in the hunter, never promoted.
		$enriched = isset( $lh['enrich'] ) && 'done' === $lh['enrich'];
		$scored   = (int) $p['score'] >= (int) $cfg['min_score'];
		if ( ! $enriched || ! $scored || ! self::qualifies( $p, $cfg ) ) {
			$cd['lh']['qualified'] = 0;
			$cd['lh']['stage']     = ! $enriched ? 'needs_enrichment' : ( ! $scored ? 'below_score' : 'needs_email' );
			TNC_Prospects::update( $p['id'], array( 'crawl_data' => wp_json_encode( $cd ) ) );
			return;
		}

		$ex = self::excluded( $p );
		if ( '' !== $ex ) {
			$cd['lh']['qualified'] = 0;
			$cd['lh']['stage']     = 'excluded';
			$cd['lh']['exclude']   = $ex;
			TNC_Prospects::update( $p['id'], array( 'crawl_data' => wp_json_encode( $cd ) ) );
			TNC_Prospects::audit( $p['id'], 'Auto-promote skipped (' . $ex . ')', 'lead_hunter', 'verified' );
			return;
		}

		$cd['lh']['qualified'] = 1;

		// #1 manual-review mode OR capacity throttle -> hold as qualified-pending.
		if ( ! empty( $cfg['review'] ) || self::promoted_last_hour() >= (int) $cfg['promote_cap'] ) {
			$cd['lh']['stage'] = 'qualified_pending';
			TNC_Prospects::update( $p['id'], array( 'crawl_data' => wp_json_encode( $cd ) ) );
			return;
		}

		// PROMOTE: move into Prospects (status advances out of 'new'), build demo.
		$was_recovered = ( isset( $lh['via'] ) && 'recovery' === $lh['via'] ) || ( isset( $lh['bucket'] ) && 'demoted' === $lh['bucket'] ) || ! empty( $lh['recover_tries'] );
		$cd['lh']['promoted']    = 1;
		$cd['lh']['stage']       = 'promoted';
		$cd['lh']['promoted_at'] = time();
		if ( $was_recovered ) { $cd['lh']['recovered'] = 1; }
		TNC_Prospects::update( $p['id'], array( 'status' => 'demo_created', 'crawl_data' => wp_json_encode( $cd ) ) );
		TNC_Prospects::audit( $p['id'], ( $was_recovered ? 'RECOVERED via deep re-enrichment — auto-promoted' : 'Auto-promoted to Prospects' ) . ' (score ' . $p['score'] . ', ' . $cfg['require'] . ( isset( $cd['lh']['email_q'] ) && 'role_on_domain' === $cd['lh']['email_q'] ? ', role email' : '' ) . ') + lightweight demo', 'lead_hunter', 'verified' );
		if ( $was_recovered ) {
			$rc = (int) get_option( 'tnc_lh_recovered', 0 );
			update_option( 'tnc_lh_recovered', $rc + 1, false );
		}
		// Lightweight demo: warm the homepage screenshot now; deep build stays lazy on open.
		if ( $p['website_url'] ) {
			TNC_Fleet::enqueue( 'probe', array( 'url' => esc_url_raw( $p['website_url'] ), 'prospect' => $p['id'], 'warm_demo' => 1 ), 5 );
		}
		$tot = (int) get_option( 'tnc_lh_promoted_today_n', 0 );
		$day = (int) get_option( 'tnc_lh_promoted_day', 0 );
		$today = (int) gmdate( 'Ymd' );
		if ( $day !== $today ) { $tot = 0; update_option( 'tnc_lh_promoted_day', $today, false ); }
		update_option( 'tnc_lh_promoted_today_n', $tot + 1, false );
	}

	/* ----------------------------------------------- always-on loop ----- */

	/** Affluence-first territory roster (Census-ranked wealthy metros). */
	private static function territories() {
		// Broad, data-rich US city pool (affluent-leaning but spanning every region
		// and state) so the intelligent rotation has real white-space to mine from
		// the full 75k+ POI DB — not just a handful of metros. ~120 cities.
		$t = get_option( 'tnc_lh_territories' );
		if ( is_array( $t ) && count( $t ) > 30 ) { return $t; } // operator-extensible.
		return array(
			// CA
			'Beverly Hills, California','Newport Beach, California','Manhattan Beach, California','Pasadena, California','Santa Monica, California','Irvine, California','San Diego, California','San Jose, California','San Francisco, California','Sacramento, California','Fresno, California','Long Beach, California','Anaheim, California','Riverside, California','Bakersfield, California','Palo Alto, California','Walnut Creek, California',
			// AZ NV NM
			'Scottsdale, Arizona','Phoenix, Arizona','Tucson, Arizona','Chandler, Arizona','Gilbert, Arizona','Mesa, Arizona','Las Vegas, Nevada','Henderson, Nevada','Reno, Nevada','Albuquerque, New Mexico','Santa Fe, New Mexico',
			// TX
			'Austin, Texas','Dallas, Texas','Houston, Texas','Plano, Texas','San Antonio, Texas','Fort Worth, Texas','Frisco, Texas','Sugar Land, Texas','The Woodlands, Texas','El Paso, Texas','Southlake, Texas',
			// FL
			'Naples, Florida','Boca Raton, Florida','Fort Lauderdale, Florida','Miami, Florida','Orlando, Florida','Tampa, Florida','Jacksonville, Florida','Sarasota, Florida','West Palm Beach, Florida','Coral Gables, Florida','St. Petersburg, Florida',
			// Northeast
			'Stamford, Connecticut','Greenwich, Connecticut','New York, New York','Brooklyn, New York','White Plains, New York','Bethesda, Maryland','Arlington, Virginia','Alexandria, Virginia','Boston, Massachusetts','Cambridge, Massachusetts','Newton, Massachusetts','Princeton, New Jersey','Hoboken, New Jersey','Philadelphia, Pennsylvania','Pittsburgh, Pennsylvania','Wilmington, Delaware','Providence, Rhode Island',
			// Southeast
			'Atlanta, Georgia','Alpharetta, Georgia','Savannah, Georgia','Charlotte, North Carolina','Raleigh, North Carolina','Durham, North Carolina','Charleston, South Carolina','Greenville, South Carolina','Nashville, Tennessee','Knoxville, Tennessee','Memphis, Tennessee','Birmingham, Alabama','Louisville, Kentucky','Richmond, Virginia','Virginia Beach, Virginia',
			// Midwest
			'Naperville, Illinois','Chicago, Illinois','Evanston, Illinois','Columbus, Ohio','Cleveland, Ohio','Cincinnati, Ohio','Indianapolis, Indiana','Carmel, Indiana','Detroit, Michigan','Ann Arbor, Michigan','Grand Rapids, Michigan','Minneapolis, Minnesota','Edina, Minnesota','Madison, Wisconsin','Milwaukee, Wisconsin','Kansas City, Missouri','St. Louis, Missouri','Omaha, Nebraska','Des Moines, Iowa',
			// Mountain / NW
			'Denver, Colorado','Boulder, Colorado','Colorado Springs, Colorado','Salt Lake City, Utah','Park City, Utah','Boise, Idaho','Bellevue, Washington','Seattle, Washington','Spokane, Washington','Portland, Oregon','Bend, Oregon',
			// South Central
			'Oklahoma City, Oklahoma','Tulsa, Oklahoma','New Orleans, Louisiana','Baton Rouge, Louisiana','Little Rock, Arkansas',
		);
	}

	/**
	 * INTELLIGENCE CORE — choose the next territory x industry tile from live
	 * signals: white-space (never-hunted) exploration, yield-weighted exploit,
	 * saturation avoidance (skip >70% dupe tiles), and a revisit cadence. Returns
	 * array(industry, area, key, reason) or null.
	 */
	private static function pick_tile() {
		$inds = self::loop_industries(); $areas = self::territories();
		if ( ! $inds || ! $areas ) { return null; }
		// DENSITY PRIOR (learned): drop industries that keep returning 0 found —
		// poi.db simply has no businesses under their mapped categories. They are
		// surfaced as coverage gaps (tnc_lh_gaps) instead of burning hunt cycles.
		$iy = (array) get_option( 'tnc_lh_indyield', array() );
		$gaps = array();
		$inds = array_values( array_filter( $inds, function ( $ind ) use ( $iy, &$gaps ) {
			$y = isset( $iy[ $ind ] ) ? $iy[ $ind ] : array();
			if ( (int) ( $y['hunts'] ?? 0 ) >= 4 && (int) ( $y['found'] ?? 0 ) === 0 ) { $gaps[] = $ind; return false; }
			return true;
		} ) );
		update_option( 'tnc_lh_gaps', $gaps, false );
		if ( ! $inds ) { return null; }
		$stats = get_option( 'tnc_lh_tilestats', array() ); if ( ! is_array( $stats ) ) { $stats = array(); }
		$now = time(); $cutoff = $now - self::REVISIT_DAYS * DAY_IN_SECONDS;
		$never = array(); $ready = array();
		foreach ( $inds as $ind ) {
			foreach ( $areas as $area ) {
				$k = $ind . '|' . $area;
				if ( ! isset( $stats[ $k ] ) ) { $never[] = array( $ind, $area, $k ); continue; }
				if ( (int) ( $stats[ $k ]['last'] ?? 0 ) <= $cutoff ) { $ready[] = array( $ind, $area, $k, $stats[ $k ] ); }
			}
		}
		// EXPLORE white-space: untouched ground first (most of the 75k POIs live in
		// cities we have never worked). Bias strongly toward fresh ground.
		if ( $never && ( wp_rand( 1, 100 ) <= 60 || ! $ready ) ) {
			// Weight fresh-ground picks by the industry's learned density so we
			// explore new GEOS for categories poi.db is rich in, not barren combos.
			$weighted = array();
			foreach ( $never as $n2 ) {
				$y2 = isset( $iy[ $n2[0] ] ) ? $iy[ $n2[0] ] : array();
				$avg = (int) ( $y2['hunts'] ?? 0 ) > 0 ? ( (int) ( $y2['found'] ?? 0 ) / (int) $y2['hunts'] ) : 5; // unknown industries get the benefit of the doubt.
				$w2 = max( 1, min( 20, (int) ceil( $avg ) ) );
				for ( $i2 = 0; $i2 < $w2; $i2++ ) { $weighted[] = $n2; }
			}
			$p = $weighted[ wp_rand( 0, count( $weighted ) - 1 ) ];
			return array( $p[0], $p[1], $p[2], 'white-space (density-weighted)' );
		}
		if ( ! $ready ) {
			// Everything within cadence — take the single oldest so we keep pushing
			// toward target rather than idling.
			$oldest = null; $ots = PHP_INT_MAX;
			foreach ( $inds as $ind ) { foreach ( $areas as $area ) { $k = $ind . '|' . $area; $last = (int) ( $stats[ $k ]['last'] ?? 0 ); if ( $last < $ots ) { $ots = $last; $oldest = array( $ind, $area, $k ); } } }
			return $oldest ? array( $oldest[0], $oldest[1], $oldest[2], 're-visit (cadence)' ) : null;
		}
		// EXPLOIT: drop saturated tiles (recent dupe-rate > 70%), weight by yield.
		$cand = array();
		foreach ( $ready as $r ) { if ( (float) ( $r[3]['dupe_rate'] ?? 0 ) <= 0.7 ) { $cand[] = $r; } }
		if ( ! $cand ) { $cand = $ready; }
		if ( wp_rand( 1, 100 ) <= self::EXPLORE_P ) {
			$p = $cand[ wp_rand( 0, count( $cand ) - 1 ) ];
			return array( $p[0], $p[1], $p[2], 'explore (sampling)' );
		}
		usort( $cand, function ( $a, $b ) { return (float) ( $b[3]['yld'] ?? 0 ) <=> (float) ( $a[3]['yld'] ?? 0 ); } );
		$p = $cand[0];
		$reason = ( (float) ( $p[3]['yld'] ?? 0 ) > 0 ) ? 'high-yield (exploit)' : 're-visit (cadence)';
		return array( $p[0], $p[1], $p[2], $reason );
	}

	/** Update per-tile learning stats (yield EMA + saturation) after a hunt. */
	public static function record_tile( $key, $res ) {
		// learned per-industry density (feeds the rotation prior).
		$ind0 = false !== strpos( (string) $key, '|' ) ? strtok( (string) $key, '|' ) : '';
		if ( $ind0 ) {
			$iy0 = (array) get_option( 'tnc_lh_indyield', array() );
			$f0  = is_array( $res ) ? (int) ( $res['found'] ?? 0 ) : 0;
			$iy0[ $ind0 ] = array( 'hunts' => (int) ( $iy0[ $ind0 ]['hunts'] ?? 0 ) + 1, 'found' => (int) ( $iy0[ $ind0 ]['found'] ?? 0 ) + max( 0, $f0 ) );
			update_option( 'tnc_lh_indyield', $iy0, false );
		}
		$stats = get_option( 'tnc_lh_tilestats', array() ); if ( ! is_array( $stats ) ) { $stats = array(); }
		$f = (int) ( $res['found'] ?? 0 ); $sg = (int) ( $res['staged'] ?? 0 ); $d = (int) ( $res['dupes'] ?? 0 );
		$prev = isset( $stats[ $key ] ) && is_array( $stats[ $key ] ) ? $stats[ $key ] : array();
		$py = isset( $prev['yld'] ) ? (float) $prev['yld'] : 0;
		$stats[ $key ] = array(
			'hunts'      => (int) ( $prev['hunts'] ?? 0 ) + 1,
			'found'      => (int) ( $prev['found'] ?? 0 ) + $f,
			'staged'     => (int) ( $prev['staged'] ?? 0 ) + $sg,
			'dupes'      => (int) ( $prev['dupes'] ?? 0 ) + $d,
			'last'       => time(),
			'yld'        => round( 0.6 * $sg + 0.4 * $py, 2 ),
			'dupe_rate'  => $f > 0 ? round( $d / $f, 2 ) : (float) ( $prev['dupe_rate'] ?? 0 ),
		);
		// Cap option size: keep most-recently-touched 400 tiles.
		if ( count( $stats ) > 400 ) {
			uasort( $stats, function ( $a, $b ) { return (int) ( $b['last'] ?? 0 ) <=> (int) ( $a['last'] ?? 0 ); } );
			$stats = array_slice( $stats, 0, 400, true );
		}
		update_option( 'tnc_lh_tilestats', $stats, false );
	}

	/** Territory intelligence summary for the dashboard (worked/fresh/saturated + top yield + current decision). */
	public static function territory_intel() {
		$inds = self::loop_industries(); $areas = self::territories();
		$stats = get_option( 'tnc_lh_tilestats', array() ); if ( ! is_array( $stats ) ) { $stats = array(); }
		$total = count( $inds ) * count( $areas ); $worked = 0; $sat = 0; $fresh = 0;
		foreach ( $inds as $ind ) { foreach ( $areas as $area ) { $k = $ind . '|' . $area;
			if ( isset( $stats[ $k ] ) ) { $worked++; if ( (float) ( $stats[ $k ]['dupe_rate'] ?? 0 ) > 0.7 ) { $sat++; } } else { $fresh++; } } }
		$arr = array();
		foreach ( $stats as $k => $v ) { $arr[] = array( 'tile' => $k, 'yld' => (float) ( $v['yld'] ?? 0 ), 'staged' => (int) ( $v['staged'] ?? 0 ), 'dupe_rate' => (float) ( $v['dupe_rate'] ?? 0 ) ); }
		usort( $arr, function ( $a, $b ) { return $b['yld'] <=> $a['yld']; } );
		return array( 'total' => $total, 'worked' => $worked, 'fresh' => $fresh, 'saturated' => $sat, 'top' => array_slice( $arr, 0, 8 ), 'core' => get_option( 'tnc_lh_core', array() ) );
	}

	private static function loop_industries() {
		return array( 'med_spa', 'plastic_surgery', 'dental', 'personal_injury', 'law_general', 'roofing', 'hvac' );
	}

	public static function qualified_today() {
		global $wpdb;
		// DISCOVERY-DAY basis (matches the 'today's haul' ring): of leads DISCOVERED
		// today, how many are qualified. Guarantees qualified_today <= discovered_today
		// and both reset together at local midnight (no updated_at inflation).
		$today = gmdate( 'Y-m-d 00:00:00', current_time( 'timestamp' ) );
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT crawl_data FROM " . TNC_Prospects::table() . " WHERE source='lead_hunter' AND created_at >= %s", $today ), ARRAY_A );
		$n = 0;
		foreach ( (array) $rows as $r ) {
			$cd = $r['crawl_data'] ? json_decode( $r['crawl_data'], true ) : array();
			if ( is_array( $cd ) && ! empty( $cd['lh']['qualified'] ) ) { $n++; }
		}
		return $n;
	}

	/**
	 * ALWAYS-ON LOOP tick — called every minute from TNC_Workers::heartbeat().
	 * Self-throttles to LOOP_EVERY. When auto is on and the daily target isn't
	 * met, it picks the least-recently-hunted territory x industry tile (coverage
	 * memory, never re-pull same-day) and fires one hunt. Fail-fast + politeness
	 * live inside run_hunt/the workers.
	 */
	/* ------------------------------------ recovery re-enrichment (#2) -- */

	/**
	 * SECOND-CHANCE ENRICHMENT. Uses SPARE fleet capacity to run DEEPER passes on
	 * previously-rejected leads (demoted / needs_email / needs_enrichment) to try
	 * to find a real, valid, non-placeholder email — and, if a lead now clears the
	 * FULL gate, auto-promote it back. Never lowers the gate; $0 / code-only (no
	 * AI). Throttled so it never starves live discovery.
	 *
	 * @param int  $limit  max records to (re)work this pass.
	 * @param bool $force  ignore the fleet-idle throttle (manual/test runs).
	 */
	public static function recover_tick( $limit = 25, $force = false ) {
		global $wpdb;
		$cfg = self::settings();
		if ( ! empty( $cfg['promote_paused'] ) && ! $force ) {
			return array( 'ok' => true, 'skipped' => 'promotion paused' );
		}
		// THROTTLE: only spend idle capacity. If the live queue is busy, defer.
		$fleet = class_exists( 'TNC_Fleet' ) ? TNC_Fleet::status() : array();
		$cap_w = isset( $fleet['workers_total'] ) ? max( 1, (int) $fleet['workers_total'] ) : 40;
		// QUEUED-only backlog check: long-lease jobs (sitecrawl/shot) are in-flight
		// work, not congestion — counting them froze recovery for hours.
		$inflight = (int) $wpdb->get_var( "SELECT COUNT(*) FROM " . $wpdb->prefix . "tnc_fleet_jobs WHERE status = 'queued'" );
		if ( ! $force && $inflight > $cap_w ) {
			return array( 'ok' => true, 'skipped' => 'fleet busy', 'inflight' => $inflight );
		}
		$budget = max( 1, min( 200, (int) $limit ) );
		// Candidate pool: demoted/needs-email leads with a website, not recently
		// retried, under the recovery attempt cap. Oldest-touched first.
		// PASS 0 — SURVIVOR NAME-SEARCH: businesses with a NAME but NO website
		// (most of the 75k OSM pool). Search "name + city" on the fleet, adopt
		// the official site, then run the normal email enrichment against it.
		$ns = $wpdb->get_results( $wpdb->prepare(
			"SELECT id, company_name, city, state_abbr, crawl_data FROM " . TNC_Prospects::table() . " WHERE source = 'lead_hunter' AND status = 'new' AND website_url = '' AND company_name <> '' ORDER BY id ASC LIMIT %d",
			max( 10, (int) ( $budget / 2 ) )
		), ARRAY_A );
		$ns_q = 0;
		foreach ( (array) $ns as $r0 ) {
			$cd0 = $r0['crawl_data'] ? json_decode( $r0['crawl_data'], true ) : array();
			if ( ! is_array( $cd0 ) ) { $cd0 = array(); }
			if ( ! empty( $cd0['lh']['ns_done'] ) || ! empty( $cd0['lh']['ns_q'] ) && ( time() - (int) $cd0['lh']['ns_q'] ) < 12 * HOUR_IN_SECONDS ) { continue; }
			$term = '"' . $r0['company_name'] . '" ' . $r0['city'] . ' ' . $r0['state_abbr'];
			$q  = 'https://duckduckgo.com/html/?q=' . rawurlencode( $term );
			$q2 = 'https://www.bing.com/search?q=' . rawurlencode( $term );
			$cd0['lh']['ns_q'] = time();
			TNC_Prospects::update( (int) $r0['id'], array( 'crawl_data' => wp_json_encode( $cd0 ) ) );
			TNC_Fleet::enqueue( 'enrich', array( 'url' => $q, 'q2' => $q2, 'prospect' => (int) $r0['id'], 'namesearch' => 1 ), 3 );
			$ns_q++;
		}
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT id FROM " . TNC_Prospects::table() . " WHERE source = 'lead_hunter' AND status = 'new' AND website_url <> '' ORDER BY id ASC LIMIT %d",
			$budget * 6
		), ARRAY_A );
		$now = time(); $picked = 0; $guessed = 0; $requeued = 0; $scanned = 0;
		foreach ( (array) $rows as $r ) {
			if ( $picked >= $budget ) { break; }
			$p = TNC_Prospects::get( (int) $r['id'] );
			if ( ! $p ) { continue; }
			$lh = self::lh( $p );
			$stage = isset( $lh['stage'] ) ? $lh['stage'] : '';
			$bucket = isset( $lh['bucket'] ) ? $lh['bucket'] : '';
			$is_target = ( 'demoted' === $bucket ) || in_array( $stage, array( 'needs_email', 'needs_enrichment', 'below_score' ), true );
			if ( ! $is_target ) { continue; }
			$scanned++;
			$rtries = isset( $lh['recover_tries'] ) ? (int) $lh['recover_tries'] : 0;
			$rts    = isset( $lh['recover_ts'] ) ? (int) $lh['recover_ts'] : 0;
			if ( $rtries >= 3 ) { continue; }                         // give up after 3 deep tries.
			if ( $rts && ( $now - $rts ) < 6 * HOUR_IN_SECONDS ) { continue; } // cooldown.

			$cd = is_array( $p['crawl_data'] ) ? $p['crawl_data'] : array();
			$cd['lh']['via']           = 'recovery';
			$cd['lh']['recover_tries'] = $rtries + 1;
			$cd['lh']['recover_ts']    = $now;
			$cd['lh']['enrich']        = 'pending';
			$cd['lh']['deep']          = 1;

			$base = untrailingslashit( $p['website_url'] );
			$pass = $rtries + 1; // 1, 2, or 3.
			if ( 1 === $pass ) {
				// PASS 1 — targeted contact-page scrape + conservative role guess.
				foreach ( array( '', '/contact', '/contact-us', '/about', '/about-us', '/team', '/staff', '/providers', '/our-team', '/location', '/locations' ) as $pp ) {
					TNC_Fleet::enqueue( 'enrich', array( 'url' => $base . $pp, 'prospect' => $p['id'], 'deep' => 1, 'sigs' => array_keys( TNC_Crawler::chat_signatures() ) ), 3 );
					$requeued++;
				}
				if ( empty( $p['contact_email'] ) ) {
					$sdom = self::norm_domain( $p['website_url'] );
					if ( $sdom && false !== strpos( $sdom, '.' ) ) {
						foreach ( array( 'info@', 'contact@', 'office@', 'hello@' ) as $rolep ) {
							$cand = $rolep . $sdom;
							if ( ! self::is_placeholder_email( $cand ) && self::valid_email( $cand ) ) { $cd['lh']['email_guess'] = $cand; $cd['lh']['email_guess_conf'] = 'role_on_domain'; TNC_Fleet::enqueue( 'everify', array( 'email' => $cand, 'prospect' => (int) $p['id'] ), 3 ); $guessed++; break; }
						}
					}
				}
			} elseif ( 2 === $pass && self::sitecrawl_ready() ) {
				// PASS 2 — CRAWL-ON-QUALIFY (queue triage): a 150-page crawl for an
				// email-less record is low-value queue clog. Email-less records get
				// a FAST 25-page contact-focused crawl at LOW priority instead; the
				// full 150-page KB crawl runs only once the record has an email.
				$cd['lh']['deep_crawl'] = 'queued';
				if ( ! empty( $p['contact_email'] ) ) {
					TNC_Fleet::enqueue( 'sitecrawl', array( 'url' => esc_url_raw( $p['website_url'] ), 'prospect' => $p['id'], 'max' => 150, 'delay_ms' => 800 ), 3 );
				} else {
					TNC_Fleet::enqueue( 'sitecrawl', array( 'url' => esc_url_raw( $p['website_url'] ), 'prospect' => $p['id'], 'max' => 25, 'delay_ms' => 500 ), 1 );
				}
				$requeued++;
			} else {
				// PASS 3 — last attempt: broaden on-domain role mailboxes + try the
				// www/non-www domain variant. All still junk-screened + MX-checked.
				if ( empty( $p['contact_email'] ) ) {
					$sdom = self::norm_domain( $p['website_url'] );
					$variants = array( $sdom );
					if ( $sdom && 0 === strpos( $sdom, 'www.' ) ) { $variants[] = substr( $sdom, 4 ); } else { $variants[] = 'www.' . $sdom; }
					$got = '';
					foreach ( $variants as $vd ) {
						if ( ! $vd || false === strpos( $vd, '.' ) ) { continue; }
						foreach ( array( 'info@', 'contact@', 'office@', 'admin@', 'frontdesk@', 'appointments@', 'reception@', 'hello@' ) as $rp ) {
							$cand = $rp . preg_replace( '/^www\./', '', $vd );
							if ( ! self::is_placeholder_email( $cand ) && self::valid_email( $cand ) ) { $got = $cand; break 2; }
						}
					}
					if ( $got ) { $cd['lh']['email_guess'] = $got; $cd['lh']['email_guess_conf'] = 'role_on_domain_p3'; TNC_Fleet::enqueue( 'everify', array( 'email' => $got, 'prospect' => (int) $p['id'] ), 3 ); $guessed++; }
				}
				// also one more deep crawl — but only for records that qualified.
				if ( self::sitecrawl_ready() && ! empty( $p['contact_email'] ) ) {
					TNC_Fleet::enqueue( 'sitecrawl', array( 'url' => esc_url_raw( $p['website_url'] ), 'prospect' => $p['id'], 'max' => 150, 'delay_ms' => 1000 ), 2 );
					$requeued++;
				}
			}
			TNC_Prospects::update( $p['id'], array( 'crawl_data' => wp_json_encode( $cd ) ) );
			TNC_Prospects::audit( $p['id'], 'Recovery pass ' . $pass . ' queued (idle-capacity, $0/no-AI)', 'lead_hunter', 'verified' );
			$picked++;
		}
		update_option( 'tnc_lh_recover', array(
			'ts' => $now, 'picked' => $picked, 'requeued' => $requeued,
			'guessed' => $guessed, 'scanned' => $scanned, 'inflight' => $inflight,
		), false );
		return array( 'ok' => true, 'picked' => $picked, 'enrich_jobs_queued' => $requeued, 'role_guesses' => $guessed, 'candidates_scanned' => $scanned, 'inflight' => $inflight );
	}

	/** PENDING-PROMOTION SWEEP: qualified leads parked by a momentary cap-hit
	 * (stage=qualified_pending) get re-evaluated every tick. Without this they
	 * were stranded forever (evaluate_promote only fired on new results). */
	public static function promote_pending_tick( $limit = 60 ) {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT id, crawl_data FROM " . TNC_Prospects::table() . " WHERE source='lead_hunter' AND status='new' AND ( crawl_data LIKE %s OR ( contact_email <> '' AND score >= 60 ) ) ORDER BY id DESC LIMIT %d",
			'%qualified_pending%', (int) $limit
		), ARRAY_A );
		$n = 0;
		foreach ( (array) $rows as $r ) {
			try { self::evaluate_promote( (int) $r['id'] ); $n++; } catch ( \Throwable $e ) { break; }
		}
		return $n;
	}

	/** Hourly cron entry for recovery re-enrichment. */
	public static function cron_recover() {
		try { self::recover_tick( 50, false ); } catch ( \Throwable $e ) {
			update_option( 'tnc_watchdog_err', 'recover: ' . $e->getMessage(), false );
		}
	}

	/* --------------------------------------------- live geo heatmap -- */

	/**
	 * Server-side geo aggregation for the live Lead Hunter heatmap. Buckets every
	 * lead into a ~0.25-degree grid cell (so tens of thousands of points stay
	 * fast — we ship cells, never raw points), with filters (industry/source/
	 * date/status) and a metric toggle (volume vs quality). Also returns ranked
	 * states/metros, live per-state counts, and hunted-vs-untapped coverage.
	 * Cached 45s per filter combo. $0 / no AI / no paid map API.
	 */
	public static function geo( $req ) {
		global $wpdb;
		$industry = $req ? sanitize_key( (string) $req->get_param( 'industry' ) ) : '';
		$source   = $req ? sanitize_key( (string) $req->get_param( 'source' ) ) : '';
		$date     = $req ? sanitize_key( (string) $req->get_param( 'date' ) ) : 'all';
		$status   = $req ? sanitize_key( (string) $req->get_param( 'status' ) ) : '';
		$metric   = ( $req && 'quality' === $req->get_param( 'metric' ) ) ? 'quality' : 'volume';
		$ckey = 'tnc_geo_' . md5( $industry . '|' . $source . '|' . $date . '|' . $status . '|' . $metric );
		$cached = get_transient( $ckey );
		if ( is_array( $cached ) ) { return rest_ensure_response( $cached ); }

		$since = 0;
		if ( 'today' === $date ) { $since = strtotime( gmdate( 'Y-m-d 00:00:00', current_time( 'timestamp' ) ) ); }
		elseif ( '7d' === $date ) { $since = time() - 7 * DAY_IN_SECONDS; }

		$rows = $wpdb->get_results( "SELECT industry, status, score, state_abbr, city, created_at, crawl_data FROM " . TNC_Prospects::table() . " WHERE source = 'lead_hunter'", ARRAY_A );
		$cells = array(); $states = array(); $total = 0; $mapped = 0; $qsum_total = 0;
		foreach ( (array) $rows as $r ) {
			$cd = $r['crawl_data'] ? json_decode( $r['crawl_data'], true ) : array();
			$lh = is_array( $cd ) && isset( $cd['lh'] ) ? $cd['lh'] : array();
			// FILTER: industry.
			if ( $industry && $r['industry'] !== $industry ) { continue; }
			// FILTER: source.
			$disc = isset( $lh['disc'] ) ? $lh['disc'] : ( isset( $lh['osm'] ) ? 'overpass' : '' );
			$is_recovery = ! empty( $lh['recovered'] ) || ( isset( $lh['via'] ) && 'recovery' === $lh['via'] );
			if ( $source ) {
				if ( 'recovery' === $source && ! $is_recovery ) { continue; }
				elseif ( 'osm_local' === $source && 'poi_db' !== $disc ) { continue; }
				elseif ( 'overpass' === $source && 'overpass' !== $disc ) { continue; }
			}
			// FILTER: date (created).
			if ( $since && strtotime( (string) $r['created_at'] ) < $since ) { continue; }
			// FILTER: status bucket.
			$is_promoted = in_array( $r['status'], array( 'demo_created', 'demo_sent', 'engaged', 'won' ), true );
			$is_qual     = ! empty( $lh['qualified'] );
			$is_emailrdy = ! empty( $lh['email_ready'] );
			if ( $status ) {
				if ( 'promoted' === $status && ! $is_promoted ) { continue; }
				elseif ( 'qualified' === $status && ! $is_qual ) { continue; }
				elseif ( 'email_ready' === $status && ! $is_emailrdy ) { continue; }
				// 'discovered' = no extra filter.
			}
			$total++;
			$q = ( $is_emailrdy || $is_promoted ) ? 1 : 0;
			$sc = (int) $r['score'];
			$qsum_total += $q;
			// STATE rollup.
			$st = $r['state_abbr'] ? strtoupper( substr( $r['state_abbr'], 0, 2 ) ) : '';
			if ( $st ) {
				if ( ! isset( $states[ $st ] ) ) { $states[ $st ] = array( 'n' => 0, 'q' => 0, 'sc' => 0 ); }
				$states[ $st ]['n']++; $states[ $st ]['q'] += $q; $states[ $st ]['sc'] += $sc;
			}
			// GEO cell.
			$lat = isset( $lh['lat'] ) ? (float) $lh['lat'] : 0;
			$lon = isset( $lh['lon'] ) ? (float) $lh['lon'] : 0;
			if ( $lat >= 18 && $lat <= 72 && $lon >= -180 && $lon <= -60 ) { // continental US + AK/HI window.
				$mapped++;
				$gk = round( $lat * 4 ) / 4 . ',' . round( $lon * 4 ) / 4; // 0.25-degree grid.
				if ( ! isset( $cells[ $gk ] ) ) { $cells[ $gk ] = array( 0, 0, 0 ); } // n, q, score-sum.
				$cells[ $gk ][0]++; $cells[ $gk ][1] += $q; $cells[ $gk ][2] += $sc;
			}
		}
		// Build cell list with intensity per metric.
		$out_cells = array(); $maxv = 0;
		foreach ( $cells as $gk => $c ) {
			list( $la, $lo ) = array_map( 'floatval', explode( ',', $gk ) );
			$intensity = ( 'quality' === $metric ) ? ( $c[0] > 0 ? round( $c[1] / $c[0], 3 ) : 0 ) : $c[0];
			$maxv = max( $maxv, $intensity );
			$out_cells[] = array( 'lat' => $la, 'lon' => $lo, 'n' => $c[0], 'q' => $c[1], 'i' => $intensity, 'avg' => $c[0] ? round( $c[2] / $c[0] ) : 0 );
		}
		// Ranked regions (states).
		$top = array();
		foreach ( $states as $st => $v ) {
			$top[] = array( 'st' => $st, 'n' => $v['n'], 'q' => $v['q'], 'qrate' => $v['n'] ? round( 100 * $v['q'] / $v['n'] ) : 0, 'avg' => $v['n'] ? round( $v['sc'] / $v['n'] ) : 0 );
		}
		usort( $top, function ( $a, $b ) { return $b['n'] <=> $a['n']; } );
		$top_quality = $top;
		usort( $top_quality, function ( $a, $b ) { return ( $b['qrate'] <=> $a['qrate'] ) ?: ( $b['n'] <=> $a['n'] ); } );
		// COVERAGE: hunted tiles vs all territory x industry tiles (white-space).
		$cover = get_option( 'tnc_lh_cover', array() );
		$cover = is_array( $cover ) ? $cover : array();
		$terr  = self::territories(); $inds = self::loop_industries();
		$total_tiles = count( $terr ) * count( $inds );
		$hunted = 0; $fresh = array();
		foreach ( $terr as $area ) {
			$any = false;
			foreach ( $inds as $ind ) { if ( isset( $cover[ $ind . '|' . $area ] ) ) { $hunted++; $any = true; } }
			if ( ! $any ) { $fresh[] = $area; }
		}
		$resp = array(
			'ok' => true, 'metric' => $metric, 'total' => $total, 'mapped' => $mapped,
			'cells' => $out_cells, 'max' => $maxv,
			'top_volume' => array_slice( $top, 0, 12 ),
			'top_quality' => array_slice( $top_quality, 0, 12 ),
			'states' => $top,
			'coverage' => array( 'hunted_tiles' => $hunted, 'total_tiles' => $total_tiles, 'pct' => $total_tiles ? round( 100 * $hunted / $total_tiles ) : 0, 'untapped' => array_slice( $fresh, 0, 12 ) ),
			'updated' => current_time( 'timestamp' ),
		);
		set_transient( $ckey, $resp, 45 );
		return rest_ensure_response( $resp );
	}

	/** Manual/test trigger for the recovery pass (REST). */
	public static function recover( $req = null ) {
		$force = $req && $req->get_param( 'force' );
		$limit = $req && $req->get_param( 'limit' ) ? (int) $req->get_param( 'limit' ) : 50;
		return rest_ensure_response( self::recover_tick( $limit, (bool) $force ) );
	}

	/* ------------------------------------ deep crawl + idle scheduler -- */

	/**
	 * Ingest a deep site crawl (up to 150 pages) — merge discovered contacts and
	 * signals into the prospect, then re-evaluate for promotion. $0 / no AI.
	 */
	public static function ingest_sitecrawl_result( $prospect_id, $d ) {
		$p = TNC_Prospects::get( $prospect_id );
		if ( ! $p ) { return; }
		$cd = is_array( $p['crawl_data'] ) ? $p['crawl_data'] : array();
		$lh = self::lh( $p );
		$best = ''; $bq = '';
		if ( ! empty( $d['emails'] ) && is_array( $d['emails'] ) ) {
			// Prefer a real, on-domain, non-placeholder, MX-valid address.
			$ranked = $d['emails'];
			usort( $ranked, function ( $a, $b ) use ( $p ) {
				$sa = ( self::email_matches_site( $a, $p['website_url'] ) ? 2 : 0 ) + ( self::is_placeholder_email( $a ) ? -5 : 0 );
				$sb = ( self::email_matches_site( $b, $p['website_url'] ) ? 2 : 0 ) + ( self::is_placeholder_email( $b ) ? -5 : 0 );
				return $sb <=> $sa;
			} );
			foreach ( $ranked as $e ) {
				if ( ! self::is_placeholder_email( $e ) && self::valid_email( $e ) ) { $best = $e; $bq = self::email_matches_site( $e, $p['website_url'] ) ? 'on_domain' : 'found'; break; }
			}
		}
		$upd = array();
		if ( $best && empty( $p['contact_email'] ) ) { $upd['contact_email'] = $best; }
		if ( empty( $p['contact_phone'] ) && ! empty( $d['phones'][0] ) ) { $upd['contact_phone'] = sanitize_text_field( $d['phones'][0] ); }
		$cd['lh'] = array_merge( $lh, array(
			'deep_crawled' => 1,
			'deep_pages'   => isset( $d['pages'] ) ? (int) $d['pages'] : 0,
			'deep_ts'      => time(),
		) );
		if ( $best && empty( $p['contact_email'] ) ) { $cd['lh']['email_q'] = $bq; }

		// P6-P8 KB CACHE: store deep-harvested content per prospect (versioned,
		// timestamped) so demo pages render rich instantly and the product-aware
		// chat is grounded in their REAL content the moment they become a client.
		// $0 / no AI — scraped + parsed only.
		$prevkb = isset( $cd['kb'] ) && is_array( $cd['kb'] ) ? $cd['kb'] : array();
		$merge_list = function ( $a, $b, $cap ) {
			$a = is_array( $a ) ? $a : array(); $b = is_array( $b ) ? $b : array();
			foreach ( $b as $x ) { if ( $x !== '' && ! in_array( $x, $a, true ) ) { $a[] = $x; } }
			return array_slice( $a, 0, $cap );
		};
		$cd['kb'] = array(
			'ver'      => (int) ( $prevkb['ver'] ?? 0 ) + 1,
			'ts'       => time(),
			'pages'    => isset( $d['pages'] ) ? (int) $d['pages'] : 0,
			'pdfs'     => $merge_list( $prevkb['pdfs'] ?? array(), $d['pdfs'] ?? array(), 30 ),
			'socials'  => $merge_list( $prevkb['socials'] ?? array(), $d['socials'] ?? array(), 12 ),
			'services' => $merge_list( $prevkb['services'] ?? array(), $d['services'] ?? array(), 50 ),
			'faq'      => ! empty( $d['faq'] ) ? 1 : (int) ( $prevkb['faq'] ?? 0 ),
			'hours'    => ! empty( $d['hours'] ) ? sanitize_text_field( $d['hours'] ) : ( $prevkb['hours'] ?? '' ),
			'content'  => substr( (string) ( ( $prevkb['content'] ?? '' ) . ' ' . ( $d['content'] ?? '' ) ), 0, 18000 ),
			'source'   => 'deep_crawl',
		);
		// P6 ADDRESS HARVEST ($0/no-AI): pull a US street address from the cached
		// content so the demo chat can answer location precisely. poi.db already
		// supplies city/state; this adds the street line + zip when present.
		if ( empty( $cd['kb']['address'] ) && ! empty( $cd['kb']['content'] ) ) {
			$ct = (string) $cd['kb']['content'];
			if ( preg_match( '/\b\d{1,6}\s+[A-Za-z0-9.\x27 -]{2,40}\s+(?:Street|St|Avenue|Ave|Boulevard|Blvd|Road|Rd|Drive|Dr|Lane|Ln|Way|Court|Ct|Place|Pl|Suite|Ste|Parkway|Pkwy|Highway|Hwy|Trail|Terrace|Ter|Circle|Cir)\b\.?(?:\s*,?\s*(?:Suite|Ste|Unit|#)\s*\w+)?\s*,?\s*[A-Za-z .]{2,30}?,?\s*[A-Z]{2}\s*\d{5}(?:-\d{4})?/', $ct, $am ) ) {
				$addr = trim( preg_replace( '/\s+/', ' ', $am[0] ) );
				if ( strlen( $addr ) >= 10 && strlen( $addr ) <= 130 ) { $cd['kb']['address'] = $addr; }
			}
		}
		$cd['kb']['richness'] = array(
			'pages'    => (int) $cd['kb']['pages'],
			'pdfs'     => count( (array) $cd['kb']['pdfs'] ),
			'faqs'     => (int) $cd['kb']['faq'],
			'services' => count( (array) $cd['kb']['services'] ),
			'socials'  => count( (array) $cd['kb']['socials'] ),
			'chars'    => strlen( (string) $cd['kb']['content'] ),
		);
		// Feed the product-aware KB index if available (grounded retrieval).
		if ( class_exists( 'TNC_KB' ) && method_exists( 'TNC_KB', 'ingest_text' ) && ! empty( $d['content'] ) ) {
			try { TNC_KB::ingest_text( (int) $p['id'], (string) $d['content'], 'deep_crawl' ); } catch ( \Throwable $e ) {}
		}
		if ( ! empty( $d['platform'] ) && empty( $p['platform'] ) ) { $upd['platform'] = sanitize_key( $d['platform'] ); }
		$upd['crawl_data'] = wp_json_encode( $cd );
		TNC_Prospects::update( $p['id'], $upd );
		$rich = $cd['kb']['richness'];
		TNC_Prospects::audit( $p['id'], 'Deep crawl (8-pass, $0): ' . $rich['pages'] . ' pages cached · ' . $rich['pdfs'] . ' PDFs · ' . $rich['faqs'] . ' FAQ · ' . $rich['services'] . ' services · ' . $rich['socials'] . ' socials · ' . count( (array) ( $d['emails'] ?? array() ) ) . ' emails', 'lead_hunter', 'verified' );
		self::evaluate_promote( $p['id'] );
	}

	/**
	 * DEEP-CRAWL-ALL: enqueue full site crawls on prospects not yet deep-crawled,
	 * lowest priority so it only consumes spare capacity. Promoted prospects first
	 * (richest KB payoff), then in-hunter leads with a website.
	 */
	/** Has the fleet proven it can run the deep-crawl worker job? */
	public static function sitecrawl_ready() {
		return (bool) get_option( 'tnc_cap_sitecrawl', 0 );
	}

	public static function deep_crawl_tick( $limit = 15 ) {
		global $wpdb;
		// Until the fleet proves sitecrawl support, enqueue exactly ONE probe so
		// capability is auto-discovered after the worker update — no mass waste.
		if ( ! self::sitecrawl_ready() ) {
			$one = $wpdb->get_var( "SELECT id FROM " . TNC_Prospects::table() . " WHERE source='lead_hunter' AND website_url <> '' AND status IN ('demo_created','demo_sent','engaged','won') ORDER BY id DESC LIMIT 1" );
			if ( $one ) {
				$pp = TNC_Prospects::get( (int) $one );
				if ( $pp && $pp['website_url'] && ! self::bad_domain( (string) wp_parse_url( $pp['website_url'], PHP_URL_HOST ) ) ) {
					TNC_Fleet::enqueue( 'sitecrawl', array( 'url' => esc_url_raw( $pp['website_url'] ), 'prospect' => (int) $one, 'max' => 25, 'delay_ms' => 800 ), 2 );
				}
			}
			return array( 'ok' => true, 'queued' => 0, 'probe' => true );
		}
		$budget = max( 1, min( 100, (int) $limit ) );
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT id FROM " . TNC_Prospects::table() . " WHERE source = 'lead_hunter' AND website_url <> '' AND status IN ('demo_created','demo_sent','engaged','won','new') ORDER BY ( status = 'new' ) ASC, id DESC LIMIT %d",
			$budget * 8
		), ARRAY_A );
		$picked = 0;
		foreach ( (array) $rows as $r ) {
			if ( $picked >= $budget ) { break; }
			$p = TNC_Prospects::get( (int) $r['id'] );
			if ( ! $p || empty( $p['website_url'] ) ) { continue; }
			$lh = self::lh( $p );
			if ( ! empty( $lh['deep_crawled'] ) || 'queued' === ( $lh['deep_crawl'] ?? '' ) ) { continue; }
			if ( self::bad_domain( (string) wp_parse_url( $p['website_url'], PHP_URL_HOST ) ) ) { continue; }
			$cd = is_array( $p['crawl_data'] ) ? $p['crawl_data'] : array();
			$cd['lh']['deep_crawl'] = 'queued';
			TNC_Prospects::update( $p['id'], array( 'crawl_data' => wp_json_encode( $cd ) ) );
			TNC_Fleet::enqueue( 'sitecrawl', array(
				'url' => esc_url_raw( $p['website_url'] ), 'prospect' => $p['id'],
				'max' => 150, 'delay_ms' => 800, // polite per-domain pacing.
			), 2 ); // lowest priority — pure idle-fill.
			$picked++;
		}
		update_option( 'tnc_lh_deepcrawl', array( 'ts' => time(), 'queued' => $picked ), false );
		return array( 'ok' => true, 'queued' => $picked );
	}

	/**
	 * IDLE-FLEET SCHEDULER — keeps 100 workers busy without ever starving live
	 * work. Priority is enforced by the queue itself (discovery 7 > enrich 6 >
	 * recovery 3 > deep-crawl 2). This only TOPS UP background work to fill spare
	 * capacity (never floods): recovery passes first, then deep crawls.
	 */
	/**
	 * RENDER-MIX: how demos currently render — LIVE IFRAME (best) / cached
	 * SCREENSHOT (plan B) / branded MOCK (safety floor, should be a small
	 * minority). Goal: real-site (iframe+screenshot) >= 80%, mock < 20%.
	 */
	public static function render_mix() {
		global $wpdb;
		$rows = $wpdb->get_results( "SELECT crawl_data FROM " . TNC_Prospects::table() . " WHERE source='lead_hunter' AND status IN ('demo_created','demo_sent','engaged','won')", ARRAY_A );
		$iframe = 0; $shot = 0; $mock = 0;
		foreach ( (array) $rows as $r ) {
			$cd = $r['crawl_data'] ? json_decode( $r['crawl_data'], true ) : array();
			$ex = is_array( $cd ) && isset( $cd['extracted'] ) ? $cd['extracted'] : array();
			if ( ! empty( $ex['framable'] ) ) { $iframe++; }
			elseif ( ! empty( $ex['screenshot_local'] ) || ! empty( $ex['screenshot'] ) ) { $shot++; }
			else { $mock++; }
		}
		$total = $iframe + $shot + $mock;
		$real  = $iframe + $shot;
		// Framable ceiling: of demos we've checked, how many PERMIT live iframe.
		$fr_yes = $iframe; $fr_no = $shot; $fr_unknown = $mock;
		$up    = get_option( 'tnc_lh_shot_up', array() );
		$up_hr = ( is_array( $up ) && isset( $up['hr'] ) && (int) $up['hr'] === (int) floor( time() / 3600 ) ) ? (int) $up['n'] : 0;
		return array(
			'total' => $total, 'iframe' => $iframe, 'screenshot' => $shot, 'mock' => $mock,
			'real_pct' => $total ? round( 100 * $real / $total ) : 0,
			'mock_pct' => $total ? round( 100 * $mock / $total ) : 0,
			'goal_real_pct' => 80, 'goal_mock_pct' => 20,
			'on_target' => $total ? ( ( 100 * $real / $total ) >= 80 ) : false,
			'upgraded_this_hour' => $up_hr,
			'framable_yes' => $fr_yes, 'framable_no' => $fr_no, 'framable_unknown' => $fr_unknown,
			'iframe_pct' => $total ? round( 100 * $iframe / $total ) : 0,
			'primary' => 'iframe', // iframe = primary goal; screenshot = plan B; mock = floor.
		);
	}

	/**
	 * IDLE-FLEET UPGRADE LOOP: for every demo still on the MOCK floor, queue a
	 * self-hosted screenshot capture (+ framable re-check) so mock% keeps dropping
	 * toward the goal. Lowest priority — pure spare-capacity work. $0 / we own it.
	 */
	public static function shot_tick( $limit = 10 ) {
		global $wpdb;
		// Discover capability with ONE probe until the fleet proves it can capture.
		if ( ! get_option( 'tnc_cap_shot' ) ) {
			$one = $wpdb->get_var( "SELECT id FROM " . TNC_Prospects::table() . " WHERE source='lead_hunter' AND website_url <> '' AND status IN ('demo_created','demo_sent','engaged','won') ORDER BY id DESC LIMIT 1" );
			if ( $one ) {
				$pp = TNC_Prospects::get( (int) $one );
				if ( $pp && $pp['website_url'] && ! self::bad_domain( (string) wp_parse_url( $pp['website_url'], PHP_URL_HOST ) ) ) {
					TNC_Fleet::enqueue( 'shot', array( 'url' => esc_url_raw( $pp['website_url'] ), 'prospect' => (int) $one ), 2 );
				}
			}
			return array( 'ok' => true, 'queued' => 0, 'probe' => true );
		}
		$budget = max( 1, min( 120, (int) $limit ) );
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT id, website_url, crawl_data FROM " . TNC_Prospects::table() . " WHERE source='lead_hunter' AND website_url <> '' AND status IN ('demo_created','demo_sent','engaged','won') ORDER BY id DESC LIMIT %d",
			$budget * 6
		), ARRAY_A );
		$picked = 0;
		foreach ( (array) $rows as $r ) {
			if ( $picked >= $budget ) { break; }
			$cd = $r['crawl_data'] ? json_decode( $r['crawl_data'], true ) : array();
			$ex = is_array( $cd ) && isset( $cd['extracted'] ) ? $cd['extracted'] : array();
			$lh = is_array( $cd ) && isset( $cd['lh'] ) ? $cd['lh'] : array();
			if ( ! empty( $ex['screenshot_local'] ) ) { continue; } // already on a screenshot.
			if ( isset( $ex['framable'] ) && $ex['framable'] ) { continue; } // IFRAME-FIRST: framable -> live iframe, no screenshot needed.
			if ( ! empty( $lh['shot_q'] ) && ( time() - (int) $lh['shot_q'] ) < 30 * MINUTE_IN_SECONDS ) { continue; } // short cooldown — drain mock backlog fast.
			if ( self::bad_domain( (string) wp_parse_url( $r['website_url'], PHP_URL_HOST ) ) ) { continue; }
			$cd['lh']['shot_q'] = time();
			TNC_Prospects::update( (int) $r['id'], array( 'crawl_data' => wp_json_encode( $cd ) ) );
			TNC_Fleet::enqueue( 'shot', array( 'url' => esc_url_raw( $r['website_url'] ), 'prospect' => (int) $r['id'] ), 2 );
			$picked++;
		}
		return array( 'ok' => true, 'queued' => $picked );
	}

	public static function fleet_fill() {
		global $wpdb;
		$cfg = self::settings();
		if ( ! empty( $cfg['auto'] ) === false && empty( $cfg['fleet_fill'] ) ) {
			// fleet_fill defaults ON; only the explicit master switch disables it.
		}
		if ( isset( $cfg['fleet_fill'] ) && ! $cfg['fleet_fill'] ) { return; }
		$fleet  = class_exists( 'TNC_Fleet' ) ? TNC_Fleet::status() : array();
		$cap_w  = isset( $fleet['workers_total'] ) ? max( 1, (int) $fleet['workers_total'] ) : 40;
		$tbl    = $wpdb->prefix . 'tnc_fleet_jobs';
		$inflight = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $tbl WHERE status IN ('queued','leased')" );
		$target = $cap_w * 2;                 // keep ~2 jobs queued per worker.
		$headroom = $target - $inflight;
		if ( $headroom < $cap_w * 0.25 ) {
			update_option( 'tnc_lh_fleetfill', array( 'ts' => time(), 'inflight' => $inflight, 'headroom' => $headroom, 'note' => 'saturated' ), false );
			return; // already well-fed; do nothing.
		}
		// 1) recovery passes (higher value than blind crawls).
		$r = self::recover_tick( min( 40, (int) ceil( $headroom / 6 ) ), false );
		$inflight2 = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $tbl WHERE status IN ('queued','leased')" );
		$headroom2 = $target - $inflight2;
		// 2) deep crawls fill whatever capacity remains.
		if ( $headroom2 > $cap_w * 0.25 ) {
			self::deep_crawl_tick( min( 20, (int) ceil( $headroom2 / 10 ) ) );
		}
		// SCREENSHOT UPGRADE LOOP: AGGRESSIVELY drain the mock backlog toward the
		// render-mix goal. While real-site% is below goal, dedicate most spare
		// capacity to screenshot capture (fast backfill), not a slow trickle.
		$inflight3 = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $tbl WHERE status IN ('queued','leased')" );
		$head3 = $target - $inflight3;
		if ( $head3 > $cap_w * 0.2 ) {
			$mix = self::render_mix();
			$aggressive = ( isset( $mix['real_pct'] ) && (int) $mix['real_pct'] < (int) $mix['goal_real_pct'] );
			$n = $aggressive ? min( 80, (int) ceil( $head3 / 2 ) ) : min( 15, (int) ceil( $head3 / 8 ) );
			self::shot_tick( $n );
		}
		update_option( 'tnc_lh_fleetfill', array( 'ts' => time(), 'inflight' => $inflight, 'headroom' => $headroom, 'recover' => $r ), false );
	}

	public static function loop_tick() {
		$cfg = self::settings();
		if ( empty( $cfg['auto'] ) ) {
			return;
		}
		// IDLE-FLEET SCHEDULER — runs every tick (own headroom throttle), BEFORE
		// the hunt throttles below, so workers are topped up with background work
		// even while a hunt is in flight or the daily target is met.
		try { self::fleet_fill(); } catch ( \Throwable $e ) { update_option( 'tnc_watchdog_err', 'fleet_fill: ' . $e->getMessage(), false ); }
		// QUEUE TRIAGE (one-time shed, flag-guarded): drop QUEUED 150-page crawls
		// for prospects that have no email yet — crawl-on-qualify. Leased jobs
		// already on workers are left to drain.
		if ( ! get_option( 'tnc_queue_shed_1200' ) ) {
			global $wpdb;
			$jt = $wpdb->prefix . 'tnc_fleet_jobs'; $pt = TNC_Prospects::table();
			$n = $wpdb->query( "UPDATE $jt j SET j.status='dead', j.result='\"shed:crawl-on-qualify\"' WHERE j.status='queued' AND j.job_type='sitecrawl' AND EXISTS (SELECT 1 FROM $pt p WHERE p.id = CAST(JSON_UNQUOTE(JSON_EXTRACT(j.payload,'$.prospect')) AS UNSIGNED) AND p.contact_email = '')" );
			update_option( 'tnc_queue_shed_1200', array( 'ts' => time(), 'shed' => (int) $n ), false );
		}
		// ZOMBIE BANKRUPTCY (one-time, flag-guarded): leased >1h past lease_until
		// = lost from local Redis during rolling restarts; will never complete.
		if ( ! get_option( 'tnc_zombie_sweep_1203' ) ) {
			global $wpdb;
			$jt = $wpdb->prefix . 'tnc_fleet_jobs';
			$nz = $wpdb->query( "UPDATE $jt SET status='dead', result='\"zombie:bankruptcy-v2\"' WHERE status='leased'" );
			update_option( 'tnc_zombie_sweep_1203', array( 'ts' => time(), 'swept' => (int) $nz ), false );
		}
		// RESURRECTION 2 (post results-channel fix): the dead jobs' results were
		// destroyed by the JSON-body bug, not bad jobs. Requeue the FAST types;
		// slow 150-page crawls regenerate gated (crawl-on-qualify).
		if ( ! get_option( 'tnc_resurrect_1205' ) ) {
			global $wpdb;
			$jt = $wpdb->prefix . 'tnc_fleet_jobs';
			$n2 = $wpdb->query( "UPDATE $jt SET status='queued', tries=0, worker='', lease_until=0 WHERE status='dead' AND job_type IN ('poi_query','enrich','everify','shot')" );
			update_option( 'tnc_resurrect_1205', array( 'ts' => time(), 'requeued' => (int) $n2 ), false );
		}
		// JARVIS QUEUE-HEALTH: sampled drain rate (done/min) — a managed metric.
		$qh = (array) get_option( 'tnc_queue_health', array() );
		if ( empty( $qh['ts'] ) || time() - (int) $qh['ts'] >= 300 ) {
			global $wpdb;
			$done_now = (int) $wpdb->get_var( "SELECT COUNT(*) FROM " . $wpdb->prefix . "tnc_fleet_jobs WHERE status='done'" );
			$rate = isset( $qh['done'] ) && ! empty( $qh['ts'] ) ? round( ( $done_now - (int) $qh['done'] ) / max( 1, ( time() - (int) $qh['ts'] ) / 60 ), 1 ) : null;
			update_option( 'tnc_queue_health', array( 'ts' => time(), 'done' => $done_now, 'rate_per_min' => $rate ), false );
		}
		try { self::promote_pending_tick(); } catch ( \Throwable $e ) { update_option( 'tnc_watchdog_err', 'promote_sweep: ' . $e->getMessage(), false ); }
		// INTELLIGENCE-CORE PACE PIVOT: when qualified volume is far below the
		// day-fraction pace of the target, pivot spare capacity HARD into the
		// highest-email-yield work (survivor recovery passes on the existing
		// pool) instead of more low-yield discovery. Surfaced in lh-status.
		try {
			$cfgp   = self::settings();
			$frac   = max( 0.05, ( time() - strtotime( 'today', current_time( 'timestamp' ) ) ) / DAY_IN_SECONDS );
			$pace   = (int) ceil( (int) $cfgp['target'] * $frac );
			$qual   = self::qualified_today();
			$behind = $pace > 0 ? ( $qual < $pace * 0.5 ) : false;
			update_option( 'tnc_lh_pivot', array( 'ts' => time(), 'behind' => $behind ? 1 : 0, 'pace' => $pace, 'qual' => $qual, 'mode' => $behind ? 'recovery-first' : 'normal' ), false );
			if ( $behind && class_exists( 'TNC_Fleet' ) ) {
				TNC_Fleet::resurrect_dead(); // one-time graveyard requeue (flag-guarded).
				self::recover_tick( 75, true ); // forced triple-budget survivor pass.
			}
		} catch ( \Throwable $e ) { update_option( 'tnc_watchdog_err', 'pivot: ' . $e->getMessage(), false ); }
		$last = (int) get_option( 'tnc_lh_loop_last', 0 );
		if ( time() - $last < self::LOOP_EVERY ) {
			return;
		}
		$st = self::state();
		if ( ! empty( $st['hunting'] ) && ( time() - (int) $st['ts'] ) < 600 ) {
			update_option( 'tnc_lh_loop_last', time(), false ); // heartbeat: alive, hunt in flight.
			return;
		}
		if ( self::qualified_today() >= (int) $cfg['target'] ) {
			return; // daily target met — idle until tomorrow.
		}
		update_option( 'tnc_lh_loop_last', time(), false );

		// INTELLIGENT TERRITORY ROTATION (Intelligence Core) — choose WHERE to hunt
		// from live signals (white-space / yield / saturation / cadence), not a
		// static metro list. record_tile() (in finalize_hunt) closes the learning
		// loop with the real found/staged/dupes once the async hunt resolves.
		// PARALLEL DISCOVERY: when behind pace, hunt MULTIPLE territories per
		// tick (the queue prioritizes; local poi.db has no rate limit).
		$pvx = (array) get_option( 'tnc_lh_pivot', array() );
		$lanes = ! empty( $pvx['behind'] ) ? 3 : 1;
		for ( $li = 1; $li < $lanes; $li++ ) {
			$extra = self::pick_tile();
			if ( $extra ) {
				list( $xi, $xa ) = $extra;
				try { self::run_hunt( $xi, $xa, self::CAP_MAX, 'auto-parallel' ); } catch ( \Throwable $e ) { break; }
			}
		}
		$pick = self::pick_tile();
		if ( ! $pick ) { return; }
		list( $ind, $area, $key, $reason ) = $pick;
		$cover = get_option( 'tnc_lh_cover', array() ); if ( ! is_array( $cover ) ) { $cover = array(); }
		$cover[ $key ] = time(); update_option( 'tnc_lh_cover', $cover, false );
		update_option( 'tnc_lh_core', array( 'industry' => $ind, 'area' => $area, 'reason' => $reason, 'ts' => time() ), false );
		$log = array( 'fired' => time(), 'industry' => $ind, 'area' => $area, 'reason' => $reason );
		try {
			$res = self::run_hunt( $ind, $area, self::CAP_MAX, 'auto' );
			if ( is_wp_error( $res ) ) {
				$msg = $res->get_error_message();
				$log['status'] = ( false !== stripos( $msg, '504' ) || false !== stripos( $msg, 'no parseable' ) ) ? 'throttled' : 'error';
				$log['note']   = $msg;
			} else {
				$log['found']  = (int) $res['found'];
				$log['staged'] = (int) $res['staged'];
				$log['status'] = $res['found'] > 0 ? ( $res['staged'] > 0 ? 'active' : 'all_dupes' ) : 'sparse';
				if ( $res['staged'] > 0 ) { update_option( 'tnc_lh_last_success', time(), false ); }
			}
		} catch ( \Throwable $e ) {
			$log['status'] = 'error';
			$log['note']   = $e->getMessage();
			update_option( 'tnc_watchdog_err', 'lh_loop: ' . $e->getMessage(), false );
		}
		update_option( 'tnc_lh_loop', $log, false );

		// SELF-HEAL ALERT: auto ON, target unmet, but no successful stage in 45 min
		// across attempts -> loud alert once (loop is firing but starving).
		$ls = (int) get_option( 'tnc_lh_last_success', 0 );
		$flagged = (int) get_option( 'tnc_lh_loop_alerted', 0 );
		if ( $ls && ( time() - $ls ) > 2700 && ! $flagged ) {
			update_option( 'tnc_lh_loop_alerted', time(), false );
			$to = TNC_Settings::recipients( 'system' );
			if ( empty( $to ) ) { $to = array( 'mike@lionclickmedia.com' ); }
			TNC_Emails::send( $to, '[TuaniChat] Lead Hunter loop starving',
				'<p>The always-on hunting loop is firing but has staged no new leads in 45+ min. Likely the public-map (Overpass) rate limit — resolves when the self-hosted map import runs. Loop is still attempting; no action needed unless it persists.</p>', 'transactional' );
		} elseif ( $ls && ( time() - $ls ) < 2700 && $flagged ) {
			update_option( 'tnc_lh_loop_alerted', 0, false );
		}
	}

	/** Loop health for the dashboard core-status strip. */
	public static function loop_health() {
		$cfg  = self::settings();
		$log  = get_option( 'tnc_lh_loop', array() );
		$log  = is_array( $log ) ? $log : array();
		$fired = isset( $log['fired'] ) ? (int) $log['fired'] : 0;
		$age   = $fired ? time() - $fired : null;
		$on    = ! empty( $cfg['auto'] );
		$state = ! $on ? 'off' : ( self::qualified_today() >= (int) $cfg['target'] ? 'target_met'
			: ( isset( $log['status'] ) ? $log['status'] : 'starting' ) );
		return array(
			'on'          => $on ? 1 : 0,
			'state'       => $state,
			'last_fired'  => $fired,
			'age'         => $age,
			'last_area'   => isset( $log['area'] ) ? ( $log['area'] . ' / ' . ( isset( $log['industry'] ) ? $log['industry'] : '' ) ) : '',
			'last_found'  => isset( $log['found'] ) ? (int) $log['found'] : null,
			'last_staged' => isset( $log['staged'] ) ? (int) $log['staged'] : null,
			// healthy = on AND fired within ~12 min (heartbeat is alive + loop running).
			'healthy'     => $on ? ( $age !== null && $age < 720 ? 1 : 0 ) : 1,
		);
	}


	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_action( 'wp_ajax_tnc_lh_export', array( __CLASS__, 'export_xlsx' ) );
		add_action( 'tnc_lh_daily_audit', array( __CLASS__, 'cron_audit' ) );
		if ( ! wp_next_scheduled( 'tnc_lh_daily_audit' ) ) {
			wp_schedule_event( time() + 300, 'daily', 'tnc_lh_daily_audit' );
		}
		add_action( 'tnc_lh_recover', array( __CLASS__, 'cron_recover' ) );
		if ( ! wp_next_scheduled( 'tnc_lh_recover' ) ) {
			wp_schedule_event( time() + 600, 'hourly', 'tnc_lh_recover' );
		}
	}

	public static function routes() {
		$perm = function () { return current_user_can( 'manage_options' ); };
		register_rest_route( TNC_REST_NS, '/admin/lh-hunt', array(
			'methods' => 'POST', 'callback' => array( __CLASS__, 'hunt' ), 'permission_callback' => $perm,
		) );
		register_rest_route( TNC_REST_NS, '/admin/lh-status', array(
			'methods' => 'GET', 'callback' => array( __CLASS__, 'status' ), 'permission_callback' => $perm,
		) );
		register_rest_route( TNC_REST_NS, '/admin/lh-audit-contacts', array(
			'methods' => 'POST', 'callback' => array( __CLASS__, 'audit_contacts' ), 'permission_callback' => $perm,
		) );
		register_rest_route( TNC_REST_NS, '/admin/lh-settings', array(
			'methods' => 'POST', 'callback' => array( __CLASS__, 'save_settings' ), 'permission_callback' => $perm,
		) );
		register_rest_route( TNC_REST_NS, '/admin/lh-target', array(
			'methods' => 'POST', 'callback' => array( __CLASS__, 'set_target' ), 'permission_callback' => $perm,
		) );
		register_rest_route( TNC_REST_NS, '/admin/lh-ticker', array(
			'methods' => 'GET', 'callback' => array( __CLASS__, 'ticker' ), 'permission_callback' => function () { return current_user_can( 'manage_options' ); },
		) );
		register_rest_route( TNC_REST_NS, '/admin/lh-list', array(
			'methods' => 'GET', 'callback' => array( __CLASS__, 'list_rows' ), 'permission_callback' => $perm,
		) );
		register_rest_route( TNC_REST_NS, '/admin/lh-poi-status', array(
			'methods' => array( 'GET', 'POST' ), 'callback' => array( __CLASS__, 'poi_status' ), 'permission_callback' => $perm,
		) );
		register_rest_route( TNC_REST_NS, '/admin/lh-recover', array(
			'methods' => 'POST', 'callback' => array( __CLASS__, 'recover' ), 'permission_callback' => $perm,
		) );
		register_rest_route( TNC_REST_NS, '/admin/lh-geo', array(
			'methods' => 'GET', 'callback' => array( __CLASS__, 'geo' ), 'permission_callback' => $perm,
		) );
	}

	/**
	 * Local POI-DB status + on-demand probe. GET returns last-known count/age.
	 * POST (or ?probe=1) enqueues a tiny poi_query so the fleet reports the live
	 * total — this is how the brain learns the DB is populated and auto-switches
	 * discovery to the local adapter. The probe never touches the brain DB.
	 */
	public static function poi_status( $req = null ) {
		$do_probe = $req && ( 'POST' === $req->get_method() || $req->get_param( 'probe' ) );
		$queued   = false;
		if ( $do_probe && self::fleet_v2() ) {
			$queued = (bool) TNC_Fleet::enqueue( 'poi_query', array(
				'cats' => array(), 'bbox' => array(), 'limit' => 1,
				'probe' => 1, 'industry' => '', 'area' => '', 'cap' => 0, 'origin' => 'probe',
			), 8 );
			update_option( 'tnc_poi_last_probe', time(), false );
		}
		$poi = get_option( 'tnc_poi_status', array() );
		$poi = is_array( $poi ) ? $poi : array();
		$ts  = isset( $poi['ts'] ) ? (int) $poi['ts'] : 0;
		return rest_ensure_response( array(
			'ok'        => true,
			'ready'     => self::local_ready(),
			'mode'      => ( self::settings()['discovery'] ?? 'auto' ),
			'count'     => isset( $poi['count'] ) ? (int) $poi['count'] : 0,
			'age_sec'   => $ts ? ( time() - $ts ) : null,
			'last_q'    => isset( $poi['last_q'] ) ? (int) $poi['last_q'] : null,
			'probe_queued' => $queued,
			'fleet_v2'  => self::fleet_v2(),
			'diag'      => TNC_Fleet::recent_jobs( 'poi_query', 2 ),
			'shot_diag' => TNC_Fleet::recent_jobs( 'shot', 3 ),
			'crawl_diag'=> TNC_Fleet::recent_jobs( 'sitecrawl', 2 ),
			'caps'      => array( 'shot' => (int) get_option( 'tnc_cap_shot', 0 ), 'sitecrawl' => (int) get_option( 'tnc_cap_sitecrawl', 0 ) ),
		) );
	}

	/** Self-bootstrap: when status is unknown/stale, fire one probe per hour. */
	private static function maybe_probe_poi() {
		$cfg  = self::settings();
		$mode = $cfg['discovery'] ?? 'auto';
		if ( 'overpass' === $mode || ! self::fleet_v2() ) {
			return;
		}
		$poi = get_option( 'tnc_poi_status', array() );
		$ts  = is_array( $poi ) && isset( $poi['ts'] ) ? (int) $poi['ts'] : 0;
		$known_fresh = $ts && ( time() - $ts ) < HOUR_IN_SECONDS;
		if ( $known_fresh ) {
			return;
		}
		$last = (int) get_option( 'tnc_poi_last_probe', 0 );
		if ( $last && ( time() - $last ) < HOUR_IN_SECONDS ) {
			return; // already probed recently.
		}
		update_option( 'tnc_poi_last_probe', time(), false );
		TNC_Fleet::enqueue( 'poi_query', array(
			'cats' => array(), 'bbox' => array(), 'limit' => 1,
			'probe' => 1, 'industry' => '', 'area' => '', 'cap' => 0, 'origin' => 'probe',
		), 8 );
	}

	/* ---------------------------------------------------------- state -- */

	private static function state() {
		$s = get_option( 'tnc_lh_state', array() );
		return is_array( $s ) ? $s : array();
	}

	private static function set_state( $patch ) {
		update_option( 'tnc_lh_state', array_merge( self::state(), $patch ), false );
	}

	/* ------------------------------------------------ industry mapping -- */

	/** Overpass selectors + an optional name-keyword bonus regex per industry. */
	private static function industry_map() {
		return array(
			'med_spa'         => array( 'sel' => array( '["shop"="beauty"]', '["leisure"="spa"]', '["healthcare"="clinic"]' ), 'kw' => '(med\s?spa|medspa|aesthetic|laser|skin|botox|rejuven|derma)' ),
			'dental'          => array( 'sel' => array( '["amenity"="dentist"]', '["healthcare"="dentist"]' ), 'kw' => '(dental|dentist|orthodont|smile)' ),
			'personal_injury' => array( 'sel' => array( '["office"="lawyer"]' ), 'kw' => '(injury|accident|trial)' ),
			'law_general'     => array( 'sel' => array( '["office"="lawyer"]' ), 'kw' => '(law|legal|attorney)' ),
			'plastic_surgery' => array( 'sel' => array( '["healthcare"="clinic"]', '["healthcare"="doctor"]' ), 'kw' => '(plastic|cosmetic|surger|aesthetic)' ),
			'roofing'         => array( 'sel' => array( '["craft"="roofer"]' ), 'kw' => '(roof)' ),
			'hvac'            => array( 'sel' => array( '["craft"="hvac"]' ), 'kw' => '(hvac|heating|cooling|air)' ),
		);
	}

	/** Affluence tiers — affluence-first territory rule. Lowercase contains-match. */
	private static function territory_tier( $area ) {
		$a    = strtolower( $area );
		$tier3 = array( 'beverly hills', 'bel air', 'malibu', 'calabasas', 'newport beach', 'la jolla', 'palo alto', 'atherton', 'greenwich', 'scarsdale', 'scottsdale', 'paradise valley', 'naples', 'boca raton', 'palm beach', 'aspen', 'manhattan beach', 'santa monica', 'beverly glen', 'brentwood', 'westlake village', 'coral gables', 'winnetka', 'highland park', 'river oaks', 'buckhead', 'georgetown', 'back bay', 'pacific heights', 'medina', 'cherry hills' );
		foreach ( $tier3 as $t ) {
			if ( false !== strpos( $a, $t ) ) {
				return 3;
			}
		}
		return 2; // user targets affluent areas by design; default mid tier.
	}

	/* ------------------------------------------------------- discovery -- */

	private static function http( $url, $args = array() ) {
		return wp_remote_get( $url, array_merge( array(
			'timeout'    => 25,
			'user-agent' => 'TuaniLeadHunter/1.0 (+https://tuanilabs.com; business discovery)',
			'sslverify'  => true,
		), $args ) );
	}

	/** Nominatim: area name -> Overpass area id (relation 36e9+, way 24e8+). */
	private static function geocode_area( $area ) {
		$r = self::http( 'https://nominatim.openstreetmap.org/search?format=json&limit=1&q=' . rawurlencode( $area ) );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		$j = json_decode( wp_remote_retrieve_body( $r ), true );
		if ( empty( $j[0]['osm_type'] ) || empty( $j[0]['osm_id'] ) ) {
			return new WP_Error( 'tnc_lh', 'Area not found: ' . $area );
		}
		$id = (int) $j[0]['osm_id'];
		if ( 'relation' === $j[0]['osm_type'] ) {
			return 3600000000 + $id;
		}
		if ( 'way' === $j[0]['osm_type'] ) {
			return 2400000000 + $id;
		}
		return new WP_Error( 'tnc_lh', 'Area is a node, not a boundary: ' . $area );
	}

	/** One Overpass query for the whole hunt (anti-flagging: single request). */
	private static function overpass( $area_id, $industry ) {
		$map = self::industry_map();
		if ( ! isset( $map[ $industry ] ) ) {
			return new WP_Error( 'tnc_lh', 'Industry not mapped for discovery: ' . $industry );
		}
		$sels = '';
		foreach ( $map[ $industry ]['sel'] as $sel ) {
			$sels .= 'nwr' . $sel . '(area.hunt);';
		}
		$q = '[out:json][timeout:40];area(' . (int) $area_id . ')->.hunt;(' . $sels . ');out center tags 120;';
		$r = wp_remote_post( 'https://overpass-api.de/api/interpreter', array(
			'timeout'    => 45,
			'user-agent' => 'TuaniLeadHunter/1.0 (+https://tuanilabs.com; business discovery)',
			'body'       => array( 'data' => $q ),
		) );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		$j = json_decode( wp_remote_retrieve_body( $r ), true );
		if ( ! is_array( $j ) || ! isset( $j['elements'] ) ) {
			return new WP_Error( 'tnc_lh', 'Overpass returned no parseable data (HTTP ' . wp_remote_retrieve_response_code( $r ) . ')' );
		}
		return $j['elements'];
	}

	/**
	 * Domains that are NEVER a prospect's own site (franchises, socials,
	 * aggregators, link tools). OSM often mis-tags these onto local-business
	 * nodes (e.g. a nail salon tagged website=subway.com). Such a 'site' is not
	 * theirs -> we null it so it can't be shown OR used to qualify.
	 */
	public static function bad_domain( $host ) {
		$host = preg_replace( '/^www\./', '', strtolower( (string) $host ) );
		$bad = array(
			'subway.com','mcdonalds.com','starbucks.com','dominos.com','pizzahut.com','tacobell.com','wendys.com','burgerking.com','dunkindonuts.com','kfc.com','chipotle.com','7-eleven.com','walmart.com','target.com','cvs.com','walgreens.com','ulta.com','sephora.com','greatclips.com','supercuts.com','regis.com','massageenvy.com','europeanwax.com','amazinglashstudio.com',
			'facebook.com','m.facebook.com','instagram.com','linktr.ee','linktree.com','yelp.com','tripadvisor.com','booksy.com','vagaro.com','fresha.com','square.site','squareup.com','wixsite.com','business.site','google.com','goo.gl','bit.ly','linkedin.com','twitter.com','x.com','tiktok.com','youtube.com','wa.me',
		);
		if ( in_array( $host, $bad, true ) ) {
			return true;
		}
		foreach ( $bad as $b ) {
			if ( substr( $host, -( strlen( $b ) + 1 ) ) === '.' . $b ) {
				return true;
			}
		}
		return false;
	}

	private static function norm_domain( $url ) {
		$h = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
		return preg_replace( '/^www\./', '', $h );
	}

	private static function norm_phone( $p ) {
		$d = preg_replace( '/\D+/', '', (string) $p );
		return strlen( $d ) >= 10 ? substr( $d, -10 ) : $d;
	}

	/* ------------------------------------------------------------ hunt -- */

	public static function hunt( $req ) {
		$industry = sanitize_key( $req->get_param( 'industry' ) );
		$area     = sanitize_text_field( (string) $req->get_param( 'area' ) );
		$cap      = max( 5, min( self::CAP_MAX, (int) $req->get_param( 'cap' ) ?: 30 ) );
		if ( '' === $area ) {
			return new WP_Error( 'tnc_lh', 'Target area is required.', array( 'status' => 400 ) );
		}
		$res = self::run_hunt( $industry, $area, $cap, 'manual' );
		return is_wp_error( $res ) ? $res : rest_ensure_response( $res );
	}

	/** Core discovery runner — used by the manual endpoint AND the always-on loop. */
	public static function run_hunt( $industry, $area, $cap, $origin = 'manual' ) {
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 180 );
		}
		$cap = max( 5, min( self::CAP_MAX, (int) $cap ) );
		$st  = self::state();
		if ( ! empty( $st['hunting'] ) && ( time() - (int) $st['ts'] ) < 600 ) {
			return new WP_Error( 'tnc_lh', 'A hunt is already running.', array( 'status' => 409 ) );
		}
		if ( ! isset( self::industry_map()[ $industry ] ) ) {
			return new WP_Error( 'tnc_lh', 'Industry not mapped for discovery: ' . $industry );
		}

		// Self-bootstrap: learn whether the fleet POI DB is live (cheap, hourly).
		self::maybe_probe_poi();

		// PRIORITY #1 — LOCAL-MAP DISCOVERY ADAPTER. When the self-hosted POI DB
		// is live on the fleet, discover from it (zero external API, no rate
		// limits, no flagging) instead of Overpass. Falls back to Overpass
		// automatically when local mode is unavailable or dispatch fails.
		if ( self::local_ready() ) {
			$res = self::discover_local( $industry, $area, $cap, $origin );
			if ( ! is_wp_error( $res ) ) {
				return $res;
			}
			// Local dispatch failed -> fall through to Overpass so the hunt still runs.
		}

		$area_id = self::geocode_area( $area );
		if ( is_wp_error( $area_id ) ) {
			return $area_id;
		}
		$elements = self::overpass( $area_id, $industry );
		if ( is_wp_error( $elements ) ) {
			return $elements;
		}

		$batch  = 'lh' . gmdate( 'ymdHis' );
		$tier   = self::territory_tier( $area );
		$seen   = self::build_seen();
		$counts = self::stage_candidates( $elements, $industry, $area, $cap, $batch, $tier, $seen );

		return self::finalize_hunt( $batch, $industry, $area, $tier, count( $elements ), $counts, $origin );
	}

	/* --------------------------------------- shared staging pipeline -- */

	/** Existing-data dedupe sets (4-key: domain / phone / name+city / osm). */
	private static function build_seen() {
		global $wpdb;
		$rows = $wpdb->get_results( 'SELECT website_url, contact_phone, company_name, city FROM ' . TNC_Prospects::table(), ARRAY_A );
		$seen = array( 'dom' => array(), 'ph' => array(), 'nc' => array(), 'osm' => array() );
		foreach ( (array) $rows as $r ) {
			if ( $r['website_url'] ) { $seen['dom'][ self::norm_domain( $r['website_url'] ) ] = 1; }
			if ( $r['contact_phone'] ) { $seen['ph'][ self::norm_phone( $r['contact_phone'] ) ] = 1; }
			$seen['nc'][ strtolower( trim( $r['company_name'] ) . '|' . trim( $r['city'] ) ) ] = 1;
		}
		return $seen;
	}

	/**
	 * Stage OSM-shaped candidates through the ONE dedupe -> create -> enrich
	 * pipeline. Both the Overpass path and the local POI-DB path feed here, so
	 * every lead — wherever discovered — gets identical 4-key dedupe,
	 * franchise-URL stripping, and fleet enrichment. Returns staged/dupes/skipped.
	 *
	 * @param array $elements OSM shape: array(type,id,tags{name,website,phone,addr:*},lat,lon|center,src).
	 * @param array $seen     dedupe sets, by reference: dom/ph/nc/osm.
	 */
	private static function stage_candidates( $elements, $industry, $area, $cap, $batch, $tier, &$seen ) {
		$map = self::industry_map();
		$kw  = isset( $map[ $industry ]['kw'] ) ? $map[ $industry ]['kw'] : '';
		$staged = 0; $dupes = 0; $skipped = 0;
		foreach ( (array) $elements as $el ) {
			if ( $staged >= $cap ) {
				break;
			}
			$t = isset( $el['tags'] ) ? $el['tags'] : array();
			$name = isset( $t['name'] ) ? trim( $t['name'] ) : '';
			if ( '' === $name ) { $skipped++; continue; }
			$site = isset( $t['website'] ) ? $t['website'] : ( isset( $t['contact:website'] ) ? $t['contact:website'] : '' );
			if ( $site && self::bad_domain( (string) wp_parse_url( $site, PHP_URL_HOST ) ) ) { $site = ''; } // drop franchise/social/aggregator URLs.
			$phone = isset( $t['phone'] ) ? $t['phone'] : ( isset( $t['contact:phone'] ) ? $t['contact:phone'] : '' );
			if ( '' === $site && '' === $phone ) { $skipped++; continue; } // nothing to contact or verify.
			$city  = isset( $t['addr:city'] ) ? $t['addr:city'] : $area;
			$state = isset( $t['addr:state'] ) ? strtoupper( substr( $t['addr:state'], 0, 4 ) ) : '';
			$osm   = ( isset( $el['type'] ) ? $el['type'] : 'node' ) . '/' . ( isset( $el['id'] ) ? $el['id'] : '' );

			// 4-KEY DEDUPE — never double-add.
			$dom = $site ? self::norm_domain( $site ) : '';
			$ph  = self::norm_phone( $phone );
			$nc  = strtolower( $name . '|' . trim( $city ) );
			if ( isset( $seen['osm'][ $osm ] ) || ( $dom && isset( $seen['dom'][ $dom ] ) ) || ( $ph && isset( $seen['ph'][ $ph ] ) ) || isset( $seen['nc'][ $nc ] ) ) {
				$dupes++;
				continue;
			}
			$seen['osm'][ $osm ] = 1;
			if ( $dom ) { $seen['dom'][ $dom ] = 1; }
			if ( $ph )  { $seen['ph'][ $ph ] = 1; }
			$seen['nc'][ $nc ] = 1;

			$kw_hit = $kw && preg_match( '/' . $kw . '/i', $name );
			$id = TNC_Prospects::create( array(
				'company_name'  => $name,
				'website_url'   => $site,
				'industry'      => $industry,
				'contact_phone' => $phone,
				'status'        => 'new',
			) );
			if ( is_wp_error( $id ) ) { continue; }
			$src = ( isset( $el['src'] ) && 'poi' === $el['src'] ) ? 'poi_db' : 'overpass';
			TNC_Prospects::update( $id, array(
				'city'       => sanitize_text_field( $city ),
				'state_abbr' => sanitize_text_field( $state ),
				'source'     => 'lead_hunter',
				'batch_id'   => $batch,
				'crawl_data' => wp_json_encode( array( 'lh' => array(
					'osm' => $osm, 'tier' => $tier, 'kw' => $kw_hit ? 1 : 0,
					'lat' => isset( $el['lat'] ) ? $el['lat'] : ( isset( $el['center']['lat'] ) ? $el['center']['lat'] : null ),
					'lon' => isset( $el['lon'] ) ? $el['lon'] : ( isset( $el['center']['lon'] ) ? $el['center']['lon'] : null ),
					'enrich' => 'pending', 'site_ok' => null, 'chat' => null, 'disc' => $src,
				) ) ),
			) );
			TNC_Prospects::audit( $id, 'Discovered via ' . ( 'poi_db' === $src ? 'local POI DB' : 'Overpass' ) . ' (' . $osm . ') in ' . $area . ' [tier ' . $tier . ']', 'discovery', 'verified' );
			// FLEET: v2 agents do FULL enrichment (Pass 1-2, $0 code) off-brain;
			// v1 agents site-verify via probe while the brain enriches.
			if ( $site ) {
				if ( self::fleet_v2() ) {
					TNC_Fleet::enqueue( 'enrich', array(
						'url' => esc_url_raw( $site ), 'prospect' => $id,
						'sigs' => array_keys( TNC_Crawler::chat_signatures() ),
					), 6 );
				} else {
					TNC_Fleet::enqueue( 'probe', array( 'url' => esc_url_raw( $site ), 'prospect' => $id ) );
				}
			}
			$staged++;
		}
		return array( 'staged' => $staged, 'dupes' => $dupes, 'skipped' => $skipped );
	}

	/** Set hunt state, kick the per-batch worker, return the standard result. */
	private static function finalize_hunt( $batch, $industry, $area, $tier, $found, $counts, $origin ) {
		$staged  = (int) $counts['staged'];
		$dupes   = (int) $counts['dupes'];
		$skipped = (int) $counts['skipped'];
		// Close the Intelligence Core learning loop with the real outcome.
		if ( 'auto' === $origin ) {
			self::record_tile( $industry . '|' . $area, array( 'found' => $found, 'staged' => $staged, 'dupes' => $dupes ) );
		}
		self::set_state( array(
			'hunting' => true, 'batch' => $batch, 'industry' => $industry, 'area' => $area,
			'tier' => $tier, 'found' => $found, 'staged' => $staged, 'dupes' => $dupes,
			'skipped' => $skipped, 'enriched' => 0, 'fails' => 0, 'error' => '', 'ts' => time(), 'origin' => $origin,
		) );
		TNC_Workers::spawn( 'lh', array( 'batch' => $batch ) );
		return array( 'ok' => true, 'batch' => $batch, 'found' => $found, 'staged' => $staged, 'dupes' => $dupes, 'skipped' => $skipped, 'origin' => $origin );
	}

	/* ------------------------------------ local POI-DB discovery (#1) -- */

	/** Local-map discovery enabled AND the fleet POI DB confirmed populated? */
	public static function local_ready() {
		$cfg  = self::settings();
		$mode = isset( $cfg['discovery'] ) ? $cfg['discovery'] : 'auto';
		if ( 'overpass' === $mode ) {
			return false; // operator forced external discovery.
		}
		$poi   = get_option( 'tnc_poi_status', array() );
		$count = is_array( $poi ) && isset( $poi['count'] ) ? (int) $poi['count'] : 0;
		$ts    = is_array( $poi ) && isset( $poi['ts'] ) ? (int) $poi['ts'] : 0;
		$fresh = $ts && ( time() - $ts ) < 7 * DAY_IN_SECONDS;
		if ( 'local' === $mode ) {
			return $count > 0; // forced local — trust last known count.
		}
		return $count > 0 && $fresh; // auto — local only when DB is live & fresh.
	}

	/**
	 * OSM tag selectors -> POI-DB category filters. The POI extract stores a
	 * normalized 'cat' column (key=value, e.g. amenity=dentist) so the worker
	 * filters with a cheap IN() list plus a bbox window — no geometry math.
	 */
	private static function poi_category_map() {
		return array(
			'med_spa'         => array( 'shop=beauty', 'leisure=spa', 'healthcare=clinic' ),
			'dental'          => array( 'amenity=dentist', 'healthcare=dentist' ),
			'personal_injury' => array( 'office=lawyer' ),
			'law_general'     => array( 'office=lawyer' ),
			'plastic_surgery' => array( 'healthcare=cosmetic_surgery', 'healthcare=clinic', 'healthcare=doctor' ),
			'roofing'         => array( 'craft=roofer' ),
			'hvac'            => array( 'craft=hvac' ),
		);
	}

	/** Nominatim bounding box for an area -> [south,north,west,east]. */
	private static function area_bbox( $area ) {
		$r = self::http( 'https://nominatim.openstreetmap.org/search?format=json&limit=1&q=' . rawurlencode( $area ) );
		if ( is_wp_error( $r ) ) { return $r; }
		$j = json_decode( wp_remote_retrieve_body( $r ), true );
		if ( empty( $j[0]['boundingbox'] ) || count( $j[0]['boundingbox'] ) < 4 ) {
			return new WP_Error( 'tnc_lh', 'No bounding box for area: ' . $area );
		}
		$bb = $j[0]['boundingbox']; // strings: [south, north, west, east].
		return array( 'south' => (float) $bb[0], 'north' => (float) $bb[1], 'west' => (float) $bb[2], 'east' => (float) $bb[3] );
	}

	/**
	 * Dispatch a local POI-DB discovery job to the fleet. The worker queries
	 * /opt/tuanichat-osm/poi.db (ISOLATED — never touches the brain DB) and
	 * returns OSM-shaped rows, which ingest_poi_result() runs through the shared
	 * staging pipeline. Async by design: discovery never blocks the brain.
	 */
	private static function discover_local( $industry, $area, $cap, $origin ) {
		if ( ! self::fleet_v2() ) {
			return new WP_Error( 'tnc_lh', 'Local discovery needs v2 fleet agents.' );
		}
		$cats = self::poi_category_map();
		if ( empty( $cats[ $industry ] ) ) {
			return new WP_Error( 'tnc_lh', 'Industry not mapped for local discovery: ' . $industry );
		}
		$bbox = self::area_bbox( $area );
		if ( is_wp_error( $bbox ) ) {
			return $bbox; // caller falls back to Overpass.
		}
		$batch = 'lh' . gmdate( 'ymdHis' );
		$tier  = self::territory_tier( $area );
		$key   = TNC_Fleet::enqueue( 'poi_query', array(
			'cats'  => $cats[ $industry ],
			'bbox'  => $bbox,
			'limit' => max( $cap * 3, 120 ), // over-fetch; dedupe/gate trims it.
			'batch' => $batch, 'industry' => $industry, 'area' => $area,
			'cap'   => $cap, 'origin' => $origin, 'tier' => $tier,
		), 7 );
		if ( ! $key ) {
			return new WP_Error( 'tnc_lh', 'Could not enqueue local discovery job.' );
		}
		// Mark discovering so the loop/UI shows activity until results land.
		self::set_state( array(
			'hunting' => true, 'batch' => $batch, 'industry' => $industry, 'area' => $area,
			'tier' => $tier, 'found' => 0, 'staged' => 0, 'dupes' => 0, 'skipped' => 0,
			'enriched' => 0, 'fails' => 0, 'error' => '', 'ts' => time(), 'origin' => $origin, 'phase' => 'poi_query',
		) );
		return array( 'ok' => true, 'batch' => $batch, 'found' => 0, 'staged' => 0, 'dupes' => 0, 'skipped' => 0, 'origin' => $origin, 'mode' => 'local', 'dispatched' => true );
	}

	/**
	 * Ingest fleet POI-DB query results: convert rows -> OSM-element shape and
	 * run the SHARED staging pipeline (identical dedupe/gate/enrich as Overpass).
	 * Called from TNC_Fleet::store_result when a poi_query job completes.
	 */
	/**
	 * EXTERNAL-SOURCE INGEST (CertStream CT-log daemon + licensing-board fetchers).
	 * Runs fresh leads through the SAME dedupe -> create -> enrich pipeline with
	 * source provenance. freshly_launched (day-0) leads jump the enrich queue.
	 */
	public static function ingest_external( $items, $source, $req = null ) {
		global $wpdb;
		$seen = self::build_seen();
		$batch = 'ext' . gmdate( 'ymdHis' );
		$staged = 0; $dupes = 0; $skipped = 0; $fresh_n = 0;
		$recent = array();
		foreach ( (array) $items as $it ) {
			if ( ! is_array( $it ) ) { continue; }
			$name  = isset( $it['name'] ) ? trim( wp_strip_all_tags( (string) $it['name'] ) ) : '';
			$site  = isset( $it['website'] ) ? esc_url_raw( (string) $it['website'] ) : '';
			$email = isset( $it['email'] ) ? strtolower( trim( (string) $it['email'] ) ) : '';
			$phone = isset( $it['phone'] ) ? sanitize_text_field( (string) $it['phone'] ) : '';
			$city  = isset( $it['city'] ) ? sanitize_text_field( (string) $it['city'] ) : '';
			$state = isset( $it['state'] ) ? strtoupper( substr( preg_replace( '/[^A-Za-z]/', '', (string) $it['state'] ), 0, 2 ) ) : '';
			$ind   = isset( $it['industry'] ) ? sanitize_key( (string) $it['industry'] ) : 'local_services';
			$fresh = ! empty( $it['freshly_launched'] );
			if ( $site && self::bad_domain( (string) wp_parse_url( $site, PHP_URL_HOST ) ) ) { $site = ''; }
			if ( '' === $name && $site ) { $name = preg_replace( '/^www\./', '', (string) wp_parse_url( $site, PHP_URL_HOST ) ); }
			if ( '' === $name || ( '' === $site && '' === $phone && '' === $email ) ) { $skipped++; continue; }
			$dom = $site ? self::norm_domain( $site ) : '';
			$ph  = self::norm_phone( $phone );
			$nc  = strtolower( $name . '|' . trim( $city ) );
			if ( ( $dom && isset( $seen['dom'][ $dom ] ) ) || ( $ph && isset( $seen['ph'][ $ph ] ) ) || isset( $seen['nc'][ $nc ] ) ) { $dupes++; continue; }
			if ( $dom ) { $seen['dom'][ $dom ] = 1; } if ( $ph ) { $seen['ph'][ $ph ] = 1; } $seen['nc'][ $nc ] = 1;
			$valid_email = ( $email && ! self::is_placeholder_email( $email ) && self::valid_email( $email ) );
			$id = TNC_Prospects::create( array(
				'company_name'  => $name,
				'website_url'   => $site,
				'industry'      => $ind,
				'contact_phone' => $phone,
				'status'        => 'new',
			) );
			if ( is_wp_error( $id ) ) { continue; }
			$upd = array(
				'city'       => $city,
				'state_abbr' => $state,
				'source'     => 'lead_hunter',
				'batch_id'   => $batch,
				'crawl_data' => wp_json_encode( array( 'lh' => array(
					'disc' => $source, 'freshly_launched' => $fresh ? 1 : 0,
					'ext_ts' => isset( $it['ts'] ) ? (int) $it['ts'] : time(),
					'enrich' => 'pending', 'site_ok' => null, 'chat' => null, 'tier' => self::territory_tier( $city ),
				) ) ),
			);
			if ( $valid_email ) { $upd['contact_email'] = $email; }
			TNC_Prospects::update( $id, $upd );
			TNC_Prospects::audit( $id, 'Discovered via ' . $source . ( $fresh ? ' (FRESHLY LAUNCHED — day-0)' : '' ) . ( $city ? ' in ' . $city . ', ' . $state : '' ), 'discovery', 'verified' );
			if ( $site ) {
				// DAY-0 PRIORITY: fresh launches jump the enrich queue (7) ahead of normal (6).
				TNC_Fleet::enqueue( 'enrich', array( 'url' => $site, 'prospect' => $id, 'sigs' => array_keys( TNC_Crawler::chat_signatures() ) ), $fresh ? 7 : 6 );
			}
			if ( $fresh && count( $recent ) < 30 ) {
				$recent[] = array( 'domain' => $dom ? $dom : $name, 'industry' => $ind, 'city' => $city, 'state' => $state, 'ts' => time() );
			}
			$staged++; if ( $fresh ) { $fresh_n++; }
		}
		// Per-source counters + stream health for the Fresh-Launch Radar.
		$ex = get_option( 'tnc_lh_extsrc', array() ); if ( ! is_array( $ex ) ) { $ex = array(); }
		$cur = isset( $ex[ $source ] ) && is_array( $ex[ $source ] ) ? $ex[ $source ] : array( 'total' => 0, 'day' => array(), 'hour' => array(), 'min' => array(), 'recent' => array() );
		$now = current_time( 'timestamp' );
		$dk = gmdate( 'Ymd', $now ); $hk = (int) floor( $now / 3600 ); $mk = (int) floor( $now / 60 );
		$cur['total']    = (int) $cur['total'] + $staged;
		$cur['day'][ $dk ]  = ( isset( $cur['day'][ $dk ] ) ? (int) $cur['day'][ $dk ] : 0 ) + $staged;
		$cur['hour'][ $hk ] = ( isset( $cur['hour'][ $hk ] ) ? (int) $cur['hour'][ $hk ] : 0 ) + $staged;
		$cur['min'][ $mk ]  = ( isset( $cur['min'][ $mk ] ) ? (int) $cur['min'][ $mk ] : 0 ) + $staged;
		$cur['last_ts']  = time();
		if ( $req ) {
			$cs = $req->get_param( 'certs_seen' ); if ( null !== $cs ) { $cur['certs_seen'] = (int) $cs; }
			$mt = $req->get_param( 'matched' );    if ( null !== $mt ) { $cur['matched'] = (int) $mt; }
		}
		if ( $recent ) { $cur['recent'] = array_slice( array_merge( $recent, isset( $cur['recent'] ) ? $cur['recent'] : array() ), 0, 30 ); }
		// prune old buckets
		foreach ( array( 'hour', 'min' ) as $b ) { if ( count( $cur[ $b ] ) > 200 ) { $cur[ $b ] = array_slice( $cur[ $b ], -200, null, true ); } }
		$ex[ $source ] = $cur;
		update_option( 'tnc_lh_extsrc', $ex, false );
		return array( 'staged' => $staged, 'dupes' => $dupes, 'skipped' => $skipped, 'fresh' => $fresh_n );
	}

	/** Fresh-Launch Radar summary (ct-stream + any external source). */
	public static function fresh_radar() {
		$ex = get_option( 'tnc_lh_extsrc', array() ); if ( ! is_array( $ex ) ) { $ex = array(); }
		$now = current_time( 'timestamp' );
		$out = array( 'sources' => array() );
		foreach ( $ex as $src => $c ) {
			$dk = gmdate( 'Ymd', $now ); $hk = (int) floor( $now / 3600 ); $mk = (int) floor( $now / 60 );
			$last = isset( $c['last_ts'] ) ? (int) $c['last_ts'] : 0;
			$age  = $last ? ( time() - $last ) : null;
			$health = ( null === $age ) ? 'never' : ( $age < 120 ? 'connected' : ( $age < 900 ? 'reconnecting' : 'down' ) );
			$cs = isset( $c['certs_seen'] ) ? (int) $c['certs_seen'] : 0; $mt = isset( $c['matched'] ) ? (int) $c['matched'] : 0;
			$ind = array();
			foreach ( (array) ( $c['recent'] ?? array() ) as $r ) { $k = $r['industry'] ?? 'other'; $ind[ $k ] = ( $ind[ $k ] ?? 0 ) + 1; }
			arsort( $ind );
			$out['sources'][ $src ] = array(
				'today' => (int) ( $c['day'][ $dk ] ?? 0 ),
				'hour'  => (int) ( $c['hour'][ $hk ] ?? 0 ),
				'minute'=> (int) ( $c['min'][ $mk ] ?? 0 ),
				'total' => (int) ( $c['total'] ?? 0 ),
				'health'=> $health, 'age_sec' => $age,
				'certs_seen' => $cs, 'matched' => $mt,
				'filter_pct' => $cs > 0 ? round( 100 * $mt / $cs ) : null,
				'industries' => array_slice( $ind, 0, 6, true ),
				'recent' => array_slice( (array) ( $c['recent'] ?? array() ), 0, 12 ),
			);
		}
		return $out;
	}

	public static function ingest_poi_result( $payload, $data ) {
		$payload  = is_array( $payload ) ? $payload : array();
		$rows     = ( is_array( $data ) && isset( $data['rows'] ) && is_array( $data['rows'] ) ) ? $data['rows'] : array();
		$industry = isset( $payload['industry'] ) ? sanitize_key( $payload['industry'] ) : '';
		$area     = isset( $payload['area'] ) ? sanitize_text_field( $payload['area'] ) : '';
		$cap      = isset( $payload['cap'] ) ? (int) $payload['cap'] : self::CAP_MAX;
		$batch    = isset( $payload['batch'] ) ? sanitize_text_field( $payload['batch'] ) : ( 'lh' . gmdate( 'ymdHis' ) );
		$tier     = isset( $payload['tier'] ) ? (int) $payload['tier'] : self::territory_tier( $area );
		$origin   = isset( $payload['origin'] ) ? sanitize_key( $payload['origin'] ) : 'auto';

		// Record POI-DB liveness/size for local_ready() (worker reports total).
		if ( is_array( $data ) && isset( $data['db_total'] ) ) {
			update_option( 'tnc_poi_status', array(
				'count'  => (int) $data['db_total'], 'ts' => time(),
				'last_q' => count( $rows ), 'area' => $area, 'industry' => $industry,
			), false );
		}

		// A probe only learns db_total — it does NOT stage or hold hunt state.
		if ( ! empty( $payload['probe'] ) || 'probe' === $origin ) {
			return array( 'ok' => true, 'probe' => true, 'db_total' => is_array( $data ) ? (int) ( $data['db_total'] ?? 0 ) : 0 );
		}

		$elements = array();
		foreach ( $rows as $r ) {
			if ( ! is_array( $r ) ) { continue; }
			$tags = array( 'name' => isset( $r['name'] ) ? $r['name'] : '' );
			if ( ! empty( $r['website'] ) ) { $tags['website'] = $r['website']; }
			if ( ! empty( $r['phone'] ) )   { $tags['phone'] = $r['phone']; }
			if ( ! empty( $r['city'] ) )    { $tags['addr:city'] = $r['city']; }
			if ( ! empty( $r['state'] ) )   { $tags['addr:state'] = $r['state']; }
			$elements[] = array(
				'type' => isset( $r['osm_type'] ) ? $r['osm_type'] : 'node',
				'id'   => isset( $r['osm_id'] ) ? $r['osm_id'] : '',
				'tags' => $tags,
				'lat'  => isset( $r['lat'] ) ? $r['lat'] : null,
				'lon'  => isset( $r['lon'] ) ? $r['lon'] : null,
				'src'  => 'poi',
			);
		}
		$seen   = self::build_seen();
		$counts = self::stage_candidates( $elements, $industry, $area, $cap, $batch, $tier, $seen );
		return self::finalize_hunt( $batch, $industry, $area, $tier, count( $elements ), $counts, $origin );
	}

	/** Fleet v2 agents (enrich-capable) heartbeating within the last 10 min? */
	private static function fleet_v2() {
		$t = (int) get_option( 'tnc_fleet_agent_v2', 0 );
		return $t && ( time() - $t ) < 600;
	}

	/* ---------------------------------------------------- enrich ticks -- */

	public static function tick( $batch ) {
		$st = self::state();
		if ( empty( $st['batch'] ) || $st['batch'] !== $batch ) {
			return;
		}
		$rows = TNC_Prospects::query( array( 'batch' => $batch ) );
		$todo = array();
		foreach ( $rows as $p ) {
			$lh = self::lh( $p );
			if ( isset( $lh['enrich'] ) && 'pending' === $lh['enrich'] ) {
				$todo[] = $p;
			}
		}
		if ( ! $todo ) {
			self::set_state( array( 'hunting' => false ) );
			return;
		}
		$n = 0;
		foreach ( $todo as $p ) {
			if ( $n++ >= self::TICK_BATCH ) {
				break;
			}
			// V2 PATH: defer to the fleet ONLY while it actually has jobs in flight
			// for this batch. If the fleet queue is idle (0 queued + 0 running) the
			// result isn't coming -> brain-enrich now (no infinite wait / stuck state).
			if ( self::fleet_v2() && ( time() - (int) self::state()['ts'] ) < 120 ) {
				$fl = TNC_Fleet::status();
				$inflight = ( isset( $fl['jobs']['queued'] ) ? (int) $fl['jobs']['queued'] : 0 ) + ( isset( $fl['jobs']['running'] ) ? (int) $fl['jobs']['running'] : 0 );
				if ( $inflight > 0 ) {
					continue; // fleet is working it — let push-ingest land the result.
				}
			}
			$ok = self::enrich_one( $p );
			$st = self::state();
			$fails = $ok ? 0 : (int) $st['fails'] + 1;
			self::set_state( array( 'enriched' => (int) $st['enriched'] + 1, 'fails' => $fails, 'ts' => time() ) );
			if ( $fails >= self::BREAKER_FAILS ) {
				// FAIL-FAST circuit breaker: stop loudly, never grind on.
				self::set_state( array( 'hunting' => false, 'error' => 'Circuit breaker: ' . self::BREAKER_FAILS . ' consecutive enrich failures — hunt stopped.' ) );
				return;
			}
		}
		// Re-check remaining pending; only respawn if work truly remains. Hard
		// staleness ceiling finalizes the hunt so 'hunting' can never stick.
		$still = 0;
		foreach ( TNC_Prospects::query( array( 'batch' => $batch ) ) as $pp ) {
			$l = self::lh( $pp );
			if ( isset( $l['enrich'] ) && 'pending' === $l['enrich'] ) { $still++; }
		}
		$age = time() - (int) self::state()['ts'];
		if ( $still > 0 && $age < 300 ) {
			sleep( 2 );
			TNC_Workers::spawn( 'lh', array( 'batch' => $batch ) );
		} else {
			self::set_state( array( 'hunting' => false ) );
		}
	}

	private static function lh( $p ) {
		return is_array( $p['crawl_data'] ) && isset( $p['crawl_data']['lh'] ) ? $p['crawl_data']['lh'] : array();
	}

	private static function enrich_one( $p ) {
		$lh   = self::lh( $p );
		$site = $p['website_url'];
		$cd   = is_array( $p['crawl_data'] ) ? $p['crawl_data'] : array();
		$html = '';
		$ok   = true;

		if ( $site ) {
			// Per-host politeness even though hunt domains are distinct.
			$hostkey = 'tnc_lh_host_' . md5( self::norm_domain( $site ) );
			if ( get_transient( $hostkey ) ) {
				sleep( 2 );
			}
			set_transient( $hostkey, 1, 5 );
			$r = self::http( $site, array( 'timeout' => 18, 'redirection' => 3 ) );
			if ( ! is_wp_error( $r ) && (int) wp_remote_retrieve_response_code( $r ) < 400 ) {
				$html = (string) wp_remote_retrieve_body( $r );
			} else {
				$ok = false;
			}
		}

		// Contacts from the homepage.
		$email = '';
		$email_q = '';
		if ( $html ) {
			$cands = array();
			if ( preg_match_all( '/mailto:([a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,})/i', $html, $mm ) ) {
				$cands = array_merge( $cands, $mm[1] );
			}
			if ( preg_match_all( '/\b([a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,})\b/i', $html, $mm ) ) {
				$cands = array_merge( $cands, $mm[1] );
			}
			list( $email, $email_q ) = TNC_Prospects::rank_email( array_unique( $cands ) );
			if ( ! $p['contact_phone'] && preg_match( '/href=["\']tel:([+0-9().\s-]{7,20})/i', $html, $tm ) ) {
				TNC_Prospects::update( $p['id'], array( 'contact_phone' => trim( $tm[1] ) ) );
				$p['contact_phone'] = trim( $tm[1] );
			}
		}

		// Platform + Chat Detection v5 (render-truth via code: JS + GTM containers).
		$platform = '';
		$chat     = array( 'provider' => '', 'type' => 'none', 'grade' => 'none', 'confidence' => 'needs_review' );
		if ( $html ) {
			$c        = new TNC_Crawler();
			$platform = $c->detect_platform( $html, $site );
			$verdict  = TNC_Crawler::redetect_chat( $site );
			if ( ! is_wp_error( $verdict ) ) {
				$chat = $verdict;
			}
		}

		// Fleet probe verdict (the 40 workers fetch in parallel; read result).
		$site_ok = $html ? true : null;
		foreach ( get_option( 'tnc_fleet_jobs', array() ) as $j ) {
			if ( isset( $j['payload']['prospect'] ) && (int) $j['payload']['prospect'] === (int) $p['id'] && 'done' === $j['status'] && is_array( $j['result'] ) ) {
				$http    = isset( $j['result']['http'] ) ? (int) $j['result']['http'] : 0;
				$site_ok = ( $http >= 200 && $http < 400 && ! empty( $j['result']['bytes'] ) && $j['result']['bytes'] > 500 );
			}
		}

		// SCORE 0-100: territory-value + chat-absence + fit.
		$tier = isset( $lh['tier'] ) ? (int) $lh['tier'] : 2;
		$bd   = array();
		$s    = 0;
		$add  = function ( $pts, $label, $hit ) use ( &$s, &$bd ) {
			if ( $hit ) { $s += $pts; $bd[] = array( 'label' => $label, 'points' => $pts ); }
		};
		$add( 8 * $tier, 'Territory value tier ' . $tier, true );
		$add( 25, 'No chat detected — greenfield', 'none' === $chat['type'] );
		$add( 12, 'Basic chat only (' . $chat['provider'] . ') — displacement', 'none' !== $chat['type'] && 'basic' === $chat['grade'] );
		$add( 4,  'AI chat in place (' . $chat['provider'] . ')', 'none' !== $chat['type'] && 'ai' === $chat['grade'] );
		$add( 15, 'Easy-install platform (' . $platform . ')', in_array( $platform, array( 'wordpress', 'shopify' ), true ) );
		$add( 5,  'Platform detected (' . $platform . ')', $platform && ! in_array( $platform, array( 'wordpress', 'shopify' ), true ) );
		$add( 10, 'Email found on site', (bool) $email );
		$add( 8,  'Phone available', (bool) $p['contact_phone'] );
		$add( 10, 'Site verified live' . ( null === $site_ok ? '' : ( $site_ok ? ' (fleet+brain)' : '' ) ), true === $site_ok );
		$add( 4,  'Industry keyword in name', ! empty( $lh['kw'] ) );
		$s = max( 0, min( 100, $s ) );

		$cd['lh'] = array_merge( $lh, array(
			'enrich'  => 'done',
			'site_ok' => $site_ok,
			'chat'    => $chat['provider'] ? $chat['provider'] : ( 'none' === $chat['type'] ? 'none' : 'custom' ),
			'email_q' => $email_q,
		) );
		if ( ! isset( $cd['extracted'] ) || ! is_array( $cd['extracted'] ) ) {
			$cd['extracted'] = array();
		}
		$cd['extracted']['chat_widget']     = $chat['provider'];
		$cd['extracted']['chat_type']       = $chat['type'];
		$cd['extracted']['chat_grade']      = $chat['grade'];
		$cd['extracted']['chat_confidence'] = $chat['confidence'];

		TNC_Prospects::update( $p['id'], array(
			'platform'        => $platform,
			'score'           => $s,
			'contact_email'   => $email,
			'crawl_data'      => wp_json_encode( $cd ),
			'score_breakdown' => wp_json_encode( $bd ),
		) );
		TNC_Prospects::audit( $p['id'], 'Lead Hunter enrich: ' . ( $email ? 'email ' : '' ) . ( $platform ? $platform . ' ' : '' ) . 'chat=' . ( $chat['provider'] ? $chat['provider'] : 'none' ) . ' score=' . $s, 'lead_hunter', $chat['confidence'] );
		self::evaluate_promote( $p['id'] );
		return $ok;
	}

	/**
	 * PUSH-BASED INGEST (fleet v2): a worker's enrich result lands here straight
	 * from the fleet result endpoint — the brain does zero fetching.
	 */
	public static function ingest_enrich_result( $prospect_id, $d ) {
		$p = TNC_Prospects::get( $prospect_id );
		if ( ! $p ) {
			return;
		}
		// SURVIVOR NAME-SEARCH RESULT: the fleet searched "business name + city"
		// and returned candidate official sites. Adopt the top non-directory hit
		// and immediately queue REAL enrichment (contact pages + mailto scrape)
		// against it — turning a no-website OSM row into a qualifiable lead.
		if ( ! empty( $d['namesearch'] ) ) {
			$links = isset( $d['links'] ) && is_array( $d['links'] ) ? $d['links'] : array();
			$site  = '';
			foreach ( $links as $L ) {
				$h = strtolower( (string) wp_parse_url( $L, PHP_URL_HOST ) );
				if ( $h && ! self::bad_domain( $h ) ) { $site = esc_url_raw( $L ); break; }
			}
			$cdn = is_array( $p['crawl_data'] ) ? $p['crawl_data'] : array();
			if ( $site && empty( $p['website_url'] ) ) {
				$cdn['lh']['via_namesearch'] = 1;
				TNC_Prospects::update( $prospect_id, array( 'website_url' => $site, 'crawl_data' => wp_json_encode( $cdn ) ) );
				TNC_Prospects::audit( $prospect_id, 'Name-search found official site: ' . $site . ' — queuing email enrichment', 'lead_hunter', 'verified' );
				$base = untrailingslashit( $site );
				foreach ( array( '', '/contact', '/contact-us', '/about' ) as $pp ) {
					TNC_Fleet::enqueue( 'enrich', array( 'url' => $base . $pp, 'prospect' => $prospect_id, 'deep' => 1, 'sigs' => array_keys( TNC_Crawler::chat_signatures() ) ), 4 );
				}
				update_option( 'tnc_lh_ns_found', (int) get_option( 'tnc_lh_ns_found', 0 ) + 1, false );
			} else {
				$cdn['lh']['ns_done'] = 1;
				TNC_Prospects::update( $prospect_id, array( 'crawl_data' => wp_json_encode( $cdn ) ) );
			}
			return;
		}
		$lh = self::lh( $p );
		// PHONE CAPTURE (future call-center channel): keep the first phone we see.
		if ( empty( $p['contact_phone'] ) && ! empty( $d['phones'] ) && is_array( $d['phones'] ) ) {
			TNC_Prospects::update( $prospect_id, array( 'contact_phone' => sanitize_text_field( (string) $d['phones'][0] ) ) );
		}
		// TRIPLE VALIDATION layer 3: every newly-scraped email gets an SMTP probe.
		if ( ! empty( $d['emails'] ) && is_array( $d['emails'] ) && empty( $p['contact_email'] ) ) {
			$cand = strtolower( trim( (string) $d['emails'][0] ) );
			if ( $cand && self::valid_email( $cand ) ) {
				TNC_Fleet::enqueue( 'everify', array( 'email' => $cand, 'prospect' => $prospect_id ), 4 );
			}
		}
		if ( isset( $lh['enrich'] ) && 'done' === $lh['enrich'] ) {
			return; // already enriched (brain fallback may have raced the fleet).
		}
		$cd = is_array( $p['crawl_data'] ) ? $p['crawl_data'] : array();

		$http    = isset( $d['http'] ) ? (int) $d['http'] : 0;
		$site_ok = $http >= 200 && $http < 400 && ! empty( $d['bytes'] ) && $d['bytes'] > 500;
		$email   = '';
		$email_q = '';
		if ( ! empty( $d['emails'] ) && is_array( $d['emails'] ) ) {
			list( $email, $email_q ) = TNC_Prospects::rank_email( $d['emails'] );
		}
		// RECOVERY fallback: nothing scraped, but recovery proposed a conservative
		// on-domain role address (info@/contact@) that passed junk + MX checks.
		if ( '' === $email && ! empty( $lh['email_guess'] ) && ! self::is_placeholder_email( $lh['email_guess'] ) && self::valid_email( $lh['email_guess'] ) ) {
			$email   = $lh['email_guess'];
			$email_q = 'role_on_domain';
		}
		if ( ! $p['contact_phone'] && ! empty( $d['phones'][0] ) ) {
			TNC_Prospects::update( $p['id'], array( 'contact_phone' => sanitize_text_field( $d['phones'][0] ) ) );
			$p['contact_phone'] = $d['phones'][0];
		}
		$platform = isset( $d['platform'] ) ? sanitize_key( $d['platform'] ) : '';

		// Chat verdict from the worker's signature scan.
		$sigs = TNC_Crawler::chat_signatures();
		$chat = array( 'provider' => '', 'type' => 'none', 'grade' => 'none', 'confidence' => 'needs_review' );
		if ( ! empty( $d['chat_sig'] ) && isset( $sigs[ $d['chat_sig'] ] ) ) {
			$info = $sigs[ $d['chat_sig'] ];
			$chat = array( 'provider' => $info[0], 'type' => 'provider', 'grade' => $info[1], 'confidence' => 'verified_present' );
		} elseif ( isset( $d['chat_markers'] ) && (int) $d['chat_markers'] >= 4 ) {
			$chat = array( 'provider' => 'Custom chat widget', 'type' => 'custom', 'grade' => 'basic', 'confidence' => 'verified_present' );
		} elseif ( isset( $d['chat_markers'] ) && (int) $d['chat_markers'] >= 2 ) {
			$chat = array( 'provider' => 'Custom chat widget', 'type' => 'custom', 'grade' => 'basic', 'confidence' => 'possible' );
		}

		$tier = isset( $lh['tier'] ) ? (int) $lh['tier'] : 2;
		$bd   = array();
		$sc   = 0;
		$add  = function ( $pts, $label, $hit ) use ( &$sc, &$bd ) {
			if ( $hit ) { $sc += $pts; $bd[] = array( 'label' => $label, 'points' => $pts ); }
		};
		$add( 8 * $tier, 'Territory value tier ' . $tier, true );
		$add( 25, 'No chat detected — greenfield', 'none' === $chat['type'] );
		$add( 12, 'Basic chat only (' . $chat['provider'] . ') — displacement', 'none' !== $chat['type'] && 'basic' === $chat['grade'] );
		$add( 4,  'AI chat in place (' . $chat['provider'] . ')', 'none' !== $chat['type'] && 'ai' === $chat['grade'] );
		$add( 15, 'Easy-install platform (' . $platform . ')', in_array( $platform, array( 'wordpress', 'shopify' ), true ) );
		$add( 5,  'Platform detected (' . $platform . ')', $platform && ! in_array( $platform, array( 'wordpress', 'shopify' ), true ) );
		$add( 10, 'Email found on site', (bool) $email );
		$add( 8,  'Phone available', (bool) $p['contact_phone'] );
		$add( 10, 'Site verified live (fleet)', $site_ok );
		$add( 4,  'Industry keyword in name', ! empty( $lh['kw'] ) );
		$sc = max( 0, min( 100, $sc ) );

		$cd['lh'] = array_merge( $lh, array(
			'enrich'  => 'done',
			'site_ok' => $site_ok,
			'chat'    => $chat['provider'] ? $chat['provider'] : ( 'none' === $chat['type'] ? 'none' : 'custom' ),
			'email_q' => $email_q,
			'via'     => 'fleet_v2',
		) );
		if ( ! isset( $cd['extracted'] ) || ! is_array( $cd['extracted'] ) ) {
			$cd['extracted'] = array();
		}
		$cd['extracted']['chat_widget']     = $chat['provider'];
		$cd['extracted']['chat_type']       = $chat['type'];
		$cd['extracted']['chat_grade']      = $chat['grade'];
		$cd['extracted']['chat_confidence'] = $chat['confidence'];

		TNC_Prospects::update( $p['id'], array(
			'platform'        => $platform,
			'score'           => $sc,
			'contact_email'   => $email,
			'crawl_data'      => wp_json_encode( $cd ),
			'score_breakdown' => wp_json_encode( $bd ),
		) );
		TNC_Prospects::audit( $p['id'], 'Fleet v2 enrich: ' . ( $email ? 'email ' : '' ) . ( $platform ? $platform . ' ' : '' ) . 'chat=' . ( $chat['provider'] ? $chat['provider'] : 'none' ) . ' score=' . $sc, 'lead_hunter', $chat['confidence'] );
		self::evaluate_promote( $p['id'] );
		$st = self::state();
		if ( ! empty( $st['batch'] ) && $st['batch'] === $p['batch_id'] ) {
			self::set_state( array( 'enriched' => (int) $st['enriched'] + 1, 'ts' => time() ) );
		}
	}

	/* -------------------------------------------------- status / list -- */

	public static function set_target( $req ) {
		$t = max( 50, min( 100000, (int) $req->get_param( 'target' ) ) );
		update_option( 'tnc_lh_target', $t, false );
		return rest_ensure_response( array( 'ok' => true, 'target' => $t ) );
	}

	/** Command-center stats: totals, today, live rates, pass/fill, fleet. */
	public static function status( $req ) {
		global $wpdb;
		$cfg = self::settings();
		$tbl   = TNC_Prospects::table();
		$nowts = current_time( 'timestamp' );      // WP site-local epoch.
		$today = gmdate( 'Y-m-d 00:00:00', $nowts ); // site-local midnight (created_at is site-local).
		$total     = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $tbl WHERE source = 'lead_hunter'" );
		$promoted  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $tbl WHERE source = 'lead_hunter' AND status <> 'new'" );
		$in_hunter = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $tbl WHERE source = 'lead_hunter' AND status = 'new'" );
		$funnel = array( 'enriching' => 0, 'discovered' => 0, 'unqualified' => 0, 'awaiting' => 0, 'promoted' => $promoted );
		foreach ( (array) $wpdb->get_col( "SELECT crawl_data FROM $tbl WHERE source = 'lead_hunter' AND status = 'new'" ) as $cdj ) {
			$cd2 = $cdj ? json_decode( $cdj, true ) : array();
			$lh2 = is_array( $cd2 ) && isset( $cd2['lh'] ) ? $cd2['lh'] : array();
			$enr = isset( $lh2['enrich'] ) ? $lh2['enrich'] : 'pending';
			$stg = isset( $lh2['stage'] ) ? $lh2['stage'] : '';
			if ( 'qualified_pending' === $stg ) { $funnel['awaiting']++; }
			elseif ( 'unqualified' === $stg || 'excluded' === $stg ) { $funnel['unqualified']++; }
			elseif ( 'pending' === $enr ) { $funnel['enriching']++; }
			else { $funnel['discovered']++; }
		}
		$fleet_q = $wpdb->prefix . 'tnc_fleet_jobs';
		$qd = array( 'queued' => 0, 'leased' => 0, 'done' => 0, 'dead' => 0 );
		foreach ( (array) $wpdb->get_results( "SELECT status, COUNT(*) n FROM $fleet_q GROUP BY status", ARRAY_A ) as $r ) {
			if ( isset( $qd[ $r['status'] ] ) ) { $qd[ $r['status'] ] = (int) $r['n']; }
		}
		$cap_w   = isset( $fleet['workers_total'] ) ? max( 1, (int) $fleet['workers_total'] ) : 40;
		$backlog = $qd['queued'] > ( $cap_w * 3 );
		$eta_min = $qd['queued'] > 0 ? (int) ceil( $qd['queued'] / max( 1, $cap_w * 0.5 ) / 60 ) : 0;
		$today_n = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $tbl WHERE source = 'lead_hunter' AND created_at >= %s", $today ) );
		// Qualified (MVP definition until the gate ships): enriched with a website + (email OR phone).
		$qual_today = 0; $fill = 0; $enriched_today = 0;
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT contact_email, contact_phone, website_url, crawl_data FROM $tbl WHERE source = 'lead_hunter' AND created_at >= %s", $today ), ARRAY_A );
		foreach ( (array) $rows as $r ) {
			$cd = $r['crawl_data'] ? json_decode( $r['crawl_data'], true ) : array();
			$done = is_array( $cd ) && isset( $cd['lh']['enrich'] ) && 'done' === $cd['lh']['enrich'];
			if ( $done ) {
				$enriched_today++;
				if ( $r['contact_email'] || $r['contact_phone'] ) {
					$fill++;
				}
			}
			if ( $r['website_url'] && ( $r['contact_email'] || $r['contact_phone'] ) ) {
				$qual_today++;
			}
		}
		$hour_n = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $tbl WHERE source = 'lead_hunter' AND created_at >= %s", gmdate( 'Y-m-d H:i:s', $nowts - 3600 ) ) );
		$min_n  = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $tbl WHERE source = 'lead_hunter' AND created_at >= %s", gmdate( 'Y-m-d H:i:s', $nowts - 600 ) ) );
		$fleet  = TNC_Fleet::status();
		$st     = self::state();
		return rest_ensure_response( array(
			'ok'    => true,
			'state' => $st,
			'stats' => array(
				'total'        => $total,
				'staged_today' => $today_n,
				'qual_today'   => $qual_today,
				'per_min'      => round( $min_n / 10, 2 ), // 10-min window rate.
				'per_hour'     => $hour_n,
				'target'       => (int) $cfg['target'],
				'in_hunter'    => $in_hunter,
				'promoted'     => $promoted,
				'discovered'   => $total,
				'qual_today'   => self::qualified_today(),
				'auto'         => (int) $cfg['auto'],
				'loop'         => self::loop_health(),
				'core'         => array( 'hunter' => ( ! empty( $cfg['auto'] ) ? 'hunting' : 'idle' ), 'fleet' => ( isset( $fleet['workers_total'] ) ? (int) $fleet['workers_total'] : 0 ), 'email' => 'ready' ),
				'funnel'       => $funnel,
				'queue'        => array( 'queued' => $qd['queued'], 'running' => $qd['leased'], 'done' => $qd['done'], 'dead' => $qd['dead'], 'backlog' => $backlog, 'eta_min' => $eta_min ),
				'min_score'    => (int) $cfg['min_score'],
				'require'      => $cfg['require'],
				'paused'       => (int) ! empty( $cfg['promote_paused'] ),
				'consistency'  => array(
					'qual_le_staged' => $qual_today <= $today_n,
					'promoted_le_total' => $promoted <= $total,
				),
				'pass_rate'    => ! empty( $st['found'] ) ? round( 100 * $st['staged'] / max( 1, $st['found'] ) ) : null,
				'fill_rate'    => $enriched_today ? round( 100 * $fill / $enriched_today ) : null,
				'fleet_workers'=> isset( $fleet['workers_total'] ) ? $fleet['workers_total'] : 0,
				'fleet_running'=> isset( $fleet['jobs']['running'] ) ? $fleet['jobs']['running'] : 0,
				'fleet_queued' => isset( $fleet['jobs']['queued'] ) ? $fleet['jobs']['queued'] : 0,
				'fleet_util'   => ( isset( $fleet['workers_total'] ) && (int) $fleet['workers_total'] > 0 ) ? min( 100, (int) round( 100 * ( (int) ( $fleet['jobs']['running'] ?? 0 ) ) / max( 1, (int) $fleet['workers_total'] ) ) ) : 0,
				'recovered'    => (int) get_option( 'tnc_lh_recovered', 0 ),
				'ns_found'     => (int) get_option( 'tnc_lh_ns_found', 0 ),
				'deep_crawled' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM " . TNC_Prospects::table() . " WHERE source='lead_hunter' AND crawl_data LIKE '%\"deep_crawled\":1%'" ),
				'qph'          => self::promoted_last_hour(),
				'territory'    => self::territory_intel(),
				'coverage_gaps'=> get_option( 'tnc_lh_gaps', array() ),
				'ind_yield'    => get_option( 'tnc_lh_indyield', array() ),
				'render_mix'   => self::render_mix(),
				'fresh_radar'  => self::fresh_radar(),
				'freshness'    => self::freshness(),
				'pivot'        => get_option( 'tnc_lh_pivot', array() ),
				'systems'      => self::systems_health(),
				'source_yield' => self::source_yield(),
				'everify'      => get_option( 'tnc_everify_stats', array() ),
				'email_funnel' => self::email_funnel(),
				'fleet_build'  => defined( 'TNC_Fleet::FLEET_BUILD' ) || class_exists( 'TNC_Fleet' ) ? TNC_Fleet::FLEET_BUILD : '',
				'update_log'   => array_reverse( array_slice( (array) get_option( 'tnc_fleet_updatelog', array() ), -8 ) ),
			),
		) );
	}

	/** LEAD HUNTER HEARTBEAT GUARDIAN — discovery must NEVER pause. Runs off
	 * fleet heartbeats (throttled 60s). A paused/stalled loop is a CRITICAL
	 * condition: it gets force-restarted immediately and the event is logged. */
	public static function guardian_tick() {
		$last = (int) get_option( 'tnc_lh_guard_last', 0 );
		if ( time() - $last < 60 ) { return; }
		update_option( 'tnc_lh_guard_last', time(), false );
		$g = (array) get_option( 'tnc_lh_guard', array( 'restarts' => 0, 'state' => 'ok' ) );
		$cfg = self::settings();
		if ( empty( $cfg['auto'] ) ) {
			// PAUSED = CRITICAL. Auto-resume: the loop never stays off.
			$so = get_option( 'tnc_lh_settings', array() ); if ( ! is_array( $so ) ) { $so = array(); }
			$so['auto'] = 1; update_option( 'tnc_lh_settings', $so, false );
			$g['state'] = 'auto-resumed'; $g['restarts'] = (int) $g['restarts'] + 1; $g['ts'] = time();
			update_option( 'tnc_lh_guard', $g, false );
			update_option( 'tnc_fleet_updatelog', array_slice( array_merge( (array) get_option( 'tnc_fleet_updatelog', array() ), array( array( 'ts' => time(), 'node' => 'lh-guardian', 'event' => 'auto-resumed-paused-loop', 'from' => 'paused', 'to' => 'hunting' ) ) ), -40 ), false );
			return;
		}
		$loop_age = time() - (int) get_option( 'tnc_lh_loop_last', 0 );
		$st = self::state();
		$stuck_hunt = ! empty( $st['hunting'] ) && ( time() - (int) $st['ts'] ) > 900;
		if ( $loop_age > 300 || $stuck_hunt ) {
			if ( $stuck_hunt ) { $st['hunting'] = 0; update_option( 'tnc_lh_state', $st, false ); }
			update_option( 'tnc_lh_loop_last', time() - self::LOOP_EVERY - 1, false ); // clear throttle without zeroing the heartbeat.
			try { self::loop_tick(); } catch ( \Throwable $e ) { update_option( 'tnc_watchdog_err', 'guardian_restart: ' . $e->getMessage(), false ); }
			$g['state'] = 'restarted'; $g['restarts'] = (int) $g['restarts'] + 1; $g['ts'] = time();
			update_option( 'tnc_lh_guard', $g, false );
			update_option( 'tnc_fleet_updatelog', array_slice( array_merge( (array) get_option( 'tnc_fleet_updatelog', array() ), array( array( 'ts' => time(), 'node' => 'lh-guardian', 'event' => 'loop-restarted', 'from' => $loop_age . 's-stale', 'to' => 'hunting' ) ) ), -40 ), false );
		} else {
			$g['state'] = 'ok'; $g['ts'] = time(); update_option( 'tnc_lh_guard', $g, false );
		}
		// OUTCOME WATCH (continuous — every guardian pass): staging flows but
		// promotion at zero for 30+ min => force the pending sweep + log.
		try {
			$fr2 = self::freshness();
			if ( $fr2['last_1h'] > 0 && 0 === $fr2['promoted_1h'] && ( null === $fr2['mins_since_promoted'] || $fr2['mins_since_promoted'] >= 30 ) ) {
				$n3 = self::promote_pending_tick( 100 );
				update_option( 'tnc_fleet_updatelog', array_slice( array_merge( (array) get_option( 'tnc_fleet_updatelog', array() ), array( array( 'ts' => time(), 'node' => 'lh-guardian', 'event' => 'promotion-stall-remediated', 'from' => '0/1h', 'to' => $n3 . ' re-evaluated' ) ) ), -40 ), false );
			}
		} catch ( \Throwable $e ) { update_option( 'tnc_watchdog_err', 'outcome_guard: ' . $e->getMessage(), false ); }
	}

	/** TRIPLE-VALIDATION verdict: score the email; hard-550 kills guesses. */
	public static function ingest_everify_result( $d ) {
		$pid = isset( $d['prospect'] ) ? (int) $d['prospect'] : 0;
		$em  = isset( $d['email'] ) ? strtolower( (string) $d['email'] ) : '';
		$v   = isset( $d['everify'] ) ? (string) $d['everify'] : 'unknown';
		if ( ! $pid || ! $em ) { return; }
		$p = TNC_Prospects::get( $pid ); if ( ! $p ) { return; }
		$cd = is_array( $p['crawl_data'] ) ? $p['crawl_data'] : array();
		// score: 1 syntax (it queued) + 1 MX (valid_email passed) + 1 SMTP ok.
		$score = 2 + ( 'ok' === $v ? 1 : 0 );
		$cd['lh']['everify'] = array( 'email' => $em, 'verdict' => $v, 'score' => $score, 'ts' => time() );
		$upd = array( 'crawl_data' => wp_json_encode( $cd ) );
		if ( 'no' === $v ) {
			// hard bounce: never accept; if it IS the current contact, clear it
			// (guesses die here; scraped emails fall back to next pass).
			if ( strtolower( (string) $p['contact_email'] ) === $em ) { $upd['contact_email'] = ''; }
			$cnt = (array) get_option( 'tnc_everify_stats', array() ); $cnt['no'] = (int)($cnt['no']??0)+1; update_option( 'tnc_everify_stats', $cnt, false );
		} else {
			if ( empty( $p['contact_email'] ) && 'ok' === $v ) { $upd['contact_email'] = $em; }
			$cnt = (array) get_option( 'tnc_everify_stats', array() ); $cnt[ $v ] = (int)($cnt[$v]??0)+1; update_option( 'tnc_everify_stats', $cnt, false );
		}
		TNC_Prospects::update( $pid, $upd );
	}

	/** FRESHNESS TRUTH: rows staged last hour/6h + minutes since the LAST row —
	 * the anti-flatline metric (day totals accumulate and can hide a dead loop). */
	public static function freshness() {
		global $wpdb;
		$t = TNC_Prospects::table();
		$r = $wpdb->get_row(
			"SELECT SUM(created_at >= DATE_SUB(UTC_TIMESTAMP(), INTERVAL 1 HOUR)) h1,
			 SUM(created_at >= DATE_SUB(UTC_TIMESTAMP(), INTERVAL 6 HOUR)) h6,
			 SUM(created_at >= DATE_SUB(UTC_TIMESTAMP(), INTERVAL 24 HOUR)) h24,
			 MAX(created_at) last_at, MAX(id) max_id FROM $t WHERE source = 'lead_hunter'", ARRAY_A );
		$mins = null;
		if ( ! empty( $r['last_at'] ) ) { $mins = (int) floor( ( time() - strtotime( $r['last_at'] . ' UTC' ) ) / 60 ); }
		// PROMOTED production (from the lh.promoted_at stamp — DB-truth).
		$ph1 = 0; $plast = null;
		$prows = $wpdb->get_col( "SELECT crawl_data FROM $t WHERE source='lead_hunter' AND status IN ('demo_created','demo_sent','engaged','won') AND crawl_data LIKE '%promoted_at%' ORDER BY id DESC LIMIT 300" );
		foreach ( (array) $prows as $cdj ) {
			if ( preg_match( '/"promoted_at":(\d+)/', (string) $cdj, $mm ) ) {
				$pa = (int) $mm[1];
				if ( $pa > time() - HOUR_IN_SECONDS ) { $ph1++; }
				if ( null === $plast || $pa > $plast ) { $plast = $pa; }
			}
		}
		return array( 'last_1h' => (int) ( $r['h1'] ?? 0 ), 'last_6h' => (int) ( $r['h6'] ?? 0 ), 'last_24h' => (int) ( $r['h24'] ?? 0 ), 'mins_since_last' => $mins, 'max_id' => (int) ( $r['max_id'] ?? 0 ), 'flatline' => ( null === $mins || $mins > 30 ),
			'promoted_1h' => $ph1, 'mins_since_promoted' => null === $plast ? null : (int) floor( ( time() - $plast ) / 60 ) );
	}

	/** SYSTEMS HEALTH (guardian view): every loop/daemon, last-seen vs cadence. */
	public static function systems_health() {
		$nodes = (array) get_option( 'tnc_fleet_nodes', array() );
		$now = time(); $out = array();
		$expect = array(
			'lic-hunter' => DAY_IN_SECONDS + 3600, 'ct-hunter' => 2 * HOUR_IN_SECONDS,
			'guardian' => DAY_IN_SECONDS + 3600,
		);
		foreach ( $nodes as $name => $n ) {
			$seen = is_array( $n ) && isset( $n['last_seen'] ) ? (int) $n['last_seen'] : 0;
			$meta = is_array( $n ) && isset( $n['meta'] ) ? (string) $n['meta'] : '';
			$cad  = 300; // workers/updater beat every <=5 min.
			foreach ( $expect as $k => $vv ) { if ( 0 === strpos( (string) $name, $k ) ) { $cad = $vv; } }
			$out[ $name ] = array( 'last_seen_s' => $seen ? $now - $seen : null, 'meta' => $meta, 'ok' => $seen && ( $now - $seen ) < $cad );
		}
		// brain loops:
		$lp = (array) get_option( 'tnc_lh_recover', array() );
		$out['recovery-loop'] = array( 'last_seen_s' => isset($lp['ts']) ? $now - (int)$lp['ts'] : null, 'meta' => 'picked ' . (int)($lp['picked']??0), 'ok' => isset($lp['ts']) && ( $now - (int)$lp['ts'] ) < 2 * HOUR_IN_SECONDS );
		$ff = (array) get_option( 'tnc_lh_fleetfill', array() );
		$out['idle-fleet-loop'] = array( 'last_seen_s' => isset($ff['ts']) ? $now - (int)$ff['ts'] : null, 'meta' => 'inflight ' . (int)($ff['inflight']??0), 'ok' => isset($ff['ts']) && ( $now - (int)$ff['ts'] ) < 30 * MINUTE_IN_SECONDS );
		$fr = self::freshness();
		$out['net-new-staging'] = array( 'last_seen_s' => null === $fr['mins_since_last'] ? null : $fr['mins_since_last'] * 60, 'meta' => $fr['last_1h'] . '/1h ' . $fr['last_6h'] . '/6h', 'ok' => ! $fr['flatline'] );
		$out['prospect-production'] = array( 'last_seen_s' => null === $fr['mins_since_promoted'] ? null : $fr['mins_since_promoted'] * 60, 'meta' => $fr['promoted_1h'] . ' promoted/1h', 'ok' => $fr['promoted_1h'] > 0 || $fr['last_1h'] === 0 || ( null !== $fr['mins_since_promoted'] && $fr['mins_since_promoted'] < 30 ) );
		$ll = (int) get_option( 'tnc_lh_loop_last', 0 );
		$gg = (array) get_option( 'tnc_lh_guard', array() );
		$cfg0 = self::settings();
		$out['lead-hunter-loop'] = array( 'last_seen_s' => $ll ? $now - $ll : null, 'meta' => empty( $cfg0['auto'] ) ? 'PAUSED (CRITICAL)' : 'hunting', 'ok' => ! empty( $cfg0['auto'] ) && $ll && ( $now - $ll ) < 300 );
		$out['lh-guardian'] = array( 'last_seen_s' => isset( $gg['ts'] ) ? $now - (int) $gg['ts'] : null, 'meta' => (string) ( $gg['state'] ?? '' ) . ' (' . (int) ( $gg['restarts'] ?? 0 ) . ' restarts)', 'ok' => isset( $gg['ts'] ) && ( $now - (int) $gg['ts'] ) < 300 );
		// VERSION-DRIFT GUARD: /fleet/version (FLEET_BUILD) must match the deployed
		// plugin (TNC_VERSION). A mismatch = a bad version bump that silently stalls
		// every fleet deploy (root-caused 2026-06: a no-match sed froze FLEET_BUILD).
		$fb = class_exists( 'TNC_Fleet' ) ? (string) TNC_Fleet::FLEET_BUILD : '';
		$pv = defined( 'TNC_VERSION' ) ? (string) TNC_VERSION : '';
		$out['version-sync'] = array( 'last_seen_s' => 0, 'meta' => 'fleet=' . $fb . ' plugin=' . $pv, 'ok' => ( $fb !== '' && $fb === $pv ) );
		$qh2 = (array) get_option( 'tnc_queue_health', array() );
		$out['queue-drain'] = array( 'last_seen_s' => isset( $qh2['ts'] ) ? $now - (int) $qh2['ts'] : null, 'meta' => ( isset( $qh2['rate_per_min'] ) && null !== $qh2['rate_per_min'] ? $qh2['rate_per_min'] . '/min' : 'sampling' ), 'ok' => isset( $qh2['ts'] ) && ( $now - (int) $qh2['ts'] ) < 900 );
		$pv = (array) get_option( 'tnc_lh_pivot', array() );
		$out['pace-pivot'] = array( 'last_seen_s' => isset($pv['ts']) ? $now - (int)$pv['ts'] : null, 'meta' => (string)($pv['mode']??''), 'ok' => isset($pv['ts']) && ( $now - (int)$pv['ts'] ) < 30 * MINUTE_IN_SECONDS );
		return $out;
	}

	/** DAILY SOURCE YIELD: staged + qualified per source, last 24h (CT stays live). */
	public static function source_yield() {
		global $wpdb;
		$t = TNC_Prospects::table();
		return $wpdb->get_results( "SELECT source, COUNT(*) staged, SUM(contact_email <> '') with_email, SUM(score >= 60 AND contact_email <> '') qualified FROM $t WHERE created_at >= DATE_SUB(NOW(), INTERVAL 1 DAY) GROUP BY source ORDER BY staged DESC", ARRAY_A );
	}

	/** FUNNEL TRUTH: discovered vs has-email vs qualified — shows whether the
	 * constraint is caps (no) or email supply (yes), by source. */
	public static function email_funnel() {
		global $wpdb;
		$t = TNC_Prospects::table();
		$today = strtotime( 'today', current_time( 'timestamp' ) );
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT COUNT(*) n, SUM(contact_email <> '') e, SUM(score >= 60 AND contact_email <> '') q,
			 SUM(UNIX_TIMESTAMP(created_at) >= %d) n_today,
			 SUM(contact_email <> '' AND UNIX_TIMESTAMP(created_at) >= %d) e_today
			 FROM $t WHERE source = 'lead_hunter'", $today, $today ), ARRAY_A );
		$r = $rows ? $rows[0] : array();
		$n = (int) ( $r['n'] ?? 0 ); $e = (int) ( $r['e'] ?? 0 );
		return array(
			'pool_total' => $n, 'pool_with_email' => $e,
			'email_rate_pct' => $n ? round( 100 * $e / $n, 1 ) : 0,
			'pool_qualified' => (int) ( $r['q'] ?? 0 ),
			'today_discovered' => (int) ( $r['n_today'] ?? 0 ),
			'today_with_email' => (int) ( $r['e_today'] ?? 0 ),
		);
	}

	/** LIVE TICKER: ultra-cheap counters for 1-second front-end polling.
	 * Two indexed COUNT queries + cached options — no crawl_data scans. */
	public static function ticker() {
		global $wpdb;
		$t = TNC_Prospects::table(); $j = $wpdb->prefix . 'tnc_fleet_jobs';
		$today = gmdate( 'Y-m-d 00:00:00', current_time( 'timestamp' ) );
		$p = $wpdb->get_row( $wpdb->prepare(
			"SELECT COUNT(*) total, SUM(status='new') in_hunter, SUM(status IN ('demo_created','demo_sent','engaged','won')) promoted,
			 SUM(created_at >= %s) staged_today, SUM(created_at >= %s AND score >= 60 AND contact_email <> '') qual_today
			 FROM $t WHERE source='lead_hunter'", $today, $today ), ARRAY_A );
		$q = $wpdb->get_row( "SELECT SUM(status='queued') queued, SUM(status='leased') running, SUM(status='done') done, SUM(status='dead') dead FROM $j", ARRAY_A );
		// LIVE-VIZ SERIES: 24 hourly buckets of staged rows (real data; sparse-safe).
		$sp = get_option( 'tnc_lh_spark_cache', array() );
		if ( ! is_array( $sp ) || empty( $sp['ts'] ) || time() - (int) $sp['ts'] > 60 ) {
			$rowsh = $wpdb->get_results( "SELECT HOUR(created_at) h, COUNT(*) n FROM $t WHERE source='lead_hunter' AND created_at >= DATE_SUB(UTC_TIMESTAMP(), INTERVAL 24 HOUR) GROUP BY HOUR(created_at)", ARRAY_A );
			$buck = array_fill( 0, 24, 0 );
			foreach ( (array) $rowsh as $r ) { $buck[ (int) $r['h'] % 24 ] = (int) $r['n']; }
			$sp = array( 'ts' => time(), 'staged' => array_values( $buck ) );
			update_option( 'tnc_lh_spark_cache', $sp, false );
		}
		$mix = get_option( 'tnc_lh_mix_cache', array() );
		if ( ! is_array( $mix ) || empty( $mix['ts'] ) || time() - (int) $mix['ts'] > 15 ) {
			$mix = array_merge( self::render_mix(), array( 'ts' => time() ) );
			update_option( 'tnc_lh_mix_cache', $mix, false );
		}
		$latest = $wpdb->get_results( "SELECT id, company_name, city, state_abbr, created_at FROM $t WHERE source='lead_hunter' ORDER BY id DESC LIMIT 5", ARRAY_A );
		// ENGINES: SSL radar (real rows) + LinkedIn/SMS via shared option contract.
		$ssl_rows = $wpdb->get_results( "SELECT id, company_name, website_url, created_at FROM $t WHERE source IN ('ct-stream','ct_stream') ORDER BY id DESC LIMIT 5", ARRAY_A );
		$nodes = (array) get_option( 'tnc_fleet_nodes', array() );
		$ct_seen = isset( $nodes['ct-hunter']['last_seen'] ) ? ( time() - (int) $nodes['ct-hunter']['last_seen'] ) : null;
		$li  = array_merge( array( 'status' => 'not-connected', 'queue' => 0, 'sent_today' => 0, 'golive' => 0, 'note' => 'awaiting engine data contract' ), (array) get_option( 'tnc_li_engine', array() ) );
		$sms = array_merge( array( 'status' => 'not-connected', 'queue' => 0, 'sent_today' => 0, 'golive' => 0, 'note' => 'awaiting engine data contract' ), (array) get_option( 'tnc_sms_engine', array() ) );
		$engines = array(
			'ssl' => array( 'live' => null !== $ct_seen && $ct_seen < 7200, 'last_beat_s' => $ct_seen, 'rows' => $ssl_rows, 'total' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $t WHERE source IN ('ct-stream','ct_stream')" ) ),
			'li'  => $li, 'sms' => $sms,
		);
		return rest_ensure_response( array( 'ok' => true, 'ts' => time(),
			'latest' => $latest,
			'p' => array_map( 'intval', (array) $p ), 'q' => array_map( 'intval', (array) $q ),
			'mix' => array( 'iframe' => (int) ( $mix['iframe'] ?? 0 ), 'screenshot' => (int) ( $mix['screenshot'] ?? 0 ), 'mock' => (int) ( $mix['mock'] ?? 0 ) ),
			'recovered' => (int) get_option( 'tnc_lh_recovered', 0 ), 'ns_found' => (int) get_option( 'tnc_lh_ns_found', 0 ),
			'engines' => $engines,
			'spark' => isset( $sp['staged'] ) ? $sp['staged'] : array(),
			'guard' => get_option( 'tnc_lh_guard', array() ) ) );
	}

	private static function filtered_rows( $f ) {
		global $wpdb;
		$where  = array( "source = 'lead_hunter'" );
		$params = array();
		if ( ! empty( $f['industry'] ) ) { $where[] = 'industry = %s'; $params[] = sanitize_key( $f['industry'] ); }
		if ( ! empty( $f['min_score'] ) ) { $where[] = 'score >= %d'; $params[] = (int) $f['min_score']; }
		if ( ! empty( $f['has_email'] ) ) { $where[] = "contact_email <> ''"; }
		if ( ! empty( $f['search'] ) ) {
			$like = '%' . $wpdb->esc_like( $f['search'] ) . '%';
			$where[] = '(company_name LIKE %s OR city LIKE %s OR website_url LIKE %s)';
			$params[] = $like; $params[] = $like; $params[] = $like;
		}
		if ( ! empty( $f['since'] ) ) {
			$map = array( '1h' => '-1 hour', 'today' => 'today', '24h' => '-24 hours', '7d' => '-7 days' );
			$from = isset( $map[ $f['since'] ] ) ? gmdate( 'Y-m-d H:i:s', strtotime( $map[ $f['since'] ], current_time( 'timestamp' ) ) ) : '';
			if ( $from ) { $where[] = 'created_at >= %s'; $params[] = $from; }
		}
		$order = ( isset( $f['sort'] ) && 'new' === $f['sort'] ) ? 'created_at DESC, id DESC' : 'score DESC, id DESC';
		$sql = 'SELECT id, company_name, website_url, industry, city, state_abbr, score, platform, contact_email, contact_phone, status, batch_id, crawl_data, created_at FROM ' . TNC_Prospects::table() . ' WHERE ' . implode( ' AND ', $where ) . ' ORDER BY ' . $order . ' LIMIT 500';
		if ( $params ) {
			$sql = $wpdb->prepare( $sql, $params );
		}
		$rows = $wpdb->get_results( $sql, ARRAY_A );
		$out  = array();
		foreach ( (array) $rows as $r ) {
			$cd = $r['crawl_data'] ? json_decode( $r['crawl_data'], true ) : array();
			$lh = is_array( $cd ) && isset( $cd['lh'] ) ? $cd['lh'] : array();
			$chat = isset( $lh['chat'] ) ? $lh['chat'] : null;
			if ( ! empty( $f['chat'] ) ) {
				if ( 'absent' === $f['chat'] && 'none' !== $chat ) { continue; }
				if ( 'present' === $f['chat'] && ( null === $chat || 'none' === $chat ) ) { continue; }
			}
			unset( $r['crawl_data'] );
			$r['chat']    = null === $chat ? '…' : $chat;
			$r['site_ok'] = isset( $lh['site_ok'] ) ? $lh['site_ok'] : null;
			$r['enrich']  = isset( $lh['enrich'] ) ? $lh['enrich'] : '';
			$out[] = $r;
		}
		return $out;
	}

	public static function list_rows( $req ) {
		$f = array(
			'industry' => $req->get_param( 'industry' ), 'min_score' => $req->get_param( 'min_score' ),
			'chat' => $req->get_param( 'chat' ), 'has_email' => $req->get_param( 'has_email' ),
			'search' => sanitize_text_field( (string) $req->get_param( 'search' ) ),
			'since' => sanitize_key( (string) $req->get_param( 'since' ) ),
			'sort' => sanitize_key( (string) $req->get_param( 'sort' ) ),
		);
		global $wpdb;
		$by = $wpdb->get_results( 'SELECT industry, COUNT(*) n FROM ' . TNC_Prospects::table() . " WHERE source = 'lead_hunter' GROUP BY industry ORDER BY n DESC", ARRAY_A );
		return rest_ensure_response( array( 'ok' => true, 'rows' => self::filtered_rows( $f ), 'by_industry' => $by ) );
	}

	/* --------------------------------------------------- xlsx export -- */

	/** Filter-respecting .xlsx (minimal OOXML, inline strings, no libs). */
	public static function export_xlsx() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( '', '', array( 'response' => 403 ) );
		}
		$rows = self::filtered_rows( array(
			'industry' => isset( $_GET['industry'] ) ? sanitize_key( $_GET['industry'] ) : '',
			'min_score' => isset( $_GET['min_score'] ) ? (int) $_GET['min_score'] : 0,
			'chat' => isset( $_GET['chat'] ) ? sanitize_key( $_GET['chat'] ) : '',
			'has_email' => ! empty( $_GET['has_email'] ),
			'search' => isset( $_GET['search'] ) ? sanitize_text_field( wp_unslash( $_GET['search'] ) ) : '',
		) );
		$cols = array( 'id', 'company_name', 'industry', 'city', 'state_abbr', 'score', 'platform', 'chat', 'site_ok', 'contact_email', 'contact_phone', 'website_url', 'status', 'batch_id', 'created_at' );

		$esc = function ( $v ) { return htmlspecialchars( (string) $v, ENT_XML1 | ENT_QUOTES, 'UTF-8' ); };
		$sheet = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>';
		$sheet .= '<row r="1">';
		foreach ( $cols as $c ) {
			$sheet .= '<c t="inlineStr"><is><t>' . $esc( $c ) . '</t></is></c>';
		}
		$sheet .= '</row>';
		$rn = 1;
		foreach ( $rows as $r ) {
			$rn++;
			$sheet .= '<row r="' . $rn . '">';
			foreach ( $cols as $c ) {
				$v = isset( $r[ $c ] ) ? $r[ $c ] : '';
				if ( 'site_ok' === $c ) {
					$v = null === $v ? '' : ( $v ? 'yes' : 'no' );
				}
				if ( is_numeric( $v ) && in_array( $c, array( 'id', 'score' ), true ) ) {
					$sheet .= '<c><v>' . (float) $v . '</v></c>';
				} else {
					$sheet .= '<c t="inlineStr"><is><t>' . $esc( $v ) . '</t></is></c>';
				}
			}
			$sheet .= '</row>';
		}
		$sheet .= '</sheetData></worksheet>';

		$files = array(
			'[Content_Types].xml' => '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>',
			'_rels/.rels' => '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>',
			'xl/workbook.xml' => '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Lead Hunter" sheetId="1" r:id="rId1"/></sheets></workbook>',
			'xl/_rels/workbook.xml.rels' => '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>',
			'xl/worksheets/sheet1.xml' => $sheet,
		);
		$tmp = wp_tempnam( 'tnc-lh-xlsx' );
		$zip = new ZipArchive();
		if ( true !== $zip->open( $tmp, ZipArchive::OVERWRITE ) ) {
			wp_die( 'zip failed' );
		}
		foreach ( $files as $name => $content ) {
			$zip->addFromString( $name, $content );
		}
		$zip->close();
		nocache_headers();
		header( 'Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' );
		header( 'Content-Disposition: attachment; filename="lead-hunter-' . gmdate( 'Ymd-His' ) . '.xlsx"' );
		header( 'Content-Length: ' . filesize( $tmp ) );
		readfile( $tmp );
		@unlink( $tmp );
		exit;
	}
}
