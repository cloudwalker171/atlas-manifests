<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Activation, schema (dbDelta) and upgrades.
 */
class TNC_Install {

	public static function activate() {
		self::create_tables();
		self::seed_settings();
		TNC_Demo::add_rewrite();
		flush_rewrite_rules();
		update_option( 'tnc_db_version', TNC_VERSION );
	}

	public static function deactivate() {
		flush_rewrite_rules();
	}

	public static function maybe_upgrade() {
		if ( get_option( 'tnc_db_version' ) !== TNC_VERSION ) {
			self::create_tables();
			if ( class_exists( 'TNC_Fleet' ) ) {
				TNC_Fleet::migrate_option_jobs(); // option-array queue -> table (one-time).
			}
			self::seed_settings();
			TNC_Samples::maybe_seed();
			self::migrate_copy();
			update_option( 'tnc_db_version', TNC_VERSION );
		}
	}

	/** One-time copy migrations (stored settings that changed defaults). */
	private static function migrate_copy() {
		$s = get_option( 'tnc_settings', array() );
		$changed = false;
		if ( is_array( $s ) && isset( $s['cta_urgency_text'] ) && 'Setup in 24 hours' === $s['cta_urgency_text'] ) {
			$s['cta_urgency_text'] = 'Live within 24 hours';
			$changed = true;
		}
		if ( is_array( $s ) && isset( $s['crawl_max_pages'] ) && 25 === (int) $s['crawl_max_pages'] ) {
			$s['crawl_max_pages'] = 50; // old default -> new default (manual values untouched).
			$changed = true;
		}
		if ( $changed ) {
			update_option( 'tnc_settings', $s );
		}
	}

	public static function create_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$charset = $wpdb->get_charset_collate();
		$p       = $wpdb->prefix;

		$sql = array();

		$sql[] = "CREATE TABLE {$p}tnc_prospects (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			company_name VARCHAR(191) NOT NULL DEFAULT '',
			website_url VARCHAR(255) NOT NULL DEFAULT '',
			industry VARCHAR(50) NOT NULL DEFAULT 'other',
			contact_name VARCHAR(191) NOT NULL DEFAULT '',
			contact_email VARCHAR(191) NOT NULL DEFAULT '',
			contact_phone VARCHAR(64) NOT NULL DEFAULT '',
			notes TEXT NULL,
			status VARCHAR(32) NOT NULL DEFAULT 'new',
			platform VARCHAR(32) NOT NULL DEFAULT '',
			score TINYINT UNSIGNED NOT NULL DEFAULT 0,
			score_breakdown TEXT NULL,
			demo_slug VARCHAR(120) NOT NULL DEFAULT '',
			batch_id VARCHAR(40) NOT NULL DEFAULT '',
			last_error TEXT NULL,
			city VARCHAR(100) NOT NULL DEFAULT '',
			state_abbr VARCHAR(4) NOT NULL DEFAULT '',
			source VARCHAR(40) NOT NULL DEFAULT 'manual',
			date_found DATETIME NULL,
			outreach_status VARCHAR(30) NOT NULL DEFAULT '',
			confidence VARCHAR(20) NOT NULL DEFAULT 'pending',
			audit_trail LONGTEXT NULL,
			crawl_data LONGTEXT NULL,
			crawl_state VARCHAR(20) NOT NULL DEFAULT 'idle',
			crawl_progress TEXT NULL,
			outreach_json LONGTEXT NULL,
			theme_overrides TEXT NULL,
			created_at DATETIME NOT NULL DEFAULT '1970-01-01 00:00:00',
			updated_at DATETIME NOT NULL DEFAULT '1970-01-01 00:00:00',
			PRIMARY KEY  (id),
			KEY status (status),
			KEY demo_slug (demo_slug),
			KEY batch_id (batch_id)
		) $charset;";

		$sql[] = "CREATE TABLE {$p}tnc_fleet_jobs (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			job_key VARCHAR(24) NOT NULL DEFAULT '',
			job_type VARCHAR(24) NOT NULL DEFAULT '',
			priority TINYINT NOT NULL DEFAULT 5,
			payload LONGTEXT NULL,
			status VARCHAR(12) NOT NULL DEFAULT 'queued',
			lease_until INT UNSIGNED NOT NULL DEFAULT 0,
			worker VARCHAR(64) NOT NULL DEFAULT '',
			tries TINYINT NOT NULL DEFAULT 0,
			result LONGTEXT NULL,
			created INT UNSIGNED NOT NULL DEFAULT 0,
			done_at INT UNSIGNED NOT NULL DEFAULT 0,
			PRIMARY KEY  (id),
			UNIQUE KEY job_key (job_key),
			KEY claim (status, priority, id)
		) $charset;";

		$sql[] = "CREATE TABLE {$p}tnc_kb_chunks (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			prospect_id BIGINT UNSIGNED NOT NULL,
			chunk_type VARCHAR(20) NOT NULL DEFAULT 'crawl',
			title VARCHAR(255) NOT NULL DEFAULT '',
			question TEXT NULL,
			content LONGTEXT NULL,
			source_url VARCHAR(255) NOT NULL DEFAULT '',
			enabled TINYINT(1) NOT NULL DEFAULT 1,
			created_at DATETIME NOT NULL DEFAULT '1970-01-01 00:00:00',
			PRIMARY KEY  (id),
			KEY prospect_id (prospect_id),
			KEY chunk_type (chunk_type)
		) $charset;";

		$sql[] = "CREATE TABLE {$p}tnc_leads (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			prospect_id BIGINT UNSIGNED NOT NULL,
			name VARCHAR(191) NOT NULL DEFAULT '',
			email VARCHAR(191) NOT NULL DEFAULT '',
			phone VARCHAR(64) NOT NULL DEFAULT '',
			message TEXT NULL,
			source VARCHAR(32) NOT NULL DEFAULT 'demo',
			created_at DATETIME NOT NULL DEFAULT '1970-01-01 00:00:00',
			PRIMARY KEY  (id),
			KEY prospect_id (prospect_id)
		) $charset;";

		$sql[] = "CREATE TABLE {$p}tnc_usage (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			prospect_id BIGINT UNSIGNED NOT NULL,
			session_id VARCHAR(64) NOT NULL DEFAULT '',
			purpose VARCHAR(32) NOT NULL DEFAULT 'chat',
			model VARCHAR(64) NOT NULL DEFAULT '',
			input_tokens INT UNSIGNED NOT NULL DEFAULT 0,
			output_tokens INT UNSIGNED NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL DEFAULT '1970-01-01 00:00:00',
			PRIMARY KEY  (id),
			KEY prospect_id (prospect_id),
			KEY session_id (session_id)
		) $charset;";

		// Learning Engine substrate (Phase 3 consumes this; logged from Phase 1).
		$sql[] = "CREATE TABLE {$p}tnc_exchanges (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			prospect_id BIGINT UNSIGNED NOT NULL,
			session_id VARCHAR(64) NOT NULL DEFAULT '',
			question TEXT NULL,
			answer TEXT NULL,
			answered TINYINT(1) NOT NULL DEFAULT 1,
			confidence VARCHAR(10) NOT NULL DEFAULT 'high',
			feedback TINYINT NULL,
			converted_to_qa TINYINT(1) NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL DEFAULT '1970-01-01 00:00:00',
			PRIMARY KEY  (id),
			KEY prospect_id (prospect_id),
			KEY answered (answered)
		) $charset;";

		foreach ( $sql as $statement ) {
			dbDelta( $statement );
		}
	}

	public static function seed_settings() {
		$existing = get_option( 'tnc_settings', array() );
		if ( ! is_array( $existing ) ) {
			$existing = array();
		}
		// Self-heal: if settings were wiped (legacy uninstall ran during an update
		// swap), restore everything — including the API key — from the backup.
		if ( empty( $existing['api_key'] ) ) {
			$backup = get_option( 'tnc_settings_backup', array() );
			if ( is_array( $backup ) && ! empty( $backup ) ) {
				$existing = array_merge( $backup, array_filter( $existing, function ( $v ) { return '' !== $v && null !== $v; } ) );
			}
		}
		$defaults = TNC_Settings::defaults();
		update_option( 'tnc_settings', array_merge( $defaults, $existing ) );

		if ( ! get_option( 'tnc_demo_secret' ) ) {
			update_option( 'tnc_demo_secret', wp_generate_password( 48, false, false ) );
		}
	}
}
