<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Prospect CRUD.
 */
class TNC_Prospects {

	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'tnc_prospects';
	}

	public static function sanitize( $data ) {
		$out = array();
		if ( isset( $data['company_name'] ) )  { $out['company_name']  = sanitize_text_field( $data['company_name'] ); }
		if ( isset( $data['website_url'] ) )   { $out['website_url']   = esc_url_raw( $data['website_url'] ); }
		if ( isset( $data['industry'] ) ) {
			$ind = sanitize_key( $data['industry'] );
			$out['industry'] = array_key_exists( $ind, TNC_Settings::industries() ) ? $ind : 'other';
		}
		if ( isset( $data['contact_name'] ) )  { $out['contact_name']  = sanitize_text_field( $data['contact_name'] ); }
		if ( isset( $data['contact_email'] ) ) { $out['contact_email'] = sanitize_email( $data['contact_email'] ); }
		if ( isset( $data['contact_phone'] ) ) { $out['contact_phone'] = sanitize_text_field( $data['contact_phone'] ); }
		if ( isset( $data['notes'] ) )         { $out['notes']         = sanitize_textarea_field( $data['notes'] ); }
		if ( isset( $data['status'] ) ) {
			$st = sanitize_key( $data['status'] );
			if ( array_key_exists( $st, TNC_Settings::statuses() ) ) {
				$out['status'] = $st;
			}
		}
		if ( isset( $data['platform'] ) )      { $out['platform']      = sanitize_text_field( $data['platform'] ); }
		if ( isset( $data['score'] ) )         { $out['score']         = max( 0, min( 100, (int) $data['score'] ) ); }
		return $out;
	}

	public static function create( $data ) {
		global $wpdb;
		$clean = self::sanitize( $data );
		if ( empty( $clean['company_name'] ) && empty( $clean['website_url'] ) ) {
			return new WP_Error( 'tnc_invalid', 'Company name or website URL is required.' );
		}
		$now = current_time( 'mysql' );
		$clean['demo_slug']  = self::generate_slug( isset( $clean['company_name'] ) ? $clean['company_name'] : 'demo' );
		$clean['created_at'] = $now;
		$clean['updated_at'] = $now;
		if ( empty( $clean['status'] ) ) {
			$clean['status'] = 'new';
		}
		$ok = $wpdb->insert( self::table(), $clean );
		if ( false === $ok ) {
			return new WP_Error( 'tnc_db', 'Could not create prospect.' );
		}
		return (int) $wpdb->insert_id;
	}

	public static function update( $id, $data ) {
		global $wpdb;
		$clean = self::sanitize( $data );
		// Internal columns set by the platform (not user-facing sanitize path).
		foreach ( array( 'crawl_data', 'outreach_json', 'score_breakdown', 'theme_overrides', 'crawl_progress', 'crawl_state', 'batch_id', 'last_error', 'audit_trail', 'confidence', 'city', 'state_abbr', 'source', 'outreach_status' ) as $jcol ) {
			if ( isset( $data[ $jcol ] ) && is_string( $data[ $jcol ] ) ) {
				$clean[ $jcol ] = $data[ $jcol ];
			}
		}
		if ( empty( $clean ) ) {
			return false;
		}
		$clean['updated_at'] = current_time( 'mysql' );
		return false !== $wpdb->update( self::table(), $clean, array( 'id' => (int) $id ) );
	}

	public static function delete( $id ) {
		global $wpdb;
		$id = (int) $id;
		$wpdb->delete( self::table(), array( 'id' => $id ) );
		$wpdb->delete( $wpdb->prefix . 'tnc_kb_chunks', array( 'prospect_id' => $id ) );
		$wpdb->delete( $wpdb->prefix . 'tnc_leads', array( 'prospect_id' => $id ) );
		$wpdb->delete( $wpdb->prefix . 'tnc_usage', array( 'prospect_id' => $id ) );
		$wpdb->delete( $wpdb->prefix . 'tnc_exchanges', array( 'prospect_id' => $id ) );
		delete_option( 'tnc_crawlq_' . $id );
		return true;
	}

	public static function get( $id ) {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE id = %d', (int) $id ), ARRAY_A );
		return $row ? self::hydrate( $row ) : null;
	}

	public static function get_by_slug( $slug ) {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE demo_slug = %s', $slug ), ARRAY_A );
		return $row ? self::hydrate( $row ) : null;
	}

	public static function query( $args = array() ) {
		global $wpdb;
		$where  = array( '1=1' );
		$params = array();
		if ( ! empty( $args['search'] ) ) {
			$like     = '%' . $wpdb->esc_like( $args['search'] ) . '%';
			$where[]  = '(company_name LIKE %s OR website_url LIKE %s OR contact_name LIKE %s OR contact_email LIKE %s)';
			$params[] = $like; $params[] = $like; $params[] = $like; $params[] = $like;
		}
		if ( ! empty( $args['status'] ) ) {
			$where[]  = 'status = %s';
			$params[] = sanitize_key( $args['status'] );
		}
		if ( ! empty( $args['industry'] ) ) {
			$where[]  = 'industry = %s';
			$params[] = sanitize_key( $args['industry'] );
		}
		if ( ! empty( $args['platform'] ) ) {
			$where[]  = 'platform = %s';
			$params[] = sanitize_key( $args['platform'] );
		}
		if ( ! empty( $args['batch'] ) ) {
			$where[]  = 'batch_id = %s';
			$params[] = sanitize_key( $args['batch'] );
		}
		if ( ! empty( $args['since'] ) ) {
			$where[]  = 'created_at >= %s';
			$params[] = sanitize_text_field( $args['since'] );
		}
		if ( ! empty( $args['until'] ) ) {
			$where[]  = 'created_at <= %s';
			$params[] = sanitize_text_field( $args['until'] );
		}
		if ( ! empty( $args['promoted_only'] ) ) {
			// Prospects view: hide Lead-Hunter discoveries still in the hunter
			// pipeline (source=lead_hunter AND status='new'). Those live in Lead
			// Hunter until promoted; only real prospects belong here.
			$where[] = "NOT ( source = 'lead_hunter' AND status = 'new' )";
		}
		$cols = empty( $args['light'] )
			? '*'
			: 'id, company_name, website_url, industry, contact_name, contact_email, contact_phone, status, platform, score, demo_slug, batch_id, last_error, confidence, crawl_state, crawl_progress, updated_at, created_at';
		$sql = 'SELECT ' . $cols . ' FROM ' . self::table() . ' WHERE ' . implode( ' AND ', $where ) . ' ORDER BY updated_at DESC LIMIT 200';
		if ( $params ) {
			$sql = $wpdb->prepare( $sql, $params );
		}
		$rows = $wpdb->get_results( $sql, ARRAY_A );
		return array_map( array( __CLASS__, 'hydrate' ), $rows ? $rows : array() );
	}

	public static function hydrate( $row ) {
		foreach ( array( 'crawl_data', 'outreach_json', 'score_breakdown', 'theme_overrides', 'crawl_progress', 'audit_trail' ) as $jcol ) {
			$decoded      = ! empty( $row[ $jcol ] ) ? json_decode( $row[ $jcol ], true ) : null;
			$row[ $jcol ] = is_array( $decoded ) ? $decoded : null;
		}
		$row['id']    = (int) $row['id'];
		$row['score'] = (int) $row['score'];
		return $row;
	}

	/**
	 * EMAIL OUTREACH-VALUE RANKING: pick the best contact email from candidates.
	 * Prefer named/role inboxes people actually read; deprioritize generic
	 * technical mailboxes. Returns [best_email, quality] where quality is
	 * good | ok | low | '' (none). A webmaster@-only result is flagged 'low'.
	 */
	public static function rank_email( $candidates ) {
		$bad    = array( 'webmaster', 'postmaster', 'hostmaster', 'no-reply', 'noreply', 'donotreply', 'mailer-daemon', 'abuse', 'privacy', 'dmarc', 'spam' );
		$role   = array( 'info', 'contact', 'hello', 'sales', 'office', 'team', 'support', 'booking', 'appointments', 'frontdesk', 'reception', 'admin' );
		$best   = '';
		$best_s = -999;
		$qual   = '';
		foreach ( (array) $candidates as $e ) {
			$e = strtolower( trim( (string) $e ) );
			if ( ! is_email( $e ) || preg_match( '/\.(png|jpe?g|gif|svg|webp|js|css)$/i', $e ) || preg_match( '/(example|sentry|wixpress|@[0-9])/', $e ) ) {
				continue;
			}
			$local = substr( $e, 0, strpos( $e, '@' ) );
			$sc    = 0;
			$is_bad = false;
			foreach ( $bad as $b ) { if ( false !== strpos( $local, $b ) ) { $sc -= 50; $is_bad = true; } }
			$is_role = false;
			foreach ( $role as $r ) { if ( $local === $r || 0 === strpos( $local, $r . '.' ) || 0 === strpos( $local, $r . '+' ) ) { $sc += 20; $is_role = true; } }
			// A personal/named local part (has a dot or looks like a name, not generic) scores highest.
			if ( ! $is_bad && ! $is_role && preg_match( '/^[a-z]+\.[a-z]+$/', $local ) ) { $sc += 30; }
			if ( false !== strpos( $e, 'gmail.com' ) || false !== strpos( $e, 'yahoo.' ) || false !== strpos( $e, 'hotmail.' ) || false !== strpos( $e, 'outlook.' ) ) { $sc -= 5; }
			if ( $sc > $best_s ) {
				$best_s = $sc;
				$best   = $e;
				$qual   = $sc >= 20 ? 'good' : ( $sc >= 0 ? 'ok' : 'low' );
			}
		}
		return array( $best, $qual );
	}

	public static function generate_slug( $company ) {
		$base = sanitize_title( $company );
		if ( '' === $base ) {
			$base = 'demo';
		}
		$base = substr( $base, 0, 60 );
		// CLEAN DEMO URLS (#55): clean company slug + SHORT 4-char token —
		// visibly tidy, still unguessable in combination (rate-limited + noindex).
		return $base . '-' . strtolower( wp_generate_password( 4, false, false ) );
	}

	public static function counts() {
		global $wpdb;
		$out = array( 'prospects' => 0, 'demos' => 0, 'leads' => 0, 'tokens' => 0 );
		$out['prospects'] = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . self::table() );
		$out['demos']     = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . self::table() . " WHERE status IN ('demo_created','demo_sent','engaged','won')" );
		$out['leads']     = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . $wpdb->prefix . 'tnc_leads' );
		$out['tokens']    = (int) $wpdb->get_var( 'SELECT COALESCE(SUM(input_tokens + output_tokens),0) FROM ' . $wpdb->prefix . 'tnc_usage' );
		return $out;
	}

	public static function recent_leads( $limit = 8 ) {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare(
			'SELECT l.*, p.company_name FROM ' . $wpdb->prefix . 'tnc_leads l LEFT JOIN ' . self::table() . ' p ON p.id = l.prospect_id ORDER BY l.created_at DESC LIMIT %d',
			(int) $limit
		), ARRAY_A );
	}

	public static function leads_for( $prospect_id ) {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare(
			'SELECT * FROM ' . $wpdb->prefix . 'tnc_leads WHERE prospect_id = %d ORDER BY created_at DESC LIMIT 100',
			(int) $prospect_id
		), ARRAY_A );
	}

	public static function add_lead( $prospect_id, $name, $email, $phone, $message ) {
		global $wpdb;
		$ok = $wpdb->insert( $wpdb->prefix . 'tnc_leads', array(
			'prospect_id' => (int) $prospect_id,
			'name'        => sanitize_text_field( $name ),
			'email'       => sanitize_email( $email ),
			'phone'       => sanitize_text_field( $phone ),
			'message'     => sanitize_textarea_field( $message ),
			'source'      => 'demo',
			'created_at'  => current_time( 'mysql' ),
		) );
		return false !== $ok ? (int) $wpdb->insert_id : 0;
	}

	/**
	 * Learning Engine substrate: log a Q&A exchange with an answered/confidence
	 * flag so the Phase 3 Knowledge-Gaps queue needs no schema changes.
	 */
	public static function log_exchange( $prospect_id, $session_id, $question, $answer, $answered, $confidence ) {
		global $wpdb;
		$wpdb->insert( $wpdb->prefix . 'tnc_exchanges', array(
			'prospect_id' => (int) $prospect_id,
			'session_id'  => substr( sanitize_text_field( $session_id ), 0, 64 ),
			'question'    => sanitize_textarea_field( mb_substr( (string) $question, 0, 2000 ) ),
			'answer'      => sanitize_textarea_field( mb_substr( (string) $answer, 0, 4000 ) ),
			'answered'    => $answered ? 1 : 0,
			'confidence'  => in_array( $confidence, array( 'high', 'low' ), true ) ? $confidence : 'high',
			'created_at'  => current_time( 'mysql' ),
		) );
	}

	/**
	 * Audit trail: append a finding (method + confidence + timestamp).
	 * Manual/visual verifications are never overwritten by lower-confidence
	 * re-scans — conflicting findings get appended and flagged instead.
	 */
	public static function audit( $prospect_id, $finding, $method, $confidence ) {
		$p = self::get( $prospect_id );
		if ( ! $p ) {
			return;
		}
		$trail   = ! empty( $p['audit_trail'] ) && is_array( $p['audit_trail'] ) ? $p['audit_trail'] : array();
		$trail[] = array(
			'finding'    => sanitize_text_field( mb_substr( $finding, 0, 300 ) ),
			'method'     => sanitize_key( $method ),
			'confidence' => sanitize_key( $confidence ),
			'ts'         => current_time( 'mysql' ),
		);
		self::update( $prospect_id, array( 'audit_trail' => wp_json_encode( array_slice( $trail, -50 ) ) ) );
	}

	public static function log_usage( $prospect_id, $session_id, $purpose, $model, $in_tokens, $out_tokens ) {
		global $wpdb;
		$wpdb->insert( $wpdb->prefix . 'tnc_usage', array(
			'prospect_id'   => (int) $prospect_id,
			'session_id'    => substr( sanitize_text_field( $session_id ), 0, 64 ),
			'purpose'       => sanitize_key( $purpose ),
			'model'         => sanitize_text_field( $model ),
			'input_tokens'  => (int) $in_tokens,
			'output_tokens' => (int) $out_tokens,
			'created_at'    => current_time( 'mysql' ),
		) );
	}
}
