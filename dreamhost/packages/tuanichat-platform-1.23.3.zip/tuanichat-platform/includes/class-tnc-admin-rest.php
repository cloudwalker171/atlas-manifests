<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Admin REST endpoints (manage_options + REST cookie nonce).
 */
class TNC_Admin_Rest {

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	public static function can() {
		return current_user_can( 'manage_options' );
	}

	public static function routes() {
		$ns   = TNC_REST_NS;
		$perm = array( __CLASS__, 'can' );

		register_rest_route( $ns, '/admin/prospects', array(
			array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'list_prospects' ), 'permission_callback' => $perm ),
			array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'create_prospect' ), 'permission_callback' => $perm ),
		) );
		register_rest_route( $ns, '/admin/prospects/(?P<id>\d+)', array(
			array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'get_prospect' ), 'permission_callback' => $perm ),
			array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'update_prospect' ), 'permission_callback' => $perm ),
			array( 'methods' => 'DELETE', 'callback' => array( __CLASS__, 'delete_prospect' ), 'permission_callback' => $perm ),
		) );
		register_rest_route( $ns, '/admin/prospects/(?P<id>\d+)/crawl', array(
			'methods' => 'POST', 'callback' => array( __CLASS__, 'crawl' ), 'permission_callback' => $perm,
		) );
		register_rest_route( $ns, '/admin/prospects/(?P<id>\d+)/snap', array(
			'methods' => 'POST', 'callback' => array( __CLASS__, 'snap' ), 'permission_callback' => $perm,
		) );
		register_rest_route( $ns, '/admin/prospects/(?P<id>\d+)/crawl-resume', array(
			'methods' => 'POST', 'callback' => array( __CLASS__, 'crawl_resume' ), 'permission_callback' => $perm,
		) );
		register_rest_route( $ns, '/admin/prospects/(?P<id>\d+)/crawl-decision', array(
			'methods' => 'POST', 'callback' => array( __CLASS__, 'crawl_decision' ), 'permission_callback' => $perm,
		) );
		register_rest_route( $ns, '/admin/prospects/(?P<id>\d+)/kb', array(
			array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'list_kb' ), 'permission_callback' => $perm ),
			array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'add_kb' ), 'permission_callback' => $perm ),
		) );
		register_rest_route( $ns, '/admin/kb/(?P<id>\d+)', array(
			array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'update_kb' ), 'permission_callback' => $perm ),
			array( 'methods' => 'DELETE', 'callback' => array( __CLASS__, 'delete_kb' ), 'permission_callback' => $perm ),
		) );
		register_rest_route( $ns, '/admin/prospects/(?P<id>\d+)/verify-chat', array(
			'methods' => 'POST', 'callback' => array( __CLASS__, 'verify_chat' ), 'permission_callback' => $perm,
		) );
		register_rest_route( $ns, '/admin/prospects/(?P<id>\d+)/starters', array(
			'methods' => 'POST', 'callback' => array( __CLASS__, 'starters' ), 'permission_callback' => $perm,
		) );
		register_rest_route( $ns, '/admin/prospects/(?P<id>\d+)/outreach', array(
			'methods' => 'POST', 'callback' => array( __CLASS__, 'outreach' ), 'permission_callback' => $perm,
		) );
		register_rest_route( $ns, '/admin/prospects/(?P<id>\d+)/outreach-save', array(
			'methods' => 'POST', 'callback' => array( __CLASS__, 'outreach_save' ), 'permission_callback' => $perm,
		) );
		register_rest_route( $ns, '/admin/bulk-import', array(
			'methods' => 'POST', 'callback' => array( __CLASS__, 'bulk_import' ), 'permission_callback' => $perm,
		) );
		register_rest_route( $ns, '/admin/bulk', array(
			'methods' => 'GET', 'callback' => array( __CLASS__, 'bulk_get' ), 'permission_callback' => $perm,
		) );
		register_rest_route( $ns, '/admin/outreach-test', array(
			'methods' => 'POST', 'callback' => array( __CLASS__, 'outreach_test' ), 'permission_callback' => $perm,
		) );
		register_rest_route( $ns, '/admin/redetect', array(
			'methods' => 'POST', 'callback' => array( __CLASS__, 'redetect_all' ), 'permission_callback' => $perm,
		) );
		register_rest_route( $ns, '/admin/products-refresh', array(
			'methods' => 'POST', 'callback' => array( __CLASS__, 'products_refresh' ), 'permission_callback' => $perm,
		) );
		register_rest_route( $ns, '/admin/theme-refresh', array(
			'methods' => 'POST', 'callback' => array( __CLASS__, 'theme_refresh' ), 'permission_callback' => $perm,
		) );
		register_rest_route( $ns, '/admin/redetect-chat', array(
			'methods' => 'POST', 'callback' => array( __CLASS__, 'redetect_chat' ), 'permission_callback' => $perm,
		) );
		register_rest_route( $ns, '/admin/ground-truth', array(
			'methods' => 'GET', 'callback' => array( __CLASS__, 'ground_truth' ), 'permission_callback' => $perm,
		) );
		register_rest_route( $ns, '/admin/enrich-backfill', array(
			'methods' => 'POST', 'callback' => array( __CLASS__, 'enrich_backfill' ), 'permission_callback' => $perm,
		) );
		register_rest_route( $ns, '/admin/state', array(
			'methods' => 'GET', 'callback' => array( __CLASS__, 'state' ), 'permission_callback' => $perm,
		) );
		register_rest_route( $ns, '/admin/cockpit', array(
			'methods' => 'GET', 'callback' => array( __CLASS__, 'cockpit' ), 'permission_callback' => $perm,
		) );
		register_rest_route( $ns, '/admin/settings', array(
			'methods' => 'POST', 'callback' => array( __CLASS__, 'save_settings' ), 'permission_callback' => $perm,
		) );
		register_rest_route( $ns, '/admin/mail-log', array(
			'methods' => 'GET', 'callback' => array( __CLASS__, 'mail_log' ), 'permission_callback' => $perm,
		) );
		register_rest_route( $ns, '/admin/mail-test', array(
			'methods' => 'POST', 'callback' => array( __CLASS__, 'mail_test' ), 'permission_callback' => $perm,
		) );
		register_rest_route( $ns, '/admin/dkim-setup', array(
			'methods' => 'POST', 'callback' => array( __CLASS__, 'dkim_setup' ), 'permission_callback' => $perm,
		) );
		register_rest_route( $ns, '/admin/dkim-status', array(
			'methods' => 'GET', 'callback' => array( __CLASS__, 'dkim_status' ), 'permission_callback' => $perm,
		) );
		register_rest_route( $ns, '/admin/fleet', array(
			'methods' => 'GET', 'callback' => array( __CLASS__, 'fleet_admin' ), 'permission_callback' => $perm,
		) );
		register_rest_route( $ns, '/admin/fleet-enqueue', array(
			'methods' => 'POST', 'callback' => array( __CLASS__, 'fleet_enqueue' ), 'permission_callback' => $perm,
		) );
		register_rest_route( $ns, '/admin/mail-streams', array(
			'methods' => 'GET', 'callback' => array( __CLASS__, 'mail_streams' ), 'permission_callback' => $perm,
		) );
		register_rest_route( $ns, '/admin/prospects/(?P<id>\d+)/opener', array(
			'methods' => 'POST', 'callback' => array( __CLASS__, 'ai_opener' ), 'permission_callback' => $perm,
		) );
		register_rest_route( $ns, '/admin/verify-email', array(
			'methods' => 'POST', 'callback' => array( __CLASS__, 'verify_email' ), 'permission_callback' => $perm,
		) );
		register_rest_route( $ns, '/admin/suppress', array(
			'methods' => 'POST', 'callback' => array( __CLASS__, 'suppress_email' ), 'permission_callback' => $perm,
		) );
		register_rest_route( $ns, '/admin/inbox', array(
			'methods' => 'GET', 'callback' => array( __CLASS__, 'outreach_inbox' ), 'permission_callback' => $perm,
		) );
		register_rest_route( $ns, '/admin/seed-test', array(
			'methods' => 'POST', 'callback' => array( __CLASS__, 'seed_test' ), 'permission_callback' => $perm,
		) );
		// PUBLIC: inbound reply webhook (token-authed) + one-click unsubscribe.
		register_rest_route( $ns, '/mail/inbound', array(
			'methods' => 'POST', 'callback' => array( __CLASS__, 'mail_inbound' ), 'permission_callback' => '__return_true',
		) );
		register_rest_route( $ns, '/unsub', array(
			'methods' => 'GET', 'callback' => array( __CLASS__, 'unsub' ), 'permission_callback' => '__return_true',
		) );
	}

	/** Strip server-only blobs before sending a prospect to the admin UI. */
	private static function slim( $p ) {
		if ( ! $p ) {
			return $p;
		}
		if ( is_array( $p['crawl_data'] ) ) {
			$p['crawl_summary'] = array(
				'platform'   => isset( $p['crawl_data']['platform'] ) ? $p['crawl_data']['platform'] : '',
				'page_count' => isset( $p['crawl_data']['page_count'] ) ? $p['crawl_data']['page_count'] : 0,
				'crawled_at' => isset( $p['crawl_data']['crawled_at'] ) ? $p['crawl_data']['crawled_at'] : '',
				'extracted'  => isset( $p['crawl_data']['extracted'] ) ? $p['crawl_data']['extracted'] : array(),
				'errors'     => isset( $p['crawl_data']['errors'] ) ? $p['crawl_data']['errors'] : array(),
				'pages'      => isset( $p['crawl_data']['pages'] ) ? array_keys( $p['crawl_data']['pages'] ) : array(),
			);
		} else {
			$p['crawl_summary'] = null;
		}
		unset( $p['crawl_data'] );
		// crawl_state + crawl_progress pass through for the progress UI.
		$p['crawl_stalled'] = TNC_Crawl_Jobs::stalled( $p );
		$p['demo_url'] = $p['demo_slug'] ? home_url( '/demo/' . $p['demo_slug'] . '/' ) : '';
		$p['theme']    = TNC_Themes::for_prospect( $p ); // resolved tokens for the Widget tab.
		return $p;
	}

	/** Resolve a preset/custom date filter into [since, until] mysql strings. */
	public static function date_window( $req ) {
		$preset = sanitize_key( (string) $req->get_param( 'range' ) );
		$now    = current_time( 'timestamp' );
		$map    = array( 'today' => 'today', '24h' => '-24 hours', '7d' => '-7 days', '30d' => '-30 days' );
		$since = ''; $until = '';
		if ( isset( $map[ $preset ] ) ) {
			$since = gmdate( 'Y-m-d H:i:s', 'today' === $map[ $preset ] ? strtotime( 'today', $now ) : strtotime( $map[ $preset ], $now ) );
		} elseif ( 'custom' === $preset ) {
			$f = sanitize_text_field( (string) $req->get_param( 'from' ) );
			$u = sanitize_text_field( (string) $req->get_param( 'to' ) );
			if ( $f ) { $since = gmdate( 'Y-m-d 00:00:00', strtotime( $f ) ); }
			if ( $u ) { $until = gmdate( 'Y-m-d 23:59:59', strtotime( $u ) ); }
		}
		return array( $since, $until );
	}

	public static function list_prospects( $req ) {
		list( $since, $until ) = self::date_window( $req );
		$rows = TNC_Prospects::query( array(
			'search'   => sanitize_text_field( (string) $req->get_param( 'search' ) ),
			'status'   => sanitize_key( (string) $req->get_param( 'status' ) ),
			'industry' => sanitize_key( (string) $req->get_param( 'industry' ) ),
			'platform' => sanitize_key( (string) $req->get_param( 'platform' ) ),
			'since'    => $since, 'until' => $until,
			'light'    => 1, // P0: never haul crawl_data blobs into the list view.
			'promoted_only' => 1, // exclude un-promoted lead_hunter discoveries (they live in Lead Hunter).
		) );
		return rest_ensure_response( array( 'prospects' => array_map( array( __CLASS__, 'slim_light' ), $rows ), 'stats' => self::prospect_stats( $since, $until ) ) );
	}

	/** Prospects stat-header: totals, recency, by status/industry, avg score. */
	public static function prospect_stats( $since = '', $until = '' ) {
		global $wpdb;
		$t = TNC_Prospects::table();
		$scope = " WHERE NOT ( source = 'lead_hunter' AND status = 'new' )"; // real prospects only.
		if ( $since ) { $scope .= $wpdb->prepare( ' AND created_at >= %s', $since ); }
		if ( $until ) { $scope .= $wpdb->prepare( ' AND created_at <= %s', $until ); }
		$now = current_time( 'mysql' );
		$d1  = gmdate( 'Y-m-d H:i:s', strtotime( $now ) - 86400 );
		$d7  = gmdate( 'Y-m-d H:i:s', strtotime( $now ) - 7 * 86400 );
		$by_status = array();
		foreach ( (array) $wpdb->get_results( "SELECT status, COUNT(*) n FROM $t" . $scope . " GROUP BY status", ARRAY_A ) as $r ) { $by_status[ $r['status'] ] = (int) $r['n']; }
		$by_ind = array();
		foreach ( (array) $wpdb->get_results( "SELECT industry, COUNT(*) n FROM $t" . $scope . " GROUP BY industry ORDER BY n DESC LIMIT 6", ARRAY_A ) as $r ) { $by_ind[ $r['industry'] ] = (int) $r['n']; }
		return array(
			'total'      => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $t" . $scope ),
			'new_1d'     => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t" . $scope . " AND created_at >= %s", $d1 ) ),
			'new_7d'     => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t" . $scope . " AND created_at >= %s", $d7 ) ),
			'avg_score'  => (int) round( (float) $wpdb->get_var( "SELECT AVG(score) FROM $t" . $scope ) ),
			'by_status'  => $by_status,
			'by_industry'=> $by_ind,
		);
	}

	/** Light row for list views: no blobs, no theme resolution — fast. */
	private static function slim_light( $p ) {
		unset( $p['crawl_data'], $p['outreach_json'], $p['score_breakdown'], $p['theme_overrides'], $p['audit_trail'], $p['notes'] );
		$p['crawl_stalled'] = TNC_Crawl_Jobs::stalled( $p );
		$p['demo_url']      = ! empty( $p['demo_slug'] ) ? home_url( '/demo/' . $p['demo_slug'] . '/' ) : '';
		$p['crawl_summary'] = null;
		$p['email_ok']      = ! empty( $p['contact_email'] ) && is_email( $p['contact_email'] );
		// True epoch (tz-proof) for 'X ago'; created_at is stored in WP/site tz.
		$p['added_ts']      = ! empty( $p['created_at'] ) ? (int) strtotime( get_gmt_from_date( $p['created_at'] ) . ' UTC' ) : 0;
		return $p;
	}

	public static function create_prospect( $req ) {
		$id = TNC_Prospects::create( $req->get_params() );
		if ( is_wp_error( $id ) ) {
			return $id;
		}
		return rest_ensure_response( array( 'ok' => true, 'id' => $id, 'prospect' => self::slim( TNC_Prospects::get( $id ) ) ) );
	}

	public static function get_prospect( $req ) {
		$p = TNC_Prospects::get( (int) $req['id'] );
		if ( ! $p ) {
			return new WP_Error( 'tnc_404', 'Not found.', array( 'status' => 404 ) );
		}
		$out          = self::slim( $p );
		$out['leads'] = TNC_Prospects::leads_for( $p['id'] );
		return rest_ensure_response( array( 'prospect' => $out ) );
	}

	public static function update_prospect( $req ) {
		$id = (int) $req['id'];
		TNC_Prospects::update( $id, $req->get_params() );
		return rest_ensure_response( array( 'ok' => true, 'prospect' => self::slim( TNC_Prospects::get( $id ) ) ) );
	}

	public static function delete_prospect( $req ) {
		TNC_Prospects::delete( (int) $req['id'] );
		return rest_ensure_response( array( 'ok' => true ) );
	}

	public static function crawl( $req ) {
		$p = TNC_Prospects::get( (int) $req['id'] );
		if ( ! $p ) {
			return new WP_Error( 'tnc_404', 'Not found.', array( 'status' => 404 ) );
		}
		if ( empty( $p['website_url'] ) ) {
			return new WP_Error( 'tnc_nourl', 'Add a website URL first.', array( 'status' => 400 ) );
		}
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 180 );
		}

		$profile = sanitize_key( (string) $req->get_param( 'profile' ) );
		if ( ! in_array( $profile, array( 'demo', 'full' ), true ) ) {
			$profile = 'demo';
		}

		// Full-site crawls run batched via WP-Cron (shared-hosting safe).
		if ( 'full' === $profile ) {
			$queued = TNC_Crawl_Jobs::enqueue( $p['id'], 'full' );
			if ( is_wp_error( $queued ) ) {
				return new WP_Error( 'tnc_crawl', $queued->get_error_message(), array( 'status' => 400 ) );
			}
			$decision = is_array( $queued ) && ! empty( $queued['decision'] );
			return rest_ensure_response( array( 'ok' => true, 'queued' => true, 'decision' => $decision, 'discovered' => $decision ? (int) $queued['discovered'] : 0, 'prospect' => self::slim( TNC_Prospects::get( $p['id'] ) ) ) );
		}

		TNC_Prospects::update( $p['id'], array( 'crawl_state' => 'running' ) );
		$crawler = new TNC_Crawler();
		$crawl   = $crawler->crawl( $p['website_url'], 'demo' );
		if ( is_wp_error( $crawl ) ) {
			TNC_Prospects::update( $p['id'], array( 'crawl_state' => 'failed' ) );
			return new WP_Error( 'tnc_crawl', $crawl->get_error_message(), array( 'status' => 400 ) );
		}

		TNC_KB::ingest_crawl( $p['id'], $crawl );
		$crawl['pages'] = array_keys( $crawl['pages'] ); // KB has the content — keep the row light.

		$updates = array(
			'crawl_data'  => wp_json_encode( $crawl ),
			'platform'    => $crawl['platform'],
			'crawl_state' => 'done',
		);
		if ( empty( $p['company_name'] ) && ! empty( $crawl['extracted']['company_name'] ) ) {
			$updates['company_name'] = $crawl['extracted']['company_name'];
		}
		if ( in_array( $p['status'], array( 'new' ), true ) ) {
			$updates['status'] = 'crawled';
		}
		TNC_Prospects::update( $p['id'], $updates );

		// Score after crawl.
		$p2 = TNC_Prospects::get( $p['id'] );
		list( $score, $breakdown ) = TNC_Outreach::score( $p2 );
		TNC_Prospects::update( $p['id'], array( 'score' => $score, 'score_breakdown' => wp_json_encode( $breakdown ) ) );

		// Audit trail: record what this crawl established (code-scan confidence).
		$exd = $crawl['extracted'];
		TNC_Prospects::audit( $p['id'], 'Platform: ' . $crawl['platform'], 'code_scan', in_array( $crawl['platform'], array( 'unknown', 'custom' ), true ) ? 'needs_review' : 'verified' );
		TNC_Prospects::audit( $p['id'], 'Chat: ' . ( $exd['chat_widget'] ? $exd['chat_widget'] : 'none found' ) . ' [' . ( isset( $exd['chat_confidence'] ) ? $exd['chat_confidence'] : 'needs_review' ) . ']', 'code_scan', isset( $exd['chat_confidence'] ) ? $exd['chat_confidence'] : 'needs_review' );
		if ( ! empty( $exd['brand']['primary'] ) ) {
			TNC_Prospects::audit( $p['id'], 'Brand palette extracted: ' . $exd['brand']['primary'], 'code_scan', 'verified' );
		}
		$auto_verified = isset( $exd['chat_confidence'] ) && 'verified_present' === $exd['chat_confidence'];
		if ( $auto_verified ) {
			TNC_Prospects::update( $p['id'], array( 'confidence' => 'verified' ) );
		} elseif ( 'verified' !== $p['confidence'] ) {
			TNC_Prospects::update( $p['id'], array( 'confidence' => 'pending', 'date_found' => current_time( 'mysql' ) ) );
		}

		TNC_Outreach::queue_starters( $p['id'] ); // smart starter questions, async.

		// Demo exists as soon as crawl + KB exist.
		$p3 = TNC_Prospects::get( $p['id'] );
		if ( 'crawled' === $p3['status'] ) {
			TNC_Prospects::update( $p['id'], array( 'status' => 'demo_created' ) );
			$p3 = TNC_Prospects::get( $p['id'] );
		}

		return rest_ensure_response( array( 'ok' => true, 'prospect' => self::slim( $p3 ) ) );
	}

	public static function list_kb( $req ) {
		$chunks = TNC_KB::get_chunks(
			(int) $req['id'],
			sanitize_text_field( (string) $req->get_param( 'search' ) ),
			sanitize_key( (string) $req->get_param( 'type' ) )
		);
		return rest_ensure_response( array( 'chunks' => $chunks ) );
	}

	public static function add_kb( $req ) {
		$pid  = (int) $req['id'];
		$type = sanitize_key( (string) $req->get_param( 'chunk_type' ) );
		if ( ! in_array( $type, array( 'manual', 'qa', 'file' ), true ) ) {
			$type = 'manual';
		}
		$content = (string) $req->get_param( 'content' );
		$title   = (string) $req->get_param( 'title' );
		$q       = (string) $req->get_param( 'question' );
		if ( 'qa' === $type && '' === trim( $q ) ) {
			return new WP_Error( 'tnc_bad', 'Question is required for Q&A pairs.', array( 'status' => 400 ) );
		}
		$ids = array();
		if ( 'qa' === $type ) {
			$ids[] = TNC_KB::add_chunk( $pid, 'qa', $title ? $title : 'Q&A', $content, '', $q );
		} else {
			$pieces = TNC_KB::chunk_text( $content );
			if ( empty( $pieces ) && '' !== trim( $content ) ) {
				$pieces = array( trim( $content ) );
			}
			$i = 0;
			foreach ( $pieces as $piece ) {
				$i++;
				$t     = $title ? $title : 'Added knowledge';
				$ids[] = TNC_KB::add_chunk( $pid, $type, count( $pieces ) > 1 ? $t . ' (' . $i . ')' : $t, $piece );
			}
		}
		return rest_ensure_response( array( 'ok' => true, 'ids' => $ids ) );
	}

	public static function update_kb( $req ) {
		TNC_KB::update_chunk( (int) $req['id'], array(
			'title'    => $req->get_param( 'title' ),
			'content'  => $req->get_param( 'content' ),
			'question' => $req->get_param( 'question' ),
			'enabled'  => $req->get_param( 'enabled' ),
		) );
		return rest_ensure_response( array( 'ok' => true ) );
	}

	public static function delete_kb( $req ) {
		TNC_KB::delete_chunk( (int) $req['id'] );
		return rest_ensure_response( array( 'ok' => true ) );
	}

	/** Manual/visual chat verification — highest confidence, never auto-overwritten. */
	public static function verify_chat( $req ) {
		$p = TNC_Prospects::get( (int) $req['id'] );
		if ( ! $p || ! is_array( $p['crawl_data'] ) ) {
			return new WP_Error( 'tnc_404', 'Crawl first.', array( 'status' => 404 ) );
		}
		$present  = (bool) $req->get_param( 'present' );
		$provider = sanitize_text_field( (string) $req->get_param( 'provider' ) );
		$note     = sanitize_text_field( (string) $req->get_param( 'note' ) );

		$cd = $p['crawl_data'];
		$cd['extracted']['chat_confidence'] = $present ? 'verified_present' : 'verified_absent';
		if ( $present ) {
			$cd['extracted']['chat_widget'] = $provider ? $provider : ( $cd['extracted']['chat_widget'] ? $cd['extracted']['chat_widget'] : 'Custom chat widget' );
			if ( empty( $cd['extracted']['chat_type'] ) || 'none' === $cd['extracted']['chat_type'] ) {
				$cd['extracted']['chat_type']  = 'custom';
				$cd['extracted']['chat_grade'] = 'basic';
			}
		} else {
			$cd['extracted']['chat_widget'] = '';
			$cd['extracted']['chat_type']   = 'none';
			$cd['extracted']['chat_grade']  = 'none';
		}
		TNC_Prospects::update( $p['id'], array( 'crawl_data' => wp_json_encode( $cd ), 'confidence' => 'verified' ) );
		TNC_Prospects::audit( $p['id'], 'Chat ' . ( $present ? 'PRESENT (' . $cd['extracted']['chat_widget'] . ')' : 'ABSENT' ) . ( $note ? ' — ' . $note : '' ), 'visual_manual', 'verified' );

		$p2 = TNC_Prospects::get( $p['id'] );
		list( $score, $breakdown ) = TNC_Outreach::score( $p2 );
		TNC_Prospects::update( $p['id'], array( 'score' => $score, 'score_breakdown' => wp_json_encode( $breakdown ) ) );
		return rest_ensure_response( array( 'ok' => true, 'prospect' => self::slim( TNC_Prospects::get( $p['id'] ) ) ) );
	}

	/** Resume a stalled deep crawl. */
	public static function crawl_resume( $req ) {
		if ( function_exists( 'wp_raise_memory_limit' ) ) {
			wp_raise_memory_limit( 'admin' );
		}
		$out = TNC_Crawl_Jobs::resume( (int) $req['id'] );
		if ( is_wp_error( $out ) ) {
			return new WP_Error( $out->get_error_code(), $out->get_error_message(), array( 'status' => 400 ) );
		}
		return rest_ensure_response( array( 'ok' => true, 'prospect' => self::slim( TNC_Prospects::get( (int) $req['id'] ) ) ) );
	}

	/** Resolve the sitemap size gate: top500 | all | cancel. */
	public static function crawl_decision( $req ) {
		$choice = sanitize_key( (string) $req->get_param( 'choice' ) );
		if ( ! in_array( $choice, array( 'top500', 'all', 'cancel' ), true ) ) {
			return new WP_Error( 'tnc_bad', 'Invalid choice.', array( 'status' => 400 ) );
		}
		$out = TNC_Crawl_Jobs::decide( (int) $req['id'], $choice );
		if ( is_wp_error( $out ) ) {
			return new WP_Error( $out->get_error_code(), $out->get_error_message(), array( 'status' => 400 ) );
		}
		return rest_ensure_response( array_merge( array( 'ok' => true ), $out, array( 'prospect' => self::slim( TNC_Prospects::get( (int) $req['id'] ) ) ) ) );
	}

	public static function starters( $req ) {
		$p = TNC_Prospects::get( (int) $req['id'] );
		if ( ! $p ) {
			return new WP_Error( 'tnc_404', 'Not found.', array( 'status' => 404 ) );
		}
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 90 );
		}
		$out = TNC_Outreach::generate_starters( $p );
		if ( is_wp_error( $out ) ) {
			return new WP_Error( $out->get_error_code(), $out->get_error_message(), array( 'status' => 400 ) );
		}
		return rest_ensure_response( array_merge( array( 'ok' => true ), $out ) );
	}

	public static function outreach( $req ) {
		$p = TNC_Prospects::get( (int) $req['id'] );
		if ( ! $p ) {
			return new WP_Error( 'tnc_404', 'Not found.', array( 'status' => 404 ) );
		}
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 120 );
		}
		$mode = sanitize_key( (string) $req->get_param( 'mode' ) );
		$kit  = 'ai' === $mode ? TNC_Outreach::generate_kit( $p ) : TNC_Outreach::template_kit( $p );
		if ( is_wp_error( $kit ) ) {
			return new WP_Error( $kit->get_error_code(), $kit->get_error_message(), array( 'status' => 400 ) );
		}
		return rest_ensure_response( array( 'ok' => true, 'kit' => $kit ) );
	}

	public static function outreach_save( $req ) {
		$p = TNC_Prospects::get( (int) $req['id'] );
		if ( ! $p ) {
			return new WP_Error( 'tnc_404', 'Not found.', array( 'status' => 404 ) );
		}
		$kit = array(
			'cold_email'       => sanitize_textarea_field( (string) $req->get_param( 'cold_email' ) ),
			'follow_up_email'  => sanitize_textarea_field( (string) $req->get_param( 'follow_up_email' ) ),
			'linkedin_message' => sanitize_textarea_field( (string) $req->get_param( 'linkedin_message' ) ),
			'audit_text'       => sanitize_textarea_field( (string) $req->get_param( 'audit_text' ) ),
			'mode'             => is_array( $p['outreach_json'] ) && isset( $p['outreach_json']['mode'] ) ? $p['outreach_json']['mode'] : 'template',
			'generated_at'     => is_array( $p['outreach_json'] ) && isset( $p['outreach_json']['generated_at'] ) ? $p['outreach_json']['generated_at'] : current_time( 'mysql' ),
		);
		TNC_Prospects::update( $p['id'], array( 'outreach_json' => wp_json_encode( $kit ) ) );
		return rest_ensure_response( array( 'ok' => true ) );
	}

	public static function bulk_import( $req ) {
		$rows = $req->get_param( 'rows' );
		if ( ! is_array( $rows ) ) {
			return new WP_Error( 'tnc_bad', 'No rows provided.', array( 'status' => 400 ) );
		}
		$result = TNC_Bulk::import( $rows );
		if ( is_wp_error( $result ) ) {
			return new WP_Error( 'tnc_bulk', $result->get_error_message(), array( 'status' => 400 ) );
		}
		return rest_ensure_response( array_merge( array( 'ok' => true ), $result ) );
	}

	public static function bulk_get( $req ) {
		$batch = sanitize_key( (string) $req->get_param( 'batch' ) );
		if ( '' === $batch ) {
			$batch = sanitize_key( (string) get_option( 'tnc_last_batch', '' ) );
		}
		$counts = $batch ? TNC_Bulk::batch_counts( $batch ) : null;
		if ( $counts && 0 === $counts['total'] ) {
			$batch  = '';
			$counts = null;
		}
		$out = array(
			'batch'   => $batch,
			'counts'  => $counts,
			'rows'    => $batch ? TNC_Bulk::batch_rows( $batch ) : array(),
			'batches' => TNC_Bulk::recent_batches(),
			'has_key' => '' !== TNC_Settings::get( 'api_key' ),
		);
		return rest_ensure_response( $out );
	}

	/** Consolidated live-state poll: counts + worker lanes only (cheap). */
	/** OPERATIONAL COCKPIT: one aggregate payload for the Workers page (5s poll). */
	public static function cockpit( $req ) {
		global $wpdb;
		$t     = $wpdb->prefix . 'tnc_usage';
		$today = gmdate( 'Y-m-d' );
		$spend = $wpdb->get_row( "SELECT COUNT(*) c, COALESCE(SUM(input_tokens),0) i, COALESCE(SUM(output_tokens),0) o FROM {$t}", ARRAY_A );
		$spend_today = $wpdb->get_row( $wpdb->prepare( "SELECT COUNT(*) c, COALESCE(SUM(input_tokens),0) i, COALESCE(SUM(output_tokens),0) o FROM {$t} WHERE created_at >= %s", $today . ' 00:00:00' ), ARRAY_A );
		$usd = function ( $r ) {
			// Haiku rate table seed: $1/M in, $5/M out.
			return round( ( (int) $r['i'] ) / 1000000 + ( (int) $r['o'] ) * 5 / 1000000, 4 );
		};
		$inbox = (array) get_option( 'tnc_inbox', array() );
		$cls   = array();
		foreach ( $inbox as $m ) {
			$k = isset( $m['class'] ) ? $m['class'] : 'other';
			$cls[ $k ] = isset( $cls[ $k ] ) ? $cls[ $k ] + 1 : 1;
		}
		return rest_ensure_response( array(
			'workers'    => TNC_Workers::status(),
			'counts'     => TNC_Prospects::counts(),
			'mail_log'   => array_slice( (array) get_option( 'tnc_mail_log', array() ), 0, 8 ),
			'identities' => TNC_Mail_Streams::status(),
			'throttles'  => TNC_Mail_Streams::isp_throttles(),
			'inbox'      => array( 'total' => count( $inbox ), 'classes' => $cls, 'paused' => count( (array) get_option( 'tnc_paused_senders', array() ) ), 'suppressed' => count( (array) get_option( 'tnc_suppression', array() ) ) ),
			'dkim'       => TNC_Emails::dkim_status(),
			'spend'      => array( 'today_usd' => $usd( $spend_today ), 'today_calls' => (int) $spend_today['c'], 'total_usd' => $usd( $spend ), 'total_calls' => (int) $spend['c'] ),
			'fleet'      => TNC_Fleet::status(),
			'backup'     => array_diff_key( TNC_Backup::status_summary(), array( 'file' => 1 ) ),
			'ts'         => time(),
		) );
	}

	public static function state( $req ) {
		return rest_ensure_response( array(
			'counts'  => TNC_Prospects::counts(),
			'workers' => TNC_Workers::status(),
			'ts'      => time(),
		) );
	}

	/** Re-detect platform + commerce for every prospect (taxonomy fix rollout). */
	public static function redetect_all( $req ) {
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 240 );
		}
		$rows = TNC_Prospects::query( array() );
		$out  = array();
		foreach ( $rows as $p ) {
			if ( empty( $p['website_url'] ) ) {
				continue;
			}
			$det = TNC_Crawler::redetect( $p['website_url'] );
			if ( is_wp_error( $det ) ) {
				$out[] = $p['company_name'] . ': fetch-failed';
				continue;
			}
			$updates = array( 'platform' => $det['platform'] );
			if ( is_array( $p['crawl_data'] ) && isset( $p['crawl_data']['extracted'] ) ) {
				$cd = $p['crawl_data'];
				$cd['platform'] = $det['platform'];
				$cd['extracted']['commerce'] = $det['commerce'];
				$updates['crawl_data'] = wp_json_encode( $cd );
			}
			TNC_Prospects::update( $p['id'], $updates );
			TNC_Prospects::audit( $p['id'], 'Platform re-detected: ' . $det['platform'] . ( $det['commerce'] ? ' + ' . $det['commerce'] : '' ) . ' (taxonomy fix)', 'code_scan', 'verified' );
			$out[] = $p['company_name'] . ': ' . $det['platform'] . ( $det['commerce'] ? '+woo' : '' );
			usleep( 400000 );
		}
		return rest_ensure_response( array( 'ok' => true, 'results' => $out ) );
	}

	/**
	 * GROUND-TRUTH FIXTURE SET (binding verification rule #10): known answers
	 * checked against live prospect data. Any regression = release-failing.
	 * Every user-caught error becomes a permanent entry here.
	 */
	/**
	 * CHAT RE-DETECTION (accuracy fix): re-runs Detection v5 (homepage + JS
	 * sample + GTM containers) for one prospect (?id=) or all, updates the
	 * stored chat verdict, and RESCORES — a false "no chat" inflates the
	 * opportunity score, so fixing detection fixes the score. Never downgrades
	 * a human visual "chat present" verdict to absent.
	 */
	/**
	 * THEME REFRESH: extract each prospect's OWN website brand colors and store
	 * them so the demo widget themes per-site (header/buttons/accents/launcher),
	 * falling back to the industry preset only when no usable site color exists.
	 * Higher conversion: a widget that matches the client's site feels native.
	 */
	public static function theme_refresh( $req ) {
		if ( function_exists( 'set_time_limit' ) ) { @set_time_limit( 240 ); }
		$only = (int) $req->get_param( 'id' );
		$rows = TNC_Prospects::query( array() );
		$out  = array();
		foreach ( $rows as $p ) {
			if ( ( $only && (int) $p['id'] !== $only ) || empty( $p['website_url'] ) ) { continue; }
			if ( class_exists( 'TNC_Leadhunter' ) && TNC_Leadhunter::bad_domain( (string) wp_parse_url( $p['website_url'], PHP_URL_HOST ) ) ) { continue; }
			$brand = TNC_Crawler::brand_for_url( $p['website_url'] );
			if ( empty( $brand['primary'] ) ) { $out[] = $p['company_name'] . ': no usable site color'; continue; }
			$cd = is_array( $p['crawl_data'] ) ? $p['crawl_data'] : array();
			if ( ! isset( $cd['extracted'] ) || ! is_array( $cd['extracted'] ) ) { $cd['extracted'] = array(); }
			$cd['extracted']['brand'] = $brand;
			TNC_Prospects::update( $p['id'], array( 'crawl_data' => wp_json_encode( $cd ) ) );
			$out[] = $p['company_name'] . ': ' . $brand['primary'] . ( ! empty( $brand['secondary'] ) ? ' / ' . $brand['secondary'] : '' );
			usleep( 200000 );
		}
		return rest_ensure_response( array( 'ok' => true, 'results' => $out ) );
	}

	public static function redetect_chat( $req ) {
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 240 );
		}
		$only = (int) $req->get_param( 'id' );
		$rows = TNC_Prospects::query( array() );
		$out  = array();
		foreach ( $rows as $p ) {
			if ( ( $only && (int) $p['id'] !== $only ) || empty( $p['website_url'] ) ) {
				continue;
			}
			$chat = TNC_Crawler::redetect_chat( $p['website_url'] );
			if ( is_wp_error( $chat ) ) {
				$out[] = $p['company_name'] . ': fetch-failed';
				continue;
			}
			$cd = is_array( $p['crawl_data'] ) ? $p['crawl_data'] : array();
			if ( ! isset( $cd['extracted'] ) || ! is_array( $cd['extracted'] ) ) {
				$cd['extracted'] = array();
			}
			$prev_conf = isset( $cd['extracted']['chat_confidence'] ) ? $cd['extracted']['chat_confidence'] : '';
			$prev_type = isset( $cd['extracted']['chat_type'] ) ? $cd['extracted']['chat_type'] : 'none';
			if ( 'none' === $chat['type'] && 'none' !== $prev_type && 'verified_present' === $prev_conf ) {
				$out[] = $p['company_name'] . ': kept verified-present (' . $cd['extracted']['chat_widget'] . ')';
				continue; // human/visual confirmation outranks a clean code scan.
			}
			$cd['extracted']['chat_widget']     = $chat['provider'];
			$cd['extracted']['chat_type']       = $chat['type'];
			$cd['extracted']['chat_grade']      = $chat['grade'];
			$cd['extracted']['chat_confidence'] = isset( $chat['confidence'] ) ? $chat['confidence'] : 'needs_review';
			$p['crawl_data'] = $cd;
			list( $score, $breakdown ) = TNC_Outreach::score( $p );
			TNC_Prospects::update( $p['id'], array(
				'crawl_data'      => wp_json_encode( $cd ),
				'score'           => $score,
				'score_breakdown' => wp_json_encode( $breakdown ),
			) );
			TNC_Prospects::audit( $p['id'], 'Chat re-detected (v5): ' . ( $chat['provider'] ? $chat['provider'] : 'none found' ) . ' [' . $chat['confidence'] . '] — rescored ' . $p['score'] . ' -> ' . $score, 'code_scan', $chat['confidence'] );
			$out[] = $p['company_name'] . ': ' . ( $chat['provider'] ? $chat['provider'] : 'none' ) . ' (' . $chat['confidence'] . ') score ' . $p['score'] . '->' . $score;
			usleep( 300000 );
		}
		return rest_ensure_response( array( 'ok' => true, 'results' => $out ) );
	}

	/**
	 * PRODUCT CATALOG REFRESH: re-pulls the structured catalog (Shopify
	 * products.json / Woo Store API / JSON-LD) for one prospect (?id=) or all
	 * with a known platform, stores it in crawl_data and re-ingests the
	 * product chunks. Light: no full re-crawl.
	 */
	public static function products_refresh( $req ) {
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 240 );
		}
		$only = (int) $req->get_param( 'id' );
		$rows = TNC_Prospects::query( array() );
		$out  = array();
		foreach ( $rows as $p ) {
			if ( ( $only && (int) $p['id'] !== $only ) || empty( $p['website_url'] ) ) {
				continue;
			}
			$c        = new TNC_Crawler();
			$products = $c->extract_products( $p['website_url'], $p['platform'], array() );
			if ( ! $products ) {
				$out[] = $p['company_name'] . ': no catalog found';
				continue;
			}
			$cd = is_array( $p['crawl_data'] ) ? $p['crawl_data'] : array();
			$cd['products'] = $products;
			TNC_Prospects::update( $p['id'], array( 'crawl_data' => wp_json_encode( $cd ) ) );
			$n = TNC_KB::ingest_products( $p['id'], $products, true );
			TNC_Prospects::audit( $p['id'], 'Product catalog ingested: ' . $n . ' products (' . $products[0]['source'] . ')', 'catalog', 'verified' );
			$out[] = $p['company_name'] . ': ' . $n . ' products (' . $products[0]['source'] . ')';
			usleep( 300000 );
		}
		return rest_ensure_response( array( 'ok' => true, 'results' => $out ) );
	}

	public static function ground_truth( $req ) {
		$truth = array(
			'lionclickmedia.com'     => array( 'platform' => 'wordpress', 'chat_present' => true ),
			'lunalifestylegroup.com' => array( 'platform' => 'wordpress', 'chat_present' => true ),
			'madreforte.com'         => array( 'platform' => 'shopify' ),
			'allbirds.com'           => array( 'platform' => 'shopify' ),
			// Dolman: user-caught false "no chat" (their site DOES pop a chat) —
			// permanent canary. A false negative here FAILS the release.
			'dolmanlaw.com'          => array( 'platform' => 'wordpress', 'chat_present' => true ),
		);
		$rows    = TNC_Prospects::query( array() );
		$results = array();
		$pass    = true;
		foreach ( $rows as $p ) {
			$host = preg_replace( '/^www\./', '', strtolower( (string) wp_parse_url( $p['website_url'], PHP_URL_HOST ) ) );
			// Check 1: platform truth where known.
			if ( isset( $truth[ $host ] ) ) {
				$ok = ( $p['platform'] === $truth[ $host ]['platform'] );
				if ( ! $ok ) {
					$pass = false;
				}
				$results[] = array( 'check' => 'platform', 'host' => $host, 'expected' => $truth[ $host ]['platform'], 'actual' => $p['platform'], 'pass' => $ok );
			}
			// Check 1b (chat-presence accuracy, release-failing): known-chat
			// canaries must NEVER read "no chat".
			if ( isset( $truth[ $host ]['chat_present'] ) && $truth[ $host ]['chat_present'] ) {
				$exd  = is_array( $p['crawl_data'] ) && isset( $p['crawl_data']['extracted'] ) ? $p['crawl_data']['extracted'] : array();
				$okc  = ! empty( $exd['chat_type'] ) && 'none' !== $exd['chat_type'];
				if ( ! $okc ) {
					$pass = false;
				}
				$results[] = array( 'check' => 'chat_canary_present', 'host' => $host, 'actual' => ( isset( $exd['chat_widget'] ) && $exd['chat_widget'] ? $exd['chat_widget'] : 'none' ), 'pass' => $okc );
			}
			// Check 2 (universal): widget persona must NEVER be the Tuani brand.
			$theme = TNC_Themes::for_prospect( $p );
			$ok2   = ( 'Tuani' !== $theme['agent_name'] );
			if ( ! $ok2 ) {
				$pass = false;
			}
			$results[] = array( 'check' => 'agent_name_not_brand', 'host' => $host, 'actual' => $theme['agent_name'], 'pass' => $ok2 );
			// Check 2b (BINDING, release-failing): button colors must be WCAG-AA
			// vs white text and never harsh red (the Madre Forte rule).
			$okb = TNC_Themes::contrast_vs_white( $theme['accent'] ) >= 4.5 && ! TNC_Themes::is_harsh_red( $theme['accent'] )
				&& TNC_Themes::contrast_vs_white( $theme['accent2'] ) >= 4.5 && ! TNC_Themes::is_harsh_red( $theme['accent2'] );
			if ( ! $okb ) {
				$pass = false;
			}
			$results[] = array( 'check' => 'button_contrast_aa_no_red', 'host' => $host, 'accent' => $theme['accent'], 'accent2' => $theme['accent2'], 'ratio' => round( TNC_Themes::contrast_vs_white( $theme['accent'] ), 2 ), 'pass' => $okb );
			// Check 3 (universal): the chat system prompt must introduce the client persona, never the Tuani brand.
			$sp  = TNC_Compliance::system_prompt( $p, '', $theme );
			$ok3 = ( false === strpos( $sp, 'You are TuaniChat' ) && false !== strpos( $sp, (string) $theme['agent_name'] ) );
			if ( ! $ok3 ) {
				$pass = false;
			}
			$results[] = array( 'check' => 'prompt_persona_client_first', 'host' => $host, 'pass' => $ok3 );
			// Capture prime-directive + plain-text-only rule must be live in every prompt.
			$ok3b = ( false !== strpos( $sp, 'PRIME DIRECTIVE' ) && false !== strpos( $sp, 'TURN CADENCE' ) && false !== strpos( $sp, 'PLAIN TEXT ONLY' ) );
			if ( ! $ok3b ) {
				$pass = false;
			}
			$results[] = array( 'check' => 'prompt_capture_directive', 'host' => $host, 'pass' => $ok3b );
		}
		// Check 4b (PRODUCT TRUTH, release-failing): for every prospect with an
		// ingested catalog, a product+price question must retrieve the exact
		// stored product record (name + listed price) — no invented SKUs/prices
		// can enter answers because answers are grounded in this context.
		global $wpdb;
		foreach ( $rows as $p ) {
			$chunk = $wpdb->get_row( $wpdb->prepare(
				'SELECT title, question, content FROM ' . TNC_KB::table() . " WHERE prospect_id = %d AND chunk_type = 'product' AND enabled = 1 ORDER BY id ASC LIMIT 1",
				(int) $p['id']
			), ARRAY_A );
			if ( ! $chunk ) {
				continue;
			}
			$pname = trim( (string) $chunk['question'] );
			$ctx   = TNC_KB::retrieve( $p['id'], 'How much is ' . $pname . '? What is the price?' );
			$has_name  = false !== stripos( $ctx, $pname );
			$price_line = '';
			if ( preg_match( '/Listed price: [^\n]+/', (string) $chunk['content'], $pm ) ) {
				$price_line = $pm[0];
			}
			$has_price = '' === $price_line || false !== strpos( $ctx, $price_line );
			$okp = $has_name && $has_price;
			if ( ! $okp ) {
				$pass = false;
			}
			$host2 = preg_replace( '/^www\./', '', strtolower( (string) wp_parse_url( $p['website_url'], PHP_URL_HOST ) ) );
			$results[] = array( 'check' => 'product_price_retrieval', 'host' => $host2, 'product' => $pname, 'price' => $price_line, 'pass' => $okp );
		}

		// Check #10 (BINDING, release-failing): no lead_hunter prospect may be
		// promoted (status <> 'new') without a valid email. Email is mandatory.
		$leak = $wpdb->get_results( "SELECT id, company_name, contact_email FROM " . TNC_Prospects::table() . " WHERE source = 'lead_hunter' AND status IN ('demo_created','demo_sent','engaged','won')", ARRAY_A );
		$leaked = array();
		$junk_leaked = array();
		foreach ( (array) $leak as $lr ) {
			if ( empty( $lr['contact_email'] ) || ! is_email( $lr['contact_email'] ) ) {
				$leaked[] = $lr['company_name'];
			} elseif ( class_exists( 'TNC_Leadhunter' ) && TNC_Leadhunter::is_placeholder_email( $lr['contact_email'] ) ) {
				$junk_leaked[] = $lr['company_name'] . ' <' . $lr['contact_email'] . '>';
			}
		}
		$ok_gate = empty( $leaked );
		if ( ! $ok_gate ) { $pass = false; }
		$results[] = array( 'check' => 'prospect_requires_valid_email', 'leaked' => array_slice( $leaked, 0, 10 ), 'leaked_count' => count( $leaked ), 'pass' => $ok_gate );
		// PERMANENT GUARD: no promoted prospect may carry a placeholder/junk email
		// (e.g. user@domain.com). Release-failing — ties to the data-quality epic.
		$ok_junk = empty( $junk_leaked );
		if ( ! $ok_junk ) { $pass = false; }
		$results[] = array( 'check' => 'prospect_no_placeholder_email', 'leaked' => array_slice( $junk_leaked, 0, 10 ), 'leaked_count' => count( $junk_leaked ), 'pass' => $ok_junk );

		// Check 5 (release-failing): every demo link as embedded in outreach
		// kits AND preview templates must return HTTP 200 and load the demo.
		// A "Demo not found" on any outreach link fails the release.
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 120 );
		}
		$urls = array();
		$aliases = get_option( 'tnc_demo_aliases', array() ); $aliases = is_array( $aliases ) ? $aliases : array();
		$alias_added = 0;
		foreach ( $rows as $p ) {
			if ( 'lost' === $p['status'] ) { continue; } // removed/dupe leads have no live demo by design.
			if ( ! empty( $p['demo_slug'] ) ) {
				$urls[ home_url( '/demo/' . $p['demo_slug'] . '/' ) ] = $p['company_name'];
			}
			$kit = is_string( $p['outreach_json'] ) ? json_decode( $p['outreach_json'], true ) : $p['outreach_json'];
			if ( is_array( $kit ) && ! empty( $kit['cold_email'] ) && preg_match( '#https?://\S+/demo/([A-Za-z0-9-]+)#', $kit['cold_email'], $mm ) ) {
				$kit_slug = $mm[1];
				// STALE-SLUG AUTO-HEAL: if a kit link points to an old slug, alias it
				// to the prospect's current slug so the link 301s to a live demo
				// instead of 404ing (fixes iTan etc., permanently + self-healing).
				if ( ! empty( $p['demo_slug'] ) && $kit_slug !== $p['demo_slug'] && ( ! isset( $aliases[ $kit_slug ] ) || $aliases[ $kit_slug ] !== $p['demo_slug'] ) ) {
					$aliases[ $kit_slug ] = $p['demo_slug']; $alias_added++;
				}
				$urls[ untrailingslashit( $mm[0] ) . '/' ] = $p['company_name'] . ' (kit link)';
			}
		}
		if ( $alias_added ) { update_option( 'tnc_demo_aliases', $aliases, false ); }
		$pv = TNC_Previews::build( 'outreach_0' );
		if ( preg_match( '#https?://\S+/demo/\S+#', wp_strip_all_tags( $pv[1] ), $mm ) ) {
			$urls[ untrailingslashit( $mm[0] ) . '/' ] = 'preview template link';
		}
		$blank_canvas = array(); $canvas_checked = 0;
		foreach ( $urls as $u => $who ) {
			$resp  = wp_remote_get( $u, array( 'timeout' => 8, 'sslverify' => false, 'redirection' => 3 ) );
			$code  = is_wp_error( $resp ) ? 0 : (int) wp_remote_retrieve_response_code( $resp );
			$body  = is_wp_error( $resp ) ? '' : (string) wp_remote_retrieve_body( $resp );
			$loads = ( 200 === $code ) && ( false !== strpos( $body, 'TNC_DEMO' ) );
			if ( ! $loads ) { $pass = false; }
			$results[] = array( 'check' => 'outreach_demo_link_loads', 'who' => $who, 'url' => $u, 'http' => $code, 'pass' => $loads );
			// PERMANENT CANVAS-FLOOR TEST (rule #10): the branded mock must be present
			// and NEVER hidden, so the demo canvas is never blank — even when the
			// site blocks framing and the screenshot fails. Reported 5+ times; locked.
			if ( $loads ) {
				$canvas_checked++;
				$has_floor = ( false !== strpos( $body, 'id="tncMock"' ) ) && ( false === strpos( $body, 'id="tncMock" style="display:none"' ) ) && ( false === strpos( $body, "id=\"tncMock\" style='display:none'" ) );
				if ( ! $has_floor ) { $blank_canvas[] = $who; }
			}
		}
		if ( $canvas_checked > 0 ) {
			$ok_canvas = empty( $blank_canvas );
			if ( ! $ok_canvas ) { $pass = false; }
			$results[] = array( 'check' => 'demo_canvas_never_blank', 'checked' => $canvas_checked, 'blank' => array_slice( $blank_canvas, 0, 8 ), 'pass' => $ok_canvas );
		}

		// Check 4 (release-wide): outgoing email templates must contain zero
		// internal annotations, em/en dashes, or gimmicky emojis (style rule).
		$banned = array( "\xE2\x80\x94", "\xE2\x80\x93", '&mdash;', '&ndash;', '&#9889;', "\xE2\x9A\xA1", "\xF0\x9F\x94\xA5", "\xE2\x9A\xA0", "\xE2\x9C\xA8", 'deliberately plain text', 'This preview' );
		$dirty  = array();
		foreach ( array_keys( TNC_Previews::catalog() ) as $k ) {
			$built = TNC_Previews::build( $k );
			$blob  = $built[0] . ' ' . $built[1];
			foreach ( $banned as $b ) {
				if ( false !== strpos( $blob, $b ) ) {
					$dirty[] = $k;
					break;
				}
			}
		}
		$ok4 = empty( $dirty );
		if ( ! $ok4 ) {
			$pass = false;
		}
		$results[] = array( 'check' => 'emails_clean_no_internal_annotations', 'dirty' => $dirty, 'pass' => $ok4 );

		return rest_ensure_response( array( 'ok' => true, 'release_pass' => $pass, 'results' => $results ) );
	}

	/**
	 * Contact enrichment BACKFILL: map already-crawled phones/emails into the
	 * Contact card for every prospect. Never overwrites a manually-entered value;
	 * marks harvested values in the audit trail; flags mismatches.
	 */
	public static function enrich_backfill( $req ) {
		$rows    = TNC_Prospects::query( array() );
		$updated = array();
		$flags   = array();
		foreach ( $rows as $p ) {
			if ( ! is_array( $p['crawl_data'] ) || empty( $p['crawl_data']['extracted'] ) ) {
				continue;
			}
			$ex   = $p['crawl_data']['extracted'];
			$set  = array();
			$site_email = ! empty( $ex['emails'][0] ) ? sanitize_email( $ex['emails'][0] ) : '';
			$site_phone = ! empty( $ex['phones'][0] ) ? sanitize_text_field( $ex['phones'][0] ) : '';
			if ( $site_email && '' === trim( (string) $p['contact_email'] ) ) {
				$set['contact_email'] = $site_email;
			}
			if ( $site_phone && '' === trim( (string) $p['contact_phone'] ) ) {
				$set['contact_phone'] = $site_phone;
			}
			// Mismatch flag: card has a value, site publishes a different one.
			if ( $site_email && '' !== trim( (string) $p['contact_email'] ) && false === stripos( $p['contact_email'], $site_email ) && ! in_array( $p['contact_email'], $ex['emails'], true ) ) {
				$flags[] = $p['company_name'] . ': card email differs from site (' . $site_email . ')';
				TNC_Prospects::audit( $p['id'], 'MISMATCH: card email vs site-published ' . $site_email . ' — review', 'enrichment', 'needs_review' );
			}
			if ( empty( $p['notes'] ) ) {
				$set['notes'] = 'Auto: ' . ( $p['platform'] ? $p['platform'] : 'unknown platform' ) . ' · ' . ( isset( $p['crawl_data']['page_count'] ) ? $p['crawl_data']['page_count'] : '?' ) . ' pages crawled · chat: ' . ( ! empty( $ex['chat_widget'] ) ? $ex['chat_widget'] : 'none found' ) . ( ! empty( $ex['locations'][0] ) ? ' · ' . $ex['locations'][0] : '' );
			}
			if ( $set ) {
				TNC_Prospects::update( $p['id'], $set );
				TNC_Prospects::audit( $p['id'], 'Contact auto-filled from site: ' . implode( ', ', array_keys( $set ) ), 'enrichment', 'verified' );
				$updated[] = $p['company_name'] . ' (' . implode( '+', array_keys( $set ) ) . ')';
			}
		}
		return rest_ensure_response( array( 'ok' => true, 'updated' => $updated, 'mismatch_flags' => $flags ) );
	}

	/** Outreach sender: check config + send a real test through the current mail path. */
	public static function outreach_test( $req ) {
		$missing = array();
		$name    = TNC_Settings::get( 'outreach_from_name' );
		$email   = TNC_Settings::get( 'outreach_from_email' );
		$domain  = TNC_Settings::get( 'outreach_from_domain' );
		if ( ! $name ) { $missing[] = 'From name'; }
		if ( ! $email ) { $missing[] = 'From email'; }
		if ( ! $domain ) { $missing[] = 'Sending domain'; }
		$sent = false;
		if ( empty( $missing ) ) {
			$to   = TNC_Settings::recipients( 'system' );
			$body = "Hi —\n\nThis is a live test of your TuaniChat outreach sender.\n\nFrom: {$name} <{$email}>\nSending domain: {$domain}\nMail path: WordPress/DreamHost mail (test phase — swaps to Brevo with a config change).\n\nIf this landed in your inbox, the sender is ACTIVE. If it landed in spam, that is expected until SPF/DKIM records exist for {$domain}.\n\n— TuaniChat";
			$headers = array( 'From: ' . $name . ' <' . $email . '>', 'Reply-To: ' . $email );
			foreach ( $to as $addr ) {
				$sent = wp_mail( $addr, '[TEST] Outreach sender check — ' . $domain, $body, $headers ) || $sent;
			}
			if ( $sent ) {
				update_option( 'tnc_outreach_sender_ok', time(), false );
			}
		}
		return rest_ensure_response( array( 'ok' => true, 'active' => empty( $missing ) && $sent, 'missing' => $missing, 'sent' => $sent ) );
	}

	/** Generate (or fetch cached) AI opener for one prospect; reports $ actuals. */
	public static function ai_opener( $req ) {
		$p = TNC_Prospects::get( (int) $req['id'] );
		if ( ! $p ) {
			return new WP_Error( 'tnc_404', 'Prospect not found.', array( 'status' => 404 ) );
		}
		$r = TNC_Outreach::ai_opener( $p, true );
		if ( ! empty( $r['meta'] ) ) {
			// Haiku dollar actuals ($1/M in, $5/M out).
			$r['cost_usd'] = round( ( (int) $r['meta']['in'] ) * 1 / 1000000 + ( (int) $r['meta']['out'] ) * 5 / 1000000, 6 );
		}
		return rest_ensure_response( array( 'ok' => true ) + $r );
	}

	public static function verify_email( $req ) {
		$email = sanitize_email( (string) $req->get_param( 'email' ) );
		return rest_ensure_response( array( 'ok' => true, 'email' => $email ) + TNC_Mail_Streams::verify_address( $email ) );
	}

	public static function suppress_email( $req ) {
		$email = sanitize_email( (string) $req->get_param( 'email' ) );
		if ( ! $email ) {
			return new WP_Error( 'tnc_bad', 'email required', array( 'status' => 400 ) );
		}
		TNC_Mail_Streams::suppress( $email, sanitize_key( (string) $req->get_param( 'reason' ) ) );
		return rest_ensure_response( array( 'ok' => true ) );
	}

	public static function outreach_inbox( $req ) {
		return rest_ensure_response( array(
			'ok'             => true,
			'inbox'          => get_option( 'tnc_inbox', array() ),
			'paused_senders' => get_option( 'tnc_paused_senders', array() ),
			'suppressed'     => count( (array) get_option( 'tnc_suppression', array() ) ),
		) );
	}

	/** SEED/PLACEMENT TEST: send one sample to each seed inbox, report results. */
	public static function seed_test( $req ) {
		$emails = $req->get_param( 'emails' );
		if ( ! is_array( $emails ) || ! $emails ) {
			return new WP_Error( 'tnc_bad', 'emails[] required', array( 'status' => 400 ) );
		}
		$emails = array_slice( array_filter( array_map( 'sanitize_email', $emails ) ), 0, 6 );
		list( $subject, $html ) = TNC_Previews::build( 'welcome' );
		$results = array();
		foreach ( $emails as $e ) {
			$sent      = TNC_Emails::send( $e, '[SEED TEST] ' . $subject, $html, 'transactional' );
			$results[] = array( 'to' => $e, 'sent' => (bool) $sent );
		}
		return rest_ensure_response( array( 'ok' => true, 'results' => $results, 'note' => 'Now check each seed inbox and record inbox vs spam per provider BEFORE any campaign.' ) );
	}

	/** Inbound webhook: Brevo inbound / IMAP poller / any parser posts here. */
	public static function mail_inbound( $req ) {
		$token = (string) get_option( 'tnc_inbound_token' );
		if ( '' === $token ) {
			$token = wp_generate_password( 32, false );
			update_option( 'tnc_inbound_token', $token, false );
		}
		if ( ! hash_equals( $token, (string) $req->get_param( 'token' ) ) ) {
			return new WP_Error( 'tnc_auth', 'Bad token.', array( 'status' => 403 ) );
		}
		$class = TNC_Mail_Streams::inbound(
			(string) $req->get_param( 'from' ),
			(string) $req->get_param( 'subject' ),
			(string) $req->get_param( 'text' )
		);
		return rest_ensure_response( array( 'ok' => true, 'class' => $class ) );
	}

	/** One-click unsubscribe: instant, permanent, friendly. */
	public static function unsub( $req ) {
		$e = sanitize_email( (string) $req->get_param( 'e' ) );
		$t = (string) $req->get_param( 't' );
		if ( $e && hash_equals( TNC_Mail_Streams::unsub_token( $e ), $t ) ) {
			TNC_Mail_Streams::suppress( $e, 'one_click_unsub' );
			return new WP_REST_Response( array( 'ok' => true, 'message' => 'You are unsubscribed. You will not hear from us again.' ), 200 );
		}
		return new WP_Error( 'tnc_bad', 'Invalid link.', array( 'status' => 400 ) );
	}

	public static function fleet_admin( $req ) {
		return rest_ensure_response( array( 'ok' => true, 'token' => TNC_Fleet::token(), 'endpoint' => esc_url_raw( rest_url( TNC_REST_NS . '/fleet' ) ) ) + TNC_Fleet::status() );
	}

	public static function fleet_enqueue( $req ) {
		$type    = sanitize_key( (string) $req->get_param( 'type' ) );
		$payload = $req->get_param( 'payload' );
		if ( ! $type ) {
			return new WP_Error( 'tnc_bad', 'type required', array( 'status' => 400 ) );
		}
		return rest_ensure_response( array( 'ok' => true, 'id' => TNC_Fleet::enqueue( $type, $payload ) ) );
	}

	public static function mail_streams( $req ) {
		return rest_ensure_response( array( 'ok' => true, 'identities' => TNC_Mail_Streams::status(), 'isp_throttles' => TNC_Mail_Streams::isp_throttles() ) );
	}

	public static function dkim_setup( $req ) {
		$r = TNC_Emails::dkim_setup();
		return is_wp_error( $r ) ? $r : rest_ensure_response( array( 'ok' => true ) + $r );
	}

	public static function dkim_status( $req ) {
		return rest_ensure_response( array( 'ok' => true ) + TNC_Emails::dkim_status() );
	}

	/**
	 * INSTANT LOCAL SCREENSHOT: download the homepage render ONCE server-side,
	 * validate it is a real image (not a generating-placeholder), store it in
	 * uploads/tnc-shots/, and point the demo at the local file. Render never
	 * depends on a third party again; a good screenshot is never replaced.
	 */
	public static function snap( $req ) {
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 120 );
		}
		$p = TNC_Prospects::get( (int) $req['id'] );
		if ( ! $p ) {
			return new WP_Error( 'tnc_404', 'Prospect not found.', array( 'status' => 404 ) );
		}
		$src  = 'https://s0.wp.com/mshots/v1/' . rawurlencode( $p['website_url'] ) . '?w=1600';
		$body = '';
		for ( $i = 0; $i < 4; $i++ ) {
			$resp = wp_remote_get( $src, array( 'timeout' => 25 ) ); // same URL every try: mShots serves the finished render once ready.
			$body = is_wp_error( $resp ) ? '' : (string) wp_remote_retrieve_body( $resp );
			$ok   = strlen( $body ) > 25000 && ( 0 === strpos( $body, "\xFF\xD8" ) || 0 === strpos( $body, "\x89PNG" ) );
			if ( $ok ) {
				break;
			}
			$body = '';
			sleep( 6 ); // mShots returns a small placeholder while generating.
		}
		if ( '' === $body ) {
			return rest_ensure_response( array( 'ok' => false, 'note' => 'Screenshot service did not return a real image after 4 tries.' ) );
		}
		$up  = wp_upload_dir();
		$dir = trailingslashit( $up['basedir'] ) . 'tnc-shots';
		wp_mkdir_p( $dir );
		$file = $dir . '/' . sanitize_file_name( $p['demo_slug'] ) . '.jpg';
		file_put_contents( $file, $body ); // phpcs:ignore
		$url   = trailingslashit( $up['baseurl'] ) . 'tnc-shots/' . sanitize_file_name( $p['demo_slug'] ) . '.jpg';
		$crawl = is_array( $p['crawl_data'] ) ? $p['crawl_data'] : array();
		if ( ! isset( $crawl['extracted'] ) || ! is_array( $crawl['extracted'] ) ) {
			$crawl['extracted'] = array();
		}
		$crawl['extracted']['screenshot_local'] = $url;

		// AUTHORITATIVE FRAMABILITY RE-PROBE: the old header check missed CSP
		// frame-ancestors (Shopify et al), producing false "framable" flags and
		// blank iframes. Reality decides: X-Frame-Options OR frame-ancestors
		// present = NOT framable, serve the local screenshot instead.
		$hr  = wp_remote_get( $p['website_url'], array( 'timeout' => 12, 'redirection' => 3 ) );
		if ( ! is_wp_error( $hr ) ) {
			$xfo = strtolower( (string) wp_remote_retrieve_header( $hr, 'x-frame-options' ) );
			$csp = strtolower( (string) wp_remote_retrieve_header( $hr, 'content-security-policy' ) );
			$crawl['extracted']['framable'] = ( '' === $xfo || ( false === strpos( $xfo, 'deny' ) && false === strpos( $xfo, 'sameorigin' ) ) ) && ( false === strpos( $csp, 'frame-ancestors' ) );
		}
		TNC_Prospects::update( $p['id'], array( 'crawl_data' => wp_json_encode( $crawl ) ) );
		return rest_ensure_response( array( 'ok' => true, 'url' => $url, 'bytes' => strlen( $body ), 'framable' => ! empty( $crawl['extracted']['framable'] ) ) );
	}

	/** Mail diagnosis: ledger of every wp_mail result + last From/envelope used. */
	public static function mail_log( $req ) {
		return rest_ensure_response( array(
			'ok'        => true,
			'last_from' => get_option( 'tnc_last_mail_from', null ),
			'log'       => get_option( 'tnc_mail_log', array() ),
		) );
	}

	/** ONE plain-text end-to-end test (no HTML) to isolate auth vs content filtering. */
	public static function mail_test( $req ) {
		$to = sanitize_email( (string) $req->get_param( 'to' ) );
		if ( ! $to ) {
			return new WP_Error( 'tnc_bad', 'Parameter "to" (email) required.', array( 'status' => 400 ) );
		}
		$stamp = gmdate( 'Y-m-d H:i:s' ) . ' UTC';
		$body  = "Plain-text TuaniChat mail-path test sent {$stamp}.\n\nFrom/envelope are forced onto the SPF-authorized chat subdomain for DMARC alignment.\nIf this arrived, the auth path works and HTML previews should follow.";
		$sent  = wp_mail( $to, '[TuaniChat] Mail path test ' . gmdate( 'His' ), $body );
		TNC_Emails::log( array( 'event' => 'mail_test', 'to' => $to, 'ok' => $sent ? 1 : 0 ) );
		return rest_ensure_response( array(
			'ok'             => true,
			'wp_mail_return' => (bool) $sent,
			'from_used'      => get_option( 'tnc_last_mail_from', null ),
		) );
	}

	public static function save_settings( $req ) {
		$pairs = array(
			'model'            => sanitize_text_field( (string) $req->get_param( 'model' ) ),
			'endpoint_base'    => esc_url_raw( (string) $req->get_param( 'endpoint_base' ) ),
			'cta_activate_url' => esc_url_raw( (string) $req->get_param( 'cta_activate_url' ) ),
			'cta_call_url'     => esc_url_raw( (string) $req->get_param( 'cta_call_url' ) ),
			'notify_email'     => implode( ', ', array_filter( array_map( function ( $e ) { return sanitize_email( trim( $e ) ); }, explode( ',', (string) $req->get_param( 'notify_email' ) ) ) ) ),
			'crawl_max_pages'  => max( 1, min( TNC_Crawl_Jobs::HARD_CAP, (int) $req->get_param( 'crawl_max_pages' ) ) ),
			'crawl_full_pages' => max( 10, min( TNC_Crawl_Jobs::HARD_CAP, (int) $req->get_param( 'crawl_full_pages' ) ) ),
			'crawl_batch_size' => max( 2, min( 15, (int) $req->get_param( 'crawl_batch_size' ) ) ),
			'bulk_stagger'     => max( 30, min( 900, (int) $req->get_param( 'bulk_stagger' ) ) ),
			'crawl_timeout'    => max( 3, min( 30, (int) $req->get_param( 'crawl_timeout' ) ) ),
			'crawl_concurrency' => max( 2, min( 8, (int) $req->get_param( 'crawl_concurrency' ) ) ),
			'crawl_per_host'   => max( 1, min( 4, (int) $req->get_param( 'crawl_per_host' ) ) ),
			'bulk_lanes'       => max( 1, min( 3, (int) $req->get_param( 'bulk_lanes' ) ) ),
			'chat_rate_limit'  => max( 3, min( 200, (int) $req->get_param( 'chat_rate_limit' ) ) ),
			'chat_daily_per_demo' => null !== $req->get_param( 'chat_daily_per_demo' ) ? max( 10, min( 5000, (int) $req->get_param( 'chat_daily_per_demo' ) ) ) : 150,
			'chat_daily_global'   => null !== $req->get_param( 'chat_daily_global' ) ? max( 20, min( 50000, (int) $req->get_param( 'chat_daily_global' ) ) ) : 800,
			'chat_session_cap'    => null !== $req->get_param( 'chat_session_cap' ) ? max( 5, min ( 500, (int) $req->get_param( 'chat_session_cap' ) ) ) : 40,
			'verify_smtp_probe'   => (int) (bool) $req->get_param( 'verify_smtp_probe' ),
			'outreach_ai_opener'  => (int) (bool) $req->get_param( 'outreach_ai_opener' ),
			'cta_booking_url'     => esc_url_raw( (string) $req->get_param( 'cta_booking_url' ) ),
		);
		foreach ( array( 'notify_leads', 'notify_crawl', 'notify_system' ) as $tk ) {
			if ( null !== $req->get_param( $tk ) ) {
				$pairs[ $tk ] = (int) (bool) $req->get_param( $tk );
			}
		}
		$pairs['outreach_from_name']   = sanitize_text_field( (string) $req->get_param( 'outreach_from_name' ) );
		$pairs['outreach_from_email']  = sanitize_email( (string) $req->get_param( 'outreach_from_email' ) );
		$pairs['outreach_from_domain'] = sanitize_text_field( (string) $req->get_param( 'outreach_from_domain' ) );
		$identity = sanitize_key( (string) $req->get_param( 'outreach_identity' ) );
		$pairs['outreach_identity']    = in_array( $identity, array( 'tuanichat', 'partner' ), true ) ? $identity : 'tuanichat';
		$pairs['cta_urgency_text']     = sanitize_text_field( (string) $req->get_param( 'cta_urgency_text' ) );
		if ( null !== $req->get_param( 'demo_autoopen_secs' ) ) {
			$pairs['demo_autoopen_secs'] = max( 3, min( 10, (int) $req->get_param( 'demo_autoopen_secs' ) ) );
		}
		if ( null !== $req->get_param( 'lead_form_helper' ) ) {
			$pairs['lead_form_helper'] = sanitize_text_field( (string) $req->get_param( 'lead_form_helper' ) );
		}
		$pairs['screenshot_api_url'] = esc_url_raw( (string) $req->get_param( 'screenshot_api_url' ) );
		$pairs['screenshot_api_key'] = sanitize_text_field( (string) $req->get_param( 'screenshot_api_key' ) );
		// API key: only update when a new value is provided (masked value ignored).
		$key = (string) $req->get_param( 'api_key' );
		if ( '' !== $key && false === strpos( $key, '•' ) ) {
			$pairs['api_key'] = trim( sanitize_text_field( $key ) );
		}
		if ( '' === $pairs['endpoint_base'] ) {
			$pairs['endpoint_base'] = 'https://api.anthropic.com';
		}
		TNC_Settings::update( $pairs );
		return rest_ensure_response( array( 'ok' => true, 'masked_key' => TNC_Settings::masked_key() ) );
	}
}
