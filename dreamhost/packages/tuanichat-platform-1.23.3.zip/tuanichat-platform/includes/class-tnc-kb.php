<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Knowledge Base: chunked storage + keyword (BM25-style) retrieval.
 */
class TNC_KB {

	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'tnc_kb_chunks';
	}

	/* ---------- Chunk CRUD ---------- */

	public static function add_chunk( $prospect_id, $type, $title, $content, $source_url = '', $question = '' ) {
		global $wpdb;
		$content = trim( (string) $content );
		if ( '' === $content ) {
			return 0;
		}
		$wpdb->insert( self::table(), array(
			'prospect_id' => (int) $prospect_id,
			'chunk_type'  => sanitize_key( $type ),
			'title'       => sanitize_text_field( mb_substr( $title, 0, 250 ) ),
			'question'    => sanitize_textarea_field( $question ),
			'content'     => wp_kses_post( $content ),
			'source_url'  => esc_url_raw( $source_url ),
			'enabled'     => 1,
			'created_at'  => current_time( 'mysql' ),
		) );
		return (int) $wpdb->insert_id;
	}

	public static function update_chunk( $chunk_id, $fields ) {
		global $wpdb;
		$clean = array();
		if ( isset( $fields['title'] ) )    { $clean['title']    = sanitize_text_field( $fields['title'] ); }
		if ( isset( $fields['content'] ) )  { $clean['content']  = wp_kses_post( $fields['content'] ); }
		if ( isset( $fields['question'] ) ) { $clean['question'] = sanitize_textarea_field( $fields['question'] ); }
		if ( isset( $fields['enabled'] ) )  { $clean['enabled']  = (int) (bool) $fields['enabled']; }
		if ( empty( $clean ) ) {
			return false;
		}
		return false !== $wpdb->update( self::table(), $clean, array( 'id' => (int) $chunk_id ) );
	}

	public static function delete_chunk( $chunk_id ) {
		global $wpdb;
		return false !== $wpdb->delete( self::table(), array( 'id' => (int) $chunk_id ) );
	}

	public static function get_chunks( $prospect_id, $search = '', $type = '' ) {
		global $wpdb;
		$where  = array( 'prospect_id = %d' );
		$params = array( (int) $prospect_id );
		if ( '' !== $search ) {
			$like     = '%' . $wpdb->esc_like( $search ) . '%';
			$where[]  = '(title LIKE %s OR content LIKE %s OR question LIKE %s)';
			$params[] = $like; $params[] = $like; $params[] = $like;
		}
		if ( '' !== $type ) {
			$where[]  = 'chunk_type = %s';
			$params[] = sanitize_key( $type );
		}
		$sql = 'SELECT * FROM ' . self::table() . ' WHERE ' . implode( ' AND ', $where ) . ' ORDER BY id DESC LIMIT 500';
		return $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A );
	}

	public static function delete_crawled( $prospect_id ) {
		global $wpdb;
		$wpdb->query( $wpdb->prepare(
			'DELETE FROM ' . self::table() . " WHERE prospect_id = %d AND chunk_type IN ('crawl','basics','pricing','product')",
			(int) $prospect_id
		) );
	}

	/* ---------- Build KB from crawl ---------- */

	public static function ingest_crawl( $prospect_id, $crawl ) {
		self::delete_crawled( $prospect_id ); // re-crawl replaces crawled chunks, preserves manual/qa/file.

		$ex = isset( $crawl['extracted'] ) ? $crawl['extracted'] : array();

		// Company basics chunk (always included in retrieval).
		$basics   = array();
		if ( ! empty( $ex['company_name'] ) )  { $basics[] = 'Company: ' . $ex['company_name']; }
		if ( ! empty( $ex['description'] ) )   { $basics[] = 'About: ' . $ex['description']; }
		if ( ! empty( $ex['services'] ) )      { $basics[] = 'Services/Products: ' . implode( '; ', $ex['services'] ); }
		if ( ! empty( $ex['locations'] ) )     { $basics[] = 'Locations: ' . implode( ' | ', $ex['locations'] ); }
		if ( ! empty( $ex['phones'] ) )        { $basics[] = 'Phone: ' . implode( ', ', $ex['phones'] ); }
		if ( ! empty( $ex['emails'] ) )        { $basics[] = 'Email: ' . implode( ', ', $ex['emails'] ); }
		if ( ! empty( $ex['trust_signals'] ) ) { $basics[] = 'Trust signals: ' . implode( ', ', $ex['trust_signals'] ); }
		if ( $basics ) {
			self::add_chunk( $prospect_id, 'basics', 'Company basics', implode( "\n", $basics ), isset( $crawl['pages'] ) ? array_key_first( $crawl['pages'] ) : '' );
		}

		// Structured pricing chunks — the only source the assistant may quote prices from.
		if ( ! empty( $ex['pricing'] ) ) {
			foreach ( $ex['pricing'] as $pr ) {
				self::add_chunk(
					$prospect_id,
					'pricing',
					'Pricing: ' . $pr['item'],
					$pr['item'] . ' — listed price: ' . $pr['price'] . ( ! empty( $pr['context'] ) ? "\nAs stated on their site: \"" . $pr['context'] . '"' : '' ),
					isset( $pr['url'] ) ? $pr['url'] : ''
				);
			}
		}

		// PRODUCT CATALOG chunks — the only source product specs/prices may come from.
		if ( ! empty( $crawl['products'] ) && is_array( $crawl['products'] ) ) {
			self::ingest_products( $prospect_id, $crawl['products'], false );
		}

		// FAQ chunks.
		if ( ! empty( $ex['faqs'] ) ) {
			foreach ( $ex['faqs'] as $faq ) {
				self::add_chunk( $prospect_id, 'crawl', 'FAQ: ' . $faq['q'], 'Q: ' . $faq['q'] . "\nA: " . $faq['a'] );
			}
		}

		// Page chunks.
		if ( ! empty( $crawl['pages'] ) ) {
			foreach ( $crawl['pages'] as $url => $page ) {
				$chunks = self::chunk_text( $page['text'] );
				$i      = 0;
				foreach ( $chunks as $piece ) {
					$i++;
					$title = $page['title'] . ( count( $chunks ) > 1 ? ' (' . $i . ')' : '' );
					self::add_chunk( $prospect_id, 'crawl', $title, $piece, $url );
					if ( $i >= 6 ) {
						break; // cap chunks per page.
					}
				}
			}
		}
	}

	/**
	 * PRODUCT-AWARE KB: one structured chunk per catalog product (name, price,
	 * variants, SKU, specs). Chat answers about products must be grounded in
	 * these records — never invented.
	 */
	public static function ingest_products( $prospect_id, $products, $replace = true ) {
		global $wpdb;
		if ( $replace ) {
			$wpdb->query( $wpdb->prepare(
				'DELETE FROM ' . self::table() . " WHERE prospect_id = %d AND chunk_type = 'product'",
				(int) $prospect_id
			) );
		}
		$n = 0;
		foreach ( (array) $products as $pr ) {
			if ( empty( $pr['name'] ) ) {
				continue;
			}
			$lines   = array( 'Product: ' . $pr['name'] );
			$lines[] = '' !== (string) $pr['price']
				? 'Listed price: $' . $pr['price'] . ( ! empty( $pr['compare'] ) ? ' (compare-at $' . $pr['compare'] . ')' : '' )
				: 'Listed price: not published';
			if ( ! empty( $pr['variants'] ) ) { $lines[] = 'Variants: ' . implode( ' | ', array_slice( (array) $pr['variants'], 0, 8 ) ); }
			if ( ! empty( $pr['sku'] ) )      { $lines[] = 'SKU: ' . $pr['sku']; }
			if ( ! empty( $pr['type'] ) )     { $lines[] = 'Category: ' . $pr['type']; }
			if ( ! empty( $pr['vendor'] ) )   { $lines[] = 'Brand: ' . $pr['vendor']; }
			if ( ! empty( $pr['specs'] ) )    { $lines[] = 'Options/Specs: ' . implode( ' | ', array_slice( (array) $pr['specs'], 0, 8 ) ); }
			if ( ! empty( $pr['desc'] ) )     { $lines[] = 'Description: ' . $pr['desc']; }
			self::add_chunk( $prospect_id, 'product', 'Product: ' . mb_substr( $pr['name'], 0, 230 ), implode( "\n", $lines ), isset( $pr['url'] ) ? $pr['url'] : '', (string) $pr['name'] );
			if ( ++$n >= 120 ) {
				break;
			}
		}
		return $n;
	}

	/** Split text into ~1200-char chunks on heading/paragraph boundaries. */
	public static function chunk_text( $text, $target = 1200 ) {
		$text = trim( (string) $text );
		if ( '' === $text ) {
			return array();
		}
		$blocks = preg_split( '/\n(?=## )|\n\n+/', $text );
		$chunks = array();
		$buf    = '';
		foreach ( $blocks as $b ) {
			$b = trim( $b );
			if ( '' === $b || strlen( $b ) < 30 ) {
				continue;
			}
			if ( strlen( $buf ) + strlen( $b ) > $target && '' !== $buf ) {
				$chunks[] = $buf;
				$buf      = '';
			}
			$buf .= ( '' === $buf ? '' : "\n\n" ) . $b;
			if ( strlen( $buf ) > $target * 2 ) {
				$chunks[] = substr( $buf, 0, $target * 2 );
				$buf      = '';
			}
		}
		if ( '' !== trim( $buf ) ) {
			$chunks[] = $buf;
		}
		// De-duplicate near-identical chunks (nav/footer repetition).
		$seen = array();
		$out  = array();
		foreach ( $chunks as $c ) {
			$sig = md5( substr( preg_replace( '/\W+/', '', strtolower( $c ) ), 0, 400 ) );
			if ( ! isset( $seen[ $sig ] ) ) {
				$seen[ $sig ] = true;
				$out[]        = $c;
			}
		}
		return $out;
	}

	/* ---------- Retrieval ---------- */

	private static function tokenize( $text ) {
		$text = strtolower( wp_strip_all_tags( (string) $text ) );
		preg_match_all( '/[a-z0-9]{3,}/', $text, $m );
		$stop = array( 'the', 'and', 'for', 'are', 'you', 'your', 'with', 'that', 'this', 'have', 'has', 'how', 'what', 'when', 'where', 'who', 'why', 'can', 'does', 'will', 'about', 'much', 'many', 'them', 'they', 'our', 'out', 'get', 'all', 'any', 'was', 'were', 'from', 'not', 'but', 'his', 'her', 'its' );
		return array_values( array_diff( $m[0], $stop ) );
	}

	/**
	 * Select relevant context for a chat message. Returns string capped at max chars.
	 */
	public static function retrieve( $prospect_id, $query, $max_chars = 7000 ) {
		$chunks = self::get_chunks( $prospect_id );
		$chunks = array_filter( $chunks, function ( $c ) {
			return ! empty( $c['enabled'] );
		} );
		if ( empty( $chunks ) ) {
			return '';
		}

		$q_tokens = self::tokenize( $query );
		$n        = count( $chunks );

		// Document frequency.
		$df         = array();
		$doc_tokens = array();
		foreach ( $chunks as $idx => $c ) {
			$toks                = self::tokenize( $c['title'] . ' ' . $c['question'] . ' ' . $c['content'] );
			$doc_tokens[ $idx ]  = array_count_values( $toks );
			foreach ( array_unique( $toks ) as $t ) {
				$df[ $t ] = isset( $df[ $t ] ) ? $df[ $t ] + 1 : 1;
			}
		}

		$avg_len = 0;
		foreach ( $doc_tokens as $dt ) {
			$avg_len += array_sum( $dt );
		}
		$avg_len = $n > 0 ? max( 1, $avg_len / $n ) : 1;

		// BM25-ish scoring.
		$k1 = 1.5;
		$b  = 0.75;
		$scores = array();
		foreach ( $chunks as $idx => $c ) {
			$score  = 0.0;
			$dl     = max( 1, array_sum( $doc_tokens[ $idx ] ) );
			foreach ( $q_tokens as $t ) {
				if ( empty( $doc_tokens[ $idx ][ $t ] ) ) {
					continue;
				}
				$tf  = $doc_tokens[ $idx ][ $t ];
				$idf = log( 1 + ( $n - $df[ $t ] + 0.5 ) / ( $df[ $t ] + 0.5 ) );
				$score += $idf * ( $tf * ( $k1 + 1 ) ) / ( $tf + $k1 * ( 1 - $b + $b * $dl / $avg_len ) );
			}
			// Q&A pairs: boost strongly when question terms overlap.
			if ( 'qa' === $c['chunk_type'] && $score > 0 ) {
				$score *= 3;
			}
			if ( 'product' === $c['chunk_type'] && $score > 0 ) {
				$score *= 2; // catalog records outrank loose page prose for product asks.
			}
			if ( 'basics' === $c['chunk_type'] ) {
				$score += 0.1; // tie-break, but basics are force-included below anyway.
			}
			$scores[ $idx ] = $score;
		}
		arsort( $scores );

		$parts = array();
		$used  = 0;

		// Pricing intent → structured pricing chunks are force-included first.
		$is_pricing = (bool) preg_match( '/(price|pricing|cost|how much|fee|fees|rate|rates|charge|quote|\$)/i', $query );
		if ( $is_pricing ) {
			// Best-matching PRODUCT records first (catalog truth for product+price asks).
			foreach ( $scores as $idx => $sc ) {
				$c = $chunks[ $idx ];
				if ( 'product' === $c['chunk_type'] && $sc > 0 && $used < $max_chars * 0.45 ) {
					$piece   = '[Product record — name/specs/price VERBATIM only]' . "\n" . $c['content'] . ( $c['source_url'] ? "\n(Source: " . $c['source_url'] . ')' : '' );
					$parts[] = $piece;
					$used   += strlen( $piece );
					unset( $scores[ $idx ] );
				}
			}
			foreach ( $chunks as $idx => $c ) {
				if ( 'pricing' === $c['chunk_type'] && $used < $max_chars * 0.5 ) {
					$piece   = '[Published price — quote VERBATIM only]\n' . $c['content'] . ( $c['source_url'] ? "\n(Source: " . $c['source_url'] . ')' : '' );
					$parts[] = $piece;
					$used   += strlen( $piece );
					unset( $scores[ $idx ] );
				}
			}
		}

		// Always include company basics first.
		foreach ( $chunks as $idx => $c ) {
			if ( 'basics' === $c['chunk_type'] ) {
				$piece  = "[Company basics]\n" . $c['content'];
				$parts[] = $piece;
				$used   += strlen( $piece );
				unset( $scores[ $idx ] );
			}
		}

		// Then best-scoring chunks.
		foreach ( $scores as $idx => $score ) {
			if ( $score <= 0 && count( $parts ) > 3 ) {
				break;
			}
			$c     = $chunks[ $idx ];
			$label = 'qa' === $c['chunk_type'] ? 'Approved answer — Q: ' . $c['question'] : $c['title'];
			$piece = '[' . $label . "]\n" . $c['content'];
			if ( $used + strlen( $piece ) > $max_chars ) {
				continue;
			}
			$parts[] = $piece;
			$used   += strlen( $piece );
			if ( $used >= $max_chars * 0.95 ) {
				break;
			}
		}

		return implode( "\n\n---\n\n", $parts );
	}
}
