<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Theme engine v2 — server-side token sets per industry preset.
 * v1.3 tokens: widget_mode (standard|advanced), button_style (outline|solid),
 * agent persona (name/avatar/subtitle), section title, guided choices.
 */
class TNC_Themes {

	public static function presets() {
		return array(
			'legal' => array(
				'ring'           => '#D4AF37',
				'panel'          => 'dark',
				'radius'         => 'rounded',
				'accent'         => '#A8861D',
				'accent2'        => '#D4AF37',
				'tone'           => 'professional, reassuring, plain-English',
				'greeting'       => "Hi, I'm the virtual intake assistant for {company}. I can answer questions about our practice and help you request a free consultation. How can I help?",
				'starters'       => array( 'Do I have a case?', 'How much does a consultation cost?', 'What should I do after an accident?', 'How do I get started?' ),
				'widget_name'    => 'Intake Assistant',
				'widget_mode'    => 'advanced',
				'button_style'   => 'solid',
				'choices'        => array( 'I would like to request a consultation', 'I want to ask about my situation', 'I have a different question' ),
			),
			'medspa' => array(
				'ring'           => '#E0A899',
				'panel'          => 'light',
				'radius'         => 'pill',
				'accent'         => '#B76E79',
				'accent2'        => '#D8A48F',
				'tone'           => 'warm, polished, welcoming',
				'greeting'       => "Welcome to {company}! I can tell you about our treatments and help you book a consultation. What are you interested in?",
				'starters'       => array( 'What treatments do you offer?', 'How do I book a consultation?', 'Is there any downtime?', 'Do you offer financing?' ),
				'widget_name'    => 'Concierge',
				'widget_mode'    => 'advanced',
				'button_style'   => 'solid',
				'choices'        => array( 'I want to book a consultation', "I'd like to ask about a treatment", 'I have a different question' ),
			),
			'dental' => array(
				'ring'           => '#22D3EE',
				'panel'          => 'light',
				'radius'         => 'rounded',
				'accent'         => '#0891B2',
				'accent2'        => '#22D3EE',
				'tone'           => 'friendly, calm, clear',
				'greeting'       => "Hi! I'm the virtual assistant for {company}. I can answer questions about our services and help you request an appointment. How can I help today?",
				'starters'       => array( 'Do you accept my insurance?', 'How do I book an appointment?', 'Do you see new patients?', 'What services do you offer?' ),
				'widget_name'    => 'Patient Assistant',
				'widget_mode'    => 'advanced',
				'button_style'   => 'solid',
				'choices'        => array( "I'd like to request an appointment", 'I have an insurance question', 'I have a different question' ),
			),
			'trades' => array(
				'ring'           => '#F97316',
				'panel'          => 'dark',
				'radius'         => 'rounded',
				'accent'         => '#EA580C',
				'accent2'        => '#FB923C',
				'tone'           => 'direct, helpful, trustworthy',
				'greeting'       => "Hi there — I'm the assistant for {company}. Ask me about our services or request a free estimate. What do you need help with?",
				'starters'       => array( 'Do you offer free estimates?', 'What areas do you serve?', 'Do you handle emergencies?', 'How soon can someone come out?' ),
				'widget_name'    => 'Service Assistant',
				'widget_mode'    => 'advanced',
				'button_style'   => 'solid',
				'choices'        => array( "I'd like a free estimate", 'I would like to request pricing', 'I have a different question' ),
			),
			'ecommerce' => array(
				'ring'           => '#A78BFA',
				'panel'          => 'dark',
				'radius'         => 'pill',
				'accent'         => '#7C3AED',
				'accent2'        => '#A78BFA',
				'tone'           => 'upbeat, concise, helpful',
				'greeting'       => "Hey! I'm the shopping assistant for {company}. I can help you find products and answer questions about shipping and returns. What are you looking for?",
				'starters'       => array( 'What are your best sellers?', 'What is your return policy?', 'How long does shipping take?', 'Help me find a product' ),
				'widget_name'    => 'Shopping Assistant',
				'widget_mode'    => 'standard',
				'button_style'   => 'solid',
				'choices'        => array( 'Help me find a product', 'I have a question about my order', 'I have a different question' ),
			),
			'generic' => array(
				'ring'           => '#7C3AED',
				'panel'          => 'dark',
				'radius'         => 'rounded',
				'accent'         => '#7C3AED',
				'accent2'        => '#E879F9',
				'tone'           => 'professional, friendly, concise',
				'greeting'       => "Hi! I'm the virtual assistant for {company}. Ask me anything about our services — and I can connect you with the team. How can I help?",
				'starters'       => array( 'What services do you offer?', 'How do I get in touch?', 'Where are you located?', 'How do I get started?' ),
				'widget_name'    => 'Assistant',
				'widget_mode'    => 'standard',
				'button_style'   => 'outline',
				'choices'        => array( 'I would like to request pricing', "I'd like to learn about your services", 'I have a different question' ),
			),
		);
	}

	/** Tokens shared by every preset (overridable per client). */
	public static function common_defaults() {
		return array(
			'agent_name'     => '', // resolved per-client in for_prospect() — NEVER the Tuani brand (ground-truth rule).
			'agent_subtitle' => 'The team can also help',
			'section_title'  => 'How can we help you?',
			'agent_avatar'   => '', // URL; empty = branded mark.
			'status_text'    => 'Online — answers from your website',
			'avatar_ring'    => '',
			'fx'             => '',
			'open_mode'      => '', // '' = legacy autoopen | 'popup' (Intercom-style open on load) | 'bubble' (launcher+teaser only).
			'msg_meta'       => 'minimal', // per-message meta on AI replies: minimal (clean, no per-bubble label) | full | none.
		);
	}

	public static function preset_for_industry( $industry ) {
		$map = array(
			'personal_injury' => 'legal',
			'law_general'     => 'legal',
			'med_spa'         => 'medspa',
			'plastic_surgery' => 'medspa',
			'dental'          => 'dental',
			'roofing'         => 'trades',
			'hvac'            => 'trades',
			'local_services'  => 'trades',
			'ecommerce'       => 'ecommerce',
		);
		$key     = isset( $map[ $industry ] ) ? $map[ $industry ] : 'generic';
		$presets = self::presets();
		$preset  = array_merge( self::common_defaults(), $presets[ $key ] );
		$preset['key'] = $key;
		return $preset;
	}

	/** Resolved theme for a prospect (preset + per-client overrides). */
	public static function for_prospect( $prospect ) {
		$theme         = self::preset_for_industry( $prospect['industry'] );
		$theme['icon'] = self::icon_for_industry( $prospect['industry'] );
		$ov            = ! empty( $prospect['theme_overrides'] ) && is_array( $prospect['theme_overrides'] ) ? $prospect['theme_overrides'] : array();

		// Brand color auto-apply: prospect's extracted palette wins over the preset
		// (with contrast safety) — manual overrides below win over everything.
		$brand = array();
		if ( ! empty( $prospect['crawl_data']['extracted']['brand'] ) && is_array( $prospect['crawl_data']['extracted']['brand'] ) ) {
			$brand = $prospect['crawl_data']['extracted']['brand'];
		}
		if ( ! empty( $brand['primary'] ) && self::usable_brand_color( $brand['primary'] ) ) {
			$theme['accent']  = $brand['primary'];
			$theme['ring']    = $brand['primary'];
			$theme['accent2'] = ( ! empty( $brand['secondary'] ) && self::usable_brand_color( $brand['secondary'] ) ) ? $brand['secondary'] : $brand['primary'];
		}
		$theme['logo'] = ! empty( $brand['logo'] ) ? esc_url_raw( $brand['logo'] ) : '';

		// Site-feel adaptation: dark/light, roundness, vibrancy from the crawl.
		if ( ! empty( $brand['site_mode'] ) && in_array( $brand['site_mode'], array( 'dark', 'light' ), true ) ) {
			$theme['panel'] = $brand['site_mode'];
		}
		if ( ! empty( $brand['radius'] ) && in_array( $brand['radius'], array( 'pill', 'rounded', 'sharp' ), true ) ) {
			$theme['radius'] = $brand['radius'];
		}
		$theme['vibrancy'] = ! empty( $brand['vibrancy'] ) ? $brand['vibrancy'] : 'muted';

		foreach ( array( 'accent', 'accent2', 'ring', 'greeting', 'widget_name', 'agent_name', 'agent_subtitle', 'section_title', 'status_text', 'avatar_ring' ) as $k ) {
			if ( ! empty( $ov[ $k ] ) && is_string( $ov[ $k ] ) ) {
				$theme[ $k ] = sanitize_text_field( $ov[ $k ] );
			}
		}

		// CLIENT-FIRST PERSONA (ground-truth rule, runs AFTER overrides so a stale
		// stored 'Tuani' override can never leak the brand into a client widget —
		// this exact path was caught by the truth set's first run): the agent
		// identity derives from the client; TuaniChat lives ONLY in the footer.
		if ( empty( $theme['agent_name'] ) || 'Tuani' === $theme['agent_name'] ) {
			$co = ! empty( $prospect['company_name'] ) ? trim( $prospect['company_name'] ) : '';
			// Use the real business name (strip trailing legal/location suffixes),
			// not a one-word truncation. 'Four Points Dermatology' -> 'Four Points
			// Dermatology Assistant', never 'Four Assistant'. Long names trim at a
			// WORD boundary near ~30 chars, keeping >=2 words.
			if ( $co ) {
				$nm = preg_replace( '/\s*,?\s*(LLC|L\.L\.C\.?|Inc\.?|Incorporated|Corp\.?|Co\.?|PLLC|PA|PC|Ltd\.?)\s*$/i', '', $co );
				$nm = trim( $nm );
				if ( mb_strlen( $nm ) > 30 ) {
					$words = preg_split( '/\s+/', $nm );
					$acc = '';
					foreach ( $words as $w ) {
						if ( '' !== $acc && mb_strlen( $acc . ' ' . $w ) > 30 ) { break; }
						$acc = '' === $acc ? $w : $acc . ' ' . $w;
					}
					$nm = $acc ? $acc : mb_substr( $nm, 0, 30 );
				}
				$theme['agent_name'] = $nm . ' Assistant';
			} else {
				$theme['agent_name'] = 'Intake Assistant';
			}
		}
		if ( ! empty( $ov['agent_avatar'] ) && is_string( $ov['agent_avatar'] ) ) {
			$theme['agent_avatar'] = esc_url_raw( $ov['agent_avatar'] );
		}
		if ( isset( $ov['panel'] ) && in_array( $ov['panel'], array( 'dark', 'light' ), true ) ) {
			$theme['panel'] = $ov['panel'];
		}
		if ( isset( $ov['radius'] ) && in_array( $ov['radius'], array( 'pill', 'rounded', 'sharp' ), true ) ) {
			$theme['radius'] = $ov['radius'];
		}
		if ( isset( $ov['fx'] ) && in_array( $ov['fx'], array( '', 'grid' ), true ) ) {
			$theme['fx'] = $ov['fx'];
		}
		if ( isset( $ov['open_mode'] ) && in_array( $ov['open_mode'], array( '', 'popup', 'bubble' ), true ) ) {
			$theme['open_mode'] = $ov['open_mode'];
		}
		if ( isset( $ov['msg_meta'] ) && in_array( $ov['msg_meta'], array( 'minimal', 'full', 'none' ), true ) ) {
			$theme['msg_meta'] = $ov['msg_meta'];
		}
		if ( ! empty( $ov['icon'] ) && is_string( $ov['icon'] ) ) {
			$theme['icon'] = sanitize_key( $ov['icon'] );
		}
		if ( isset( $ov['widget_mode'] ) && in_array( $ov['widget_mode'], array( 'standard', 'advanced' ), true ) ) {
			$theme['widget_mode'] = $ov['widget_mode'];
		}
		if ( isset( $ov['button_style'] ) && in_array( $ov['button_style'], array( 'outline', 'solid' ), true ) ) {
			$theme['button_style'] = $ov['button_style'];
		}
		foreach ( array( 'starters', 'choices' ) as $listk ) {
			if ( ! empty( $ov[ $listk ] ) && is_array( $ov[ $listk ] ) ) {
				$clean = array();
				foreach ( array_slice( $ov[ $listk ], 0, 6 ) as $item ) {
					$item = sanitize_text_field( (string) $item );
					if ( '' !== $item ) {
						$clean[] = $item;
					}
				}
				if ( $clean ) {
					$theme[ $listk ] = $clean;
				}
			}
		}

		$company           = $prospect['company_name'] ? $prospect['company_name'] : 'this business';
		$theme['greeting'] = str_replace( '{company}', $company, $theme['greeting'] );

		// BINDING RULE — runs LAST so neither brand colors nor manual overrides
		// can ever ship a red / low-contrast button. White-text surfaces (solid
		// chips, CTAs, launcher, user bubbles) use accent/accent2: both must be
		// AA-safe, never harsh red.
		// COLOR-ENHANCEMENT FOUNDATION: upgrade every accent to its best modern,
		// rich version (unless the operator disabled it), THEN guarantee AA. A
		// manual hex override still flows through enhancement so it stays cohesive;
		// set theme_overrides['raw_color']=1 to use a picked hex verbatim.
		$enhance = empty( $ov['raw_color'] );
		if ( $enhance ) {
			$theme['accent']  = self::enhance_color( $theme['accent'] );
			$theme['accent2'] = self::enhance_color( $theme['accent2'] );
			if ( ! empty( $theme['ring'] ) ) { $theme['ring'] = self::enhance_color( $theme['ring'] ); }
		}
		$theme['accent']  = self::safe_accent( $theme['accent'] );
		$theme['accent2'] = self::safe_accent( $theme['accent2'], $theme['accent'] );
		if ( self::is_harsh_red( $theme['ring'] ) ) {
			$theme['ring'] = $theme['accent']; // glow follows the tamed accent.
		}
		// Cohesive palette derived from the enhanced primary (hover/gradient/tint/
		// text/border/glow) — the redesigned widget + demo + admin preview all read
		// from this so the whole UI feels designed, never a flat swatch.
		$theme['palette'] = self::palette( $theme['accent'] );
		return $theme;
	}

	/** Launcher icon key per industry. */
	public static function icon_for_industry( $industry ) {
		// DEFAULT = clean premium CHAT BUBBLE for all industries (always looks
		// right). The themed icons below remain available as per-client 'icon'
		// overrides (e.g. Luna's moon) when a brand fit is deliberate.
		return 'chat';
		$map = array(
			'personal_injury' => 'gavel',
			'law_general'     => 'gavel',
			'med_spa'         => 'lotus',
			'plastic_surgery' => 'profile',
			'dental'          => 'tooth',
			'roofing'         => 'roof',
			'hvac'            => 'fan',
			'local_services'  => 'spark',
			'ecommerce'       => 'bag',
		);
		return isset( $map[ $industry ] ) ? $map[ $industry ] : 'spark';
	}

	/** Inline SVG launcher icons (24x24, currentColor strokes). */
	public static function icon_svg( $key ) {
		$icons = array(
			'gavel'   => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m14 13-7.5 7.5a2.1 2.1 0 0 1-3-3L11 10"/><path d="m16 16 6 6"/><path d="m8 8 6-6 6 6-6 6z"/></svg>',
			'fan'     => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="2.2"/><path d="M12 9.8C12 5 9 3.5 6.5 5.5S6 12 9.8 12"/><path d="M14.2 12c4.8 0 6.3-3 4.3-5.5S12 6 12 9.8"/><path d="M12 14.2c0 4.8 3 6.3 5.5 4.3S18 12 14.2 12"/><path d="M9.8 12C5 12 3.5 15 5.5 17.5S12 18 12 14.2"/></svg>',
			'roof'    => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m2 12 10-8 10 8"/><path d="M5 10v9h14v-9"/><path d="M9 19v-5h6v5"/></svg>',
			'tooth'   => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5.5c-1.5-1.8-4-2.5-6-1.5C3.5 5.3 3 8.5 4.3 11c1 2 1.4 3.4 1.7 6 .2 1.7.8 2.5 1.7 2.5 1.5 0 1.4-2.3 2.2-4 .5-1.1 1.2-1.7 2.1-1.7s1.6.6 2.1 1.7c.8 1.7.7 4 2.2 4 .9 0 1.5-.8 1.7-2.5.3-2.6.7-4 1.7-6 1.3-2.5.8-5.7-1.7-7-2-1-4.5-.3-6 1.5z"/></svg>',
			'lotus'   => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20c-2.5-1.5-4-4-4-7 0-3.5 2-6.5 4-8 2 1.5 4 4.5 4 8 0 3-1.5 5.5-4 7z"/><path d="M12 20c-3.5.5-6.5-.5-8.5-3 1.5-1 3.5-1.5 5.5-1.2"/><path d="M12 20c3.5.5 6.5-.5 8.5-3-1.5-1-3.5-1.5-5.5-1.2"/></svg>',
			'profile' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 4c-3 0-5.5 2-5.5 5.5 0 2 .5 3 .2 4.5-.2 1-1 1.8-1.2 2.5-.2.8.3 1.5 1.2 1.5h1.8c.5 1.2.5 2 .5 2"/><path d="M14 4c2.8.3 4.5 2.4 4.5 5 0 2.8-1.8 4-2.5 6-.5 1.5 0 3 .5 5"/></svg>',
			'bag'     => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 7h12l1 13H5z"/><path d="M9 10V6a3 3 0 0 1 6 0v4"/></svg>',
			'moon'    => '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M14 2a10 10 0 1 0 8 16A8 8 0 0 1 14 2z"/></svg>',
			'chat'    => '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M20 2H4a2 2 0 0 0-2 2v18l4-4h14a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2zM7 9h10v2H7zm0 4h7v2H7z"/></svg>',
			'spark'   => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.4 8.4 0 0 1-9 8.4 8.6 8.6 0 0 1-3.5-.8L3 21l1.9-5.5a8.4 8.4 0 1 1 16.1-4z"/><path d="m12 8 1 2.5L15.5 11.5 13 12.5 12 15l-1-2.5L8.5 11.5 11 10.5z" fill="currentColor" stroke="none"/></svg>',
		);
		return isset( $icons[ $key ] ) ? $icons[ $key ] : $icons['spark'];
	}

	/** Gamma-corrected WCAG relative luminance (the original luminance() is a
	 * fast linear approximation kept for its tuned thresholds elsewhere). */
	public static function wcag_luminance( $hex ) {
		$hex = ltrim( (string) $hex, '#' );
		if ( 3 === strlen( $hex ) ) {
			$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
		}
		if ( 6 !== strlen( $hex ) || ! ctype_xdigit( $hex ) ) {
			return 1;
		}
		$lin = function ( $c ) {
			$c = $c / 255;
			return $c <= 0.03928 ? $c / 12.92 : pow( ( $c + 0.055 ) / 1.055, 2.4 );
		};
		return 0.2126 * $lin( hexdec( substr( $hex, 0, 2 ) ) )
			+ 0.7152 * $lin( hexdec( substr( $hex, 2, 2 ) ) )
			+ 0.0722 * $lin( hexdec( substr( $hex, 4, 2 ) ) );
	}

	/** WCAG contrast ratio of white text on a hex background. */
	public static function contrast_vs_white( $hex ) {
		return 1.05 / ( self::wcag_luminance( $hex ) + 0.05 );
	}

	private static function hex_to_hsl( $hex ) {
		$hex = ltrim( (string) $hex, '#' );
		if ( 3 === strlen( $hex ) ) {
			$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
		}
		if ( 6 !== strlen( $hex ) || ! ctype_xdigit( $hex ) ) {
			return null;
		}
		$r = hexdec( substr( $hex, 0, 2 ) ) / 255;
		$g = hexdec( substr( $hex, 2, 2 ) ) / 255;
		$b = hexdec( substr( $hex, 4, 2 ) ) / 255;
		$max = max( $r, $g, $b );
		$min = min( $r, $g, $b );
		$l   = ( $max + $min ) / 2;
		$d   = $max - $min;
		if ( $d < 0.00001 ) {
			return array( 0, 0, $l );
		}
		$sat = $l > 0.5 ? $d / ( 2 - $max - $min ) : $d / ( $max + $min );
		if ( $max === $r ) {
			$h = fmod( ( $g - $b ) / $d, 6 );
		} elseif ( $max === $g ) {
			$h = ( $b - $r ) / $d + 2;
		} else {
			$h = ( $r - $g ) / $d + 4;
		}
		$h = fmod( $h * 60 + 360, 360 );
		return array( $h, $sat, $l );
	}

	private static function hsl_to_hex( $h, $sat, $l ) {
		$c = ( 1 - abs( 2 * $l - 1 ) ) * $sat;
		$x = $c * ( 1 - abs( fmod( $h / 60, 2 ) - 1 ) );
		$m = $l - $c / 2;
		if ( $h < 60 )       { $rgb = array( $c, $x, 0 ); }
		elseif ( $h < 120 )  { $rgb = array( $x, $c, 0 ); }
		elseif ( $h < 180 )  { $rgb = array( 0, $c, $x ); }
		elseif ( $h < 240 )  { $rgb = array( 0, $x, $c ); }
		elseif ( $h < 300 )  { $rgb = array( $x, 0, $c ); }
		else                 { $rgb = array( $c, 0, $x ); }
		$out = '#';
		foreach ( $rgb as $v ) {
			$out .= str_pad( dechex( (int) round( ( $v + $m ) * 255 ) ), 2, '0', STR_PAD_LEFT );
		}
		return $out;
	}

	/** Harsh/alarm red: hue in the pure-red zone with real saturation. */
	public static function is_harsh_red( $hex ) {
		$hsl = self::hex_to_hsl( $hex );
		if ( ! $hsl ) {
			return false;
		}
		list( $h, $sat, $l ) = $hsl;
		return ( $h <= 16 || $h >= 348 ) && $sat >= 0.45 && $l >= 0.22;
	}

	/**
	 * COLOR-ENHANCEMENT ENGINE (foundation setting). Takes a detected/raw brand
	 * color and returns its BEST MODERN, RICH version: lifts muddy low-chroma
	 * colors toward a tasteful vivid level (hue-aware), seats lightness in a
	 * punchy band, and keeps the hue on-brand. Pairs with safe_accent() which then
	 * guarantees WCAG-AA. (HSL chroma boost approximating an OKLCH lift.)
	 */
	public static function enhance_color( $hex ) {
		$hsl = self::hex_to_hsl( $hex );
		if ( ! $hsl ) { return $hex; }
		list( $h, $sat, $l ) = $hsl;
		// Near-neutral grays: can't be "enriched" without inventing a hue — leave subtle.
		if ( $sat < 0.06 ) { return self::hsl_to_hex( $h, min( 0.10, $sat ), max( 0.30, min( 0.50, $l ) ) ); }
		// Hue-aware target chroma: yellows/greens read harsh if oversaturated; reds/
		// blues/purples carry richness well. Tune the modern target per hue band.
		$target = 0.74;
		if ( $h >= 45 && $h <= 75 )   { $target = 0.62; } // yellows
		elseif ( $h > 75 && $h <= 165 ) { $target = 0.58; } // greens
		elseif ( $h >= 200 && $h <= 270 ) { $target = 0.80; } // blues/indigo — go vivid (Intercom-like)
		// Boost vibrance: pull UP to target (never wash a color that was already vivid).
		$sat = max( $sat, $target );
		$sat = min( $sat, 0.90 );
		// Seat lightness in a punchy, modern band (not muddy-dark, not pastel).
		$l = max( 0.40, min( 0.56, $l < 0.30 ? 0.30 + $l * 0.6 : $l ) );
		return self::hsl_to_hex( $h, $sat, $l );
	}

	/**
	 * COHESIVE PALETTE from one enhanced primary — so the whole widget feels
	 * designed (primary / hover / gradient pair / soft tint / contrast-safe text /
	 * border), like Intercom blue or Lion Click cyan, never a flat swatch.
	 */
	public static function palette( $hex ) {
		$primary = self::safe_accent( self::enhance_color( $hex ) );
		$hsl = self::hex_to_hsl( $primary );
		if ( ! $hsl ) { $hsl = array( 222, 0.6, 0.5 ); }
		list( $h, $sat, $l ) = $hsl;
		$txt = self::contrast_vs_white( $primary ) >= 4.5 ? '#ffffff' : '#0f1116';
		return array(
			'primary'   => $primary,
			'hover'     => self::hsl_to_hex( $h, $sat, max( 0.12, $l - 0.10 ) ),
			'grad2'     => self::hsl_to_hex( fmod( $h + 14, 360 ), min( 0.92, $sat + 0.05 ), min( 0.64, $l + 0.10 ) ),
			'tint'      => self::hsl_to_hex( $h, min( 0.55, $sat * 0.5 + 0.10 ), 0.95 ),       // light bot-bubble bg
			'tint_dark' => self::hsl_to_hex( $h, min( 0.45, $sat ), 0.17 ),                    // dark-panel surface
			'border'    => self::hsl_to_hex( $h, min( 0.60, $sat ), 0.84 ),
			'glow'      => self::hsl_to_hex( $h, min( 0.95, $sat + 0.1 ), min( 0.60, $l + 0.06 ) ),
			'text'      => $txt,
		);
	}

	/**
	 * BINDING BUTTON-COLOR RULE (the Madre Forte rule): every accent that will
	 * carry white text must be WCAG-AA safe (>= 4.5:1) and NEVER harsh red.
	 * Harsh reds get the premium wine treatment (desaturate + darken, hue eased
	 * off pure red); anything still failing AA is darkened stepwise; if a color
	 * cannot be made safe it falls back to the neutral enterprise navy.
	 */
	public static function safe_accent( $hex, $fallback = '#1F2A44' ) {
		$hsl = self::hex_to_hsl( $hex );
		if ( ! $hsl ) {
			return $fallback;
		}
		list( $h, $sat, $l ) = $hsl;
		if ( self::is_harsh_red( $hex ) ) {
			// Wine/burgundy: keep brand-adjacent warmth, lose the alarm.
			$h   = 342;
			$sat = min( $sat, 0.48 );
			$l   = min( $l, 0.30 );
		}
		$guard = 0;
		while ( self::contrast_vs_white( self::hsl_to_hex( $h, $sat, $l ) ) < 4.5 && $l > 0.10 && $guard++ < 24 ) {
			$l -= 0.025;
			if ( $sat > 0.62 ) {
				$sat -= 0.02; // tame neon while darkening.
			}
		}
		$out = self::hsl_to_hex( $h, $sat, $l );
		if ( self::contrast_vs_white( $out ) < 4.5 || self::is_harsh_red( $out ) ) {
			return $fallback;
		}
		return $out;
	}

	/** Relative luminance 0..1 from a hex color. */
	public static function luminance( $hex ) {
		$hex = ltrim( (string) $hex, '#' );
		if ( 3 === strlen( $hex ) ) {
			$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
		}
		if ( 6 !== strlen( $hex ) || ! ctype_xdigit( $hex ) ) {
			return 1;
		}
		$r = hexdec( substr( $hex, 0, 2 ) ) / 255;
		$g = hexdec( substr( $hex, 2, 2 ) ) / 255;
		$b = hexdec( substr( $hex, 4, 2 ) ) / 255;
		return 0.2126 * $r + 0.7152 * $g + 0.0722 * $b;
	}

	/** Usable as a widget accent: dark enough for white text + has some saturation. */
	public static function usable_brand_color( $hex ) {
		$hex = ltrim( (string) $hex, '#' );
		if ( ! in_array( strlen( $hex ), array( 3, 6 ), true ) || ! ctype_xdigit( $hex ) ) {
			return false;
		}
		$lum = self::luminance( $hex );
		if ( $lum > 0.62 || $lum < 0.02 ) {
			return false;
		}
		if ( 3 === strlen( $hex ) ) {
			$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
		}
		$r = hexdec( substr( $hex, 0, 2 ) ); $g = hexdec( substr( $hex, 2, 2 ) ); $b = hexdec( substr( $hex, 4, 2 ) );
		return ( max( $r, $g, $b ) - min( $r, $g, $b ) ) >= 18; // not pure grey.
	}
}
