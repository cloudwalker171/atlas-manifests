<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Settings accessors. Single option array `tnc_settings`.
 * The API key is never exposed to any front-end or REST response.
 */
class TNC_Settings {

	public static function defaults() {
		return array(
			'api_key'          => '',
			'model'            => 'claude-haiku-4-5-20251001',
			'endpoint_base'    => 'https://api.anthropic.com',
			'cta_activate_url' => '',
			'cta_call_url'     => '',
			'notify_email'     => get_option( 'admin_email' ), // comma-separated list supported.
			'notify_leads'     => 1,
			'notify_crawl'     => 1,
			'notify_system'    => 1,
			'crawl_max_pages'  => 50,  // demo profile — deep enough for practice-area/service/location pages.
			'crawl_full_pages' => 200, // full profile (hard cap 500 in TNC_Crawl_Jobs).
			'crawl_batch_size' => 6,   // pages per WP-Cron batch.
			'crawl_depth'      => 2,
			'crawl_timeout'    => 10,
			'crawl_concurrency' => 6, // parallel fetches per wave.
			'crawl_per_host'   => 3,  // politeness cap per target host.
			'bulk_lanes'       => 2,  // concurrent prospect crawls.
			'bulk_stagger'     => 150, // seconds between bulk crawls.
			'chat_rate_limit'  => 20, // messages per IP per 5 minutes.
			'chat_daily_per_demo' => 150, // hard daily message cap per demo (cost guard).
			'chat_daily_global'   => 800, // platform-wide daily message ceiling — pause + alert on breach.
			'chat_session_cap'    => 40,  // messages per visitor session per day (bot/abuse guard).
			'outreach_from_name'   => '',
			'outreach_from_email'  => '',
			'outreach_from_domain' => '', // e.g. go.lionclickmedia.com for the test phase; repoint to tuanilabs.com later.
			'outreach_identity'    => 'tuanichat', // tuanichat | partner (Lion Click 'partnered with TuaniChat' framing).
			'cta_urgency_text'     => 'Live within 24 hours',
			'lead_form_helper'     => 'Leave your details and we\'ll set it up for you — typically live within 24 hours.',
			'demo_autoopen_secs'   => 6, // demo auto-open delay (3-10s) — gives the pulsing launcher time to draw the eye.
			'screenshot_api_url' => '', // optional render service ({url} placeholder); enables visual chat verification.
			'screenshot_api_key' => '',
			'max_context'      => 7000,
		);
	}

	public static function all() {
		$opt = get_option( 'tnc_settings', array() );
		if ( ! is_array( $opt ) ) {
			$opt = array();
		}
		return array_merge( self::defaults(), $opt );
	}

	public static function get( $key, $fallback = '' ) {
		$all = self::all();
		return isset( $all[ $key ] ) && '' !== $all[ $key ] ? $all[ $key ] : $fallback;
	}

	public static function update( $pairs ) {
		$all = self::all();
		foreach ( $pairs as $k => $v ) {
			if ( array_key_exists( $k, self::defaults() ) ) {
				$all[ $k ] = $v;
			}
		}
		update_option( 'tnc_settings', $all );
		update_option( 'tnc_settings_backup', $all, false ); // survives legacy uninstall wipes.
		return $all;
	}

	/**
	 * Notification recipients for a type (leads|crawl|system).
	 * Parses the comma-separated notify_email list; returns array or empty when toggled off.
	 */
	public static function recipients( $type = 'system' ) {
		$on = (int) self::get( 'notify_' . sanitize_key( $type ), 1 );
		if ( ! $on ) {
			return array();
		}
		$raw  = (string) self::get( 'notify_email', get_option( 'admin_email' ) );
		$out  = array();
		foreach ( explode( ',', $raw ) as $e ) {
			$e = sanitize_email( trim( $e ) );
			if ( $e ) {
				$out[] = $e;
			}
		}
		return $out;
	}

	/** Masked key for display: keeps first 7 + last 4 chars. */
	public static function masked_key() {
		$key = (string) self::get( 'api_key' );
		if ( '' === $key ) {
			return '';
		}
		if ( strlen( $key ) <= 12 ) {
			return str_repeat( '•', 12 );
		}
		return substr( $key, 0, 7 ) . str_repeat( '•', 10 ) . substr( $key, -4 );
	}

	public static function industries() {
		return array(
			'personal_injury' => 'Personal Injury Law',
			'law_general'     => 'Law Firm (General)',
			'med_spa'         => 'Med Spa',
			'plastic_surgery' => 'Plastic Surgery',
			'dental'          => 'Dental',
			'roofing'         => 'Roofing',
			'hvac'            => 'HVAC',
			'local_services'  => 'Local Services',
			'ecommerce'       => 'E-commerce',
			'other'           => 'Other',
		);
	}

	public static function statuses() {
		return array(
			'new'            => 'New',
			'queued'         => 'Queued',
			'crawling'       => 'Crawling',
			'crawled'        => 'Crawled',
			'demo_created'   => 'Demo Created',
			'demo_sent'      => 'Demo Sent',
			'engaged'        => 'Engaged',
			'won'            => 'Won',
			'lost'           => 'Lost',
			'not_compatible' => 'Not Compatible',
			'error'          => 'Error',
		);
	}
}
