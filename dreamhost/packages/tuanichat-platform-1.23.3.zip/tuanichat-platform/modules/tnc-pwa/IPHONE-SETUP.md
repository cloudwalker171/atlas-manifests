# J.A.R.V.I.S. on your iPhone — exact taps

Once the module is deployed on chat.lionclickmedia.com:

## Install (one time, ~30 seconds)

1. Open **Safari** on your iPhone (must be Safari, not Chrome).
2. Go to: **chat.lionclickmedia.com/?tnc_pwa=app**
3. Log in with your WordPress admin login (let Face ID / iCloud Keychain save it — you won't type it again; PWA sessions last a year).
4. Tap the **Share button** (the square with the arrow, bottom center of Safari).
5. Scroll down → tap **"Add to Home Screen"**.
6. It will show the violet J.A.R.V.I.S. icon and the name **J.A.R.V.I.S.** → tap **Add** (top right).

You now have a J.A.R.V.I.S. app icon on your home screen. Tapping it launches full-screen — no Safari bars, looks and feels native.

## Enable push alerts (the pager)

1. Open J.A.R.V.I.S. **from the home-screen icon** (iOS only allows push for installed PWAs, iOS 16.4+).
2. On the JARVIS tab, tap **🔔 ENABLE ALERTS** → tap **Allow**.
3. You'll get a test notification: *"J.A.R.V.I.S. online — Push channel verified."*

After that the brain can page you: 🔥 hot prospects, ✚ self-heal events, 📊 the daily brief, 🚨 lead-production flatline alarms.

## Using it

- **Swipe left/right** (or tap the bottom tabs) to move between JARVIS / HUNTER / PROSPECTS / EMAIL / DATA / HEALTH.
- **Pull down** on any panel to force-refresh.
- Counters update **live every second**.
- **🔊 VOICE** chip: J.A.R.V.I.S. greets you out loud on open ("Good evening, sir...").
- **🛑 MASTER KILL SWITCH** halts everything (asks you to confirm first).
- Poor signal? The app opens instantly with the last-known numbers and a ⚠ OFFLINE banner, then goes live when the connection returns.

## Honest scope

This is a PWA — $0, no App Store, updates instantly with the plugin's self-updater, and delivers ~95% of a native app. If you ever want a true App Store app (App Store presence, richer background features), that's a separate, much larger effort — nothing built here is wasted, the same REST API would power it.
