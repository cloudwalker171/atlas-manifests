<?php
/**
 * TNC Module: J.A.R.V.I.S. Mobile PWA
 *
 * Module ID:        tnc_pwa
 * Contract version: 1.2.0
 * Owner lane:       mobile-pwa (this module). Core plugin owns deploy via self-updater.
 *
 * v1.2.0:
 *   - A.T.L.A.S. (100M database tracker) snapshot section + panel.
 *   - Outreach engine cards: Smart LinkedIn / Smart SMS (tnc_li_engine / tnc_sms_engine
 *     option contracts, fail-closed GATED badges) + SSL Radar status.
 *   - Email panel extras: deliverability, bounce, unsubs, hot replies, demo views,
 *     warmup stage, go-live gate readiness, best send window. Fail-closed golive.
 *   - Pipeline value + response-rate trend.
 *   - Health score computed server-side from weighted guardian checks (explainable).
 *   - Vibrant V2 UI, varied live visualizations, DEMO DATA labeling.
 *
 * v1.1.0 (council enhancements):
 *   - Web Push (VAPID, iOS 16.4+ home-screen PWAs): subscribe/unsubscribe REST,
 *     dependency-free sender (includes/class-tnc-webpush.php), public API
 *     tnc_pwa_push() + `tnc_pwa_push` action for the brain to fire alerts.
 *   - Built-in daily brief (cron) + lead-production flatline watchdog.
 *   - Long-lived session for PWA logins (no password typing on mobile; Face ID
 *     autofill / passkey plugins remain compatible).
 *   - Master kill switch + alert acknowledge commands (guarded client-side).
 *
 * Self-contained module for the TuaniChat core plugin (prefix tnc_).
 * Integration: the core plugin loader simply does
 *     require_once __DIR__ . '/modules/tnc-pwa/module-pwa.php';
 * Everything else is hook-based. See CONTRACT.md for the data-provider filters.
 *
 * Endpoints served (no rewrite rules needed — query-var based, root scope):
 *   /?tnc_pwa=app       -> mobile J.A.R.V.I.S. app shell (auth required)
 *   /?tnc_pwa=manifest  -> web app manifest (application/manifest+json)
 *   /?tnc_pwa=sw        -> service worker JS (scope "/", served from root URL)
 *   /?tnc_pwa=icon&s=N  -> app icons (180|192|512|maskable)
 *
 * REST API (cookie auth + X-WP-Nonce):
 *   GET  /wp-json/tnc/v1/pwa/snapshot
 *   POST /wp-json/tnc/v1/pwa/command
 *   POST /wp-json/tnc/v1/pwa/push/subscribe | /push/unsubscribe | /push/test
 *
 * Security: no secrets in client code. Capability gated (filterable).
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }
if ( class_exists( 'TNC_Module_PWA' ) ) { return; }

final class TNC_Module_PWA {

	const VERSION   = '1.2.0';
	const QV        = 'tnc_pwa';
	const THEME_HEX = '#a855f7'; // TuaniLabs violet (V2 vibrant)
	const BG_HEX    = '#070310';

	private static $instance = null;

	public static function boot() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		require_once __DIR__ . '/includes/class-tnc-webpush.php';

		add_action( 'init', array( $this, 'maybe_serve' ), 0 );
		add_action( 'template_redirect', array( $this, 'maybe_serve' ), 0 );      // after query parse — survives canonical redirects.
		add_action( 'parse_request', array( $this, 'maybe_serve_pr' ), 0 );        // earliest — before WP serves the homepage.
		add_filter( 'query_vars', function( $v ){ $v[] = self::QV; return $v; } ); // whitelist so WP doesn't 404/canonicalize it away.
		add_filter( 'do_redirect_guess_404_permalink', function( $g ){ return isset( $_GET[ self::QV ] ) ? false : $g; } );
		add_filter( 'redirect_canonical', function( $r ){ return isset( $_GET[ self::QV ] ) ? false : $r; } ); // stop ?tnc_pwa= homepage redirect.
		add_action( 'init', array( $this, 'ensure_cron' ), 20 );
		add_action( 'rest_api_init', array( $this, 'register_rest' ) );
		add_action( 'wp_head', array( $this, 'head_tags' ) );
		add_action( 'admin_head', array( $this, 'head_tags' ) );
		add_action( 'admin_bar_menu', array( $this, 'admin_bar_link' ), 90 );

		// Fast mobile auth: PWA logins get a long-lived session (no retyping passwords;
		// iOS Face ID password autofill / passkey plugins handle the one-time login).
		add_filter( 'auth_cookie_expiration', array( $this, 'long_session_for_pwa' ), 20, 3 );

		// Public push API for the brain / core plugin:
		//   do_action( 'tnc_pwa_push', 'Title', 'Body text', array( 'tag' => 'hot-prospect' ) );
		add_action( 'tnc_pwa_push', array( __CLASS__, 'push' ), 10, 3 );

		// Cron handlers.
		add_filter( 'cron_schedules', array( $this, 'cron_schedules' ) );
		add_action( 'tnc_pwa_daily_brief', array( $this, 'cron_daily_brief' ) );
		add_action( 'tnc_pwa_watchdog', array( $this, 'cron_watchdog' ) );
	}

	/* ------------------------------------------------------------------ */
	/*  Fast secure login                                                   */
	/* ------------------------------------------------------------------ */

	public function long_session_for_pwa( $expiration, $user_id, $remember ) {
		$redirect = isset( $_REQUEST['redirect_to'] ) ? (string) wp_unslash( $_REQUEST['redirect_to'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		if ( false !== strpos( $redirect, self::QV . '%3Dapp' ) || false !== strpos( $redirect, self::QV . '=app' ) ) {
			return (int) apply_filters( 'tnc_pwa_session_length', YEAR_IN_SECONDS );
		}
		return $expiration;
	}

	/* ------------------------------------------------------------------ */
	/*  Capability                                                         */
	/* ------------------------------------------------------------------ */

	private function cap() {
		/** Core plugin may relax/tighten who can open the mobile app. */
		return apply_filters( 'tnc_pwa_capability', 'manage_options' );
	}

	private function user_allowed() {
		return is_user_logged_in() && current_user_can( $this->cap() );
	}

	/* ------------------------------------------------------------------ */
	/*  Front controller (query-var routes)                                */
	/* ------------------------------------------------------------------ */

	public function maybe_serve_pr( $wp ) {
		if ( isset( $_GET[ self::QV ] ) ) { if ( function_exists( 'nocache_headers' ) ) { nocache_headers(); } $this->maybe_serve(); }
	}
	public function maybe_serve() {
		if ( ! isset( $_GET[ self::QV ] ) ) {
			return;
		}
		if ( function_exists( 'nocache_headers' ) ) { nocache_headers(); } // never let a page cache store these routes.
		$what = sanitize_key( wp_unslash( $_GET[ self::QV ] ) );
		switch ( $what ) {
			case 'app':      $this->serve_app();      break;
			case 'manifest': $this->serve_manifest(); break;
			case 'sw':       $this->serve_sw();       break;
			case 'icon':     $this->serve_icon();     break;
			default: return;
		}
		exit;
	}

	private function url( $what, $extra = array() ) {
		return add_query_arg( array_merge( array( self::QV => $what ), $extra ), home_url( '/' ) );
	}

	/* ---- App shell ---------------------------------------------------- */

	private function serve_app() {
		if ( ! is_user_logged_in() ) {
			wp_safe_redirect( wp_login_url( $this->url( 'app' ) ) );
			exit;
		}
		if ( ! $this->user_allowed() ) {
			status_header( 403 );
			nocache_headers();
			header( 'Content-Type: text/html; charset=utf-8' );
			echo '<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><body style="background:' . esc_attr( self::BG_HEX ) . ';color:#cbb8ff;font-family:-apple-system,sans-serif;display:grid;place-items:center;height:100vh;margin:0"><div style="text-align:center"><h1 style="color:' . esc_attr( self::THEME_HEX ) . '">J.A.R.V.I.S.</h1><p>This account is not cleared for the command center.</p></div></body>';
			exit;
		}

		$html = file_get_contents( __DIR__ . '/assets/app.html' );
		if ( false === $html ) {
			wp_die( 'TNC PWA: app shell asset missing.' );
		}

		$user   = wp_get_current_user();
		$config = array(
			'rest'     => esc_url_raw( rest_url( 'tnc/v1/pwa/' ) ),
			'nonce'    => wp_create_nonce( 'wp_rest' ),
			'sw'       => esc_url_raw( $this->url( 'sw' ) ),
			'appUrl'   => esc_url_raw( $this->url( 'app' ) ),
			'manifest' => esc_url_raw( $this->url( 'manifest' ) ),
			'icon'     => esc_url_raw( $this->url( 'icon', array( 's' => '192' ) ) ),
			'user'     => $user->display_name ? $user->display_name : $user->user_login,
			'version'  => self::VERSION,
			'pollMs'   => (int) apply_filters( 'tnc_pwa_poll_interval_ms', 1000 ),
			'vapid'    => self::push_available() ? self::vapid()['publicKey'] : null,
		);

		$inject = '<link rel="manifest" href="' . esc_url( $this->url( 'manifest' ) ) . '">' . "\n"
			. '<link rel="apple-touch-icon" href="' . esc_url( $this->url( 'icon', array( 's' => '180' ) ) ) . '">' . "\n"
			. '<script>window.TNC_PWA_CONFIG=' . wp_json_encode( $config ) . ';</script>';

		$html = str_replace( '<!--TNC_CONFIG-->', $inject, $html );

		nocache_headers();
		header( 'Content-Type: text/html; charset=utf-8' );
		header( 'X-Frame-Options: SAMEORIGIN' );
		echo $html; // phpcs:ignore WordPress.Security.EscapeOutput -- full asset document.
		exit;
	}

	/* ---- Manifest ------------------------------------------------------ */

	private function serve_manifest() {
		$manifest = array(
			'name'             => 'J.A.R.V.I.S. / TuaniChat',
			'short_name'       => 'J.A.R.V.I.S.',
			'description'      => 'TuaniChat autonomous command center — live monitoring in your pocket.',
			'start_url'        => $this->url( 'app' ),
			'scope'            => home_url( '/' ),
			'display'          => 'standalone',
			'orientation'      => 'portrait',
			'background_color' => self::BG_HEX,
			'theme_color'      => self::THEME_HEX,
			'icons'            => array(
				array( 'src' => $this->url( 'icon', array( 's' => '192' ) ), 'sizes' => '192x192', 'type' => 'image/png' ),
				array( 'src' => $this->url( 'icon', array( 's' => '512' ) ), 'sizes' => '512x512', 'type' => 'image/png' ),
				array( 'src' => $this->url( 'icon', array( 's' => 'maskable' ) ), 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'maskable' ),
			),
		);
		header( 'Content-Type: application/manifest+json; charset=utf-8' );
		header( 'Cache-Control: public, max-age=3600' );
		echo wp_json_encode( apply_filters( 'tnc_pwa_manifest', $manifest ) );
		exit;
	}

	/* ---- Service worker (root scope because URL path is "/") ----------- */

	private function serve_sw() {
		$js = file_get_contents( __DIR__ . '/assets/sw.js' );
		if ( false === $js ) {
			status_header( 404 );
			exit;
		}
		$js = str_replace( '__TNC_PWA_VERSION__', self::VERSION, $js );
		header( 'Content-Type: application/javascript; charset=utf-8' );
		header( 'Cache-Control: no-cache' );
		header( 'Service-Worker-Allowed: /' );
		echo $js; // phpcs:ignore WordPress.Security.EscapeOutput
		exit;
	}

	/* ---- Icons ---------------------------------------------------------- */

	private function serve_icon() {
		$s    = isset( $_GET['s'] ) ? sanitize_key( wp_unslash( $_GET['s'] ) ) : '192';
		$map  = array(
			'180'      => 'icon-180.png',
			'192'      => 'icon-192.png',
			'512'      => 'icon-512.png',
			'maskable' => 'icon-512-maskable.png',
		);
		$file = isset( $map[ $s ] ) ? __DIR__ . '/assets/icons/' . $map[ $s ] : null;
		if ( ! $file || ! file_exists( $file ) ) {
			status_header( 404 );
			exit;
		}
		header( 'Content-Type: image/png' );
		header( 'Cache-Control: public, max-age=86400' );
		header( 'Content-Length: ' . filesize( $file ) );
		readfile( $file );
		exit;
	}

	/* ------------------------------------------------------------------ */
	/*  Discoverability                                                     */
	/* ------------------------------------------------------------------ */

	public function head_tags() {
		echo '<link rel="manifest" href="' . esc_url( $this->url( 'manifest' ) ) . '">' . "\n";
		echo '<link rel="apple-touch-icon" href="' . esc_url( $this->url( 'icon', array( 's' => '180' ) ) ) . '">' . "\n";
		echo '<meta name="theme-color" content="' . esc_attr( self::THEME_HEX ) . '">' . "\n";
	}

	public function admin_bar_link( $bar ) {
		if ( ! $this->user_allowed() ) {
			return;
		}
		$bar->add_node( array(
			'id'    => 'tnc-pwa',
			'title' => '📱 J.A.R.V.I.S. Mobile',
			'href'  => $this->url( 'app' ),
		) );
	}

	/* ------------------------------------------------------------------ */
	/*  REST API                                                            */
	/* ------------------------------------------------------------------ */

	public function register_rest() {
		register_rest_route( 'tnc/v1', '/pwa/snapshot', array(
			'methods'             => 'GET',
			'callback'            => array( $this, 'rest_snapshot' ),
			'permission_callback' => array( $this, 'rest_permission' ),
		) );
		register_rest_route( 'tnc/v1', '/pwa/command', array(
			'methods'             => 'POST',
			'callback'            => array( $this, 'rest_command' ),
			'permission_callback' => array( $this, 'rest_permission' ),
		) );
		register_rest_route( 'tnc/v1', '/pwa/push/subscribe', array(
			'methods'             => 'POST',
			'callback'            => array( $this, 'rest_push_subscribe' ),
			'permission_callback' => array( $this, 'rest_permission' ),
		) );
		register_rest_route( 'tnc/v1', '/pwa/push/unsubscribe', array(
			'methods'             => 'POST',
			'callback'            => array( $this, 'rest_push_unsubscribe' ),
			'permission_callback' => array( $this, 'rest_permission' ),
		) );
		register_rest_route( 'tnc/v1', '/pwa/push/test', array(
			'methods'             => 'POST',
			'callback'            => array( $this, 'rest_push_test' ),
			'permission_callback' => array( $this, 'rest_permission' ),
		) );
	}

	public function rest_permission() {
		return $this->user_allowed();
	}

	/* ------------------------------------------------------------------ */
	/*  Web Push (VAPID)                                                    */
	/* ------------------------------------------------------------------ */

	public static function push_available() {
		return class_exists( 'TNC_WebPush' ) && TNC_WebPush::supported();
	}

	/** Lazily create + persist VAPID keys (private key never leaves the server). */
	private static function vapid() {
		$keys = get_option( 'tnc_pwa_vapid' );
		if ( empty( $keys['publicKey'] ) || empty( $keys['privateKeyPem'] ) ) {
			$keys = TNC_WebPush::generate_vapid_keys();
			if ( $keys ) {
				update_option( 'tnc_pwa_vapid', $keys, false );
			}
		}
		return $keys;
	}

	public function rest_push_subscribe( WP_REST_Request $req ) {
		if ( ! self::push_available() ) {
			return new WP_Error( 'tnc_push_unsupported', 'Push not available on this host.', array( 'status' => 501 ) );
		}
		$sub = $req->get_param( 'subscription' );
		if ( empty( $sub['endpoint'] ) || empty( $sub['keys']['p256dh'] ) || empty( $sub['keys']['auth'] ) ) {
			return new WP_Error( 'tnc_push_bad_sub', 'Malformed subscription.', array( 'status' => 400 ) );
		}
		$subs = get_option( 'tnc_pwa_push_subs', array() );
		$key  = md5( $sub['endpoint'] );
		$subs[ $key ] = array(
			'sub'     => array(
				'endpoint' => esc_url_raw( $sub['endpoint'] ),
				'keys'     => array(
					'p256dh' => sanitize_text_field( $sub['keys']['p256dh'] ),
					'auth'   => sanitize_text_field( $sub['keys']['auth'] ),
				),
			),
			'user_id' => get_current_user_id(),
			'added'   => time(),
		);
		update_option( 'tnc_pwa_push_subs', $subs, false );
		return rest_ensure_response( array( 'subscribed' => true, 'devices' => count( $subs ) ) );
	}

	public function rest_push_unsubscribe( WP_REST_Request $req ) {
		$endpoint = (string) $req->get_param( 'endpoint' );
		$subs     = get_option( 'tnc_pwa_push_subs', array() );
		unset( $subs[ md5( $endpoint ) ] );
		update_option( 'tnc_pwa_push_subs', $subs, false );
		return rest_ensure_response( array( 'subscribed' => false ) );
	}

	public function rest_push_test() {
		$sent = self::push( 'J.A.R.V.I.S. online', 'Push channel verified. I will alert you here, sir.', array( 'tag' => 'test' ) );
		return rest_ensure_response( array( 'sent' => $sent ) );
	}

	/**
	 * Send a push notification to every registered device.
	 * Brain/core usage:  do_action( 'tnc_pwa_push', $title, $body, $data );
	 * Suggested tags: hot-prospect | self-heal | daily-brief | milestone | alarm
	 *
	 * @return int devices reached
	 */
	public static function push( $title, $body = '', $data = array() ) {
		if ( ! self::push_available() ) {
			return 0;
		}
		// Core may replace the transport entirely (e.g. minishlink/web-push).
		$external = apply_filters( 'tnc_pwa_push_sender', null );
		if ( is_callable( $external ) ) {
			return (int) call_user_func( $external, $title, $body, $data );
		}

		$vapid = self::vapid();
		if ( empty( $vapid['publicKey'] ) ) {
			return 0;
		}
		$subject = apply_filters( 'tnc_pwa_push_subject', 'mailto:' . get_option( 'admin_email' ) );
		$payload = wp_json_encode( array(
			'title' => $title,
			'body'  => $body,
			'tag'   => isset( $data['tag'] ) ? $data['tag'] : 'jarvis',
			'url'   => isset( $data['url'] ) ? $data['url'] : add_query_arg( self::QV, 'app', home_url( '/' ) ),
			'data'  => $data,
		) );

		$subs = get_option( 'tnc_pwa_push_subs', array() );
		$sent = 0;
		foreach ( $subs as $key => $entry ) {
			$res = TNC_WebPush::send( $entry['sub'], $payload, $vapid['publicKey'], $vapid['privateKeyPem'], $subject );
			if ( is_wp_error( $res ) && 'tnc_push_gone' === $res->get_error_code() ) {
				unset( $subs[ $key ] ); // device unsubscribed — prune.
			} elseif ( true === $res ) {
				$sent++;
			}
		}
		update_option( 'tnc_pwa_push_subs', $subs, false );
		return $sent;
	}

	/* ------------------------------------------------------------------ */
	/*  Cron: daily brief + flatline watchdog                               */
	/* ------------------------------------------------------------------ */

	public function cron_schedules( $schedules ) {
		if ( ! isset( $schedules['tnc_pwa_15min'] ) ) {
			$schedules['tnc_pwa_15min'] = array( 'interval' => 15 * MINUTE_IN_SECONDS, 'display' => 'Every 15 minutes (TNC PWA)' );
		}
		return $schedules;
	}

	public function ensure_cron() {
		if ( ! wp_next_scheduled( 'tnc_pwa_daily_brief' ) ) {
			$hour = (int) apply_filters( 'tnc_pwa_brief_hour_utc', 13 ); // 13:00 UTC default.
			$next = strtotime( 'today ' . $hour . ':00 UTC' );
			if ( $next <= time() ) {
				$next = strtotime( 'tomorrow ' . $hour . ':00 UTC' );
			}
			wp_schedule_event( $next, 'daily', 'tnc_pwa_daily_brief' );
		}
		if ( ! wp_next_scheduled( 'tnc_pwa_watchdog' ) ) {
			wp_schedule_event( time() + 60, 'tnc_pwa_15min', 'tnc_pwa_watchdog' );
		}
	}

	public function cron_daily_brief() {
		$snap = $this->rest_snapshot()->get_data(); // filter already applied inside.
		$body = sprintf(
			'Prospects: %s (+%s today) · Leads/hr: %s · Emails sent: %s · Health: %s%%',
			number_format_i18n( $snap['prospects']['total'] ),
			number_format_i18n( $snap['prospects']['new_today'] ),
			number_format_i18n( $snap['lead_hunter']['rate_per_hour'] ),
			number_format_i18n( $snap['email']['sent_today'] ),
			$snap['health']['score']
		);
		self::push( '📊 J.A.R.V.I.S. daily brief', $body, array( 'tag' => 'daily-brief' ) );
	}

	/** Lead-production flatline alarm (rate 0 while hunter is running), 6 h cooldown. */
	public function cron_watchdog() {
		$snap = $this->rest_snapshot()->get_data();
		$flat = ! empty( $snap['lead_hunter']['running'] ) && (int) $snap['lead_hunter']['rate_per_hour'] === 0;
		if ( $flat && time() - (int) get_option( 'tnc_pwa_last_flatline_alert', 0 ) > 6 * HOUR_IN_SECONDS ) {
			update_option( 'tnc_pwa_last_flatline_alert', time(), false );
			self::push( '🚨 Lead production flatline', 'Hunter is running but producing 0 leads/hr. Tap to inspect.', array( 'tag' => 'alarm' ) );
		}
	}

	/* ------------------------------------------------------------------ */
	/*  Snapshot                                                            */
	/* ------------------------------------------------------------------ */

	/**
	 * One consolidated payload per poll (app polls every 1s — keep it cheap).
	 * The CORE PLUGIN supplies real data via the `tnc_pwa_snapshot` filter.
	 * Defaults below make a best effort against common tnc_ storage and
	 * degrade gracefully (zeros / fail-closed) if a source is absent.
	 */
	public function rest_snapshot() {
		global $wpdb;

		$prospects_table = $wpdb->prefix . 'tnc_prospects';
		$prospect_count  = null;
		$table_exists    = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $prospects_table ) );
		if ( $table_exists ) {
			$prospect_count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM `{$prospects_table}`" ); // phpcs:ignore
		}

		$defaults = array(
			'ts'          => time(),
			'jarvis'      => array(
				'status'      => get_option( 'tnc_kill_switch', false ) ? 'halted' : 'online',
				'mode'        => get_option( 'tnc_jarvis_mode', 'autonomous' ),
				'kill_switch' => (bool) get_option( 'tnc_kill_switch', false ),
				'uptime'      => null,
				'decisions'   => array(), // [ [t => unix, msg => string, type => info|action|heal|warn ], ... ]
			),
			'lead_hunter' => array(
				'running'       => (bool) get_option( 'tnc_lead_hunter_running', false ),
				'rate_per_hour' => 0,
				'leads_today'   => 0,
				'queue_depth'   => 0,
				'render_mix'    => array( 'html' => 0, 'js' => 0, 'hybrid' => 0 ), // percentages
			),
			'prospects'   => array(
				'total'     => null === $prospect_count ? 0 : $prospect_count,
				'new_today' => 0,
				'qualified' => 0,
			),
			'email'       => array(
				'queued'         => 0,
				'sent_today'     => 0,
				'open_rate'      => 0,
				'replies'        => 0,
				'paused'         => (bool) get_option( 'tnc_email_paused', false ),
				// Fail-closed by design: 0 sends + GATED badge until core opens the gate.
				'golive'         => (bool) get_option( 'tnc_email_golive', false ),
				'gate_readiness' => 0,    // 0-100 readiness ring toward go-live
				'deliverability' => 0,    // 0-100 health score
				'bounce_rate'    => 0,    // percent, rolling 24h
				'unsubs_today'   => 0,
				'hot_replies'    => 0,    // positive-intent replies
				'demo_views'     => 0,    // prospects who opened their demo page
				'warmup_stage'   => (int) get_option( 'tnc_email_warmup_stage', 0 ),
				'warmup_stages'  => 4,
				'best_window'    => null, // e.g. '9-11 AM PT'
			),
			'pipeline'    => array(
				'value_usd'           => 0,       // prospects x est. value
				'response_rate_trend' => array(), // last N daily response-rate %
			),
			'engines'     => array(
				// Fail-closed: golive defaults false; badge shows amber GATED until core flips it.
				'linkedin'  => wp_parse_args( (array) get_option( 'tnc_li_engine', array() ), array(
					'status' => 'idle', 'queue' => 0, 'sent_today' => 0, 'golive' => false,
				) ),
				'sms'       => wp_parse_args( (array) get_option( 'tnc_sms_engine', array() ), array(
					'status' => 'idle', 'queue' => 0, 'sent_today' => 0, 'golive' => false,
				) ),
				'ssl_radar' => wp_parse_args( (array) get_option( 'tnc_ssl_radar', array() ), array(
					'status' => 'offline', 'detections_today' => 0,
				) ),
			),
			'atlas'       => wp_parse_args( (array) get_option( 'tnc_atlas_stats', array() ), array(
				'records_total'     => 0,
				'processed_today'   => 0,
				'daily_goal'        => 1000000,
				'imports_today'     => 0,
				'enriched_today'    => 0,
				'ai_enriched_today' => 0,
				'fleet_workers'     => 0,
				'fleet_workers_max' => 0,
				'verified_pct'      => 0,
			) ),
			'database'    => array(
				'rows'        => null === $prospect_count ? 0 : $prospect_count,
				'tables'      => (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = %s AND table_name LIKE %s', DB_NAME, $wpdb->prefix . 'tnc_%' ) ),
				'size_mb'     => 0,
				'last_backup' => get_option( 'tnc_last_backup', null ),
			),
			'health'      => array(
				'score'            => 100,
				'self_heals_today' => $this->self_heals_today(), // C5 FIX: real daily counter, written by run_self_heal()
				'checks'           => array(), // [ [name, ok(bool), weight(int,default 1), detail], ... ]
			),
		);

		$data = apply_filters( 'tnc_pwa_snapshot', $defaults );

		// Health is REAL and explainable: weighted share of guardian checks passing.
		if ( ! empty( $data['health']['checks'] ) && is_array( $data['health']['checks'] ) ) {
			$sum = 0;
			$ok  = 0;
			foreach ( $data['health']['checks'] as $check ) {
				$w    = isset( $check['weight'] ) ? max( 0, (int) $check['weight'] ) : 1;
				$sum += $w;
				if ( ! empty( $check['ok'] ) ) {
					$ok += $w;
				}
			}
			$data['health']['score'] = $sum ? (int) round( 100 * $ok / $sum ) : 100;
		}

		return rest_ensure_response( $data );
	}

	/**
	 * Key controls only (read-focused app). Core handles execution via:
	 *   - filter `tnc_pwa_command_result` ($result, $action, $params) -> array|WP_Error
	 *   - action `tnc_pwa_command` ($action, $params) for fire-and-forget
	 * Whitelist is filterable so core can extend without touching this module.
	 */
	public function rest_command( WP_REST_Request $req ) {
		$action  = sanitize_key( (string) $req->get_param( 'action' ) );
		$params  = (array) $req->get_param( 'params' );
		$allowed = apply_filters( 'tnc_pwa_allowed_commands', array(
			'lead_hunter_pause',
			'lead_hunter_resume',
			'email_pause',
			'email_resume',
			'self_heal',
			'kill_switch_engage',
			'kill_switch_release',
			'ack_alert',
		) );

		if ( ! in_array( $action, $allowed, true ) ) {
			return new WP_Error( 'tnc_pwa_forbidden_command', 'Command not allowed.', array( 'status' => 400 ) );
		}

		// Minimal built-in fallbacks so toggles work even before core wiring.
		// $extra carries honest, command-specific payload onto the response.
		$extra = array();
		switch ( $action ) {
			case 'lead_hunter_pause':  update_option( 'tnc_lead_hunter_running', false ); break;
			case 'lead_hunter_resume': update_option( 'tnc_lead_hunter_running', true );  break;
			case 'email_pause':        update_option( 'tnc_email_paused', true );  break;
			case 'email_resume':       update_option( 'tnc_email_paused', false ); break;
			case 'kill_switch_engage':
				update_option( 'tnc_kill_switch', true );
				update_option( 'tnc_lead_hunter_running', false );
				update_option( 'tnc_email_paused', true );
				self::push( '🛑 Kill switch engaged', 'All J.A.R.V.I.S. systems halted from mobile.', array( 'tag' => 'alarm' ) );
				break;
			case 'kill_switch_release':
				update_option( 'tnc_kill_switch', false );
				break;
			case 'self_heal':
				// C3 FIX: previously allow-listed but had no case, so it fell through
				// to a fake handled-true response while doing nothing. Now runs a REAL
				// heal and reports exactly what it repaired (honest 0 when nothing needed fixing).
				$extra = $this->run_self_heal();
				break;
			case 'ack_alert':
				// C3 FIX (same fall-through class): actually clear the active alert flag.
				$cleared = (bool) get_option( 'tnc_pwa_active_alert', false );
				if ( $cleared ) { delete_option( 'tnc_pwa_active_alert' ); }
				$extra = array( 'alert_cleared' => $cleared );
				break;
		}

		do_action( 'tnc_pwa_command', $action, $params );
		$base   = array_merge( array( 'handled' => true, 'action' => $action ), $extra );
		$result = apply_filters( 'tnc_pwa_command_result', $base, $action, $params );

		if ( is_wp_error( $result ) ) {
			return $result;
		}
		return rest_ensure_response( $result );
	}

	/**
	 * C5 FIX: real per-day self-heal counter. Stored as tnc_self_heals (date plus
	 * count). Returns 0 on a new day so the PWA tile reflects TODAY's verified heals.
	 */
	private function self_heals_today() {
		$rec   = get_option( 'tnc_self_heals', array() );
		$today = gmdate( 'Y-m-d' );
		if ( is_array( $rec ) && isset( $rec['date'], $rec['count'] ) && $rec['date'] === $today ) {
			return (int) $rec['count'];
		}
		return 0;
	}

	/** Increment today's verified-heal counter by $n (>=0) and return the new total. */
	private function record_self_heal( $n = 1 ) {
		$n     = max( 0, (int) $n );
		$today = gmdate( 'Y-m-d' );
		$rec   = get_option( 'tnc_self_heals', array() );
		$count = ( is_array( $rec ) && isset( $rec['date'], $rec['count'] ) && $rec['date'] === $today ) ? (int) $rec['count'] : 0;
		$count += $n;
		update_option( 'tnc_self_heals', array( 'date' => $today, 'count' => $count ), false );
		return $count;
	}

	/**
	 * C3 FIX: a REAL, bounded self-heal. Repairs only what it can verify and counts
	 * only repairs actually performed. Built-in repair: reschedule recurring cron
	 * hooks that have gone missing. Core/modules add deeper, verified heals via the
	 * tnc_pwa_self_heal filter. Honest contract: healed equals count of actions done.
	 */
	private function run_self_heal() {
		$actions = array();

		$expected = apply_filters( 'tnc_pwa_self_heal_cron', array() );
		if ( is_array( $expected ) ) {
			foreach ( $expected as $hook => $recurrence ) {
				if ( ! is_string( $hook ) || '' === $hook ) { continue; }
				if ( ! wp_next_scheduled( $hook ) ) {
					if ( false !== wp_schedule_event( time() + 60, (string) $recurrence, $hook ) ) {
						$actions[] = 'rescheduled cron: ' . $hook;
					}
				}
			}
		}

		$extra = apply_filters( 'tnc_pwa_self_heal', array() );
		if ( is_array( $extra ) ) {
			foreach ( $extra as $a ) {
				if ( is_string( $a ) && '' !== $a ) { $actions[] = $a; }
			}
		}

		$healed = count( $actions );
		$count  = $healed > 0 ? $this->record_self_heal( $healed ) : $this->self_heals_today();

		return array(
			'healed'           => $healed,
			'actions'          => $actions,
			'self_heals_today' => $count,
			'note'             => $healed ? 'self-heal performed verified repairs' : 'nothing required healing (honest 0)',
		);
	}
}

TNC_Module_PWA::boot();
