# tnc_pwa — Module Contract (v1.2.0)

## v1.2.0 additions (data the core lane must wire)

New snapshot sections — all defaults fail-closed / zero, app degrades gracefully:

```php
$d['atlas'] = [                      // A.T.L.A.S. — 100M database tracker (own panel)
  'records_total' => 0, 'processed_today' => 0, 'daily_goal' => 1000000,
  'imports_today' => 0, 'enriched_today' => 0, 'ai_enriched_today' => 0,
  'fleet_workers' => 0, 'fleet_workers_max' => 0, 'verified_pct' => 0,
];                                   // default source: get_option('tnc_atlas_stats')

$d['engines'] = [
  'linkedin'  => ['status'=>'idle','queue'=>0,'sent_today'=>0,'golive'=>false], // get_option('tnc_li_engine')
  'sms'       => ['status'=>'idle','queue'=>0,'sent_today'=>0,'golive'=>false], // get_option('tnc_sms_engine')
  'ssl_radar' => ['status'=>'offline','detections_today'=>0],                   // get_option('tnc_ssl_radar')
];                                   // golive=false renders amber GATED badge (fail-closed)

$d['email'] += [                     // new email-panel tiles
  'golive' => false,                 // get_option('tnc_email_golive') — fail-closed; UI shows "GATED · GO-LIVE OFF"
  'gate_readiness' => 0,             // 0-100 go-live readiness ring
  'deliverability' => 0, 'bounce_rate' => 0, 'unsubs_today' => 0,
  'hot_replies' => 0, 'demo_views' => 0,
  'warmup_stage' => 0, 'warmup_stages' => 4, 'best_window' => '9-11 AM PT',
];

$d['pipeline'] = [ 'value_usd' => 0, 'response_rate_trend' => [/* daily % */] ];
```

Health is now computed server-side and explainable: `score = round(100 * Σweight(ok) / Σweight)` from `health.checks` (each: `name, ok, weight=1, detail`). Core supplies the checks; the score is derived — never a mystery number. The app shows a tap-for-breakdown sheet listing what's costing the missing %.

Demo labeling: when the app runs without injected config it shows an amber "DEMO DATA · SIMULATED FEED" tag; live mode never shows it.

Module lane: **mobile-pwa**. Core deploy lane owns shipping this via the self-updater channel on chat.lionclickmedia.com.

## Install (core-deploy session)

1. Drop the `tnc-pwa/` folder into the core plugin, e.g. `wp-content/plugins/tuanichat/modules/tnc-pwa/`.
2. In the core loader add one line:
   ```php
   require_once __DIR__ . '/modules/tnc-pwa/module-pwa.php';
   ```
3. Add `tnc-pwa/**` to the self-updater package manifest. Bumping `TNC_Module_PWA::VERSION` busts the service-worker cache automatically.
4. No DB tables, no rewrite rules, no flush needed. Options used (all autoload=no where written by this module): `tnc_pwa_vapid`, `tnc_pwa_push_subs`, `tnc_pwa_last_flatline_alert`. Reads/writes shared toggles: `tnc_lead_hunter_running`, `tnc_email_paused`, `tnc_kill_switch`, `tnc_jarvis_mode`.

## URLs (query-var routed, work on any permalink setup)

| URL | Serves |
|---|---|
| `/?tnc_pwa=app` | Mobile app shell (login + capability required) |
| `/?tnc_pwa=manifest` | Web app manifest (standalone, violet `#8b5cf6`) |
| `/?tnc_pwa=sw` | Service worker (root scope — URL path is `/`) |
| `/?tnc_pwa=icon&s=180\|192\|512\|maskable` | Icons |

## REST (namespace `tnc/v1`, cookie auth + `X-WP-Nonce`)

| Route | Method | Purpose |
|---|---|---|
| `/pwa/snapshot` | GET | Full dashboard payload, polled every 1 s |
| `/pwa/command` | POST | `{action, params}` — whitelisted commands |
| `/pwa/push/subscribe` | POST | `{subscription}` (PushSubscription JSON) |
| `/pwa/push/unsubscribe` | POST | `{endpoint}` |
| `/pwa/push/test` | POST | Sends a test push to all devices |

Permission for all routes: `is_user_logged_in() && current_user_can( apply_filters('tnc_pwa_capability','manage_options') )`.

## ⭐ Data contract — what core must wire

### 1. `tnc_pwa_snapshot` (filter) — the one that matters

Core replaces the zero-value defaults with real Lead Hunter / J.A.R.V.I.S. data:

```php
add_filter( 'tnc_pwa_snapshot', function ( $d ) {
    $d['jarvis']['mode']             = tnc_jarvis()->mode();           // 'autonomous' | ...
    $d['jarvis']['decisions']        = tnc_jarvis()->recent_decisions( 30 );
    // each: [ 't' => unix, 'msg' => string, 'type' => 'info'|'action'|'heal'|'warn' ]
    $d['lead_hunter']['rate_per_hour'] = tnc_hunter()->rate();
    $d['lead_hunter']['leads_today']   = tnc_hunter()->today();
    $d['lead_hunter']['queue_depth']   = tnc_hunter()->queue();
    $d['lead_hunter']['render_mix']    = [ 'html' => 46, 'js' => 38, 'hybrid' => 16 ]; // %
    $d['prospects']  = [ 'total' => ..., 'new_today' => ..., 'qualified' => ... ];
    $d['email']      = [ 'queued' => ..., 'sent_today' => ..., 'open_rate' => ..., 'replies' => ..., 'paused' => ... ];
    $d['database']   = [ 'rows' => ..., 'tables' => ..., 'size_mb' => ..., 'last_backup' => '02:00 UTC' ];
    $d['health']     = [ 'score' => 98, 'self_heals_today' => 3,
                         'checks' => [ [ 'name' => 'Cron heartbeat', 'ok' => true ], ... ] ];
    return $d;
} );
```

Keep it cheap (cached/option reads) — it runs every second per open phone.

### 2. Commands

Whitelist (filter `tnc_pwa_allowed_commands`): `lead_hunter_pause/resume`, `email_pause/resume`, `self_heal`, `kill_switch_engage/release`, `ack_alert`.

The module flips the shared options as a fallback; core should hook real behavior:

```php
add_action( 'tnc_pwa_command', function ( $action, $params ) { ... }, 10, 2 );
add_filter( 'tnc_pwa_command_result', fn( $result, $action, $params ) => $result, 10, 3 );
```

Kill-switch engage also force-pauses hunter + email options and pushes an