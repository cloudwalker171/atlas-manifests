/* TNC J.A.R.V.I.S. PWA service worker — v__TNC_PWA_VERSION__
 * Strategy:
 *  - App shell (?tnc_pwa=app): network-first, cached fallback => offline-instant open.
 *  - Icons/manifest: cache-first.
 *  - REST snapshot: network-first, LAST GOOD RESPONSE cached => app opens showing
 *    last-known stats on poor signal, then live-updates when connected.
 *  - Web Push: shows J.A.R.V.I.S. notifications; tap focuses/opens the app.
 */
const CACHE = 'tnc-pwa-v__TNC_PWA_VERSION__';
const DATA_CACHE = 'tnc-pwa-data';

self.addEventListener('install', () => self.skipWaiting());

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys
        .filter((k) => k.startsWith('tnc-pwa-') && k !== CACHE && k !== DATA_CACHE)
        .map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

function kind(url) {
  const u = new URL(url);
  if (u.pathname.includes('/wp-json/tnc/v1/pwa/snapshot')) return 'snapshot';
  if (u.pathname.includes('/wp-json/')) return 'rest';
  const qv = u.searchParams.get('tnc_pwa');
  if (qv === 'app') return 'app';
  if (qv === 'icon' || qv === 'manifest') return 'asset';
  return 'other';
}

self.addEventListener('fetch', (e) => {
  if (e.request.method !== 'GET') return;
  const k = kind(e.request.url);
  if (k === 'rest' || k === 'other') return;

  if (k === 'asset') {
    e.respondWith(
      caches.match(e.request).then((hit) =>
        hit || fetch(e.request).then((res) => {
          const copy = res.clone();
          caches.open(CACHE).then((c) => c.put(e.request, copy));
          return res;
        })
      )
    );
    return;
  }

  if (k === 'snapshot') {
    // Network-first; keep last good payload for offline-instant stats.
    e.respondWith(
      fetch(e.request)
        .then((res) => {
          if (res.ok) {
            const copy = res.clone();
            caches.open(DATA_CACHE).then((c) => c.put('last-snapshot', copy));
          }
          return res;
        })
        .catch(() =>
          caches.open(DATA_CACHE).then((c) => c.match('last-snapshot'))
            .then((hit) => hit || Response.error())
        )
    );
    return;
  }

  // app shell: network-first, cached fallback (offline-instant open)
  e.respondWith(
    fetch(e.request)
      .then((res) => {
        if (res.ok && !res.redirected) {
          const copy = res.clone();
          caches.open(CACHE).then((c) => c.put(e.request, copy));
        }
        return res;
      })
      .catch(() => caches.match(e.request))
  );
});

/* ---------------- Web Push (iOS 16.4+ home-screen PWA) ---------------- */

self.addEventListener('push', (e) => {
  let p = {};
  try { p = e.data ? e.data.json() : {}; } catch (_) { p = { title: 'J.A.R.V.I.S.', body: e.data && e.data.text() }; }
  const title = p.title || 'J.A.R.V.I.S.';
  e.waitUntil(self.registration.showNotification(title, {
    body: p.body || '',
    tag: p.tag || 'jarvis',
    icon: './?tnc_pwa=icon&s=192',
    badge: './?tnc_pwa=icon&s=192',
    data: { url: p.url || './?tnc_pwa=app' },
    renotify: p.tag === 'alarm'
  }));
});

self.addEventListener('notificationclick', (e) => {
  e.notification.close();
  const url = (e.notification.data && e.notification.data.url) || './?tnc_pwa=app';
  e.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((list) => {
      for (const c of list) {
        if (c.url.includes('tnc_pwa=app') && 'focus' in c) return c.focus();
      }
      return clients.openWindow(url);
    })
  );
});

self.addEventListener('pushsubscriptionchange', (e) => {
  // App re-subscribes on next open; nothing critical to do here.
});
