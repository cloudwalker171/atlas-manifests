<?php
/**
 * TNC_WebPush — minimal dependency-free Web Push sender (RFC 8291 aes128gcm + RFC 8292 VAPID).
 *
 * Requires: PHP >= 7.3 (openssl_pkey_derive, hash_hkdf), OpenSSL with EC P-256.
 * If the host lacks EC support, TNC_WebPush::supported() returns false and the
 * PWA module silently disables push (everything else keeps working).
 *
 * The core plugin may swap this for minishlink/web-push via the
 * `tnc_pwa_push_sender` filter — see CONTRACT.md.
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }
if ( class_exists( 'TNC_WebPush' ) ) { return; }

final class TNC_WebPush {

	// SPKI DER prefix for an EC P-256 public key (followed by the 65-byte uncompressed point).
	const P256_SPKI_PREFIX = '3059301306072a8648ce3d020106082a8648ce3d030107034200';

	public static function supported() {
		return PHP_VERSION_ID >= 70300
			&& function_exists( 'openssl_pkey_derive' )
			&& function_exists( 'hash_hkdf' )
			&& function_exists( 'openssl_pkey_new' );
	}

	/* ------------------------------------------------------------------ */
	/*  VAPID keys                                                          */
	/* ------------------------------------------------------------------ */

	/** @return array{publicKey:string,privateKeyPem:string}|null base64url public, PEM private */
	public static function generate_vapid_keys() {
		$res = openssl_pkey_new( array( 'curve_name' => 'prime256v1', 'private_key_type' => OPENSSL_KEYTYPE_EC ) );
		if ( ! $res ) { return null; }
		openssl_pkey_export( $res, $pem );
		$det = openssl_pkey_get_details( $res );
		if ( empty( $det['ec']['x'] ) || empty( $det['ec']['y'] ) ) { return null; }
		$pub = "\x04" . str_pad( $det['ec']['x'], 32, "\0", STR_PAD_LEFT ) . str_pad( $det['ec']['y'], 32, "\0", STR_PAD_LEFT );
		return array( 'publicKey' => self::b64url( $pub ), 'privateKeyPem' => $pem );
	}

	/* ------------------------------------------------------------------ */
	/*  Send                                                                */
	/* ------------------------------------------------------------------ */

	/**
	 * @param array  $subscription { endpoint, keys: { p256dh, auth } }
	 * @param string $payload      JSON string (<= ~3.5 KB)
	 * @param string $vapid_public base64url
	 * @param string $vapid_private_pem
	 * @param string $subject      mailto: or https: contact
	 * @return true|WP_Error
	 */
	public static function send( $subscription, $payload, $vapid_public, $vapid_private_pem, $subject, $ttl = 86400 ) {
		if ( ! self::supported() ) {
			return new WP_Error( 'tnc_push_unsupported', 'Host lacks EC/HKDF support.' );
		}
		if ( empty( $subscription['endpoint'] ) || empty( $subscription['keys']['p256dh'] ) || empty( $subscription['keys']['auth'] ) ) {
			return new WP_Error( 'tnc_push_bad_sub', 'Malformed subscription.' );
		}

		$endpoint    = $subscription['endpoint'];
		$client_pub  = self::b64url_decode( $subscription['keys']['p256dh'] ); // 65 bytes
		$auth_secret = self::b64url_decode( $subscription['keys']['auth'] );  // 16 bytes
		if ( 65 !== strlen( $client_pub ) || 16 !== strlen( $auth_secret ) ) {
			return new WP_Error( 'tnc_push_bad_keys', 'Bad subscription key sizes.' );
		}

		// 1. Ephemeral ("as") keypair + ECDH with client public key.
		$as_res = openssl_pkey_new( array( 'curve_name' => 'prime256v1', 'private_key_type' => OPENSSL_KEYTYPE_EC ) );
		$as_det = openssl_pkey_get_details( $as_res );
		$as_pub = "\x04" . str_pad( $as_det['ec']['x'], 32, "\0", STR_PAD_LEFT ) . str_pad( $as_det['ec']['y'], 32, "\0", STR_PAD_LEFT );

		$client_key = openssl_pkey_get_public( self::raw_point_to_pem( $client_pub ) );
		$shared     = openssl_pkey_derive( $client_key, $as_res, 32 );
		if ( false === $shared ) {
			return new WP_Error( 'tnc_push_ecdh', 'ECDH derive failed.' );
		}

		// 2. HKDF per RFC 8291.
		$salt     = random_bytes( 16 );
		$key_info = "WebPush: info\0" . $client_pub . $as_pub;
		$prk      = hash_hkdf( 'sha256', $shared, 32, $key_info, $auth_secret );
		$cek      = hash_hkdf( 'sha256', $prk, 16, "Content-Encoding: aes128gcm\0", $salt );
		$nonce    = hash_hkdf( 'sha256', $prk, 12, "Content-Encoding: nonce\0", $salt );

		// 3. aes128gcm body: header(salt|rs|idlen|keyid) + ciphertext(payload + 0x02 delimiter).
		$plaintext = $payload . "\x02";
		$tag       = '';
		$cipher    = openssl_encrypt( $plaintext, 'aes-128-gcm', $cek, OPENSSL_RAW_DATA, $nonce, $tag, '', 16 );
		if ( false === $cipher ) {
			return new WP_Error( 'tnc_push_encrypt', 'AES-GCM failed.' );
		}
		$rs   = pack( 'N', 4096 );
		$body = $salt . $rs . chr( strlen( $as_pub ) ) . $as_pub . $cipher . $tag;

		// 4. VAPID JWT (ES256), audience = push service origin.
		$parts = wp_parse_url( $endpoint );
		$aud   = $parts['scheme'] . '://' . $parts['host'];
		$jwt   = self::vapid_jwt( $aud, $subject, $vapid_private_pem );
		if ( is_wp_error( $jwt ) ) { return $jwt; }

		$response = wp_remote_post( $endpoint, array(
			'timeout' => 10,
			'headers' => array(
				'TTL'              => (string) $ttl,
				'Content-Encoding' => 'aes128gcm',
				'Content-Type'     => 'application/octet-stream',
				'Urgency'          => 'high',
				'Authorization'    => 'vapid t=' . $jwt . ', k=' . $vapid_public,
			),
			'body'    => $body,
		) );

		if ( is_wp_error( $response ) ) { return $response; }
		$code = (int) wp_remote_retrieve_response_code( $response );
		if ( 404 === $code || 410 === $code ) {
			return new WP_Error( 'tnc_push_gone', 'Subscription expired.', array( 'status' => $code ) );
		}
		if ( $code < 200 || $code >= 300 ) {
			return new WP_Error( 'tnc_push_http_' . $code, wp_remote_retrieve_body( $response ) );
		}
		return true;
	}

	/* ------------------------------------------------------------------ */
	/*  Internals                                                           */
	/* ------------------------------------------------------------------ */

	private static function vapid_jwt( $aud, $subject, $private_pem ) {
		$header = self::b64url( wp_json_encode( array( 'typ' => 'JWT', 'alg' => 'ES256' ) ) );
		$claims = self::b64url( wp_json_encode( array( 'aud' => $aud, 'exp' => time() + 12 * 3600, 'sub' => $subject ) ) );
		$input  = $header . '.' . $claims;

		$ok = openssl_sign( $input, $der, $private_pem, OPENSSL_ALGO_SHA256 );
		if ( ! $ok ) {
			return new WP_Error( 'tnc_push_sign', 'VAPID signing failed.' );
		}
		$sig = self::der_to_raw_sig( $der );
		if ( null === $sig ) {
			return new WP_Error( 'tnc_push_sig_fmt', 'Could not normalize ECDSA signature.' );
		}
		return $input . '.' . self::b64url( $sig );
	}

	/** DER ECDSA-Sig-Value -> raw 64-byte r||s. */
	private static function der_to_raw_sig( $der ) {
		$pos = 0;
		if ( "\x30" !== $der[ $pos++ ] ) { return null; }
		$len = ord( $der[ $pos++ ] );
		if ( $len & 0x80 ) { $pos += ( $len & 0x7f ); }
		$out = '';
		for ( $i = 0; $i < 2; $i++ ) {
			if ( "\x02" !== $der[ $pos++ ] ) { return null; }
			$l   = ord( $der[ $pos++ ] );
			$int = substr( $der, $pos, $l );
			$pos += $l;
			$int = ltrim( $int, "\0" );
			if ( strlen( $int ) > 32 ) { return null; }
			$out .= str_pad( $int, 32, "\0", STR_PAD_LEFT );
		}
		return $out;
	}

	private static function raw_point_to_pem( $point65 ) {
		$der = hex2bin( self::P256_SPKI_PREFIX ) . $point65;
		return "-----BEGIN PUBLIC KEY-----\n" . chunk_split( base64_encode( $der ), 64, "\n" ) . "-----END PUBLIC KEY-----\n";
	}

	public static function b64url( $bin ) {
		return rtrim( strtr( base64_encode( $bin ), '+/', '-_' ), '=' );
	}

	public static function b64url_decode( $str ) {
		return base64_decode( strtr( $str, '-_', '+/' ) . str_repeat( '=', ( 4 - strlen( $str ) % 4 ) % 4 ) );
	}
}
