<?php
/**
 * Plugin Name:       TuaniChat Platform
 * Plugin URI:        https://tuanilabs.com
 * Description:       AI Intake Assistant platform by TuaniLabs — prospect manager, site crawler, knowledge base, central chat proxy, private demo pages, and outreach kit generator.
 * Version:           1.23.3
 * Requires at least: 6.4
 * Requires PHP:      8.1
 * Author:            TuaniLabs LLC
 * Author URI:        https://tuanilabs.com
 * License:           Proprietary
 * Text Domain:       tuanichat
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'TNC_VERSION', '1.23.2' );
define( 'TNC_PLUGIN_FILE', __FILE__ );
define( 'TNC_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'TNC_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'TNC_REST_NS', 'tuanichat/v1' );
define( 'TNC_TZ', 'America/Los_Angeles' ); // canonical platform clock (Pacific, auto DST). WP timezone set to match.

require_once TNC_PLUGIN_DIR . 'includes/class-tnc-install.php';
require_once TNC_PLUGIN_DIR . 'includes/class-tnc-settings.php';
require_once TNC_PLUGIN_DIR . 'includes/class-tnc-prospects.php';
require_once TNC_PLUGIN_DIR . 'includes/class-tnc-crawler.php';
require_once TNC_PLUGIN_DIR . 'includes/class-tnc-crawl-jobs.php';
require_once TNC_PLUGIN_DIR . 'includes/class-tnc-bulk.php';
require_once TNC_PLUGIN_DIR . 'includes/class-tnc-samples.php';
require_once TNC_PLUGIN_DIR . 'includes/class-tnc-workers.php';
require_once TNC_PLUGIN_DIR . 'includes/class-tnc-mail-streams.php';
require_once TNC_PLUGIN_DIR . 'includes/class-tnc-fleet.php';
require_once TNC_PLUGIN_DIR . 'includes/class-tnc-components.php';
require_once TNC_PLUGIN_DIR . 'includes/class-tnc-jarvis-bundle.php';
require_once TNC_PLUGIN_DIR . 'modules/tnc-pwa/module-pwa.php';
// Wire the mobile PWA snapshot to real platform data (fail-closed defaults stay).
add_filter( 'tnc_pwa_snapshot', function( $d ) {
	if ( ! class_exists( 'TNC_Leadhunter' ) ) { return $d; }
	try {
		$fr = TNC_Leadhunter::freshness();
		$li = (array) get_option( 'tnc_li_engine', array() );
		$sms = (array) get_option( 'tnc_sms_engine', array() );
		$d['lead'] = array_merge( isset( $d['lead'] ) ? (array) $d['lead'] : array(), array(
			'staged_1h' => (int) ( $fr['last_1h'] ?? 0 ), 'staged_24h' => (int) ( $fr['last_24h'] ?? 0 ),
			'promoted_1h' => (int) ( $fr['promoted_1h'] ?? 0 ), 'mins_since' => $fr['mins_since_last'] ?? null,
		) );
		$d['engines'] = array(
			'linkedin'  => array( 'status' => $li['status'] ?? 'idle', 'queue' => (int) ( $li['queue'] ?? 0 ), 'sent_today' => (int) ( $li['sent_today'] ?? 0 ), 'golive' => ! empty( $li['golive'] ) ),
			'sms'       => array( 'status' => $sms['status'] ?? 'idle', 'queue' => (int) ( $sms['queue'] ?? 0 ), 'sent_today' => (int) ( $sms['sent_today'] ?? 0 ), 'golive' => ! empty( $sms['golive'] ) ),
			'ssl_radar' => array( 'status' => 'offline', 'detections_today' => 0 ),
		);
		// health: net-new staging + promotion are the two production heartbeats.
		$d['health'] = isset( $d['health'] ) ? $d['health'] : array();
		$d['health']['checks'] = array(
			array( 'name' => 'Lead production', 'ok' => empty( $fr['flatline'] ), 'weight' => 2, 'detail' => (int) ( $fr['last_1h'] ?? 0 ) . '/hr staged' ),
			array( 'name' => 'Prospect promotion', 'ok' => (int) ( $fr['promoted_1h'] ?? 0 ) > 0 || (int) ( $fr['last_1h'] ?? 0 ) === 0, 'weight' => 2, 'detail' => (int) ( $fr['promoted_1h'] ?? 0 ) . '/hr promoted' ),
		);
	} catch ( \Throwable $e ) {}
	return $d;
}, 10, 1 );
require_once TNC_PLUGIN_DIR . 'includes/class-tnc-backup.php';
require_once TNC_PLUGIN_DIR . 'includes/class-tnc-leadhunter.php';
require_once TNC_PLUGIN_DIR . 'includes/class-tnc-emails.php';
require_once TNC_PLUGIN_DIR . 'includes/class-tnc-previews.php';
require_once TNC_PLUGIN_DIR . 'includes/class-tnc-kb.php';
require_once TNC_PLUGIN_DIR . 'includes/class-tnc-themes.php';
require_once TNC_PLUGIN_DIR . 'includes/class-tnc-compliance.php';
require_once TNC_PLUGIN_DIR . 'includes/class-tnc-anthropic.php';
require_once TNC_PLUGIN_DIR . 'includes/class-tnc-chat.php';
require_once TNC_PLUGIN_DIR . 'includes/class-tnc-outreach.php';
require_once TNC_PLUGIN_DIR . 'includes/class-tnc-demo.php';
require_once TNC_PLUGIN_DIR . 'includes/class-tnc-admin-rest.php';
require_once TNC_PLUGIN_DIR . 'includes/class-tnc-admin.php';

register_activation_hook( __FILE__, array( 'TNC_Install', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'TNC_Install', 'deactivate' ) );

add_action( 'plugins_loaded', 'tnc_boot' );
function tnc_boot() {
	TNC_Install::maybe_upgrade();
	TNC_Demo::init();
	TNC_Chat::init();
	TNC_Crawl_Jobs::init();
	TNC_Bulk::init();
	TNC_Outreach::init();
	TNC_Workers::init();
	TNC_Admin_Rest::init();
	TNC_Previews::init();
	TNC_Emails::init();
	TNC_Fleet::init();
	TNC_Backup::init();
	TNC_Leadhunter::init();
	if ( is_admin() ) {
		TNC_Admin::init();
	}
}
