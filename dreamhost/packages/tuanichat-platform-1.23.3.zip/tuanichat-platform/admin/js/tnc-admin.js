/* TuaniChat Platform admin app (vanilla JS) */
(function () {
  'use strict';
  var A = window.tncAdmin || {};
  var root = document.getElementById('tnc-app');
  if (!root) return;

  /* ---------- helpers ---------- */
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function api(path, method, body) {
    return fetch(A.rest + path, {
      method: method || 'GET',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': A.nonce },
      body: body ? JSON.stringify(body) : undefined
    }).then(function (r) {
      return r.json().then(function (j) {
        if (!r.ok) throw new Error((j && j.message) || 'Request failed (' + r.status + ')');
        return j;
      });
    });
  }
  var toastTimer;
  function toast(msg, isErr) {
    var t = document.querySelector('.tnc-toast');
    if (t) t.remove();
    t = document.createElement('div');
    t.className = 'tnc-toast' + (isErr ? ' err' : '');
    t.textContent = msg;
    document.body.appendChild(t);
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.remove(); }, 4200);
  }
  function spin(btn, on, label) {
    if (!btn) return;
    if (on) {
      btn.dataset.label = btn.innerHTML;
      btn.disabled = true;
      btn.innerHTML = '<span class="tnc-spin"></span> ' + esc(label || 'Working…');
    } else {
      btn.disabled = false;
      btn.innerHTML = btn.dataset.label || btn.innerHTML;
    }
  }
  function skeletons(n, cls) {
    var h = '';
    for (var i = 0; i < n; i++) h += '<div class="tnc-skel ' + cls + '"></div>';
    return h;
  }
  function scoreCls(s) { return s >= 65 ? 'hi' : (s >= 35 ? 'mid' : 'lo'); }
  function crawlPct(p) {
    var pr = p.crawl_progress;
    if (!pr || !pr.total) return '';
    return Math.min(100, Math.round((pr.fetched / pr.total) * 100)) + '% (' + pr.fetched + '/' + pr.total + ')';
  }
  function fmtNum(n) {
    n = Number(n) || 0;
    if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M';
    if (n >= 1000) return (n / 1000).toFixed(1) + 'k';
    return String(n);
  }
  function pill(status) {
    return '<span class="tnc-pill ' + esc(status) + '">' + esc(A.statuses[status] || status) + '</span>';
  }
  function options(map, sel, blank) {
    var h = blank ? '<option value="">' + esc(blank) + '</option>' : '';
    Object.keys(map).forEach(function (k) {
      h += '<option value="' + esc(k) + '"' + (k === sel ? ' selected' : '') + '>' + esc(map[k]) + '</option>';
    });
    return h;
  }
  function copyText(text, el) {
    var done = function () {
      if (el) { var o = el.textContent; el.textContent = 'Copied ✓'; setTimeout(function () { el.textContent = o; }, 1600); }
    };
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(text).then(done);
    } else {
      var ta = document.createElement('textarea');
      ta.value = text; document.body.appendChild(ta); ta.select();
      try { document.execCommand('copy'); } catch (e) {}
      ta.remove(); done();
    }
  }

  /* ---------- Real-time state poller (visibility-aware) ---------- */
  var live = { timer: null, fn: null, ms: 5000 };
  function liveStart(fn, ms) {
    live.fn = fn; live.ms = ms || 5000;
    liveStop();
    var tick = function () {
      if (document.hidden) { live.timer = setTimeout(tick, 15000); return; } // back off when hidden.
      Promise.resolve(live.fn()).finally(function () { live.timer = setTimeout(tick, live.ms); });
    };
    live.timer = setTimeout(tick, live.ms);
  }
  function liveStop() { if (live.timer) { clearTimeout(live.timer); live.timer = null; } }
  document.addEventListener('visibilitychange', function () { /* next tick self-adjusts */ });
  function countUp(el, to) {
    var from = parseInt(String(el.textContent).replace(/[^\d]/g, ''), 10) || 0;
    to = parseInt(to, 10) || 0;
    if (from === to) return;
    var steps = 12, i = 0;
    var iv = setInterval(function () {
      i++;
      el.textContent = i >= steps ? to : Math.round(from + (to - from) * (i / steps));
      if (i >= steps) clearInterval(iv);
    }, 40);
  }

  function shell(content) {
    var tabs = [
      ['tnc-dashboard', 'Dashboard'],
      ['tnc-prospects', 'Prospects'],
      ['tnc-bulk', 'Bulk Import'],
      ['tnc-settings', 'Settings']
    ].map(function (t) {
      return '<a href="admin.php?page=' + t[0] + '" class="' + (A.page === t[0] ? 'on' : '') + '">' + t[1] + '</a>';
    }).join('');
    root.innerHTML =
      '<div class="orb orb1"></div><div class="orb orb2"></div>' +
      '<div class="tnc-top"><div class="tnc-logo">Tuani<span class="tnc-grad">Chat</span><span class="labs">labs platform</span></div>' +
      '<div class="tnc-tabs">' + tabs + '</div>' +
      '<div id="tncLiveDot" style="display:flex;align-items:center;gap:7px;margin-left:14px;font-size:11.5px;color:#34D399"><span style="width:9px;height:9px;border-radius:50%;background:#34D399;box-shadow:0 0 0 0 rgba(52,211,153,.6);animation:tncLivePulse 2s infinite"></span><span id="tncLiveTxt">LIVE</span></div>' +
      '<style>@keyframes tncLivePulse{0%{box-shadow:0 0 0 0 rgba(52,211,153,.55)}70%{box-shadow:0 0 0 9px rgba(52,211,153,0)}100%{box-shadow:0 0 0 0 rgba(52,211,153,0)}}.tncRowGlow{animation:tncRG 1.4s ease-out}@keyframes tncRG{0%{background:rgba(52,211,153,.28)}100%{background:transparent}}</style>' +
      '<div class="tnc-main">' + content + '</div>';
    if (!window.__tncLiveTick) {
      window.__tncLiveTick = setInterval(function () {
        var t = document.getElementById('tncLiveTxt');
        if (t && window.__tncLastPoll) { var s2 = Math.round((Date.now() - window.__tncLastPoll) / 1000); t.textContent = 'LIVE \u00b7 updated ' + (s2 < 2 ? 'now' : s2 + 's ago'); }
      }, 1000);
    }
  }

  /* ---------- Dashboard ---------- */
  function renderDashboard() {
    var c = A.counts || {};
    var leads = (A.leads || []).map(function (l) {
      return '<div class="tnc-lead"><span class="who">' + esc(l.name || l.email || l.phone || 'Lead') + '</span>' +
        ' <span class="tnc-muted">→ ' + esc(l.company_name || '') + '</span>' +
        '<div class="meta">' + esc([l.email, l.phone].filter(Boolean).join(' · ')) + ' · ' + esc(l.created_at) + '</div></div>';
    }).join('') || '<div class="tnc-empty"><div class="big">✦</div>No leads yet — send some demos.</div>';

    var stat = function (label, value) {
      return '<div class="tnc-stat"><div class="lbl">' + label + '</div><div class="num">' + value + '</div></div>';
    };

    shell(
      '<span class="tnc-badge">TuaniChat Platform · Demo Builder</span>' +
      '<h1 class="tnc-h1">Turning prospects into <span class="tnc-grad">clients.</span></h1>' +
      '<p class="tnc-sub">Your AI intake assistant pipeline at a glance.</p>' +
      '<div class="tnc-cards">' +
      '<div class="tnc-stat"><div class="lbl">Prospects</div><div class="num" data-live="prospects">' + (c.prospects || 0) + '</div></div>' +
      '<div class="tnc-stat"><div class="lbl">Demos Live</div><div class="num" data-live="demos">' + (c.demos || 0) + '</div></div>' +
      '<div class="tnc-stat"><div class="lbl">Leads Captured</div><div class="num" data-live="leads">' + (c.leads || 0) + '</div></div>' +
      stat('Tokens Used', fmtNum(c.tokens)) +
      '</div>' +
      '<div class="tnc-card" style="margin-bottom:24px"><h3>Workers</h3><div class="hint">Crawl lanes · live</div><div id="tncWorkers" class="tnc-muted">Loading…</div></div>' +
      '<div class="tnc-grid2">' +
      '<div class="tnc-card"><h3>Recent leads</h3><div class="hint">Captured on your demo pages</div>' + leads + '</div>' +
      '<div class="tnc-card"><h3>Quick start</h3><div class="hint">From prospect to wow in four steps</div>' +
      '<div class="tnc-kv"><span class="k">1</span><span class="v">Add a prospect with their website URL</span></div>' +
      '<div class="tnc-kv"><span class="k">2</span><span class="v">Crawl the site — KB + private demo are built automatically</span></div>' +
      '<div class="tnc-kv"><span class="k">3</span><span class="v">Generate the outreach kit, send the demo link</span></div>' +
      '<div class="tnc-kv"><span class="k">4</span><span class="v">Watch leads and engagement roll in</span></div>' +
      '<div class="tnc-mt" style="display:flex;gap:12px"><a class="tnc-btn" href="admin.php?page=tnc-prospects">Go to Prospects</a>' +
      '<a class="tnc-btn ghost" href="admin.php?page=tnc-settings">Settings</a></div></div>' +
      '</div>'
    );
    var paintWorkers = function (w) {
      var el = document.getElementById('tncWorkers');
      if (!el || !w) return;
      var hb = w.heartbeat_age == null
        ? '<span style="color:#FB7185">heartbeat: not set up</span>'
        : (w.heartbeat_age < 150 ? '<span style="color:#34D399">heartbeat ' + w.heartbeat_age + 's ago</span>' : '<span style="color:#FBBF24">heartbeat ' + Math.round(w.heartbeat_age / 60) + 'm ago</span>');
      var deep = (w.deep || []).map(function (d) {
        return '<div class="tnc-kv"><span class="k">Deep crawl</span><span class="v">' + esc(d.name || ('#' + d.id)) + ' — ' +
          (d.state === 'decision'
            ? 'awaiting size decision (' + d.total + ' pages found)'
            : d.fetched + '/' + d.total + (d.stalled ? ' · <b style="color:#FB7185">stalled</b>' : '') + (d.eta_min ? ' · ~' + d.eta_min + ' min left' : '')) + '</span></div>';
      }).join('');
      el.innerHTML = w.lanes.map(function (l) {
        return '<span class="tnc-pill ' + (l.active ? 'crawling' : 'plat') + '" style="margin-right:8px">Lane ' + l.lane + ' — ' + (l.active ? 'active' : 'idle') + '</span>';
      }).join('') + ' <span class="tnc-muted" style="font-size:12px">' + w.queued + ' queued · ' + w.crawling + ' crawling · <b style="color:var(--text,#E4E4E7)">' + (w.pages_per_min || 0) + ' pages/min</b> · ' + hb + '</span>' + deep;
    };
    liveStart(function () {
      return api('/admin/state').then(function (j) {
        ['prospects', 'demos', 'leads'].forEach(function (k) {
          var el = document.querySelector('[data-live="' + k + '"]');
          if (el) countUp(el, j.counts[k]);
        });
        paintWorkers(j.workers);
      }).catch(function () {});
    }, 4000);
  }

  /* ---------- Prospects list ---------- */
  var listState = { search: '', status: '', industry: '', platform: '', range: '', from: '', to: '', sort: 'created_at', dir: -1, rows: [], stats: null };
  var PLATFORMS = ['wordpress', 'shopify', 'wix', 'squarespace', 'webflow', 'gohighlevel', 'custom', 'unknown', 'generic'];

  function renderList() {
    shell(
      '<span class="tnc-badge">Pipeline</span>' +
      '<h1 class="tnc-h1">Prospects</h1><p class="tnc-sub">Every demo starts here. Add a prospect, crawl their site, wow them.</p>' +
      '<div id="tncPStats" class="tnc-pstats"></div>' +
      '<div class="tnc-toolbar">' +
      '<input type="text" id="tncSearch" placeholder="Search prospects…" value="' + esc(listState.search) + '">' +
      '<select id="tncFStatus">' + options(A.statuses, listState.status, 'All statuses') + '</select>' +
      '<select id="tncFInd">' + options(A.industries, listState.industry, 'All industries') + '</select>' +
      '<select id="tncFPlat"><option value="">All platforms</option>' + PLATFORMS.map(function (pl) { return '<option value="' + pl + '"' + (listState.platform === pl ? ' selected' : '') + '>' + pl + '</option>'; }).join('') + '</select>' +
      dateFilterHTML() +
      '<div class="tnc-spacer"></div>' +
      '<button class="tnc-btn" id="tncNew">+ New Prospect</button>' +
      '</div>' +
      '<div id="tncPromoStrip" style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin:0 0 12px;padding:9px 12px;border:1px solid rgba(124,92,252,.3);border-radius:10px;background:linear-gradient(90deg,rgba(52,211,153,.08),transparent)"></div>' + '<div class="tnc-card" style="padding:8px 4px"><div id="tncList">' + skeletons(4, 'tnc-skel-row') + '</div></div>'
    );
    document.getElementById('tncNew').addEventListener('click', function () { prospectModal(null); });
    var deb;
    document.getElementById('tncSearch').addEventListener('input', function (e) {
      clearTimeout(deb);
      deb = setTimeout(function () { listState.search = e.target.value; loadList(); }, 350);
    });
    document.getElementById('tncFStatus').addEventListener('change', function (e) { listState.status = e.target.value; loadList(); });
    document.getElementById('tncFInd').addEventListener('change', function (e) { listState.industry = e.target.value; loadList(); });
    document.getElementById('tncFPlat').addEventListener('change', function (e) { listState.platform = e.target.value; loadList(); });
    bindDateFilter(loadList);
    loadList();
  }

  /* ---------- Reusable date-filter component ---------- */
  function dateFilterHTML() {
    var presets = [['', 'All time'], ['today', 'Today'], ['24h', '24h'], ['7d', '7 days'], ['30d', '30 days'], ['custom', 'Custom…']];
    var btns = presets.map(function (p) {
      return '<button type="button" class="tnc-dfb' + (listState.range === p[0] ? ' on' : '') + '" data-r="' + p[0] + '">' + p[1] + '</button>';
    }).join('');
    var custom = '<span id="tncDfCustom" style="display:' + (listState.range === 'custom' ? 'inline-flex' : 'none') + ';gap:6px;align-items:center;margin-left:4px">' +
      '<input type="date" id="tncDfFrom" value="' + esc(listState.from) + '"><span class="tnc-muted">→</span><input type="date" id="tncDfTo" value="' + esc(listState.to) + '"></span>';
    return '<div class="tnc-datefilter">' + btns + custom + '</div>';
  }
  function bindDateFilter(onChange) {
    document.querySelectorAll('.tnc-dfb').forEach(function (b) {
      b.addEventListener('click', function () {
        listState.range = b.dataset.r;
        document.querySelectorAll('.tnc-dfb').forEach(function (x) { x.classList.toggle('on', x === b); });
        var cu = document.getElementById('tncDfCustom'); if (cu) cu.style.display = listState.range === 'custom' ? 'inline-flex' : 'none';
        if (listState.range !== 'custom') onChange();
      });
    });
    ['tncDfFrom', 'tncDfTo'].forEach(function (id) {
      var el = document.getElementById(id); if (!el) return;
      el.addEventListener('change', function () { listState.from = document.getElementById('tncDfFrom').value; listState.to = document.getElementById('tncDfTo').value; onChange(); });
    });
  }
  function dateQuery() {
    if (!listState.range) return '';
    if (listState.range === 'custom') return '&range=custom&from=' + encodeURIComponent(listState.from) + '&to=' + encodeURIComponent(listState.to);
    return '&range=' + encodeURIComponent(listState.range);
  }

  function loadList() {
    var q = '?search=' + encodeURIComponent(listState.search) + '&status=' + encodeURIComponent(listState.status) + '&industry=' + encodeURIComponent(listState.industry) + '&platform=' + encodeURIComponent(listState.platform) + dateQuery();
    return api('/admin/prospects' + q).then(function (j) {
      listState.rows = j.prospects; listState.stats = j.stats || null;
      drawList();
      // PLATFORM RULE: everything realtime. The list ALWAYS live-polls (2s);
      // hidden tabs back off automatically inside liveStart.
      window.__tncLastPoll = Date.now();
      detectArrivals(j.prospects || []);
      if (!live.timer) liveStart(loadList, 2000);
    }).catch(function (e) { toast(e.message, true); });
  }

  function ago(ts, epoch){ var s2; if(epoch){ s2=(Date.now()/1000)-epoch; } else { if(!ts) return ''; var d=new Date((ts+'').replace(' ','T')); s2=(Date.now()-d.getTime())/1000; } if(isNaN(s2)||s2<0) return ts?esc((ts+'').slice(0,10)):''; if(s2<3600) return Math.max(1,Math.round(s2/60))+'m ago'; if(s2<86400) return Math.round(s2/3600)+'h ago'; if(s2<7*86400) return Math.round(s2/86400)+'d ago'; return ts?esc((ts+'').slice(0,10)):''; }
  function isNew(ts, epoch){ var ms; if(epoch){ ms=Date.now()-epoch*1000; } else { if(!ts) return false; ms=Date.now()-new Date((ts+'').replace(' ','T')).getTime(); } return ms<48*3600*1000; }
  function renderPStats(){
    var el=document.getElementById('tncPStats'); if(!el) return; var k=listState.stats; if(!k){return;}
    var topInd=Object.keys(k.by_industry||{}).slice(0,1).map(function(i){return (A.industries[i]||i)+' '+k.by_industry[i];})[0]||'—';
    var ready=(k.by_status&&(k.by_status.demo_created||0)+(k.by_status.demo_sent||0)+(k.by_status.engaged||0)+(k.by_status.won||0))||0;
    var vals=[['total',k.total,''],['new1d',k.new_1d,'grn'],['new7d',k.new_7d,''],['ready',ready,'grn'],['avg',k.avg_score,''],['ind',esc(topInd),'ind']];
    // BUILD ONCE — boot animation fires only on first mount (data-booted guard).
    if(!el.getAttribute('data-booted')){
      var labels={total:'Total prospects',new1d:'NEW today',new7d:'New 7 days',ready:'Email-ready',avg:'Avg score',ind:'Top industry'};
      el.innerHTML='<div class="tnc-pstat-row">'+vals.map(function(v){return '<div class="tnc-pstat"><div class="pv '+(v[2]==='ind'?'':v[2])+'" id="ps_'+v[0]+'"'+(v[2]==='ind'?' style="font-size:15px"':'')+'>'+v[1]+'</div><div class="pl">'+labels[v[0]]+'</div></div>';}).join('')+'</div>';
      el.setAttribute('data-booted','1');
    } else {
      // REFRESH — patch text nodes in place, glow on change. Tiles never disappear.
      vals.forEach(function(v){var n=document.getElementById('ps_'+v[0]);if(!n)return;if(String(n.textContent)!==String(v[1])){n.textContent=v[1];n.classList.remove('tnc-pop');void n.offsetWidth;n.classList.add('tnc-pop');}});
    }
  }
  function detectArrivals(rows) {
    var maxId = 0; rows.forEach(function (p) { var i2 = parseInt(p.id, 10); if (i2 > maxId) maxId = i2; });
    if (window.__tncMaxPid && maxId > window.__tncMaxPid) { window.__tncFresh = maxId; }
    window.__tncMaxPid = maxId;
  }
  function renderPromotedStrip() {
    var el = document.getElementById('tncPromoStrip'); if (!el) return;
    var rows = (listState.rows || []).slice().sort(function (a, b) { return parseInt(b.id, 10) - parseInt(a.id, 10); }).slice(0, 5);
    if (!rows.length) { el.innerHTML = ''; return; }
    var h = '<span style="font-size:10px;letter-spacing:1.2px;color:#34D399;font-weight:700">\u25cf JUST PROMOTED</span>';
    rows.forEach(function (p) {
      h += '<span style="font-size:12px;padding:3px 9px;border:1px solid rgba(124,92,252,.35);border-radius:999px;background:rgba(16,18,31,.8)">' + esc(p.company_name || '') + ' <span class="tnc-muted">' + ago(p.created_at, p.added_ts) + '</span></span>';
    });
    el.innerHTML = h;
    if (window.__tncFresh) { el.style.boxShadow = '0 0 18px rgba(52,211,153,.45)'; setTimeout(function () { el.style.boxShadow = 'none'; }, 1000); window.__tncFresh = 0; }
  }
  function drawList() {
    renderPStats();
    renderPromotedStrip();
    var el = document.getElementById('tncList');
    if (!el) return;
    var list = listState.rows.slice();
    var k = listState.sort, d = listState.dir;
    list.sort(function (a, b) {
      if (k === 'score') return (Number(a.score) - Number(b.score)) * d;
      return String(a[k] || '').localeCompare(String(b[k] || '')) * d;
    });
    (function (j) {
      if (!j.prospects.length) {
        el.innerHTML = '<div class="tnc-empty"><div class="big">✦</div>No prospects' + (listState.search || listState.status || listState.industry || listState.platform ? ' match your filters.' : ' yet.') + '<br><span class="tnc-muted">Click “+ New Prospect” to add one.</span></div>';
        return;
      }
      var rows = j.prospects.map(function (p) {
        return '<tr data-id="' + p.id + '" tabindex="0">' +
          '<td><div class="tnc-co">' + (isNew(p.created_at,p.added_ts)?'<span class="tnc-newb">NEW</span> ':'') + esc(p.company_name || '(no name)') + (p.email_ok ? ' <span title="' + esc(p.contact_email) + '" style="color:#34D399;font-size:11px">✉</span>' : ' <span title="no valid email" style="color:#FB7185;font-size:11px">✉</span>') + (p.contact_phone ? ' <span title="' + esc(p.contact_phone) + '" style="font-size:11px;opacity:.6">☎</span>' : '') + '</div><div class="tnc-url">' + esc(p.website_url) + '</div></td>' +
          '<td>' + esc(A.industries[p.industry] || p.industry) + '</td>' +
          '<td>' + (p.platform ? '<span class="tnc-pill plat">' + esc(p.platform) + '</span>' : '<span class="tnc-muted">—</span>') + '</td>' +
          '<td>' + pill(p.status) + '</td>' +
          '<td><span class="tnc-score ' + scoreCls(p.score) + '">' + p.score + '</span></td>' +
          '<td class="tnc-muted" style="font-size:12px">' + ago(p.created_at,p.added_ts) + '</td></tr>';
      }).join('');
      var th = function (key, label) {
        var arrow = listState.sort === key ? '<span class="arrow">' + (listState.dir === -1 ? '▼' : '▲') + '</span>' : '';
        return '<th class="sortable" data-k="' + key + '">' + label + arrow + '</th>';
      };
      el.innerHTML = '<table class="tnc-table"><colgroup><col style="width:32%"><col style="width:17%"><col style="width:13%"><col style="width:15%"><col style="width:10%"><col style="width:13%"></colgroup><thead><tr>' + th('company_name', 'Company') + th('industry', 'Industry') + th('platform', 'Platform') + th('status', 'Status') + th('score', 'Score') + th('created_at', 'Added') + '</tr></thead><tbody>' + rows + '</tbody></table>';
      el.querySelectorAll('tbody tr').forEach(function (tr) {
        var go = function () { window.location.href = 'admin.php?page=tnc-prospects&prospect=' + tr.dataset.id; };
        tr.addEventListener('click', go);
        tr.addEventListener('keydown', function (e) { if (e.key === 'Enter') go(); });
      });
      el.querySelectorAll('th.sortable').forEach(function (h) {
        h.addEventListener('click', function () {
          var key = h.dataset.k;
          if (listState.sort === key) { listState.dir = -listState.dir; } else { listState.sort = key; listState.dir = key === 'score' ? -1 : 1; }
          drawList();
        });
      });
    })({ prospects: list });
  }

  function prospectModal(p) {
    var isNew = !p;
    p = p || { industry: 'other', status: 'new' };
    var ov = document.createElement('div');
    ov.className = 'tnc-overlay';
    ov.innerHTML = '<div class="tnc-modal"><h3>' + (isNew ? 'New Prospect' : 'Edit Prospect') + '</h3>' +
      '<div class="tnc-row2"><div class="tnc-field"><label>Company name</label><input type="text" id="pmName" value="' + esc(p.company_name || '') + '"></div>' +
      '<div class="tnc-field"><label>Website URL</label><input type="url" id="pmUrl" placeholder="https://…" value="' + esc(p.website_url || '') + '"></div></div>' +
      '<div class="tnc-row2"><div class="tnc-field"><label>Industry / niche</label><select id="pmInd">' + options(A.industries, p.industry) + '</select></div>' +
      '<div class="tnc-field"><label>Status</label><select id="pmStatus">' + options(A.statuses, p.status) + '</select></div></div>' +
      '<div class="tnc-row2"><div class="tnc-field"><label>Contact name</label><input type="text" id="pmCName" value="' + esc(p.contact_name || '') + '"></div>' +
      '<div class="tnc-field"><label>Contact email</label><input type="email" id="pmCEmail" value="' + esc(p.contact_email || '') + '"></div></div>' +
      '<div class="tnc-field"><label>Contact phone</label><input type="tel" id="pmCPhone" value="' + esc(p.contact_phone || '') + '"></div>' +
      '<div class="tnc-field"><label>Notes</label><textarea id="pmNotes">' + esc(p.notes || '') + '</textarea></div>' +
      '<div class="foot"><button class="tnc-btn ghost" id="pmCancel">Cancel</button><button class="tnc-btn" id="pmSave">' + (isNew ? 'Create Prospect' : 'Save Changes') + '</button></div></div>';
    document.body.appendChild(ov);
    ov.querySelector('#pmName').focus();
    ov.addEventListener('click', function (e) { if (e.target === ov) ov.remove(); });
    ov.querySelector('#pmCancel').addEventListener('click', function () { ov.remove(); });
    ov.querySelector('#pmSave').addEventListener('click', function () {
      var btn = this;
      var body = {
        company_name: ov.querySelector('#pmName').value,
        website_url: ov.querySelector('#pmUrl').value,
        industry: ov.querySelector('#pmInd').value,
        status: ov.querySelector('#pmStatus').value,
        contact_name: ov.querySelector('#pmCName').value,
        contact_email: ov.querySelector('#pmCEmail').value,
        contact_phone: ov.querySelector('#pmCPhone').value,
        notes: ov.querySelector('#pmNotes').value
      };
      spin(btn, true, 'Saving…');
      var req = isNew ? api('/admin/prospects', 'POST', body) : api('/admin/prospects/' + p.id, 'POST', body);
      req.then(function (j) {
        ov.remove();
        toast(isNew ? 'Prospect created' : 'Saved');
        if (isNew) { window.location.href = 'admin.php?page=tnc-prospects&prospect=' + j.id; }
        else { loadDetail(p.id); }
      }).catch(function (e) { spin(btn, false); toast(e.message, true); });
    });
  }

  /* ---------- Prospect detail ---------- */
  var det = { p: null, tab: 'overview', kbSearch: '', kbType: '', kitMode: '' };
  var formDirty = false; // true while a form holds unsaved edits — pollers must NEVER clobber it.

  function progHtml(p) {
    var pct = crawlPct(p);
    return '<div class="tnc-prog"><i style="width:' + (pct ? pct.split('%')[0] : 5) + '%"></i></div>' +
      '<div class="tnc-muted" style="font-size:12px;margin-top:4px">Deep crawl ' + (pct || 'starting…') +
      (p.crawl_stalled ? ' · <b style="color:#FB7185">stalled</b>' : '') + '</div>';
  }
  function decisionHtml(p) {
    var n = (p.crawl_progress && p.crawl_progress.total) ? p.crawl_progress.total : '500+';
    return '<div class="tnc-decide" id="tncDecide"><b>⚠ Big site:</b> the sitemap lists ~' + esc(String(n)) + ' pages — more than the 500-page cap. How should we crawl it?' +
      '<div class="btns"><button class="tnc-btn sm" data-c="top500">Crawl top 500</button>' +
      '<button class="tnc-btn ghost sm" data-c="all">Crawl all ' + esc(String(n)) + '</button>' +
      '<button class="tnc-btn danger sm" data-c="cancel">Cancel</button></div></div>';
  }

  function renderDetailShell() {
    shell('<a class="tnc-back" href="admin.php?page=tnc-prospects">← All prospects</a><div id="tncDetail">' + skeletons(3, 'tnc-skel-block') + '</div>');
  }

  function loadDetail(id) {
    api('/admin/prospects/' + id).then(function (j) {
      det.p = j.prospect;
      drawDetail();
    }).catch(function (e) { toast(e.message, true); });
  }

  function drawDetail() {
    var p = det.p;
    var el = document.getElementById('tncDetail');
    if (!el || !p) return;
    formDirty = false; // fresh render mirrors the server — nothing unsaved.
    var crawling = p.crawl_state === 'running' || p.crawl_state === 'queued';
    var tabs = [['overview', 'Overview'], ['kb', 'Knowledge Base'], ['widget', 'Widget'], ['outreach', 'Outreach Kit'], ['leads', 'Leads (' + (p.leads || []).length + ')']];
    var head =
      '<div style="display:flex;align-items:flex-start;gap:20px;flex-wrap:wrap">' +
      '<div style="flex:1;min-width:260px"><h1 class="tnc-h1">' + esc(p.company_name || '(no name)') + '</h1>' +
      '<p class="tnc-sub" style="margin-bottom:12px">' + esc(p.website_url) + '</p>' +
      '<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">' + pill(p.status) +
      (p.platform ? '<span class="tnc-pill plat">' + esc(p.platform) + '</span>' : '') +
      '<span class="tnc-score ' + scoreCls(p.score) + '">Score ' + p.score + '</span>' +
      '<span class="tnc-pill plat">' + esc(A.industries[p.industry] || p.industry) + '</span></div>' +
      (crawling ? '<div style="max-width:340px" id="tncHeadProg">' + progHtml(p) + '</div>' : '') +
      (p.crawl_state === 'decision' ? decisionHtml(p) : '') +
      '</div>' +
      '<div style="display:flex;gap:10px;flex-wrap:wrap">' +
      (crawling
        ? '<button class="tnc-btn" disabled><span class="tnc-spin"></span> Crawling…</button>' +
          (p.crawl_stalled ? '<button class="tnc-btn ghost" id="dResume">⟳ Resume crawl</button>' : '')
        : '<button class="tnc-btn" id="dCrawl">' + (p.crawl_summary ? '↻ Re-crawl' : 'Crawl Website') + '</button>' +
          '<button class="tnc-btn ghost" id="dCrawlFull" title="Full-site sitemap crawl, batched in the background (cap 500 pages)">Deep Crawl</button>') +
      (p.demo_url && p.crawl_summary ? '<a class="tnc-btn ghost" href="' + esc(p.demo_url) + '" target="_blank">Open Demo ↗</a><button class="tnc-btn ghost" id="dCopyDemo">Copy Link</button>' : '') +
      '<button class="tnc-btn ghost" id="dEdit">Edit</button>' +
      '<button class="tnc-btn danger" id="dDel">Delete</button></div></div>' +
      '<div class="tnc-dtabs">' + tabs.map(function (t) {
        return '<button data-t="' + t[0] + '" class="' + (det.tab === t[0] ? 'on' : '') + '">' + t[1] + '</button>';
      }).join('') + '</div><div id="tncTabBody"></div>';
    el.innerHTML = head;

    el.querySelectorAll('.tnc-dtabs button').forEach(function (b) {
      b.addEventListener('click', function () { det.tab = b.dataset.t; drawDetail(); });
    });
    el.querySelector('#dEdit').addEventListener('click', function () { prospectModal(p); });
    var tbDel = el.querySelector('#tncTabBody');
    if (tbDel) ['input', 'change'].forEach(function (evt) {
      tbDel.addEventListener(evt, function (e) {
        var tg = e.target && e.target.tagName;
        if (tg === 'INPUT' || tg === 'SELECT' || tg === 'TEXTAREA') formDirty = true;
      });
    });
    var resBtn = el.querySelector('#dResume');
    if (resBtn) resBtn.addEventListener('click', function () {
      spin(resBtn, true, 'Resuming…');
      api('/admin/prospects/' + p.id + '/crawl-resume', 'POST').then(function (j) {
        j.prospect.leads = p.leads;
        det.p = j.prospect;
        toast('Crawl resumed — worker respawned');
        drawDetail();
      }).catch(function (e) { spin(resBtn, false); toast(e.message, true); });
    });
    var dec = el.querySelector('#tncDecide');
    if (dec) dec.querySelectorAll('button[data-c]').forEach(function (b) {
      b.addEventListener('click', function () {
        spin(b, true, 'Working…');
        api('/admin/prospects/' + p.id + '/crawl-decision', 'POST', { choice: b.dataset.c }).then(function (j) {
          j.prospect.leads = p.leads;
          det.p = j.prospect;
          toast(b.dataset.c === 'cancel' ? 'Deep crawl cancelled' : 'Deep crawl started');
          drawDetail();
        }).catch(function (e) { spin(b, false); toast(e.message, true); });
      });
    });
    el.querySelector('#dDel').addEventListener('click', function () {
      if (!window.confirm('Delete this prospect, its knowledge base, demo and leads?')) return;
      api('/admin/prospects/' + p.id, 'DELETE').then(function () {
        window.location.href = 'admin.php?page=tnc-prospects';
      }).catch(function (e) { toast(e.message, true); });
    });
    var copyBtn = el.querySelector('#dCopyDemo');
    if (copyBtn) copyBtn.addEventListener('click', function () { copyText(p.demo_url, copyBtn); });

    var crawlBtn = el.querySelector('#dCrawl');
    if (crawlBtn) {
      crawlBtn.addEventListener('click', function () {
        var btn = this;
        spin(btn, true, 'Crawling site… (up to a minute)');
        api('/admin/prospects/' + p.id + '/crawl', 'POST', { profile: 'demo' }).then(function (j) {
          det.p = j.prospect;
          det.p.leads = p.leads;
          toast('Crawl complete — ' + (j.prospect.crawl_summary ? j.prospect.crawl_summary.page_count : 0) + ' pages analyzed');
          loadDetail(p.id);
        }).catch(function (e) { spin(btn, false); toast(e.message, true); });
      });
    }
    var fullBtn = el.querySelector('#dCrawlFull');
    if (fullBtn) {
      fullBtn.addEventListener('click', function () {
        var btn = this;
        spin(btn, true, 'Queuing deep crawl…');
        api('/admin/prospects/' + p.id + '/crawl', 'POST', { profile: 'full' }).then(function (j) {
          det.p = j.prospect;
          det.p.leads = p.leads;
          toast('Deep crawl running in the background');
          drawDetail();
        }).catch(function (e) { spin(btn, false); toast(e.message, true); });
      });
    }
    if (crawling) {
      clearTimeout(window.tncPoll);
      var pollOnce = function () {
        api('/admin/prospects/' + p.id).then(function (j) {
          j.prospect.leads = j.prospect.leads || p.leads;
          var nowDone = j.prospect.crawl_state === 'done';
          det.p = j.prospect;
          if (nowDone) {
            toast('Deep crawl complete — knowledge base updated');
            if (formDirty) { // never clobber unsaved edits, even on completion.
              var hp0 = document.getElementById('tncHeadProg');
              if (hp0) hp0.innerHTML = '<div class="tnc-muted" style="font-size:12px">✓ Crawl complete — save your edits, then the page refreshes.</div>';
            } else {
              drawDetail();
            }
            return;
          }
          if (formDirty || det.tab === 'widget' || det.tab === 'outreach' || det.tab === 'kb') {
            // Form tabs: patch ONLY the header progress in place — the form is sacred.
            var hp = document.getElementById('tncHeadProg');
            if (hp) hp.innerHTML = progHtml(j.prospect);
            window.tncPoll = setTimeout(pollOnce, 5000);
          } else {
            drawDetail(); // read-only tabs: full live re-render is safe (re-arms this poll).
          }
        }).catch(function () { window.tncPoll = setTimeout(pollOnce, 8000); });
      };
      window.tncPoll = setTimeout(pollOnce, 4000);
    }

    if (det.tab === 'overview') drawOverview();
    if (det.tab === 'kb') drawKB();
    if (det.tab === 'widget') drawWidget();
    if (det.tab === 'outreach') drawOutreach();
    if (det.tab === 'leads') drawLeads();
  }

  function drawOverview() {
    var p = det.p, cs = p.crawl_summary, el = document.getElementById('tncTabBody');
    var left = '<div class="tnc-card"><h3>Contact</h3>' +
      '<div class="tnc-kv"><span class="k">Name</span><span class="v">' + esc(p.contact_name || '—') + '</span></div>' +
      '<div class="tnc-kv"><span class="k">Email</span><span class="v">' + esc(p.contact_email || '—') + '</span></div>' +
      '<div class="tnc-kv"><span class="k">Phone</span><span class="v">' + esc(p.contact_phone || '—') + '</span></div>' +
      '<div class="tnc-kv"><span class="k">Notes</span><span class="v">' + esc(p.notes || '—') + '</span></div></div>';

    var bd = (p.score_breakdown || []);
    left += '<div class="tnc-card tnc-mt"><h3>Prospect score — ' + p.score + '/100</h3><div class="hint">Why this prospect is worth your time</div>' +
      (bd.length ? bd.map(function (b) {
        return '<div class="tnc-bd"><span>' + esc(b.label) + '</span><span class="pts">+' + b.points + '</span></div>';
      }).join('') : '<div class="tnc-muted">Crawl the website to compute the score.</div>') + '</div>';

    var right;
    if (cs) {
      var ex = cs.extracted || {};
      right = '<div class="tnc-card"><h3>Website intelligence</h3><div class="hint">Crawled ' + cs.page_count + ' pages · ' + esc(cs.crawled_at) + (cs.errors && cs.errors.length ? ' · ' + cs.errors.length + ' page errors' : '') + '</div>' +
        '<div class="tnc-kv"><span class="k">Platform</span><span class="v" style="text-transform:capitalize">' + esc(cs.platform) + '</span></div>' +
        '<div class="tnc-kv"><span class="k">Existing chat</span><span class="v">' + esc(ex.chat_widget || 'None found in code') + ' <span class="tnc-muted">[' + esc(ex.chat_confidence || 'needs_review') + ']</span></span></div>' +
        '<div class="tnc-kv"><span class="k">Verify chat</span><span class="v"><button class="tnc-btn ghost sm" id="vChatYes">Mark present</button> <button class="tnc-btn ghost sm" id="vChatNo">Mark absent</button></span></div>' +
        '<div class="tnc-kv"><span class="k">Services found</span><span class="v">' + esc((ex.services || []).slice(0, 6).join(', ') || '—') + '</span></div>' +
        '<div class="tnc-kv"><span class="k">Phones</span><span class="v">' + esc((ex.phones || []).join(', ') || '—') + '</span></div>' +
        '<div class="tnc-kv"><span class="k">Emails</span><span class="v">' + esc((ex.emails || []).join(', ') || '—') + '</span></div>' +
        '<div class="tnc-kv"><span class="k">Locations</span><span class="v">' + esc((ex.locations || []).join(' | ') || '—') + '</span></div>' +
        '<div class="tnc-kv"><span class="k">Forms</span><span class="v">' + (ex.forms_present ? 'Yes' : 'No') + '</span></div>' +
        '<div class="tnc-kv"><span class="k">Trust signals</span><span class="v">' + esc((ex.trust_signals || []).join(', ') || '—') + '</span></div>' +
        '<div class="tnc-kv"><span class="k">Pixels</span><span class="v">' + esc((ex.pixels || []).join(', ') || 'None') + '</span></div>' +
        '<div class="tnc-kv"><span class="k">FAQs found</span><span class="v">' + ((ex.faqs || []).length) + '</span></div></div>';
      if (p.demo_url) {
        right += '<div class="tnc-card tnc-mt"><h3>Private demo</h3><div class="hint">Send this unguessable link to the prospect</div>' +
          '<code class="tnc-code" style="word-break:break-all;display:block;padding:10px 14px">' + esc(p.demo_url) + '</code>' +
          '<div class="tnc-mt" style="display:flex;gap:12px"><a class="tnc-btn" target="_blank" href="' + esc(p.demo_url) + '">Open Demo ↗</a>' +
          '<button class="tnc-btn ghost" id="ovCopy">Copy Link</button></div></div>';
      }
    } else {
      right = '<div class="tnc-card"><div class="tnc-empty"><div class="big">🕸</div>Not crawled yet.<br><span class="tnc-muted">Click “Crawl Website” to analyze the site, build the knowledge base and create the demo page.</span></div></div>';
    }
    var trail = (p.audit_trail || []);
    if (trail.length) {
      right += '<div class="tnc-card tnc-mt"><h3>Audit trail</h3><div class="hint">Every finding · method · confidence · time</div>' +
        trail.slice(-10).reverse().map(function (t) {
          return '<div class="tnc-kv"><span class="k" style="font-size:11px">' + esc(t.ts) + '</span><span class="v" style="font-size:12.5px">' + esc(t.finding) + ' <span class="tnc-muted">(' + esc(t.method) + ' · ' + esc(t.confidence) + ')</span></span></div>';
        }).join('') + '</div>';
    }
    el.innerHTML = '<div class="tnc-grid2"><div>' + left + '</div><div>' + right + '</div></div>';
    var oc = el.querySelector('#ovCopy');
    if (oc) oc.addEventListener('click', function () { copyText(p.demo_url, oc); });
    var vy = el.querySelector('#vChatYes'), vn = el.querySelector('#vChatNo');
    var verify = function (present) {
      var provider = present ? (window.prompt('Provider name (e.g. Intercom, Custom chat widget):', 'Custom chat widget') || '') : '';
      if (present && !provider) return;
      var note = window.prompt('How was this confirmed? (e.g. visually checked the live site)', 'Visually verified on the live site') || '';
      api('/admin/prospects/' + p.id + '/verify-chat', 'POST', { present: present ? 1 : 0, provider: provider, note: note }).then(function (j) {
        j.prospect.leads = p.leads;
        det.p = j.prospect;
        toast('Verification recorded — score recalculated');
        drawDetail();
      }).catch(function (e) { toast(e.message, true); });
    };
    if (vy) vy.addEventListener('click', function () { verify(true); });
    if (vn) vn.addEventListener('click', function () { verify(false); });
  }

  /* ---------- KB tab ---------- */
  function drawKB() {
    var p = det.p, el = document.getElementById('tncTabBody');
    el.innerHTML =
      '<div class="tnc-grid2"><div class="tnc-stack">' +
      '<div class="tnc-card"><h3>Add knowledge</h3><div class="hint">Paste anything the assistant should know (chunked automatically)</div>' +
      '<div class="tnc-field"><label>Title (optional)</label><input type="text" id="kbTitle" placeholder="e.g. Insurance policy details"></div>' +
      '<div class="tnc-field"><label>Text</label><textarea id="kbText" placeholder="Paste text…"></textarea></div>' +
      '<div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap"><button class="tnc-btn" id="kbAdd">Add to Knowledge Base</button>' +
      '<label class="tnc-btn ghost" style="cursor:pointer">Upload .txt<input type="file" id="kbFile" accept=".txt,text/plain" style="display:none"></label>' +
      '<span class="tnc-muted" style="font-size:12px">PDF/DOCX extraction — Phase 1.5</span></div></div>' +
      '<div class="tnc-card"><h3>Add Q&amp;A pair</h3><div class="hint">Approved answers take precedence over everything else</div>' +
      '<div class="tnc-field"><label>Question</label><input type="text" id="qaQ" placeholder="e.g. Do you offer free consultations?"></div>' +
      '<div class="tnc-field"><label>Approved answer</label><textarea id="qaA" placeholder="The exact answer the assistant should give…"></textarea></div>' +
      '<button class="tnc-btn" id="qaAdd">Add Q&amp;A</button></div></div>' +
      '<div><div class="tnc-card"><h3>Knowledge chunks</h3><div class="hint">What the assistant knows about ' + esc(p.company_name || 'this prospect') + '</div>' +
      '<div class="tnc-toolbar" style="margin-bottom:12px"><input type="text" id="kbSearch" placeholder="Search chunks…" value="' + esc(det.kbSearch) + '">' +
      '<select id="kbType" style="min-width:128px"><option value="">All types</option>' +
      ['basics', 'crawl', 'pricing', 'manual', 'qa', 'file'].map(function (t) { return '<option value="' + t + '"' + (det.kbType === t ? ' selected' : '') + '>' + t + '</option>'; }).join('') +
      '</select></div><div id="kbList">' + skeletons(3, 'tnc-skel-block') + '</div></div></div></div>';

    el.querySelector('#kbAdd').addEventListener('click', function () {
      var btn = this, txt = el.querySelector('#kbText').value.trim();
      if (!txt) { toast('Paste some text first', true); return; }
      spin(btn, true, 'Adding…');
      api('/admin/prospects/' + p.id + '/kb', 'POST', { chunk_type: 'manual', title: el.querySelector('#kbTitle').value, content: txt })
        .then(function () { spin(btn, false); el.querySelector('#kbText').value = ''; el.querySelector('#kbTitle').value = ''; toast('Knowledge added'); loadKB(); })
        .catch(function (e) { spin(btn, false); toast(e.message, true); });
    });
    el.querySelector('#qaAdd').addEventListener('click', function () {
      var btn = this, q = el.querySelector('#qaQ').value.trim(), a = el.querySelector('#qaA').value.trim();
      if (!q || !a) { toast('Both question and answer are required', true); return; }
      spin(btn, true, 'Adding…');
      api('/admin/prospects/' + p.id + '/kb', 'POST', { chunk_type: 'qa', question: q, content: a, title: 'Q&A' })
        .then(function () { spin(btn, false); el.querySelector('#qaQ').value = ''; el.querySelector('#qaA').value = ''; toast('Q&A added'); loadKB(); })
        .catch(function (e) { spin(btn, false); toast(e.message, true); });
    });
    el.querySelector('#kbFile').addEventListener('change', function (e) {
      var f = e.target.files[0];
      if (!f) return;
      if (f.size > 1024 * 1024) { toast('File too large (max 1 MB)', true); return; }
      var reader = new FileReader();
      reader.onload = function () {
        api('/admin/prospects/' + p.id + '/kb', 'POST', { chunk_type: 'file', title: f.name, content: String(reader.result) })
          .then(function () { toast('File ingested'); loadKB(); })
          .catch(function (er) { toast(er.message, true); });
      };
      reader.readAsText(f);
      e.target.value = '';
    });
    var deb;
    el.querySelector('#kbSearch').addEventListener('input', function (e) {
      clearTimeout(deb);
      deb = setTimeout(function () { det.kbSearch = e.target.value; loadKB(); }, 350);
    });
    el.querySelector('#kbType').addEventListener('change', function (e) { det.kbType = e.target.value; loadKB(); });
    loadKB();
  }

  function loadKB() {
    var p = det.p;
    api('/admin/prospects/' + p.id + '/kb?search=' + encodeURIComponent(det.kbSearch) + '&type=' + encodeURIComponent(det.kbType)).then(function (j) {
      var list = document.getElementById('kbList');
      if (!list) return;
      if (!j.chunks.length) {
        list.innerHTML = '<div class="tnc-empty"><div class="big">⛁</div>No chunks yet.<br><span class="tnc-muted">Crawl the site or add knowledge manually.</span></div>';
        return;
      }
      list.innerHTML = '<div class="hint">' + j.chunks.length + ' chunks</div>' + j.chunks.map(function (c) {
        return '<div class="tnc-chunk' + (Number(c.enabled) ? '' : ' off') + '" data-id="' + c.id + '">' +
          '<div class="head"><span class="tnc-tag ' + esc(c.chunk_type) + '">' + esc(c.chunk_type) + '</span>' +
          '<span class="title">' + esc(c.title || '(untitled)') + '</span>' +
          '<label class="tnc-switch" title="Include in retrieval"><input type="checkbox" class="ckEn" ' + (Number(c.enabled) ? 'checked' : '') + '><span></span></label>' +
          '<button class="tnc-btn ghost sm ckEdit">Edit</button><button class="tnc-btn danger sm ckDel">✕</button></div>' +
          (c.question ? '<div style="font-size:13px;font-weight:600;margin-bottom:4px">Q: ' + esc(c.question) + '</div>' : '') +
          '<div class="body" title="Click to expand">' + esc(c.content) + '</div>' +
          (c.source_url ? '<div class="src">⛓ ' + esc(c.source_url) + '</div>' : '') + '</div>';
      }).join('');
      list.querySelectorAll('.tnc-chunk').forEach(function (node) {
        var id = node.dataset.id;
        node.querySelector('.body').addEventListener('click', function () { this.classList.toggle('open'); });
        node.querySelector('.ckEn').addEventListener('change', function (e) {
          api('/admin/kb/' + id, 'POST', { enabled: e.target.checked ? 1 : 0 })
            .then(function () { node.classList.toggle('off', !e.target.checked); })
            .catch(function (er) { toast(er.message, true); });
        });
        node.querySelector('.ckDel').addEventListener('click', function () {
          if (!window.confirm('Delete this chunk?')) return;
          api('/admin/kb/' + id, 'DELETE').then(function () { node.remove(); }).catch(function (er) { toast(er.message, true); });
        });
        node.querySelector('.ckEdit').addEventListener('click', function () {
          var c = j.chunks.find(function (x) { return String(x.id) === String(id); });
          chunkModal(c);
        });
      });
    }).catch(function (e) { toast(e.message, true); });
  }

  function chunkModal(c) {
    var ov = document.createElement('div');
    ov.className = 'tnc-overlay';
    ov.innerHTML = '<div class="tnc-modal"><h3>Edit chunk</h3>' +
      '<div class="tnc-field"><label>Title</label><input type="text" id="cmTitle" value="' + esc(c.title) + '"></div>' +
      (c.chunk_type === 'qa' ? '<div class="tnc-field"><label>Question</label><input type="text" id="cmQ" value="' + esc(c.question || '') + '"></div>' : '') +
      '<div class="tnc-field"><label>Content</label><textarea id="cmBody" style="min-height:220px">' + esc(c.content) + '</textarea></div>' +
      '<div class="foot"><button class="tnc-btn ghost" id="cmCancel">Cancel</button><button class="tnc-btn" id="cmSave">Save</button></div></div>';
    document.body.appendChild(ov);
    ov.addEventListener('click', function (e) { if (e.target === ov) ov.remove(); });
    ov.querySelector('#cmCancel').addEventListener('click', function () { ov.remove(); });
    ov.querySelector('#cmSave').addEventListener('click', function () {
      var body = { title: ov.querySelector('#cmTitle').value, content: ov.querySelector('#cmBody').value };
      var qEl = ov.querySelector('#cmQ');
      if (qEl) body.question = qEl.value;
      api('/admin/kb/' + c.id, 'POST', body).then(function () { ov.remove(); toast('Chunk saved'); loadKB(); })
        .catch(function (e) { toast(e.message, true); });
    });
  }


  /* ---------- Widget tab (v1.3 modes/styles + v1.4 brand palette) ---------- */
  function ovColor(p, key) {
    return (p.theme_overrides && p.theme_overrides[key]) ? p.theme_overrides[key] : '';
  }
  function brandPaletteHtml(p, t) {
    var brand = (p.crawl_summary && p.crawl_summary.extracted && p.crawl_summary.extracted.brand) || {};
    var sw = function (hex, label) {
      if (!hex) return '';
      return '<span style="display:inline-flex;align-items:center;gap:7px;margin-right:16px;font-size:12px;color:var(--muted)">' +
        '<i style="width:18px;height:18px;border-radius:6px;background:' + esc(hex) + ';display:inline-block;border:1px solid rgba(255,255,255,.15)"></i>' + label + ' ' + esc(hex) + '</span>';
    };
    var inner = (brand.primary || brand.secondary)
      ? sw(brand.primary, 'primary') + sw(brand.secondary, 'secondary') + (brand.logo ? '<span style="font-size:12px;color:var(--muted)">logo ✓</span>' : '')
      : '<span style="font-size:12px;color:var(--muted)">None extracted yet — industry preset palette in use. Re-crawl to detect.</span>';
    return '<div class="tnc-field"><label>Extracted brand palette (auto-applied when usable)</label><div style="padding:10px 2px">' + inner + '</div></div>';
  }
  function drawWidget() {
    var p = det.p, el = document.getElementById('tncTabBody');
    var t = p.theme || {};
    var listVal = function (a) { return (a || []).join('\n'); };
    // VISUAL COLOR PICKER (spectrum + preset swatches + hex-on-click) — replaces raw hex boxes.
    var PRESET = ['#1759cf','#0d9dbf','#b11b48','#7C5CFC','#0a7b96','#c35528','#16a34a','#9333ea','#e11d48','#0f172a'];
    var toHex = function (v) { v = (v || '').trim(); if (/^#?[0-9a-fA-F]{6}$/.test(v)) { return v[0] === '#' ? v : '#' + v; } return ''; };
    var cfield = function (id, val, ph, label) {
      var hx = toHex(val) || toHex(ph) || '#1759cf'; var raw = (val || '');
      var sw = PRESET.map(function (c) { return '<i class="tnc-sw" data-for="' + id + '" data-c="' + c + '" title="' + c + '" style="background:' + c + ';width:19px;height:19px;border-radius:5px;display:inline-block;cursor:pointer;border:1px solid rgba(255,255,255,.28);margin-right:4px;vertical-align:middle"></i>'; }).join('');
      return '<div class="tnc-field"><label>' + label + '</label><div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">' +
        '<input type="color" id="' + id + '" value="' + hx + '" style="width:46px;height:32px;border:1px solid var(--line,#2a2a3a);border-radius:8px;background:none;cursor:pointer;padding:2px">' +
        '<span class="tnc-swrow">' + sw + '</span>' +
        '<button type="button" class="tnc-hexbtn" data-for="' + id + '" title="show/edit hex" style="background:rgba(124,92,252,.16);border:1px solid rgba(124,92,252,.5);color:#A78BFA;border-radius:7px;padding:4px 9px;font-size:12px;font-weight:700;cursor:pointer">#</button>' +
        '<input type="text" class="tnc-hex" id="' + id + '_hex" value="' + esc(raw) + '" placeholder="' + esc(ph || '') + '" style="display:none;width:96px">' +
      '</div></div>';
    };
    var curAnim = (function () { try { var o = (p && typeof p.theme_overrides === 'object') ? p.theme_overrides : JSON.parse(p.theme_overrides || '{}'); return o.launcher || 'ring'; } catch (e) { return 'ring'; } })();

    el.innerHTML =
      '<div class="tnc-grid2"><div class="tnc-card"><h3>Widget configuration</h3>' +
      '<div class="hint">Per-client display options — industry preset picks the defaults, everything here overrides them.</div>' +
      '<div class="tnc-row2">' +
      '<div class="tnc-field"><label>Widget mode</label><select id="wMode">' +
      '<option value="standard"' + (t.widget_mode === 'standard' ? ' selected' : '') + '>Standard — greeting + starter chips</option>' +
      '<option value="advanced"' + (t.widget_mode === 'advanced' ? ' selected' : '') + '>Advanced — persona + guided choices</option></select></div>' +
      '<div class="tnc-field"><label>Button style</label><select id="wStyle">' +
      '<option value="outline"' + (t.button_style === 'outline' ? ' selected' : '') + '>Outline — themed border chips</option>' +
      '<option value="solid"' + (t.button_style === 'solid' ? ' selected' : '') + '>Solid — filled pills</option></select></div></div>' +
      '<div class="tnc-row2">' +
      '<div class="tnc-field"><label>Agent display name</label><input type="text" id="wAgent" value="' + esc(t.agent_name || '') + '" placeholder="e.g. Michael"></div>' +
      '<div class="tnc-field"><label>Subtitle line</label><input type="text" id="wSub" value="' + esc(t.agent_subtitle || '') + '"></div></div>' +
      '<div class="tnc-row2">' +
      '<div class="tnc-field"><label>Section title</label><input type="text" id="wSect" value="' + esc(t.section_title || '') + '"></div>' +
      '<div class="tnc-field"><label>Agent avatar URL (optional)</label><input type="url" id="wAvatar" value="' + esc(t.agent_avatar || '') + '" placeholder="https://… (empty = branded mark)"></div></div>' +
      brandPaletteHtml(p, t) +
      '<div class="tnc-row2">' + cfield('wAccent', ovColor(p,'accent'), t.accent, 'Accent color') + cfield('wAccent2', ovColor(p,'accent2'), t.accent2, 'Accent 2 (gradient)') + '</div>' +
      '<div class="tnc-row2">' + cfield('wRing', ovColor(p,'ring'), t.ring || t.accent, 'Launcher ring color') +
      '<div class="tnc-field"><label>Launcher icon</label><select id="wIcon">' +
      ['gavel', 'fan', 'roof', 'tooth', 'lotus', 'profile', 'bag', 'spark'].map(function (k) { return '<option value="' + k + '"' + (t.icon === k ? ' selected' : '') + '>' + k + '</option>'; }).join('') +
      '</select></div></div>' +
      '<div class="tnc-row2"><div class="tnc-field"><label>Launcher animation</label><select id="wAnim">' +
      [['ring','Clockwise spinning ring (Lion Click)'],['glow','Glow / pulse halo'],['breathe','Breathe (gentle scale)'],['pulse','Pulse ring'],['bounce','Bounce'],['static','Static (no animation)']].map(function(o){ return '<option value="'+o[0]+'"'+((curAnim===o[0])?' selected':'')+'>'+o[1]+'</option>'; }).join('') +
      '</select></div><div class="tnc-field"></div></div>' +
      '<div class="tnc-field"><label>Guided choices — advanced mode (one per line)</label><textarea id="wChoices" style="min-height:84px">' + esc(listVal(t.choices)) + '</textarea></div>' +
      '<div class="tnc-field"><label>Starter questions — standard mode (one per line)</label><textarea id="wStarters" style="min-height:84px">' + esc(listVal(t.starters)) + '</textarea></div>' +
      '<div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-bottom:14px"><button class="tnc-btn ghost" id="wRegen">✦ Regenerate with AI</button>' +
      (A.maskedKey ? '<span class="tnc-muted" style="font-size:12px">Grounded in their crawled services & FAQs</span>' : '<span class="tnc-muted" style="font-size:12px">Add your API key in Settings to activate AI generation — preset questions in use.</span>') + '</div>' +
      '<div class="hint" style="margin-top:4px">In advanced mode every AI reply carries the non-removable "· AI Agent ·" disclosure line.</div>' +
      '<button class="tnc-btn" id="wSave">Save Widget Settings</button></div>' +
      '<div class="tnc-card"><h3>Live preview</h3>' +
      '<div class="hint">Top = the REAL deployed demo widget (exact match, reloads on Save). Below = live unsaved tweaks.</div>' +
      (p.demo_url ? '<iframe id="wPrevFrame" src="' + esc(p.demo_url) + (p.demo_url.indexOf('?')>-1?'&':'?') + 'cb=' + Date.now() + '" style="width:100%;height:640px;border:1px solid var(--line,#2a2a3a);border-radius:12px;background:#0b0d14"></iframe>' : '<div id="wPrev"></div>') +
      '</div></div>';

    var read = function () {
      var lines = function (id) {
        return document.getElementById(id).value.split('\n').map(function (x) { return x.trim(); }).filter(Boolean).slice(0, 6);
      };
      return {
        widget_mode: document.getElementById('wMode').value,
        button_style: document.getElementById('wStyle').value,
        agent_name: document.getElementById('wAgent').value.trim(),
        agent_subtitle: document.getElementById('wSub').value.trim(),
        section_title: document.getElementById('wSect').value.trim(),
        agent_avatar: document.getElementById('wAvatar').value.trim(),
        accent: document.getElementById('wAccent').value.trim(),
        accent2: document.getElementById('wAccent2').value.trim(),
        ring: document.getElementById('wRing').value.trim(),
        icon: document.getElementById('wIcon').value,
        launcher: (document.getElementById('wAnim')||{}).value || 'ring',
        choices: lines('wChoices'),
        starters: lines('wStarters')
      };
    };

    var paint = function () {
      var v = read();
      var prev = document.getElementById('wPrev');
      if (!prev) { return; } // single real-widget iframe preview is the source of truth.
      var acc = v.accent || t.accent || '#7C3AED', acc2 = v.accent2 || t.accent2 || '#E879F9';
      var solid = v.button_style === 'solid';
      var chip = function (txt, rightAligned) {
        var st = solid
          ? 'background:linear-gradient(135deg,' + esc(acc) + ',' + esc(acc2) + ');color:#fff;border:none'
          : 'background:transparent;color:var(--text);border:1.5px solid ' + esc(acc);
        return '<div class="wp-chip" style="' + st + '">' + esc(txt) + '</div>';
      };
      var html;
      if (v.widget_mode === 'advanced') {
        var av = v.agent_avatar
          ? '<img class="wp-av" src="' + esc(v.agent_avatar) + '" alt="">'
          : '<div class="wp-av" style="background:linear-gradient(135deg,' + esc(acc) + ',' + esc(acc2) + ')">✦</div>';
        html = '<div class="tnc-wprev"><div class="wp-head adv"><span class="wp-ic l">‹</span>' + av +
          '<div class="wp-t">' + esc(v.agent_name || 'Agent') + '</div><div class="wp-s">' + esc(v.agent_subtitle) + '</div>' +
          '<span class="wp-ic r">✕</span></div><div class="wp-body">' +
          '<div class="wp-sect">' + esc(v.section_title || 'How can we help you?') + '</div>' +
          '<div class="wp-choices">' + v.choices.map(function (c) { return chip(c, true); }).join('') + '</div>' +
          '<div class="wp-bot">Sample answer from the knowledge base…<div class="wp-attr">' + esc(v.agent_name || 'Agent') + ' · AI Agent · just now</div></div>' +
          '</div><div class="wp-input">Ask anything…</div></div>';
      } else {
        html = '<div class="tnc-wprev"><div class="wp-head">' +
          '<div class="wp-av" style="background:linear-gradient(135deg,' + esc(acc) + ',' + esc(acc2) + ')">✦</div>' +
          '<div><div class="wp-t">' + esc(p.company_name || 'Company') + ' ' + esc(t.widget_name || 'Assistant') + '</div>' +
          '<div class="wp-s" style="color:#34D399">● Online — answers from your website</div></div></div><div class="wp-body">' +
          '<div class="wp-bot">' + esc((t.greeting || 'Hi! How can I help?').slice(0, 120)) + '</div>' +
          '<div class="wp-chips-std">' + v.starters.slice(0, 4).map(function (c) { return chip(c, false); }).join('') + '</div>' +
          '</div><div class="wp-input">Ask anything…</div></div>';
      }
      prev.innerHTML = html;
    };

    ['wMode', 'wStyle', 'wAgent', 'wSub', 'wSect', 'wAvatar', 'wAccent', 'wAccent2', 'wRing', 'wIcon', 'wAnim', 'wChoices', 'wStarters'].forEach(function (id) {
      var e = document.getElementById(id); if (!e) return;
      e.addEventListener('input', paint); e.addEventListener('change', paint);
    });
    // Swatch click -> set the color input; hex button -> reveal/edit hex; hex input -> sync.
    document.querySelectorAll('.tnc-sw').forEach(function (sw) {
      sw.addEventListener('click', function () { var ci = document.getElementById(sw.dataset.for); if (ci) { ci.value = sw.dataset.c; var hx = document.getElementById(sw.dataset.for + '_hex'); if (hx) hx.value = sw.dataset.c; paint(); } });
    });
    document.querySelectorAll('.tnc-hexbtn').forEach(function (b) {
      b.addEventListener('click', function () { var hx = document.getElementById(b.dataset.for + '_hex'); if (hx) { hx.style.display = hx.style.display === 'none' ? '' : 'none'; if (hx.style.display !== 'none') hx.focus(); } });
    });
    document.querySelectorAll('.tnc-hex').forEach(function (hx) {
      hx.addEventListener('input', function () { var v = hx.value.trim(); if (/^#?[0-9a-fA-F]{6}$/.test(v)) { var ci = document.getElementById(hx.id.replace('_hex','')); if (ci) { ci.value = v[0] === '#' ? v : '#' + v; paint(); } } });
    });
    paint();

    document.getElementById('wRegen').addEventListener('click', function () {
      var btn = this;
      spin(btn, true, 'Generating from their site…');
      api('/admin/prospects/' + p.id + '/starters', 'POST').then(function (j) {
        spin(btn, false);
        if (j.starters) document.getElementById('wStarters').value = j.starters.join('\n');
        if (j.choices && j.choices.length) document.getElementById('wChoices').value = j.choices.join('\n');
        paint();
        toast('Smart questions generated & saved');
      }).catch(function (e) { spin(btn, false); toast(e.message, true); });
    });

    document.getElementById('wSave').addEventListener('click', function () {
      var btn = this;
      spin(btn, true, 'Saving…');
      api('/admin/prospects/' + p.id, 'POST', { theme_overrides: JSON.stringify(read()) }).then(function (j) {
        spin(btn, false);
        j.prospect.leads = p.leads;
        det.p = j.prospect;
        toast('Widget settings saved — the demo updates instantly');
        drawDetail();
        setTimeout(function(){ var fr=document.getElementById('wPrevFrame'); if(fr){ var base=fr.src.split('cb=')[0]; fr.src=base+'cb='+Date.now(); } }, 400);
      }).catch(function (e) { spin(btn, false); toast(e.message, true); });
    });
  }

  /* ---------- Outreach tab ---------- */
  function drawOutreach() {
    var p = det.p, el = document.getElementById('tncTabBody');
    var kit = p.outreach_json;
    var blocks = [
      ['cold_email', 'Cold email'],
      ['follow_up_email', 'Follow-up email'],
      ['linkedin_message', 'LinkedIn message (short)'],
      ['audit_text', 'Website audit']
    ];
    var mode = det.kitMode || (kit && kit.mode === 'ai' ? 'ai' : 'template');
    det.kitMode = mode;
    var modeBadge = kit ? (kit.mode === 'ai' ? ' · ✨ AI-generated' : ' · ⚡ template engine') : '';
    var inner = '<div class="tnc-card"><div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:8px">' +
      '<div style="flex:1"><h3>Outreach kit</h3><div class="hint">' + (kit ? 'Generated ' + esc(kit.generated_at || '') + esc(modeBadge) + ' — edit freely, then copy.' : 'Built from the crawl data. Crawl first, then generate.') + '</div></div>' +
      '<div class="tnc-kitmode"><button id="okFree" class="' + (mode === 'template' ? 'on' : '') + '">⚡ Free templates</button>' +
      '<button id="okAI" class="' + (mode === 'ai' ? 'on' : '') + '">✨ AI-generated</button></div>' +
      '<span class="tnc-muted" style="font-size:11px">' + (mode === 'ai' ? 'Uses AI credits' : 'Zero AI cost') + '</span>' +
      '<button class="tnc-btn" id="okGen">' + (kit ? '↻ Regenerate' : (mode === 'ai' ? '✦ Generate with AI' : '⚡ Generate Kit (free)')) + '</button>' +
      (kit ? '<button class="tnc-btn ghost" id="okSave">Save Edits</button>' : '') + '</div>';
    if (kit) {
      inner += blocks.map(function (b) {
        return '<div class="tnc-out-block"><div class="bar"><h4>' + b[1] + '</h4><button class="tnc-btn ghost sm okCopy" data-k="' + b[0] + '">Copy</button></div>' +
          '<textarea data-k="' + b[0] + '">' + esc(kit[b[0]] || '') + '</textarea></div>';
      }).join('');
    } else {
      inner += '<div class="tnc-empty"><div class="big">✉️</div>No kit yet.' + (p.crawl_summary ? '' : '<br><span class="tnc-muted">Crawl the website first.</span>') + '</div>';
    }
    inner += '</div>';
    el.innerHTML = inner;

    el.querySelector('#okFree').addEventListener('click', function () { det.kitMode = 'template'; drawOutreach(); });
    el.querySelector('#okAI').addEventListener('click', function () { det.kitMode = 'ai'; drawOutreach(); });
    el.querySelector('#okGen').addEventListener('click', function () {
      var btn = this;
      spin(btn, true, det.kitMode === 'ai' ? 'Writing with AI…' : 'Merging templates…');
      api('/admin/prospects/' + p.id + '/outreach', 'POST', { mode: det.kitMode }).then(function (j) {
        det.p.outreach_json = j.kit;
        toast('Outreach kit generated');
        drawDetail();
      }).catch(function (e) { spin(btn, false); toast(e.message, true); });
    });
    var saveBtn = el.querySelector('#okSave');
    if (saveBtn) saveBtn.addEventListener('click', function () {
      var btn = this, body = {};
      el.querySelectorAll('textarea[data-k]').forEach(function (t) { body[t.dataset.k] = t.value; });
      spin(btn, true, 'Saving…');
      api('/admin/prospects/' + p.id + '/outreach-save', 'POST', body).then(function () {
        spin(btn, false);
        formDirty = false;
        Object.keys(body).forEach(function (k) { det.p.outreach_json[k] = body[k]; });
        toast('Edits saved');
      }).catch(function (e) { spin(btn, false); toast(e.message, true); });
    });
    el.querySelectorAll('.okCopy').forEach(function (b) {
      b.addEventListener('click', function () {
        var t = el.querySelector('textarea[data-k="' + b.dataset.k + '"]');
        copyText(t.value, b);
      });
    });
  }

  /* ---------- Leads tab ---------- */
  function drawLeads() {
    var p = det.p, el = document.getElementById('tncTabBody');
    var leads = p.leads || [];
    el.innerHTML = '<div class="tnc-card"><h3>Captured leads</h3><div class="hint">Submitted on the demo page for ' + esc(p.company_name || '') + '</div>' +
      (leads.length ? leads.map(function (l) {
        return '<div class="tnc-lead"><span class="who">' + esc(l.name || '(no name)') + '</span>' +
          '<div class="meta">' + esc([l.email, l.phone].filter(Boolean).join(' · ') || 'no contact info') + ' · ' + esc(l.created_at) + '</div>' +
          (l.message ? '<div style="font-size:13px;margin-top:4px">' + esc(l.message) + '</div>' : '') + '</div>';
      }).join('') : '<div class="tnc-empty"><div class="big">◎</div>No leads yet — share the demo link!</div>') + '</div>';
  }

  /* ---------- Settings ---------- */
  function renderSettings() {
    var s = A.settings || {};
    shell(
      '<span class="tnc-badge">Central Brain</span>' +
      '<h1 class="tnc-h1">Settings</h1><p class="tnc-sub">Keys live server-side and are never exposed to widgets or demo pages.</p>' +
      '<div class="tnc-grid2"><div class="tnc-stack">' +
      '<div class="tnc-card"><h3>AI engine</h3><div class="hint">Anthropic API — used for demo chats and outreach generation</div>' +
      '<div class="tnc-field"><label>API key ' + (A.maskedKey ? '<span class="tnc-copy-ok">(saved: ' + esc(A.maskedKey) + ')</span>' : '<span style="color:var(--bad)">(not set)</span>') + '</label>' +
      '<input type="password" id="sKey" placeholder="' + (A.maskedKey ? 'Enter a new key to replace' : 'sk-ant-…') + '" autocomplete="off"></div>' +
      '<div class="tnc-field"><label>Model</label><input type="text" id="sModel" value="' + esc(s.model || '') + '"></div>' +
      '<div class="tnc-field"><label>API endpoint base</label><input type="url" id="sEndpoint" value="' + esc(s.endpoint_base || '') + '"><div class="hint" style="margin-top:8px">Configurable for the future move to tuanilabs.com infrastructure.</div></div></div>' +
      '<div class="tnc-card"><h3>Crawler</h3><div class="hint">Demo crawls are fast &amp; prioritized; deep crawls run batched via WP-Cron (hard cap 500 pages)</div>' +
      '<div class="tnc-row2"><div class="tnc-field"><label>Demo crawl pages</label><input type="number" id="sMaxPages" value="' + esc(s.crawl_max_pages) + '" min="1" max="500"></div>' +
      '<div class="tnc-field"><label>Deep crawl pages</label><input type="number" id="sFullPages" value="' + esc(s.crawl_full_pages || 200) + '" min="10" max="500"></div></div>' +
      '<div class="tnc-row2"><div class="tnc-field"><label>Pages per cron batch</label><input type="number" id="sBatch" value="' + esc(s.crawl_batch_size || 6) + '" min="2" max="15"></div>' +
      '<div class="tnc-field"><label>Timeout / page (s)</label><input type="number" id="sTimeout" value="' + esc(s.crawl_timeout) + '" min="3" max="30"></div></div>' +
      '<div class="tnc-row2"><div class="tnc-field"><label>Parallel fetches (curl_multi)</label><input type="number" id="sConc" value="' + esc(s.crawl_concurrency || 6) + '" min="2" max="8"></div>' +
      '<div class="tnc-field"><label>Per-host politeness cap</label><input type="number" id="sPerHost" value="' + esc(s.crawl_per_host || 3) + '" min="1" max="4"></div></div>' +
      '<div class="tnc-field"><label>Concurrent crawl lanes (bulk)</label><input type="number" id="sLanes" value="' + esc(s.bulk_lanes || 2) + '" min="1" max="3"></div>' +
      '<div class="tnc-row2"><div class="tnc-field"><label>Chat rate limit (msgs / IP / 5 min)</label><input type="number" id="sRate" value="' + esc(s.chat_rate_limit) + '" min="3" max="200"></div>' +
      '<div class="tnc-field"><label>Bulk stagger (s between crawls)</label><input type="number" id="sStagger" value="' + esc(s.bulk_stagger || 150) + '" min="30" max="900"></div></div></div>' +
      '<div class="tnc-card"><h3>Cron heartbeat</h3><div class="hint">Run this command every minute via a system cron (DreamHost panel → Advanced → Cron Jobs). It keeps crawls, batches and workers moving with zero site traffic — and auto-resumes anything stalled.</div>' +
      '<code class="tnc-code" style="display:block;padding:10px 14px;word-break:break-all">' + esc('curl -s "' + (A.heartbeatUrl || '') + '" >/dev/null 2>&1') + '</code>' +
      '<div class="tnc-mt"><button class="tnc-btn ghost" id="sHbCopy">Copy command</button></div></div>' +
      '</div><div class="tnc-stack">' +
      '<div class="tnc-card"><h3>Demo pages</h3><div class="hint">CTA buttons shown on every private demo</div>' +
      '<div class="tnc-field"><label>"Activate This On My Website" URL</label><input type="url" id="sCta1" value="' + esc(s.cta_activate_url || '') + '" placeholder="https://… "><div class="hint" style="margin-top:8px">Will point to the Stripe pricing page (monthly/annual) in Phase 2.</div></div>' +
      '<div class="tnc-field"><label>"Book Setup Call" URL</label><input type="url" id="sCta2" value="' + esc(s.cta_call_url || '') + '" placeholder="https://…(calendar link)"></div>' +
      '<div class="tnc-field"><label>Sticky CTA urgency line</label><input type="text" id="sUrgency" value="' + esc(s.cta_urgency_text || 'Live within 24 hours') + '"></div>' +
      '<div class="tnc-row2"><div class="tnc-field"><label>Auto-open delay (seconds, 3–10)</label><input type="number" id="sAutoOpen" min="3" max="10" value="' + esc(s.demo_autoopen_secs || 6) + '"></div>' +
      '<div class="tnc-field"><label>Lead form helper line</label><input type="text" id="sHelper" value="' + esc(s.lead_form_helper || "Leave your details and we'll set it up for you — typically live within 24 hours.") + '"></div></div></div>' +
      '<div class="tnc-card"><h3>Outreach sender (test phase)</h3><div class="hint">Test end-to-end from a Lion Click sending subdomain, then repoint to tuanilabs.com with a config change. Separate from notification email.</div>' +
      '<div class="tnc-row2"><div class="tnc-field"><label>From name</label><input type="text" id="sOFName" value="' + esc(s.outreach_from_name || '') + '" placeholder="Michael at Lion Click"></div>' +
      '<div class="tnc-field"><label>From email</label><input type="email" id="sOFEmail" value="' + esc(s.outreach_from_email || '') + '" placeholder="michael@go.lionclickmedia.com"></div></div>' +
      '<div class="tnc-row2"><div class="tnc-field"><label>Sending domain</label><input type="text" id="sOFDomain" value="' + esc(s.outreach_from_domain || '') + '" placeholder="go.lionclickmedia.com"></div>' +
      '<div class="tnc-field"><label>Outreach identity</label><select id="sOIdent"><option value="tuanichat"' + (s.outreach_identity !== 'partner' ? ' selected' : '') + '>TuaniChat direct</option><option value="partner"' + (s.outreach_identity === 'partner' ? ' selected' : '') + '>Partner intro — Lion Click ✕ TuaniChat</option></select></div></div>' +
      '<div class="tnc-mt" style="display:flex;gap:12px;align-items:center;flex-wrap:wrap"><button class="tnc-btn" id="sOTest">⚡ Activate &amp; send test</button><span id="sOStat" class="tnc-muted" style="font-size:12px">Save the three fields above first, then test — a sample lands in your notification inbox.</span></div></div>' +
      '<div class="tnc-card"><h3>Screenshot Verify API (optional)</h3><div class="hint">Visual chat verification at scale needs a render service (shared hosting cannot headless-browse). When configured, crawls add a visual pass; when empty, code detection flags "Possible / Needs review" honestly instead of asserting "no chat".</div>' +
      '<div class="tnc-field"><label>Render service URL ({url} placeholder)</label><input type="url" id="sShotUrl" value="' + esc(s.screenshot_api_url || '') + '" placeholder="https://api.example-renderer.com/shot?key=…&url={url}"></div>' +
      '<div class="tnc-field"><label>Service API key</label><input type="text" id="sShotKey" value="' + esc(s.screenshot_api_key || '') + '"></div></div>' +
      '<div class="tnc-card"><h3>Notifications</h3><div class="hint">Lead alerts, crawl/size alerts, batch reports & system tests</div>' +
      '<div class="tnc-field"><label>Notification email(s)</label><input type="text" id="sNotify" value="' + esc(s.notify_email || '') + '" placeholder="you@x.com, partner@x.com"><div class="hint" style="margin-top:6px">Separate multiple emails with commas — every recipient gets every enabled alert.</div></div>' +
      '<div style="display:flex;gap:18px;flex-wrap:wrap;margin-top:4px">' +
      ['notify_leads,🔥 Leads', 'notify_crawl,🕸 Crawl alerts', 'notify_system,⚙ System'].map(function (t) {
        var k = t.split(',')[0], lbl = t.split(',')[1];
        return '<label style="display:flex;align-items:center;gap:7px;font-size:13px;cursor:pointer"><input type="checkbox" id="s_' + k + '"' + (Number(s[k] == null ? 1 : s[k]) ? ' checked' : '') + '> ' + lbl + '</label>';
      }).join('') + '</div></div>' +
      '<div class="tnc-card"><h3>Save</h3><div class="hint">Applies immediately to all demos</div><button class="tnc-btn" id="sSave" style="width:100%">Save Settings</button></div>' +
      '</div></div>'
    );
    document.getElementById('sSave').addEventListener('click', function () {
      var btn = this;
      spin(btn, true, 'Saving…');
      api('/admin/settings', 'POST', {
        api_key: document.getElementById('sKey').value,
        model: document.getElementById('sModel').value,
        endpoint_base: document.getElementById('sEndpoint').value,
        cta_activate_url: document.getElementById('sCta1').value,
        cta_call_url: document.getElementById('sCta2').value,
        notify_email: document.getElementById('sNotify').value,
        crawl_max_pages: document.getElementById('sMaxPages').value,
        crawl_full_pages: document.getElementById('sFullPages').value,
        crawl_batch_size: document.getElementById('sBatch').value,
        crawl_timeout: document.getElementById('sTimeout').value,
        crawl_concurrency: document.getElementById('sConc').value,
        crawl_per_host: document.getElementById('sPerHost').value,
        bulk_lanes: document.getElementById('sLanes').value,
        chat_rate_limit: document.getElementById('sRate').value,
        outreach_from_name: document.getElementById('sOFName').value,
        outreach_from_email: document.getElementById('sOFEmail').value,
        outreach_from_domain: document.getElementById('sOFDomain').value,
        outreach_identity: document.getElementById('sOIdent').value,
        cta_urgency_text: document.getElementById('sUrgency').value,
        screenshot_api_url: document.getElementById('sShotUrl').value,
        screenshot_api_key: document.getElementById('sShotKey').value,
        bulk_stagger: document.getElementById('sStagger').value,
        demo_autoopen_secs: document.getElementById('sAutoOpen').value,
        lead_form_helper: document.getElementById('sHelper').value,
        notify_leads: document.getElementById('s_notify_leads').checked ? 1 : 0,
        notify_crawl: document.getElementById('s_notify_crawl').checked ? 1 : 0,
        notify_system: document.getElementById('s_notify_system').checked ? 1 : 0
      }).then(function (j) {
        spin(btn, false);
        A.maskedKey = j.masked_key;
        toast('Settings saved');
        renderSettings();
      }).catch(function (e) { spin(btn, false); toast(e.message, true); });
    });
    var otBtn = document.getElementById('sOTest');
    if (otBtn) otBtn.addEventListener('click', function () {
      spin(otBtn, true, 'Testing…');
      api('/admin/outreach-test', 'POST').then(function (j) {
        spin(otBtn, false);
        var st = document.getElementById('sOStat');
        if (j.active) {
          st.innerHTML = '<b style="color:#34D399">● ACTIVE</b> — test sent through DreamHost mail. Check your inbox (and spam — expected until SPF/DKIM exist for the sending domain).';
          toast('Outreach sender active — test sent');
        } else if (j.missing && j.missing.length) {
          st.innerHTML = '<b style="color:#FBBF24">Missing:</b> ' + esc(j.missing.join(', ')) + ' — fill these in, Save Settings, then test again.';
          toast('Fill in: ' + j.missing.join(', '), true);
        } else {
          st.innerHTML = '<b style="color:#FB7185">Send failed</b> — the host mail function rejected it. Tell Claude.';
          toast('Test send failed', true);
        }
      }).catch(function (e) { spin(otBtn, false); toast(e.message, true); });
    });
    var hbBtn = document.getElementById('sHbCopy');
    if (hbBtn) hbBtn.addEventListener('click', function () { copyText('curl -s "' + (A.heartbeatUrl || '') + '" >/dev/null 2>&1', hbBtn); });
  }


  /* ---------- Bulk Import (v1.2) ---------- */
  var bulk = { batch: (typeof A.batch === 'string' ? A.batch : ''), rows: [], counts: null, batches: [], hasKey: false, parsed: null, mapping: {}, sort: 'score', dir: -1, sel: {}, pollT: null };
  var BULK_FIELDS = [
    ['company_name', 'Company name', /^(company([_ -]?name)?|business|account|name)$/i],
    ['website_url', 'Website URL', /(web ?site|^url$|domain|site)/i],
    ['industry', 'Industry / niche', /(industry|niche|vertical|category)/i],
    ['contact_name', 'Contact name', /(contact([_ -]?name)?$|first[_ -]?name|full[_ -]?name|owner)/i],
    ['contact_email', 'Contact email', /(e-?mail)/i]
  ];

  function parseCSV(text) {
    var rows = [], row = [], cur = '', inQ = false, i, c;
    text = String(text || '').replace(/\r\n/g, '\n').replace(/\r/g, '\n');
    for (i = 0; i < text.length; i++) {
      c = text[i];
      if (inQ) {
        if (c === '"') { if (text[i + 1] === '"') { cur += '"'; i++; } else { inQ = false; } }
        else { cur += c; }
      } else if (c === '"') { inQ = true; }
      else if (c === ',') { row.push(cur); cur = ''; }
      else if (c === '\n') { row.push(cur); rows.push(row); row = []; cur = ''; }
      else { cur += c; }
    }
    if (cur !== '' || row.length) { row.push(cur); rows.push(row); }
    return rows.filter(function (r) { return r.some(function (v) { return String(v).trim() !== ''; }); });
  }

  function smartMap(headers) {
    var map = {};
    BULK_FIELDS.forEach(function (f) {
      var idx = -1;
      headers.forEach(function (h, i) {
        if (idx === -1 && f[2].test(String(h).trim())) idx = i;
      });
      map[f[0]] = idx;
    });
    return map;
  }

  function industryKey(val) {
    var v = String(val || '').toLowerCase().trim();
    if (!v) return 'other';
    if (A.industries[v]) return v;
    var found = 'other';
    Object.keys(A.industries).forEach(function (k) {
      var label = A.industries[k].toLowerCase();
      if (label === v || label.indexOf(v) !== -1 || v.indexOf(k.replace(/_/g, ' ')) !== -1) found = k;
    });
    if (/injur/i.test(v)) found = 'personal_injury';
    else if (/law|attorn|legal/i.test(v) && found === 'other') found = 'law_general';
    else if (/spa|aesthet/i.test(v)) found = 'med_spa';
    else if (/dent/i.test(v)) found = 'dental';
    else if (/roof/i.test(v)) found = 'roofing';
    else if (/hvac|heat|cool|air/i.test(v) && found === 'other') found = 'hvac';
    else if (/shop|commerce|store/i.test(v)) found = 'ecommerce';
    return found;
  }

  function renderBulk() {
    shell(
      '<span class="tnc-badge">Bulk Demo Generation</span>' +
      '<h1 class="tnc-h1">From list to <span class="tnc-grad">demos.</span></h1>' +
      '<p class="tnc-sub">Upload a CSV of prospects — each row is crawled (staggered), gets a knowledge base, a private demo and a score. Then export and start outreach.</p>' +
      '<div id="tncUpload"></div><div id="tncResults">' + skeletons(2, 'tnc-skel-block') + '</div>'
    );
    drawUpload();
    loadBulk();
  }

  function drawUpload() {
    var el = document.getElementById('tncUpload');
    if (!el) return;
    if (!bulk.parsed) {
      el.innerHTML = '<div class="tnc-card" style="margin-bottom:24px"><h3>Import CSV</h3>' +
        '<div class="hint">Columns: company_name, website_url, industry, contact_name, contact_email — any order, headers matched automatically. Duplicates (by domain) are skipped.</div>' +
        '<div class="tnc-drop" id="bkDrop"><div class="big">⇪</div>Drop a .csv here or click to choose<input type="file" id="bkFile" accept=".csv,text/csv" style="display:none"></div></div>';
      var drop = el.querySelector('#bkDrop'), file = el.querySelector('#bkFile');
      drop.addEventListener('click', function () { file.click(); });
      drop.addEventListener('dragover', function (e) { e.preventDefault(); drop.classList.add('over'); });
      drop.addEventListener('dragleave', function () { drop.classList.remove('over'); });
      drop.addEventListener('drop', function (e) {
        e.preventDefault(); drop.classList.remove('over');
        if (e.dataTransfer.files[0]) readCsvFile(e.dataTransfer.files[0]);
      });
      file.addEventListener('change', function (e) { if (e.target.files[0]) readCsvFile(e.target.files[0]); });
      return;
    }
    // Mapping + preview
    var headers = bulk.parsed.headers;
    var opts = function (sel) {
      var h = '<option value="-1">— not in file —</option>';
      headers.forEach(function (hd, i) { h += '<option value="' + i + '"' + (i === sel ? ' selected' : '') + '>' + esc(hd) + '</option>'; });
      return h;
    };
    var mapHtml = BULK_FIELDS.map(function (f) {
      return '<div class="tnc-field" style="margin-bottom:0"><label>' + f[1] + '</label><select data-f="' + f[0] + '">' + opts(bulk.mapping[f[0]]) + '</select></div>';
    }).join('');
    var prev = bulk.parsed.rows.slice(0, 5).map(function (r) {
      return '<tr>' + headers.map(function (h, i) { return '<td>' + esc(r[i] || '') + '</td>'; }).join('') + '</tr>';
    }).join('');
    el.innerHTML = '<div class="tnc-card" style="margin-bottom:24px"><h3>Map columns</h3>' +
      '<div class="hint">' + bulk.parsed.rows.length + ' data rows in ' + esc(bulk.parsed.name) + ' — check the mapping, then import.</div>' +
      '<div class="tnc-map">' + mapHtml + '</div>' +
      '<div style="overflow-x:auto"><table class="tnc-prev"><thead><tr>' + headers.map(function (h) { return '<th>' + esc(h) + '</th>'; }).join('') + '</tr></thead><tbody>' + prev + '</tbody></table></div>' +
      '<div class="tnc-mt" style="display:flex;gap:12px"><button class="tnc-btn" id="bkImport">Import ' + bulk.parsed.rows.length + ' prospects</button>' +
      '<button class="tnc-btn ghost" id="bkCancel">Cancel</button></div></div>';
    el.querySelectorAll('select[data-f]').forEach(function (s) {
      s.addEventListener('change', function () { bulk.mapping[s.dataset.f] = parseInt(s.value, 10); });
    });
    el.querySelector('#bkCancel').addEventListener('click', function () { bulk.parsed = null; drawUpload(); });
    el.querySelector('#bkImport').addEventListener('click', function () {
      var btn = this;
      if (bulk.mapping.website_url < 0) { toast('Map the Website URL column first', true); return; }
      var rows = bulk.parsed.rows.map(function (r) {
        var get = function (f) { var i = bulk.mapping[f]; return i >= 0 ? String(r[i] || '').trim() : ''; };
        return {
          company_name: get('company_name'),
          website_url: get('website_url'),
          industry: industryKey(get('industry')),
          contact_name: get('contact_name'),
          contact_email: get('contact_email')
        };
      }).filter(function (r) { return r.website_url; });
      if (!rows.length) { toast('No rows with a website URL', true); return; }
      spin(btn, true, 'Importing…');
      api('/admin/bulk-import', 'POST', { rows: rows }).then(function (j) {
        bulk.parsed = null;
        bulk.batch = j.batch_id || bulk.batch;
        bulk.sel = {};
        var msg = j.created + ' queued';
        if (j.skipped) msg += ', ' + j.skipped + ' duplicates skipped';
        if (j.invalid && j.invalid.length) msg += ', ' + j.invalid.length + ' invalid';
        toast(msg, j.created === 0);
        drawUpload();
        loadBulk();
      }).catch(function (e) { spin(btn, false); toast(e.message, true); });
    });
  }

  function readCsvFile(f) {
    if (f.size > 2 * 1024 * 1024) { toast('CSV too large (max 2 MB)', true); return; }
    var reader = new FileReader();
    reader.onload = function () {
      var all = parseCSV(String(reader.result));
      if (all.length < 2) { toast('CSV needs a header row plus at least one data row', true); return; }
      var headers = all[0].map(function (h) { return String(h).trim(); });
      bulk.parsed = { name: f.name, headers: headers, rows: all.slice(1) };
      bulk.mapping = smartMap(headers);
      drawUpload();
    };
    reader.readAsText(f);
  }

  function loadBulk() {
    api('/admin/bulk?batch=' + encodeURIComponent(bulk.batch || '')).then(function (j) {
      bulk.batch = j.batch || '';
      bulk.rows = j.rows || [];
      bulk.counts = j.counts;
      bulk.batches = j.batches || [];
      bulk.hasKey = !!j.has_key;
      drawResults();
      clearTimeout(bulk.pollT);
      if (bulk.counts && (bulk.counts.queued > 0 || bulk.counts.crawling > 0)) {
        bulk.pollT = setTimeout(loadBulk, 6000);
      }
    }).catch(function (e) {
      var el = document.getElementById('tncResults');
      if (el) el.innerHTML = '<div class="tnc-card"><div class="tnc-empty">' + esc(e.message) + '</div></div>';
    });
  }

  function sortedRows() {
    var rows = bulk.rows.slice();
    var k = bulk.sort, d = bulk.dir;
    rows.sort(function (a, b) {
      var va = a[k], vb = b[k];
      if (k === 'score') { va = Number(va); vb = Number(vb); return (va - vb) * d; }
      return String(va || '').localeCompare(String(vb || '')) * d;
    });
    return rows;
  }

  function drawResults() {
    var el = document.getElementById('tncResults');
    if (!el) return;
    if (!bulk.batch || !bulk.counts) {
      el.innerHTML = '<div class="tnc-card"><div class="tnc-empty"><div class="big">▦</div>No batches yet.<br><span class="tnc-muted">Import a CSV above to generate demos in bulk.</span></div></div>';
      return;
    }
    var c = bulk.counts;
    var working = c.queued + c.crawling;
    var stat = function (label, value) {
      return '<div class="tnc-stat"><div class="lbl">' + label + '</div><div class="num">' + value + '</div></div>';
    };
    var picker = '';
    if (bulk.batches.length > 1) {
      picker = '<select id="bkBatch" style="width:auto;min-width:220px">' + bulk.batches.map(function (b) {
        return '<option value="' + esc(b.id) + '"' + (b.id === bulk.batch ? ' selected' : '') + '>' + esc(b.started || b.id) + ' — ' + b.counts.total + ' rows</option>';
      }).join('') + '</select>';
    }
    var th = function (key, label, extra) {
      var arrow = bulk.sort === key ? '<span class="arrow">' + (bulk.dir === -1 ? '▼' : '▲') + '</span>' : '';
      return '<th class="sortable" data-k="' + key + '"' + (extra || '') + '>' + label + arrow + '</th>';
    };
    var rows = sortedRows().map(function (r) {
      var st = '<span class="tnc-pill ' + esc(r.status) + '">' + esc(A.statuses[r.status] || r.status) + '</span>';
      if (r.status === 'crawling') st = '<span class="tnc-pill crawling"><span class="tnc-spin" style="width:9px;height:9px;border-width:1.5px;margin-right:5px"></span>Crawling</span>';
      if (r.status === 'error' && r.last_error) st += '<div class="tnc-err-note" title="' + esc(r.last_error) + '">' + esc(r.last_error.slice(0, 60)) + '</div>';
      var demo = r.demo_url && r.status !== 'queued' && r.status !== 'crawling' && r.status !== 'error'
        ? '<a class="tnc-btn ghost sm" target="_blank" href="' + esc(r.demo_url) + '">Open ↗</a> <button class="tnc-btn ghost sm bkCopy" data-u="' + esc(r.demo_url) + '">Copy</button>'
        : '<span class="tnc-muted">—</span>';
      return '<tr data-id="' + r.id + '">' +
        '<td><input type="checkbox" class="bkSel" data-id="' + r.id + '"' + (bulk.sel[r.id] ? ' checked' : '') + '></td>' +
        '<td><div class="tnc-co">' + esc(r.company_name || '(no name)') + '</div><div class="tnc-url">' + esc(r.website_url) + '</div></td>' +
        '<td>' + (r.contact_name ? esc(r.contact_name) : '<span class="tnc-muted">—</span>') + (r.contact_email ? '<div class="tnc-url">' + esc(r.contact_email) + '</div>' : '') + '</td>' +
        '<td><span class="tnc-score ' + scoreCls(r.score) + '">' + r.score + '</span></td>' +
        '<td>' + st + '</td>' +
        '<td>' + demo + '</td></tr>';
    }).join('');

    el.innerHTML =
      '<div class="tnc-cards">' +
      stat('Total In Batch', c.total) + stat('Demos Ready', c.ready) + stat('In Queue', working) + stat('Errors', c.errors) +
      '</div>' +
      '<div class="tnc-card" style="padding:8px 4px 16px">' +
      '<div class="tnc-toolbar" style="padding:16px 16px 0">' +
      '<h3 style="margin:0">Ready for outreach</h3>' +
      (working ? '<span class="tnc-pill crawling">Processing — one crawl every ' + Math.round((Number(A.settings.bulk_stagger) || 150) / 60 * 10) / 10 + ' min</span>' : '') +
      '<div class="tnc-spacer"></div>' + picker +
      '<button class="tnc-btn ghost" id="bkExport">Export CSV</button></div>' +
      (bulk.hasKey ? '' : '<div class="hint" style="padding:0 16px">No API key — kits use the ⚡ free template engine (always included). ✨ AI personalization unlocks once a key is added in Settings.</div>') +
      '<table class="tnc-table"><colgroup><col style="width:4%"><col style="width:30%"><col style="width:20%"><col style="width:9%"><col style="width:17%"><col style="width:20%"></colgroup>' +
      '<thead><tr><th><input type="checkbox" id="bkSelAll"></th>' + th('company_name', 'Company') + '<th>Contact</th>' + th('score', 'Score') + th('status', 'Status') + '<th>Demo link</th></tr></thead>' +
      '<tbody>' + (rows || '<tr><td colspan="6"><div class="tnc-empty">No rows in this batch.</div></td></tr>') + '</tbody></table></div>';

    el.querySelectorAll('th.sortable').forEach(function (h) {
      h.addEventListener('click', function () {
        var k = h.dataset.k;
        if (bulk.sort === k) { bulk.dir = -bulk.dir; } else { bulk.sort = k; bulk.dir = k === 'score' ? -1 : 1; }
        drawResults();
      });
    });
    el.querySelectorAll('.bkCopy').forEach(function (b) {
      b.addEventListener('click', function () { copyText(b.dataset.u, b); });
    });
    el.querySelectorAll('.bkSel').forEach(function (cb) {
      cb.addEventListener('change', function () { bulk.sel[cb.dataset.id] = cb.checked; });
    });
    var selAll = el.querySelector('#bkSelAll');
    if (selAll) selAll.addEventListener('change', function () {
      bulk.rows.forEach(function (r) { bulk.sel[r.id] = selAll.checked; });
      drawResults();
    });
    var batchSel = el.querySelector('#bkBatch');
    if (batchSel) batchSel.addEventListener('change', function () { bulk.batch = batchSel.value; bulk.sel = {}; loadBulk(); });
    el.querySelector('#bkExport').addEventListener('click', exportBulkCsv);
  }

  function exportBulkCsv() {
    var anySel = Object.keys(bulk.sel).some(function (k) { return bulk.sel[k]; });
    var rows = sortedRows().filter(function (r) {
      if (anySel && !bulk.sel[r.id]) return false;
      return r.status !== 'queued' && r.status !== 'crawling';
    });
    if (!rows.length) { toast('Nothing to export yet', true); return; }
    var q = function (v) { return '"' + String(v == null ? '' : v).replace(/"/g, '""') + '"'; };
    var header = ['company', 'contact_name', 'contact_email', 'website', 'demo_url', 'score', 'status', 'linkedin_message', 'cold_email_subject'];
    var lines = [header.join(',')];
    rows.forEach(function (r) {
      lines.push([q(r.company_name), q(r.contact_name), q(r.contact_email), q(r.website_url), q(r.demo_url), r.score, q(r.status), q(r.linkedin), q(r.cold_subject)].join(','));
    });
    if (!bulk.hasKey) lines.push(q('NOTE: outreach columns empty — no API key configured in TuaniChat Settings'));
    var blob = new Blob([lines.join('\n')], { type: 'text/csv' });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'tuanichat-batch-' + (bulk.batch || 'export') + '.csv';
    document.body.appendChild(a);
    a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500);
    toast('Exported ' + rows.length + ' rows');
  }

  /* ---------- boot ---------- */
  var bootProspect = parseInt(A.prospect, 10) || 0;
  if (A.page === 'tnc-prospects' && bootProspect) {
    renderDetailShell();
    loadDetail(bootProspect);
  } else if (A.page === 'tnc-prospects') {
    renderList();
  } else if (A.page === 'tnc-bulk') {
    renderBulk();
  } else if (A.page === 'tnc-settings') {
    renderSettings();
  } else {
    renderDashboard();
  }
})();
