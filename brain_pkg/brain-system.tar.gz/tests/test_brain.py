"""
Unit tests for the /brain system. Run with: python -m pytest -q
or, with zero deps: python -m unittest discover -s tests

Covers: initialization, the schema factory, write dynamics (reinforce /
contradict / promote), retrieval + context injection, the decision core,
self-review, the reflection pass, the seed, and the integration hooks
(file inbox + markdown cross-feed).
"""

from __future__ import annotations

import json
import os
import sys
import tempfile
import unittest

# Make the package importable when run from the repo root.
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from brain import Brain  # noqa: E402
from brain.api import initialize_brain  # noqa: E402
from brain.decide import next_best_action, self_review_response  # noqa: E402
from brain.integrate import drain_inbox, import_from_markdown  # noqa: E402
from brain.reflect import reflect, compress_duplicate_lessons, promote_rules  # noqa: E402
from brain.retrieval import retrieve_relevant_context, search_memory  # noqa: E402
from brain.schemas import make_record, MEMORY_FILES  # noqa: E402
from brain.seed import seed_brain  # noqa: E402
from brain.store import BrainStore  # noqa: E402


class BrainTestBase(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.mkdtemp(prefix="brain_test_")
        self.root = os.path.join(self.tmp, "brain")
        self.store = initialize_brain(self.root)


class TestInit(BrainTestBase):
    def test_structure_created(self):
        for sub in ("memory", "projects", "logs", "vectors", "archive"):
            self.assertTrue(os.path.isdir(os.path.join(self.root, sub)))
        for fname in MEMORY_FILES.values():
            self.assertTrue(os.path.isfile(os.path.join(self.root, "memory", fname)))
        for proj in ("google_ads", "atlas", "tuanichat"):
            self.assertTrue(os.path.isdir(os.path.join(self.root, "projects", proj)))

    def test_idempotent(self):
        self.store.add("lesson", "keep me", project="atlas")
        # Re-init must not wipe existing data.
        self.store.initialize()
        self.assertEqual(len(self.store.load("lesson")), 1)


class TestSchemas(BrainTestBase):
    def test_make_record_fields(self):
        rec = make_record("mistake", "  oops  ", project="atlas", confidence=120, severity=-5)
        self.assertEqual(rec["text"], "oops")
        self.assertEqual(rec["confidence"], 100)  # clamped
        self.assertEqual(rec["severity"], 0)  # clamped
        self.assertIn("created_at", rec)
        self.assertEqual(rec["kind"], "mistake")

    def test_bad_kind(self):
        with self.assertRaises(ValueError):
            make_record("nonsense", "x")


class TestWriteDynamics(BrainTestBase):
    def test_reinforce_collapses_duplicates(self):
        r1 = self.store.add("lesson", "always verify ground truth", project="google_ads")
        r2 = self.store.add("lesson", "Always verify ground truth", project="google_ads")
        # Same id reinforced, not a new record.
        self.assertEqual(r1["id"], r2["id"])
        self.assertEqual(len(self.store.load("lesson")), 1)
        self.assertEqual(self.store.load("lesson")[0]["frequency"], 2)
        self.assertGreater(self.store.load("lesson")[0]["confidence"], r1["confidence"] - 1)

    def test_contradiction_supersedes(self):
        old = self.store.add("lesson", "use crt.sh for CT logs", project="atlas")
        new = self.store.add(
            "lesson",
            "crt.sh is unreliable; use multi-CT-log collector",
            project="atlas",
            contradicts=old["id"],
        )
        refreshed = self.store.get(old["id"])
        self.assertEqual(refreshed["status"], "superseded")
        self.assertEqual(refreshed["meta"]["superseded_by"], new["id"])
        self.assertIn(old["id"], new["links"])

    def test_auto_promote_to_rule(self):
        # High confidence + frequency >= 3 promotes a lesson to a rule.
        for _ in range(3):
            self.store.add(
                "lesson",
                "never scale enrich past PG-safe",
                project="atlas",
                confidence=95,
            )
        rules = self.store.load("rule")
        self.assertTrue(any("enrich" in r["text"] for r in rules))
        self.assertEqual(rules[0]["meta"]["promoted_from"][:6], "lesson")

    def test_atomic_write_valid_json(self):
        self.store.add("win", "pipe works", project="atlas")
        with open(os.path.join(self.root, "memory", "wins.json"), encoding="utf-8") as fh:
            data = json.load(fh)
        self.assertIsInstance(data, list)


class TestRetrieval(BrainTestBase):
    def test_search_relevance(self):
        self.store.add("roadbump", "psycopg2 fails to build on CentOS7", project="atlas",
                       meta={"resolution": "pin 2.8.6 binary"})
        self.store.add("lesson", "Google Ads negatives applied at launch", project="google_ads")
        hits = search_memory(self.store, "centos7 psycopg2 install error", project="atlas")
        self.assertTrue(hits)
        self.assertIn("psycopg2", hits[0]["text"])

    def test_context_not_overloaded(self):
        for i in range(30):
            self.store.add("lesson", f"lesson about postgres scaling number {i}", project="atlas")
        ctx = retrieve_relevant_context(self.store, "postgres scaling", project="atlas", max_items=5)
        self.assertLessEqual(len(ctx["relevant"]), 5)
        self.assertIn("RELEVANT MEMORY", ctx["as_text"])


class TestDecide(BrainTestBase):
    def test_known_roadbump_returns_resolution(self):
        self.store.add(
            "roadbump",
            "git push non-fast-forward on manifests repo",
            project="atlas",
            confidence=85,
            meta={"resolution": "fetch && rebase origin/main then retry"},
        )
        rec = next_best_action(self.store, "git push rejected non-fast-forward", project="atlas",
                               situation="roadbump")
        self.assertIn("rebase", rec["action"].lower())
        self.assertGreater(rec["confidence"], 50)

    def test_win_repeats_workflow(self):
        self.store.add("win", "auto-pull pipe deploy succeeded", project="atlas",
                       confidence=85, meta={"conditions": "HMAC verified, seq increasing"})
        rec = next_best_action(self.store, "deploy via auto-pull pipe", project="atlas", situation="task")
        self.assertTrue(rec["action"])
        self.assertTrue(rec["supporting"])

    def test_self_review(self):
        good = self_review_response(dict.fromkeys(
            ["accuracy", "completeness", "clarity", "usefulness", "strategy",
             "automation_potential", "preference_alignment"], 9))
        self.assertTrue(good["pass"])
        bad = self_review_response({"accuracy": 10, "clarity": 6})
        self.assertFalse(bad["pass"])
        self.assertIn("clarity", bad["weak_axes"])


class TestReflect(BrainTestBase):
    def test_compress_duplicates(self):
        # Bypass add()'s reinforcement to force raw duplicates on disk.
        recs = [
            make_record("lesson", "same lesson text", project="atlas"),
            make_record("lesson", "Same Lesson Text", project="atlas"),
            make_record("lesson", "different", project="atlas"),
        ]
        self.store.save("lesson", recs)
        merged = compress_duplicate_lessons(self.store, "lesson")
        self.assertEqual(merged, 1)
        self.assertEqual(len(self.store.load("lesson")), 2)

    def test_full_reflect_runs(self):
        seed_brain(self.store)
        report = reflect(self.store)
        self.assertIn("merged", report)
        self.assertIn("promoted", report)
        # A summary record was written.
        self.assertTrue(self.store.load("summary"))


class TestSeed(BrainTestBase):
    def test_seed_loads_real_lessons(self):
        report = seed_brain(self.store)
        self.assertGreater(report["seeded"], 15)
        # The SEV-1 PG lesson must be present and high-severity.
        roadbumps = self.store.load("roadbump")
        sev1 = [r for r in roadbumps if "PG" in r["text"] or "Postgres" in r["text"]]
        self.assertTrue(sev1)
        self.assertGreaterEqual(sev1[0]["severity"], 90)
        # Some lessons should have been promoted to rules.
        self.assertTrue(self.store.load("rule"))


class TestIntegration(BrainTestBase):
    def test_file_inbox_drain(self):
        inbox = self.store.log_path("inbox.jsonl")
        os.makedirs(os.path.dirname(inbox), exist_ok=True)
        events = [
            {"type": "atlas_outcome", "industry": "roofing", "source": "osm", "converted": True},
            {"type": "deploy_roadbump", "blocker": "ufw blocked ssh", "resolution": "allow OpenSSH"},
            {"type": "lesson", "text": "from a worker", "project": "atlas"},
        ]
        with open(inbox, "w", encoding="utf-8") as fh:
            for e in events:
                fh.write(json.dumps(e) + "\n")
        report = drain_inbox(self.store)
        self.assertEqual(report["applied"], 3)
        self.assertEqual(report["errors"], [])
        # The inbox is truncated after draining.
        self.assertEqual(os.path.getsize(inbox), 0)
        # The win + pattern from the outcome landed.
        self.assertTrue(self.store.load("win"))
        self.assertTrue(self.store.load("roadbump"))

    def test_markdown_import(self):
        md_dir = os.path.join(self.tmp, "md")
        os.makedirs(md_dir)
        with open(os.path.join(md_dir, "atlas-learnings.md"), "w", encoding="utf-8") as fh:
            fh.write("---\ntype: project\n---\nNever hard-delete; reversible purge only.\n")
        report = import_from_markdown(self.store, md_dir)
        self.assertEqual(report["imported"], 1)
        lessons = self.store.load("lesson")
        self.assertTrue(any("reversible" in l["text"] for l in lessons))
        self.assertEqual(lessons[0]["project"], "atlas")


class TestBrainFacade(BrainTestBase):
    def test_brain_object_roundtrip(self):
        b = Brain(self.root)
        b.add_mistake("shipped a false success", project="global")
        b.add_roadmap("wire outcome loop", status="in_progress", priority=90, project="tuanichat")
        hits = b.search("false success")
        self.assertTrue(hits)
        rec = b.decide("about to report a deploy as done", project="global")
        self.assertTrue(rec["action"])


if __name__ == "__main__":
        unittest.main(verbosity=2)
