"""
example_usage.py
================

A runnable, end-to-end tour of the /brain self-learning memory system.

Run it:
    python examples/example_usage.py

It creates a throwaway brain under ./_demo_brain, seeds the real project
lessons, then walks the full operating loop:
    RECALL -> REASON -> EXECUTE -> REVIEW -> LEARN -> STORE -> IMPROVE
"""

from __future__ import annotations

import os
import shutil
import sys

# Make the package importable when run from the repo root.
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from brain import Brain
from brain.seed import seed_brain


def banner(title: str) -> None:
    print("\n" + "=" * 72)
    print(title)
    print("=" * 72)


def main() -> None:
    root = os.path.join(os.path.dirname(__file__), "_demo_brain")
    if os.path.isdir(root):
        shutil.rmtree(root)

    # --- initialize + seed -------------------------------------------------
    banner("1) initialize + seed the brain with REAL project lessons")
    brain = Brain(root)
    report = seed_brain(brain.store)
    print(f"seeded {report['seeded']} records; rules now: {report['counts']['rule']}")
    print(f"record counts: {report['counts']}")

    # --- RECALL: inject only relevant context ------------------------------
    banner("2) RECALL — context for 'scale enrichment on the hetzner box'")
    ctx = brain.recall("we want to scale enrichment throughput on the hetzner box",
                       project="atlas")
    print(ctx["as_text"])

    # --- REASON: next best action ------------------------------------------
    banner("3) REASON — next_best_action for the same situation")
    decision = brain.decide("scale enrichment throughput on the hetzner box",
                            project="atlas", situation="task")
    print("ACTION    :", decision["action"])
    print("RATIONALE :", decision["rationale"])
    print("CONFIDENCE:", decision["confidence"])
    for w in decision["warnings"]:
        print("WARN      :", w)

    # --- REVIEW: self-review a drafted response ----------------------------
    banner("4) REVIEW — self_review_response (any axis < 9 => improve)")
    review = brain.review({
        "accuracy": 9, "completeness": 8, "clarity": 9, "usefulness": 9,
        "strategy": 9, "automation_potential": 7, "preference_alignment": 9,
    })
    print("pass:", review["pass"])
    print("advice:", review["advice"])

    # --- LEARN + STORE: a new correction + a new win -----------------------
    banner("5) LEARN + STORE — capture a correction and a win")
    brain.add_lesson(
        "When reporting a deploy, never say 'done' until verified against the box's "
        "health check output.",
        project="global", confidence=85, severity=60, tags=["honesty", "deploy"],
    )
    brain.add_win(
        "Used ICP targeting instead of adding enrich lanes; throughput stayed PG-safe.",
        project="atlas", conditions="ICP filter on; ~1,200/min; 8GB box",
        confidence=75, tags=["icp", "enrichment"],
    )
    brain.add_roadmap(
        "Wire the TuaniChat outcome token so conversion learning activates.",
        project="tuanichat", status="in_progress", priority=90,
    )
    print("added: 1 lesson, 1 win, 1 roadmap item")

    # --- self-learning: reinforcement + promotion --------------------------
    banner("6) self-learning — repeat a lesson 3x => confidence climbs, promotes to a rule")
    for _ in range(3):
        brain.add_lesson("Take a restore point before every apply.",
                         project="atlas", confidence=92)
    rules = [r for r in brain.store.load("rule") if "restore point" in r["text"].lower()]
    print("promoted to rule:", bool(rules))

    # --- contradiction: newest wins ----------------------------------------
    banner("7) contradiction — newest record supersedes the old (with a pointer)")
    old = brain.add_lesson("Pull interval is 10 minutes.", project="atlas")
    new = brain.add_lesson("Pull interval is 3 minutes (user changed it).",
                           project="atlas", contradicts=old["id"])
    refreshed = brain.store.get(old["id"])
    print(f"old status: {refreshed['status']} -> superseded_by {refreshed['meta'].get('superseded_by')}")

    # --- integration hooks -------------------------------------------------
    banner("8) integration — ATLAS outcome + deploy roadbump via the API")
    brain.record_atlas_outcome(industry="roofing", source="osm", converted=True,
                               detail="demo -> paid in 4 days")
    brain.record_deploy_roadbump(
        blocker="autopull timer disabled by a bad manifest",
        resolution="lifeline guardrail rejects manifests that touch the autopull "
                   "service/timer; restore last-good + re-enable timer",
        severity=90,
    )
    print("recorded 1 conversion pattern/win + 1 deploy roadbump")

    # --- file bridge: a worker feeds the brain by appending a JSON line ----
    banner("9) file bridge — a worker appends to logs/inbox.jsonl; brain drains it")
    import json
    inbox = brain.store.log_path("inbox.jsonl")
    os.makedirs(os.path.dirname(inbox), exist_ok=True)
    with open(inbox, "a", encoding="utf-8") as fh:
        fh.write(json.dumps({"type": "atlas_outcome", "industry": "dental",
                             "source": "ct_logs", "converted": False}) + "\n")
    drained = brain.drain_inbox()
    print("drained:", drained)

    # --- IMPROVE: the nightly/weekly reflection ("Dreams") -----------------
    banner("10) IMPROVE — reflect() consolidates: dedup, decay, promote, insights")
    rep = brain.reflect()
    print("reflection report:", rep)

    # --- session summary ---------------------------------------------------
    banner("11) session summary")
    summ = brain.summarize_session(
        project="global",
        highlights=["walked the full brain loop"],
        wins=["ICP targeting win recorded"],
        next_steps=["wire TuaniChat outcome token"],
    )
    print(summ["text"])

    banner("done")
    print(f"brain lives at: {brain.root}")
    print("inspect: python -m brain stats --root", brain.root)


if __name__ == "__main__":
    main()
