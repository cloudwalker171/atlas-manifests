# /brain — the self-learning autonomous memory system

A production-quality, modular, **self-learning** memory system that the whole
platform (the ATLAS Meta Brain, the agents, the deploy pipe, and Claude)
reads/writes so the system gets smarter every day.

JSON-first, **stdlib only** for the core (no external dependencies), with a
clean upgrade path to SQLite and a pluggable vector layer. Fully unit-tested
(19 tests, all passing) and runnable.

---

## The operating loop

```
RECALL  ->  REASON  ->  EXECUTE  ->  REVIEW  ->  LEARN  ->  STORE  ->  IMPROVE
```

| Step    | Function | What happens |
|---------|----------|--------------|
| RECALL  | `retrieve_relevant_context()` | Before answering, search memory for the relevant past mistakes / preferences / best-practices / project-rules / patterns / roadbumps and inject **only** what's relevant (never overload). |
| REASON  | `next_best_action()` / `decide()` | Given the situation, recall lessons + rules + patterns + known roadbump fixes and return the recommended action. This is "the Meta agent always knows what to do." |
| EXECUTE | *(your code/agent)* | Act. |
| REVIEW  | `self_review_response()` | Score the draft 1-10 on accuracy, completeness, clarity, usefulness, strategy, automation-potential, preference-alignment. Any axis < 9 => improve before finalizing. |
| LEARN   | `add_lesson/add_mistake/add_win/add_roadbump/...` | Every user correction becomes a stored lesson; every blocker + its fix becomes a roadbump; every successful workflow becomes a win. |
| STORE   | `BrainStore` | Atomic JSON writes (temp file + `os.replace`) so a crash can never corrupt memory. |
| IMPROVE | `reflect()` | The nightly/weekly "Dreams" pass: dedup, decay, reinforce, promote-to-rules, extract higher-level insights, write a curated summary. |

---

## Architecture

```
brain/
  __init__.py     public API surface + package docstring
  schemas.py      record shapes, factory, time helpers, thresholds
  store.py        JSON-first persistence + self-learning WRITE dynamics
  retrieval.py    scoring, search, "inject only relevant" context builder
  decide.py       next_best_action + self_review_response (the decision core)
  reflect.py      the consolidation / "Dreams" layer (CLI: python -m brain reflect)
  integrate.py    ATLAS / deploy-pipe / agent hooks + file bridge + markdown sync
  api.py          the spec-named facade + the `Brain` convenience object
  cli.py          command-line entrypoints (python -m brain ...)
  seed.py         the REAL project lessons (so the brain starts smart)

# created on first run under the brain root:
brain/                       <- the brain ROOT (data, not code)
  memory/{mistakes,lessons,preferences,best_practices,patterns,
          summaries,wins,roadbumps,roadmap,rules}.json
  projects/{google_ads,seo,lionclick_media,tuanichat,atlas,client_work}/
  logs/        (reflect.log.jsonl, inbox.jsonl, import logs)
  vectors/     (reserved for an optional embedding index)
  archive/     (archive.json — superseded / merged / aged-out records)
```

> Note: "brain" is both the **package** (code) and the **root data folder**.
> Keep them separate in deployment (e.g. code in `/opt/brain`, data in
> `/var/lib/brain`) — set the data root with `BRAIN_ROOT` or `--root`.

---

## Record types

Beyond the base mistakes / lessons / preferences / best-practices / patterns:

- **wins** — successful workflows worth repeating, **with the conditions** that
  made them work (`meta.conditions`).
- **roadbumps** — a blocker + **exactly how it was resolved** (`meta.resolution`),
  so the same block is instantly solved next time.
- **roadmap** — planned items with `status` (planned / in_progress / done /
  blocked) and `priority`, so the brain always knows what's next.
- **rules** — high-confidence, repeated lessons auto-**promoted** to
  always-applied status.
- **summaries** — session + weekly reflection summaries.

Every record carries: `id, kind, project, category, text, confidence (0-100),
frequency, severity (0-100), tags, status, created_at, updated_at, last_used,
source, links, meta`.

---

## Self-learning dynamics

- **Reinforcement** — adding a near-duplicate bumps `frequency` and raises
  `confidence` (diminishing returns) instead of creating a new row.
- **Decay** — records unused for `DECAY_STALE_DAYS` (default 30) lose confidence
  during reflection; near-dead records (<= `ARCHIVE_CONFIDENCE`) are archived.
- **Promotion** — a lesson/best-practice at `confidence >= 90` seen `>= 3` times
  is auto-copied into `rules.json` as an always-applied rule.
- **Contradiction** — `add(..., contradicts=old_id)` archives the old record with
  a `superseded_by` pointer and links the new one back (**newest wins**).
- **Insight extraction** — reflection clusters related records by tag and writes
  higher-level `pattern` meta-records ("recurring theme X across N records").

---

## Quick start

```python
from brain import Brain

b = Brain("./brain")                       # initializes the folder structure
b.add_lesson("Verify against ground truth, not a summary view.",
             project="google_ads", confidence=95, frequency=3)

ctx = b.recall("launching a new Google Ads campaign", project="google_ads")
print(ctx["as_text"])                      # the injected briefing

rec = b.decide("launching a new Google Ads campaign", project="google_ads")
print(rec["action"], rec["confidence"])
```

Run the full tour:

```
python examples/example_usage.py
```

Run the tests:

```
python -m unittest discover -s tests        # zero deps
# or
python -m pytest -q
```

---

## CLI

```
python -m brain init            --root ./brain
python -m brain seed            --root ./brain      # load the REAL project lessons
python -m brain search "query"  --root ./brain --project atlas
python -m brain decide "ctx"    --root ./brain --project google_ads
python -m brain reflect         --root ./brain      # the nightly/weekly pass
python -m brain drain           --root ./brain      # apply queued inbox.jsonl events
python -m brain import-md DIR   --root ./brain      # import native markdown memory
python -m brain export-md DIR   --root ./brain      # export rules/lessons to markdown
python -m brain stats           --root ./brain

python -m brain.reflect --root ./brain --drain      # canonical scheduled command
```

---

## How each system plugs in

The brain is only useful if it's actually loaded. Three integration classes:

### 1. Importable API (in-process)
```python
from brain.integrate import (
    record_atlas_outcome, record_deploy_roadbump, agent_preflight)

# (a) ATLAS Smart Brain outcome loop -> wins/mistakes/patterns
record_atlas_outcome(store, industry="roofing", source="osm", converted=True)

# (b) deploy pipe -> roadbumps (blocker + resolution)
record_deploy_roadbump(store,
    blocker="never scale enrich pool past PG-safe (caused a SEV-1 PG outage)",
    resolution="cap at ~1,200/min on the 8GB box; add lanes only with headroom",
    severity=95)

# (c) agents call this BEFORE acting
brief = agent_preflight(store, "deploy a new manifest", project="atlas")
#   -> {"context": <injected memory>, "recommendation": <next_best_action>}
```

### 2. File bridge (cross-process / cross-box, zero deps)
Any process — including the Hetzner / InterServer workers — feeds the brain by
appending one JSON line to `<root>/logs/inbox.jsonl`:

```json
{"type":"atlas_outcome","industry":"dental","source":"ct_logs","converted":false}
{"type":"deploy_roadbump","blocker":"...","resolution":"...","severity":90}
{"type":"lesson","text":"...","project":"atlas","confidence":80}
```

The brain ingests them on `python -m brain drain` (or `reflect --drain`). No
network, no dependencies — perfect for a box that can't import the package.

### 3. Markdown cross-feed (sync with native Claude memory)
```python
from brain.integrate import import_from_markdown, export_to_markdown
import_from_markdown(store, "/path/to/agent/memory")   # native md -> brain
export_to_markdown(store, "/path/to/agent/memory_out") # high-conf rules -> md
```

An **optional HTTP bridge** (a ~30-line stdlib `http.server` wrapper) is
intentionally left out of the core to keep zero attack surface; see
`INTEGRATION_PLAN.md` for the drop-in snippet and when to use the file bridge
instead (recommended for the Hetzner box).

---

## Scheduling `reflect` (the "Dreams" layer)

**Linux (systemd timer)** — see `deploy/brain-reflect.service` + `.timer`:
```
systemctl enable --now brain-reflect.timer    # nightly 03:30
```

**Linux (cron)**:
```
30 3 * * *  cd /opt/brain && /usr/bin/python3 -m brain.reflect --root /var/lib/brain --drain >> /var/log/brain-reflect.log 2>&1
```

**Windows (Task Scheduler)**:
```
schtasks /Create /SC DAILY /ST 03:30 /TN BrainReflect ^
  /TR "python -m brain.reflect --root C:\brain --drain"
```

Run a heavier weekly pass (same command — it's idempotent) on Sundays if you
want a separate "weekly learning summary" cadence; the summary record is written
every run with the full report in `meta`.

---

## JSON -> SQLite upgrade path

The store is deliberately backend-agnostic. The whole surface area to swap is
the read/write primitives in `store.py` (`_read_json` / `_write_json` / `load` /
`save` / `get`). To upgrade when memory grows:

1. Add a `sqlite` branch in `BrainStore.__init__` (the constructor already
   accepts `backend="sqlite"`).
2. Create one table `records(id TEXT PRIMARY KEY, kind, project, ...)` with the
   record fields as columns and `tags`/`links`/`meta` as JSON text columns.
3. Implement `load(kind)` as `SELECT * WHERE kind=?`, `save` as an upsert, `get`
   as `SELECT ... WHERE id=?`. Everything above the store (retrieval, decide,
   reflect, integrate, api) is unchanged.
4. Add an index on `(kind, project)` and `(status)`; add FTS5 on `text` to
   replace the keyword scorer if you want SQL-side search.

Trigger to upgrade: when any single memory file exceeds a few MB or full-scan
search latency is noticeable (roughly tens of thousands of records). Until then,
JSON is simpler, diff-able, and git-friendly.

## Optional vector retrieval

`retrieval.score_record` is a transparent keyword + metadata scorer. To plug in
embeddings: store vectors under `vectors/`, add an embed function, and blend a
cosine-similarity term into `score_record` (or replace `base`). The
`retrieve_relevant_context` interface does not change. Kept optional so the core
has zero dependencies.

---

## Honesty: code-complete vs needs live wiring

**Code-complete and tested here:**
- the full package, all spec-named functions, the upgrade-ready store, the
  decision core, self-review, reflection, the seed of real lessons, the file
  bridge, markdown import/export, the CLI, and 19 passing unit tests.

**Needs live wiring on the box (documented, not done — we do NOT touch prod):**
- pointing the ATLAS outcome loop / deploy pipe at a real brain root (in-process
  import or the file inbox);
- the systemd timer / cron entry actually installed on Hetzner;
- the optional HTTP bridge if you decide you want network writes (file bridge is
  recommended instead).

See `INTEGRATION_PLAN.md` and `deploy/` for the exact staged steps.
