"""
brain.decide
============

The decision core — "the Meta super-smart agent always knows what to do."

Given a situation (a new mistake, win, roadbump, or task), :func:`next_best_action`
recalls the relevant rules + lessons + patterns + roadbumps and returns a
structured recommendation: what to do, why, the confidence, and the supporting
memory it leaned on. This is what agents call *before acting*.

It also exposes :func:`self_review_response` (the REVIEW step) which scores a
drafted response on the user's seven axes and tells the caller whether to
improve before finalizing.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from .retrieval import retrieve_relevant_context, search_memory
from .store import BrainStore

# The seven self-review axes from the spec.
REVIEW_AXES = (
    "accuracy",
    "completeness",
    "clarity",
    "usefulness",
    "strategy",
    "automation_potential",
    "preference_alignment",
)

REVIEW_THRESHOLD = 9  # any axis below this => improve before finalizing


def next_best_action(
    store: BrainStore,
    context: str,
    *,
    project: Optional[str] = None,
    situation: str = "task",
) -> Dict[str, Any]:
    """Recommend the next best action for a situation.

    Parameters
    ----------
    context:
        A description of the situation (e.g. "PG outage while scaling enrich",
        "launching a new Google Ads search campaign", "demo converted in
        roofing vertical").
    project:
        Optional project scope.
    situation:
        One of ``"mistake"``, ``"win"``, ``"roadbump"``, ``"task"`` — tunes which
        record kinds are weighted.

    Returns
    -------
    dict
        ``{"action": str, "rationale": str, "confidence": int,
           "supporting": [...records...], "warnings": [...], "situation": str}``
    """
    bundle = retrieve_relevant_context(store, context, project=project, mark_used=True)
    rules = bundle["rules"]
    relevant = bundle["relevant"]

    # Pull explicit roadbump resolutions — if we've hit this block before, the
    # fix is already known and should be applied instantly.
    roadbumps = search_memory(
        store, context, project=project, kinds=["roadbump"], limit=3, min_score=0.8
    )
    wins = search_memory(
        store, context, project=project, kinds=["win"], limit=3, min_score=0.8
    )
    mistakes = search_memory(
        store, context, project=project, kinds=["mistake"], limit=3, min_score=0.8
    )

    warnings: List[str] = []
    for m in mistakes:
        warnings.append(f"AVOID: {m['text']}")
    for r in rules:
        if r.get("severity", 0) >= 70:
            warnings.append(f"CRITICAL RULE: {r['text']}")

    # Decide the headline action by priority of evidence.
    action, rationale, basis = _synthesize_action(
        situation, roadbumps, wins, rules, relevant, mistakes
    )

    supporting = _dedupe(roadbumps + wins + rules + relevant)
    confidence = _aggregate_confidence(basis)

    return {
        "situation": situation,
        "action": action,
        "rationale": rationale,
        "confidence": confidence,
        "supporting": supporting,
        "warnings": warnings,
    }


def _synthesize_action(
    situation: str,
    roadbumps: List[Dict[str, Any]],
    wins: List[Dict[str, Any]],
    rules: List[Dict[str, Any]],
    relevant: List[Dict[str, Any]],
    mistakes: List[Dict[str, Any]],
):
    """Pick the recommended action and the records it is based on."""
    # 1) Known blocker => apply the recorded resolution immediately.
    if roadbumps:
        rb = roadbumps[0]
        fix = rb.get("meta", {}).get("resolution") or rb["text"]
        return (
            f"Apply the known resolution: {fix}",
            f"This blocker was hit before and resolved; reuse the fix instead of "
            f"re-debugging. (roadbump {rb['id']})",
            [rb] + rules,
        )

    # 2) Proven win => repeat the workflow under its conditions.
    if situation in ("task", "win") and wins:
        w = wins[0]
        cond = w.get("meta", {}).get("conditions", "")
        cond_txt = f" Conditions that made it work: {cond}" if cond else ""
        return (
            f"Repeat the proven workflow: {w['text']}.{cond_txt}",
            f"This workflow succeeded before (win {w['id']}, conf {w['confidence']}); "
            f"repeat it under the same conditions.",
            [w] + rules,
        )

    # 3) Rules + relevant lessons => follow the established standard.
    if rules or relevant:
        lead = rules[0] if rules else relevant[0]
        extra = "; ".join(r["text"] for r in (rules[:1] + relevant[:2]))
        return (
            f"Follow established guidance: {extra}",
            f"Multiple memory records bear on this; apply the highest-confidence "
            f"rule/lesson first (lead {lead['id']}).",
            (rules + relevant)[:4],
        )

    # 4) Nothing known => proceed carefully and record the outcome.
    return (
        "No strong prior memory. Proceed with the standard meta-governance review "
        "(council + Jarvis + brain), act conservatively, and STORE the outcome "
        "(win/mistake/roadbump) so the brain learns from it.",
        "The brain has no high-confidence precedent for this situation; treat it "
        "as a learning opportunity and capture the result.",
        [],
    )


def _aggregate_confidence(basis: List[Dict[str, Any]]) -> int:
    """Confidence of the recommendation = max supporting confidence, lightly
    boosted when several independent records agree."""
    if not basis:
        return 30
    confs = sorted((b.get("confidence", 0) for b in basis), reverse=True)
    agree_boost = min(10, (len(confs) - 1) * 3)
    return min(100, confs[0] + agree_boost)


def _dedupe(records: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    seen = set()
    out = []
    for r in records:
        if r["id"] in seen:
            continue
        seen.add(r["id"])
        out.append(r)
    return out


def decide(store: BrainStore, context: str, **kwargs: Any) -> Dict[str, Any]:
    """Alias for :func:`next_best_action` (the spec names it ``decide()``)."""
    return next_best_action(store, context, **kwargs)


# ---------------------------------------------------------------------------
# Self-review (the REVIEW step)
# ---------------------------------------------------------------------------

def self_review_response(
    scores: Dict[str, int],
    *,
    threshold: int = REVIEW_THRESHOLD,
) -> Dict[str, Any]:
    """Evaluate a drafted response against the seven axes.

    Parameters
    ----------
    scores:
        Mapping of axis name -> 1-10 score. Missing axes are treated as needing
        attention (scored as ``threshold - 1``) so they are surfaced, not hidden.
    threshold:
        Any axis strictly below this triggers an "improve" verdict.

    Returns
    -------
    dict
        ``{"pass": bool, "weak_axes": [...], "scores": {...}, "advice": str}``.
        When ``pass`` is False the caller should improve the response before
        finalizing (the IMPROVE step).
    """
    normalized = {}
    for axis in REVIEW_AXES:
        normalized[axis] = int(scores.get(axis, threshold - 1))

    weak = [axis for axis, val in normalized.items() if val < threshold]
    passed = not weak

    if passed:
        advice = "All axes >= threshold. Finalize."
    else:
        advice = (
            "Improve before finalizing. Weak axes: "
            + ", ".join(f"{a} ({normalized[a]})" for a in weak)
            + "."
        )
    return {"pass": passed, "weak_axes": weak, "scores": normalized, "advice": advice}
