"""
brain
=====

A production-quality, modular, self-learning autonomous memory system — the
"/brain" — that the whole platform (ATLAS Meta Brain, agents, deploy pipe, and
Claude) reads/writes so the system gets smarter every day.

Operating loop
--------------
    RECALL -> REASON -> EXECUTE -> REVIEW -> LEARN -> STORE -> IMPROVE

- RECALL  : ``retrieve_relevant_context`` injects only the relevant prior
            mistakes/preferences/best-practices/rules/patterns/roadbumps.
- REASON  : ``next_best_action`` / ``decide`` recommends what to do.
- REVIEW  : ``self_review_response`` scores the draft on seven axes.
- LEARN   : every correction/outcome -> ``add_lesson`` / ``add_mistake`` / ``add_win``.
- STORE   : the JSON-first :class:`store.BrainStore` persists atomically.
- IMPROVE : ``reflect`` consolidates nightly/weekly (dedup, decay, promote, insight).

Quick start
-----------
    >>> from brain import Brain
    >>> b = Brain("./brain")
    >>> b.add_lesson("Verify against ground truth, not a summary view.",
    ...              project="google_ads", confidence=95, frequency=3)
    >>> b.decide("launching a new Google Ads campaign", project="google_ads")

Modules
-------
- ``schemas``   : record shapes + factory + time helpers
- ``store``     : JSON-first persistence + self-learning write dynamics
- ``retrieval`` : scoring, search, context injection
- ``decide``    : next_best_action + self_review_response
- ``reflect``   : the consolidation / "Dreams" layer
- ``integrate`` : ATLAS / deploy-pipe / agent hooks + markdown cross-feed + file bridge
- ``api``       : the spec-named facade + the ``Brain`` convenience object
- ``cli``       : command-line entrypoints (``python -m brain ...``)
"""

from __future__ import annotations

from .api import (
    Brain,
    add_best_practice,
    add_lesson,
    add_mistake,
    add_pattern,
    add_preference,
    add_roadbump,
    add_roadmap,
    add_win,
    compress_duplicate_lessons,
    decide,
    initialize_brain,
    load_memory,
    next_best_action,
    reflect,
    retrieve_relevant_context,
    save_memory,
    search_memory,
    self_review_response,
    summarize_session,
)
from .store import BrainStore

__version__ = "1.0.0"

__all__ = [
    "Brain",
    "BrainStore",
    "initialize_brain",
    "load_memory",
    "save_memory",
    "add_mistake",
    "add_lesson",
    "add_preference",
    "add_best_practice",
    "add_pattern",
    "add_win",
    "add_roadbump",
    "add_roadmap",
    "search_memory",
    "retrieve_relevant_context",
    "next_best_action",
    "decide",
    "self_review_response",
    "summarize_session",
    "compress_duplicate_lessons",
    "reflect",
    "__version__",
]
