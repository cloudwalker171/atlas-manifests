"""
brain.retrieval
===============

Read-side intelligence for the /brain: scoring, search, and the
"inject only what's relevant" context builder used at the top of the
RECALL -> REASON -> EXECUTE -> REVIEW -> LEARN -> STORE -> IMPROVE loop.

No external dependencies. Relevance uses a transparent keyword-overlap +
metadata-boost score so it is debuggable and deterministic. The interface is
designed so a vector backend can be slotted in later (see ``vectors/`` and the
README) without changing callers.
"""

from __future__ import annotations

import re
from typing import Any, Dict, List, Optional

from .schemas import parse_iso, now_iso
from .store import BrainStore

_WORD_RE = re.compile(r"[a-z0-9]+")


def _tokens(text: str) -> List[str]:
    """Lowercase word tokens, length>=3 (drops noise words like 'a', 'to')."""
    return [w for w in _WORD_RE.findall((text or "").lower()) if len(w) >= 3]


def score_record(record: Dict[str, Any], query: str, project: Optional[str] = None) -> float:
    """Return a relevance score for ``record`` against ``query``.

    The score blends:
    - keyword overlap between the query and the record's text+tags+category,
    - a confidence boost (we trust well-established records more),
    - a severity boost (critical mistakes/roadbumps surface earlier),
    - a project-match boost,
    - a small recency boost.

    Returns 0.0 for archived/superseded records or zero keyword overlap, so the
    caller can threshold cheaply.
    """
    if record.get("status") not in ("active", "planned", "in_progress", "blocked"):
        return 0.0

    q_tokens = set(_tokens(query))
    if not q_tokens:
        return 0.0

    hay = " ".join(
        [record.get("text", ""), record.get("category", ""), " ".join(record.get("tags", []))]
    )
    r_tokens = set(_tokens(hay))
    overlap = q_tokens & r_tokens

    # No keyword overlap => not topically relevant. Rules are the only exception:
    # they are "always-applied", so they may surface within their own project on
    # a faint signal. Everything else returns 0 so high-confidence-but-unrelated
    # records (e.g. a SEV-1 atlas roadbump) never leak into an unrelated query.
    if not overlap:
        if record.get("kind") == "rule" and project and record.get("project") in (project, "global"):
            return round(record.get("confidence", 0) / 100.0 * 1.0, 4)
        return 0.0

    base = len(overlap) / max(1, len(q_tokens))

    score = base * 10.0
    # Metadata boosts are GATED on real keyword overlap (computed above).
    score += record.get("confidence", 0) / 100.0 * 2.0
    score += record.get("severity", 0) / 100.0 * 1.5

    if project and record.get("project") == project:
        score += 2.0
    elif project and record.get("project") not in (project, "global"):
        # Cross-project record on a project-scoped query: penalize so it only
        # wins when its keyword overlap is genuinely strong.
        score -= 2.0
    if record.get("kind") == "rule":
        score += 1.5  # always-applied rules get a nudge

    # Recency: small boost for records used in the last ~7 days.
    last = parse_iso(record.get("last_used"))
    if last is not None:
        age_days = (parse_iso(now_iso()) - last).days
        if age_days <= 7:
            score += 0.5

    return round(score, 4)


def search_memory(
    store: BrainStore,
    query: str,
    *,
    project: Optional[str] = None,
    kinds: Optional[List[str]] = None,
    limit: int = 10,
    min_score: float = 0.5,
    mark_used: bool = False,
) -> List[Dict[str, Any]]:
    """Search across memory and return the top matching records.

    Parameters
    ----------
    query:
        Free-text situation/question.
    project:
        Optional project scope to boost (does not hard-filter unless you also
        pass it in ``kinds`` filtering upstream).
    kinds:
        Restrict to these record kinds (default: all).
    limit:
        Max records to return.
    min_score:
        Drop records below this relevance.
    mark_used:
        If True, stamp ``last_used`` on returned records (feeds reinforcement /
        decay accounting).

    Returns
    -------
    list of dict
        Records sorted by descending relevance, each with a ``_score`` key.
    """
    candidates = store.load_all()
    if kinds:
        candidates = [r for r in candidates if r.get("kind") in kinds]

    scored: List[Dict[str, Any]] = []
    for rec in candidates:
        s = score_record(rec, query, project=project)
        if s >= min_score:
            rec = dict(rec)
            rec["_score"] = s
            scored.append(rec)

    scored.sort(key=lambda r: r["_score"], reverse=True)
    top = scored[:limit]

    if mark_used and top:
        _stamp_last_used(store, top)

    return top


def _stamp_last_used(store: BrainStore, records: List[Dict[str, Any]]) -> None:
    """Persist a ``last_used`` bump for the given records (best effort)."""
    by_kind: Dict[str, set] = {}
    for r in records:
        by_kind.setdefault(r["kind"], set()).add(r["id"])
    for kind, ids in by_kind.items():
        live = store.load(kind)
        changed = False
        for rec in live:
            if rec.get("id") in ids:
                rec["last_used"] = now_iso()
                changed = True
        if changed:
            store.save(kind, live)


def retrieve_relevant_context(
    store: BrainStore,
    query: str,
    *,
    project: Optional[str] = None,
    max_items: int = 8,
    mark_used: bool = True,
) -> Dict[str, Any]:
    """Build a compact, *non-overloading* context bundle for a new task.

    This is the RECALL step. It pulls the most relevant past mistakes,
    preferences, best-practices, project rules, patterns, wins, and roadbumps —
    but caps the total so the model is not drowned. Always-applied ``rule``
    records are included up to a small reserved slot regardless of query overlap.

    Returns
    -------
    dict
        ``{"rules": [...], "relevant": [...], "as_text": str, "count": int}``
        where ``as_text`` is a ready-to-inject bulletized briefing.
    """
    # Reserve slots for always-applied rules in this project (or global).
    rules = [
        r
        for r in store.load("rule")
        if r.get("status") == "active"
        and r.get("project") in (project, "global", None)
    ]
    rules.sort(key=lambda r: (r.get("confidence", 0), r.get("severity", 0)), reverse=True)
    rules = rules[:4]

    relevant = search_memory(
        store,
        query,
        project=project,
        limit=max_items,
        min_score=0.6,
        mark_used=mark_used,
    )
    # Don't double-list a rule that already matched.
    rule_ids = {r["id"] for r in rules}
    relevant = [r for r in relevant if r["id"] not in rule_ids][: max_items]

    as_text = _format_briefing(rules, relevant)
    return {
        "rules": rules,
        "relevant": relevant,
        "as_text": as_text,
        "count": len(rules) + len(relevant),
    }


def _format_briefing(rules: List[Dict[str, Any]], relevant: List[Dict[str, Any]]) -> str:
    """Render rules + relevant records as a short markdown briefing."""
    lines: List[str] = []
    if rules:
        lines.append("ALWAYS-APPLIED RULES:")
        for r in rules:
            lines.append(f"  - [{r['project']}] {r['text']} (conf {r['confidence']})")
    if relevant:
        lines.append("RELEVANT MEMORY:")
        for r in relevant:
            sev = f", sev {r['severity']}" if r.get("severity") else ""
            lines.append(
                f"  - ({r['kind']}/{r['project']}) {r['text']} "
                f"(conf {r['confidence']}{sev})"
            )
    if not lines:
        return "(no relevant prior memory)"
    return "\n".join(lines)
