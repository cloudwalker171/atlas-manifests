"""
brain.api
=========

The ergonomic, spec-named facade over the package. This is what most callers
import: it wires a :class:`brain.store.BrainStore` to the retrieval, decision,
and reflection layers and exposes the exact functions the user's spec asked for:

    initialize_brain, load_memory, save_memory, add_mistake, add_lesson,
    add_preference, add_best_practice, add_win, add_roadbump, add_roadmap,
    add_pattern, search_memory, retrieve_relevant_context, decide /
    next_best_action, self_review_response, summarize_session,
    compress_duplicate_lessons, reflect.

A single :class:`Brain` object bundles them with a default root so usage stays
one-liner simple, while the underlying functions remain independently callable.
"""

from __future__ import annotations

import os
from typing import Any, Dict, List, Optional

from . import decide as _decide
from . import reflect as _reflect
from . import retrieval as _retrieval
from .integrate import (
    agent_preflight,
    drain_inbox,
    export_to_markdown,
    import_from_markdown,
    record_atlas_outcome,
    record_deploy_roadbump,
)
from .schemas import make_record, now_iso
from .store import BrainStore

DEFAULT_ROOT = os.environ.get("BRAIN_ROOT", os.path.join(os.getcwd(), "brain"))


# ---------------------------------------------------------------------------
# Spec-named free functions (work on an explicit store)
# ---------------------------------------------------------------------------

def initialize_brain(root: str = DEFAULT_ROOT, backend: str = "json") -> BrainStore:
    """Create the brain folder structure and return a ready :class:`BrainStore`."""
    store = BrainStore(root, backend=backend)
    store.initialize()
    return store


def load_memory(store: BrainStore, kind: Optional[str] = None) -> List[Dict[str, Any]]:
    """Load one ``kind`` of memory, or everything if ``kind`` is None."""
    return store.load(kind) if kind else store.load_all()


def save_memory(store: BrainStore, kind: str, records: List[Dict[str, Any]]) -> None:
    """Persist all records of one ``kind``."""
    store.save(kind, records)


def add_mistake(store: BrainStore, text: str, **kw: Any) -> Dict[str, Any]:
    """Record a mistake (defaults to elevated severity)."""
    kw.setdefault("severity", 50)
    kw.setdefault("confidence", 70)
    return store.add("mistake", text, **kw)


def add_lesson(store: BrainStore, text: str, **kw: Any) -> Dict[str, Any]:
    """Record a generalized lesson (often from a user correction)."""
    kw.setdefault("confidence", 65)
    return store.add("lesson", text, **kw)


def add_preference(store: BrainStore, text: str, **kw: Any) -> Dict[str, Any]:
    """Record a durable user/operator preference."""
    kw.setdefault("confidence", 80)
    return store.add("preference", text, **kw)


def add_best_practice(store: BrainStore, text: str, **kw: Any) -> Dict[str, Any]:
    """Record a positive standard to apply."""
    kw.setdefault("confidence", 75)
    return store.add("best_practice", text, **kw)


def add_pattern(store: BrainStore, text: str, **kw: Any) -> Dict[str, Any]:
    """Record an observed recurring pattern."""
    return store.add("pattern", text, **kw)


def add_win(store: BrainStore, text: str, *, conditions: str = "", **kw: Any) -> Dict[str, Any]:
    """Record a successful workflow worth repeating, with its conditions."""
    meta = kw.pop("meta", {})
    if conditions:
        meta["conditions"] = conditions
    kw.setdefault("confidence", 70)
    return store.add("win", text, meta=meta, **kw)


def add_roadbump(
    store: BrainStore, blocker: str, *, resolution: str = "", **kw: Any
) -> Dict[str, Any]:
    """Record a blocker + exactly how it was resolved (so it's instantly solved next time)."""
    meta = kw.pop("meta", {})
    if resolution:
        meta["resolution"] = resolution
    kw.setdefault("confidence", 80)
    kw.setdefault("severity", 60)
    return store.add("roadbump", blocker, meta=meta, **kw)


def add_roadmap(
    store: BrainStore,
    item: str,
    *,
    status: str = "planned",
    priority: int = 50,
    **kw: Any,
) -> Dict[str, Any]:
    """Record a planned roadmap item with status + priority (what's next)."""
    meta = kw.pop("meta", {})
    meta["priority"] = priority
    kw["status"] = status
    return store.add("roadmap", item, meta=meta, reinforce=False, **kw)


def search_memory(store: BrainStore, query: str, **kw: Any) -> List[Dict[str, Any]]:
    """Relevance-search memory (see :func:`brain.retrieval.search_memory`)."""
    return _retrieval.search_memory(store, query, **kw)


def retrieve_relevant_context(store: BrainStore, query: str, **kw: Any) -> Dict[str, Any]:
    """Build the RECALL briefing (see :func:`brain.retrieval.retrieve_relevant_context`)."""
    return _retrieval.retrieve_relevant_context(store, query, **kw)


def next_best_action(store: BrainStore, context: str, **kw: Any) -> Dict[str, Any]:
    """The decision core (see :func:`brain.decide.next_best_action`)."""
    return _decide.next_best_action(store, context, **kw)


def decide(store: BrainStore, context: str, **kw: Any) -> Dict[str, Any]:
    """Alias for :func:`next_best_action`."""
    return _decide.next_best_action(store, context, **kw)


def self_review_response(scores: Dict[str, int], **kw: Any) -> Dict[str, Any]:
    """Score a drafted response on the seven axes (the REVIEW step)."""
    return _decide.self_review_response(scores, **kw)


def compress_duplicate_lessons(store: BrainStore, kind: str = "lesson") -> int:
    """Merge near-duplicate records of one kind."""
    return _reflect.compress_duplicate_lessons(store, kind)


def reflect(store: BrainStore) -> Dict[str, Any]:
    """Run the full nightly/weekly consolidation pass."""
    return _reflect.reflect(store)


def summarize_session(
    store: BrainStore,
    *,
    project: str = "global",
    highlights: Optional[List[str]] = None,
    mistakes: Optional[List[str]] = None,
    wins: Optional[List[str]] = None,
    next_steps: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """Write a session summary record after a session.

    Captures highlights/mistakes/wins/next-steps into a ``summary`` record so the
    brain has a running narrative of what happened.
    """
    parts = []
    if highlights:
        parts.append("Highlights: " + "; ".join(highlights))
    if wins:
        parts.append("Wins: " + "; ".join(wins))
    if mistakes:
        parts.append("Mistakes: " + "; ".join(mistakes))
    if next_steps:
        parts.append("Next: " + "; ".join(next_steps))
    text = f"Session summary ({now_iso()}) [{project}]. " + " | ".join(parts or ["(no notes)"])

    summary = make_record(
        "summary",
        text,
        project=project,
        category="session",
        confidence=100,
        source="session",
        meta={
            "highlights": highlights or [],
            "wins": wins or [],
            "mistakes": mistakes or [],
            "next_steps": next_steps or [],
        },
    )
    rows = store.load("summary")
    rows.append(summary)
    store.save("summary", rows)
    return summary


# ---------------------------------------------------------------------------
# Convenience object
# ---------------------------------------------------------------------------

class Brain:
    """A bound brain: a store plus all spec functions as methods.

    Example
    -------
    >>> brain = Brain("/path/to/brain")
    >>> brain.add_lesson("Always verify against ground truth, not a summary view.")
    >>> brain.decide("launching a new Google Ads search campaign", project="google_ads")
    """

    def __init__(self, root: str = DEFAULT_ROOT, backend: str = "json") -> None:
        self.store = initialize_brain(root, backend=backend)
        self.root = self.store.root

    # --- writers ---
    def add_mistake(self, text: str, **kw: Any) -> Dict[str, Any]:
        return add_mistake(self.store, text, **kw)

    def add_lesson(self, text: str, **kw: Any) -> Dict[str, Any]:
        return add_lesson(self.store, text, **kw)

    def add_preference(self, text: str, **kw: Any) -> Dict[str, Any]:
        return add_preference(self.store, text, **kw)

    def add_best_practice(self, text: str, **kw: Any) -> Dict[str, Any]:
        return add_best_practice(self.store, text, **kw)

    def add_pattern(self, text: str, **kw: Any) -> Dict[str, Any]:
        return add_pattern(self.store, text, **kw)

    def add_win(self, text: str, **kw: Any) -> Dict[str, Any]:
        return add_win(self.store, text, **kw)

    def add_roadbump(self, blocker: str, **kw: Any) -> Dict[str, Any]:
        return add_roadbump(self.store, blocker, **kw)

    def add_roadmap(self, item: str, **kw: Any) -> Dict[str, Any]:
        return add_roadmap(self.store, item, **kw)

    # --- readers / decision ---
    def search(self, query: str, **kw: Any) -> List[Dict[str, Any]]:
        return search_memory(self.store, query, **kw)

    def recall(self, query: str, **kw: Any) -> Dict[str, Any]:
        return retrieve_relevant_context(self.store, query, **kw)

    def decide(self, context: str, **kw: Any) -> Dict[str, Any]:
        return next_best_action(self.store, context, **kw)

    def preflight(self, task: str, **kw: Any) -> Dict[str, Any]:
        return agent_preflight(self.store, task, **kw)

    def review(self, scores: Dict[str, int], **kw: Any) -> Dict[str, Any]:
        return self_review_response(scores, **kw)

    # --- session / maintenance ---
    def summarize_session(self, **kw: Any) -> Dict[str, Any]:
        return summarize_session(self.store, **kw)

    def reflect(self) -> Dict[str, Any]:
        return reflect(self.store)

    def drain_inbox(self, path: Optional[str] = None) -> Dict[str, Any]:
        return drain_inbox(self.store, path)

    # --- integration ---
    def record_atlas_outcome(self, **kw: Any) -> Dict[str, Any]:
        return record_atlas_outcome(self.store, **kw)

    def record_deploy_roadbump(self, **kw: Any) -> Dict[str, Any]:
        return record_deploy_roadbump(self.store, **kw)

    def import_from_markdown(self, markdown_dir: str, **kw: Any) -> Dict[str, Any]:
        return import_from_markdown(self.store, markdown_dir, **kw)

    def export_to_markdown(self, out_dir: str, **kw: Any) -> Dict[str, Any]:
        return export_to_markdown(self.store, out_dir, **kw)
