"""
brain.reflect
=============

The consolidation / "Dreams" layer — runnable on a schedule (nightly/weekly).

Reflection makes the brain smarter over time without any live traffic:

- **compress_duplicate_lessons** : merge near-duplicate records, summing
  frequency and keeping the highest confidence.
- **decay**                      : lower confidence on stale records (unused for
  ``DECAY_STALE_DAYS``); deep decay archives near-dead records.
- **reinforce_repeats**          : raise confidence where frequency is high.
- **promote_rules**              : promote high-confidence repeated lessons.
- **extract_insights**           : roll up higher-level patterns (e.g. a cluster
  of related lessons -> a meta-lesson).
- **weekly_summary**             : write a curated learning summary.

Entry point :func:`reflect` runs the whole pass and returns a report dict.
``python -m brain.reflect`` (see ``cli.py`` / ``__main__``) runs it from cron.
"""

from __future__ import annotations

from datetime import timedelta
from typing import Any, Dict, List

from .schemas import (
    ARCHIVE_CONFIDENCE,
    DECAY_STALE_DAYS,
    MEMORY_FILES,
    PROMOTE_CONFIDENCE,
    PROMOTE_FREQUENCY,
    clamp,
    make_record,
    normalize_text,
    now_iso,
    parse_iso,
)
from .store import BrainStore


def compress_duplicate_lessons(store: BrainStore, kind: str = "lesson") -> int:
    """Merge near-duplicate records of one ``kind``. Returns merged count.

    Duplicates are detected by normalized text within the same project. The
    survivor keeps the highest confidence and the summed frequency; the others
    are archived with a pointer to the survivor.
    """
    records = store.load(kind)
    survivors: Dict[str, Dict[str, Any]] = {}
    merged_out: List[Dict[str, Any]] = []
    merged_count = 0

    for rec in records:
        if rec.get("status") != "active":
            survivors.setdefault(rec["id"], rec)
            continue
        key = (rec.get("project", "global"), normalize_text(rec.get("text", "")))
        if key in survivors:
            keep = survivors[key]
            keep["frequency"] = keep.get("frequency", 1) + rec.get("frequency", 1)
            keep["confidence"] = max(keep.get("confidence", 0), rec.get("confidence", 0))
            keep["tags"] = sorted(set(keep.get("tags", [])) | set(rec.get("tags", [])))
            keep["severity"] = max(keep.get("severity", 0), rec.get("severity", 0))
            keep["updated_at"] = now_iso()
            rec["status"] = "merged"
            rec.setdefault("meta", {})["merged_into"] = keep["id"]
            merged_out.append(rec)
            merged_count += 1
        else:
            survivors[key] = rec

    if merged_count:
        kept = [r for r in records if r.get("status") != "merged"]
        store.save(kind, kept)
        store.archive(merged_out, reason="duplicate-merged")
    return merged_count


def decay_and_reinforce(store: BrainStore) -> Dict[str, int]:
    """Apply staleness decay and frequency reinforcement across all kinds.

    Returns counts of ``{"decayed": n, "reinforced": n}``.
    """
    decayed = reinforced = 0
    cutoff = parse_iso(now_iso()) - timedelta(days=DECAY_STALE_DAYS)

    for kind in MEMORY_FILES:
        records = store.load(kind)
        changed = False
        for rec in records:
            if rec.get("status") != "active":
                continue
            last = parse_iso(rec.get("last_used"))
            # Decay: unused since cutoff -> lower confidence.
            if last is not None and last < cutoff:
                old = rec.get("confidence", 0)
                rec["confidence"] = clamp(old - 5, 0, 100)
                if rec["confidence"] != old:
                    decayed += 1
                    changed = True
            # Reinforce: high frequency lifts confidence (capped).
            if rec.get("frequency", 1) >= 3:
                old = rec.get("confidence", 0)
                rec["confidence"] = clamp(old + 2, 0, 100)
                if rec["confidence"] != old:
                    reinforced += 1
                    changed = True
            if changed:
                rec["updated_at"] = now_iso()
        if changed:
            store.save(kind, records)
    return {"decayed": decayed, "reinforced": reinforced}


def archive_irrelevant(store: BrainStore) -> int:
    """Archive active records that have decayed below ARCHIVE_CONFIDENCE.

    Returns the number archived. Roadmap items and rules are never auto-archived
    by confidence (roadmap is status-driven; rules are intentional).
    """
    archived = 0
    for kind in MEMORY_FILES:
        if kind in ("roadmap", "rule"):
            continue
        records = store.load(kind)
        to_archive = [
            r
            for r in records
            if r.get("status") == "active" and r.get("confidence", 0) <= ARCHIVE_CONFIDENCE
        ]
        if to_archive:
            keep = [r for r in records if r not in to_archive]
            store.save(kind, keep)
            store.archive(to_archive, reason="low-confidence-stale")
            archived += len(to_archive)
    return archived


def promote_rules(store: BrainStore) -> int:
    """Promote eligible lessons/best_practices to rules. Returns promoted count."""
    promoted = 0
    rules = store.load("rule")
    promoted_sources = {r.get("meta", {}).get("promoted_from") for r in rules}

    for kind in ("lesson", "best_practice"):
        for rec in store.load(kind):
            if rec.get("status") != "active":
                continue
            if rec["id"] in promoted_sources:
                continue
            if (
                rec.get("confidence", 0) >= PROMOTE_CONFIDENCE
                and rec.get("frequency", 0) >= PROMOTE_FREQUENCY
            ):
                rule = make_record(
                    "rule",
                    rec["text"],
                    project=rec.get("project", "global"),
                    category=rec.get("category", "general"),
                    confidence=rec["confidence"],
                    frequency=rec["frequency"],
                    severity=rec.get("severity", 0),
                    tags=rec.get("tags", []),
                    source="reflect_promote",
                    links=[rec["id"]],
                    meta={"promoted_from": rec["id"]},
                )
                rules.append(rule)
                promoted += 1
    if promoted:
        store.save("rule", rules)
    return promoted


def extract_insights(store: BrainStore, min_cluster: int = 3) -> int:
    """Roll up clusters of related records into higher-level pattern records.

    A simple, transparent heuristic: group active lessons/mistakes by their most
    common tag; if a tag appears across >= ``min_cluster`` records, write a
    ``pattern`` meta-record noting the recurring theme. Returns insights created.
    """
    tag_to_records: Dict[str, List[Dict[str, Any]]] = {}
    for kind in ("lesson", "mistake", "roadbump"):
        for rec in store.load(kind):
            if rec.get("status") != "active":
                continue
            for tag in rec.get("tags", []):
                tag_to_records.setdefault(tag, []).append(rec)

    existing = {p.get("meta", {}).get("insight_tag") for p in store.load("pattern")}
    created = 0
    patterns = store.load("pattern")
    for tag, recs in tag_to_records.items():
        if len(recs) < min_cluster or tag in existing:
            continue
        projects = sorted({r.get("project", "global") for r in recs})
        insight = make_record(
            "pattern",
            f"Recurring theme '{tag}' across {len(recs)} records "
            f"(projects: {', '.join(projects)}). Treat '{tag}' as a known focus area.",
            project=projects[0] if len(projects) == 1 else "global",
            category="meta_insight",
            confidence=min(95, 60 + len(recs) * 5),
            frequency=len(recs),
            tags=[tag, "insight"],
            source="reflect_insight",
            links=[r["id"] for r in recs],
            meta={"insight_tag": tag, "cluster_size": len(recs)},
        )
        patterns.append(insight)
        created += 1
    if created:
        store.save("pattern", patterns)
    return created


def write_summary(store: BrainStore, report: Dict[str, Any]) -> Dict[str, Any]:
    """Write a curated reflection summary record + a JSONL log line."""
    counts = {kind: len(store.load(kind)) for kind in MEMORY_FILES}
    text = (
        f"Reflection run {now_iso()}: "
        f"merged {report.get('merged', 0)} dupes, "
        f"decayed {report.get('decayed', 0)}, reinforced {report.get('reinforced', 0)}, "
        f"archived {report.get('archived', 0)}, promoted {report.get('promoted', 0)} rules, "
        f"extracted {report.get('insights', 0)} insights. "
        f"Active counts: {counts}."
    )
    summary = make_record(
        "summary",
        text,
        project="global",
        category="reflection",
        confidence=100,
        source="reflect",
        meta={"report": report, "counts": counts},
    )
    summaries = store.load("summary")
    summaries.append(summary)
    store.save("summary", summaries)
    store.append_log("reflect.log.jsonl", {"ts": now_iso(), "report": report})
    return summary


def reflect(store: BrainStore) -> Dict[str, Any]:
    """Run the full consolidation pass. Returns a report dict.

    Order matters: merge -> decay/reinforce -> archive -> promote -> insights ->
    summarize. This is the single function a scheduler calls.
    """
    merged = 0
    for kind in ("lesson", "mistake", "best_practice", "preference", "pattern", "win", "roadbump"):
        merged += compress_duplicate_lessons(store, kind)

    dr = decay_and_reinforce(store)
    archived = archive_irrelevant(store)
    promoted = promote_rules(store)
    insights = extract_insights(store)

    report = {
        "ts": now_iso(),
        "merged": merged,
        "decayed": dr["decayed"],
        "reinforced": dr["reinforced"],
        "archived": archived,
        "promoted": promoted,
        "insights": insights,
    }
    write_summary(store, report)
    return report


def _main() -> int:
    """``python -m brain.reflect [--root DIR]`` — the scheduled consolidation pass."""
    import argparse
    import json

    parser = argparse.ArgumentParser(prog="brain.reflect", description="Run the brain consolidation pass")
    parser.add_argument("--root", default="./brain", help="brain root directory")
    parser.add_argument("--drain", action="store_true", help="drain the file inbox first")
    args = parser.parse_args()

    store = BrainStore(args.root)
    store.initialize()
    if args.drain:
        from .integrate import drain_inbox

        drain_inbox(store)
    report = reflect(store)
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(_main())
