"""
brain.seed
==========

Seed the brain with the REAL, hard-won lessons from this project so it starts
smart, not empty. These records are distilled from the live operational memory
(the native Claude markdown memory) and the project reports in Downloads/.

Each entry carries an honest confidence (battle-tested rules are high; newer or
softer learnings are lower) so the self-learning dynamics behave correctly from
day one. Run via ``python -m brain seed`` or :func:`seed_brain`.

NOTE on provenance: every lesson below was confirmed against the user's stored
memory / reports as of June 2026. They are operating learnings, not secrets — no
credentials, tokens, or PII are seeded (those are intentionally excluded).
"""

from __future__ import annotations

from typing import Any, Dict

from .store import BrainStore


def seed_brain(store: BrainStore) -> Dict[str, Any]:
    """Load the real project lessons. Idempotent (reinforces on re-run)."""
    created = 0

    def add(kind: str, text: str, **kw: Any) -> None:
        nonlocal created
        # 'priority' is a roadmap-only concept stored in meta, not a core field.
        if "priority" in kw:
            meta = kw.pop("meta", {})
            meta["priority"] = kw.pop("priority")
            kw["meta"] = meta
        if kind == "roadmap":
            kw.setdefault("reinforce", False)
        store.add(kind, text, **kw)
        created += 1

    # ----------------------------------------------------------------- ATLAS
    add(
        "roadbump",
        "Scaling the enrichment pool too high caused a SEV-1 Postgres outage on the 8GB Hetzner box.",
        project="atlas",
        category="scaling",
        confidence=95,
        frequency=3,
        severity=95,
        tags=["postgres", "enrichment", "scaling", "sev1"],
        source="seed",
        meta={
            "resolution": "Never scale the enrich pool past PG-safe limits; safe sustained rate is "
            "~1,200/min on the 8GB box (v4 lane puller). Add lanes only with headroom; intake (~28k/min) "
            "always outruns enrichment, so the unlock is ICP targeting, not more lanes."
        },
    )
    add(
        "lesson",
        "Intake always outruns enrichment; the fix is ICP TARGETING (only enrich businesses fitting the "
        "ICP), not adding more enrichment lanes. Quality over hoarding.",
        project="atlas",
        category="architecture",
        confidence=92,
        frequency=3,
        severity=40,
        tags=["icp", "enrichment", "architecture"],
        source="seed",
    )
    add(
        "lesson",
        "The enriched_per_min field in enrich-hetzner.json is MISLEADING (last-writer-wins across workers). "
        "Measure the real DB 'done' delta instead of trusting that field.",
        project="atlas",
        category="metrics",
        confidence=90,
        frequency=2,
        severity=30,
        tags=["metrics", "measurement", "enrichment"],
        source="seed",
    )
    add(
        "best_practice",
        "Reversible purge, never hard-delete: archive low-ICP + enrich-fail + aged(>=90d) rows to a "
        "compressed cold store (archive.business_cold + tombstone) with one-command RESTORE. Use an additive "
        "icp_status column, NOT lifecycle (lifecycle has a PG CHECK constraint that aborts the sweep).",
        project="atlas",
        category="data_management",
        confidence=90,
        frequency=2,
        severity=60,
        tags=["purge", "archive", "postgres", "reversible"],
        source="seed",
    )
    add(
        "roadbump",
        "InterServer (CentOS7/OpenVZ/py3.6, EOL) fails to install psycopg2 from source (missing Python.h, "
        "dead yum mirrors).",
        project="atlas",
        category="deploy",
        confidence=95,
        frequency=3,
        severity=70,
        tags=["interserver", "psycopg2", "centos7", "deploy"],
        source="seed",
        meta={
            "resolution": "Pin psycopg2-binary==2.8.6 with --only-binary :all: (ships a prebuilt cp36 "
            "manylinux1 wheel, no compiler needed). 2.9+ dropped cp36 wheels. pg8000 (pure-python) is the "
            "zero-compile fallback. scp is disabled on that box — use ssh+curl|bash, not scp; SSH login is "
            "password-based, not key."
        },
    )
    add(
        "roadbump",
        "Uploading a WP plugin to DreamHost via wp-admin can CORRUPT the file on overwrite -> fatal PHP "
        "error -> whole-site 500.",
        project="tuanichat",
        category="deploy",
        confidence=90,
        frequency=2,
        severity=85,
        tags=["dreamhost", "wordpress", "deploy", "rollback"],
        source="seed",
        meta={
            "resolution": "Recover by renaming the plugin folder to .disabled via DreamHost File Manager. "
            "Verify render after each live plugin update; keep a one-click rollback. The chat subdomain uses "
            "a SEPARATE DreamHost SFTP user from the main site."
        },
    )
    add(
        "roadbump",
        "Git pushes to the atlas-manifests repo hit non-fast-forward because the box pushes status every ~30s.",
        project="atlas",
        category="deploy",
        confidence=88,
        frequency=2,
        severity=50,
        tags=["git", "deploy", "manifests"],
        source="seed",
        meta={
            "resolution": "ALWAYS git fetch && rebase origin/main, then push, with a retry loop. "
            "'git push | tail' masks failure exit codes — verify the push landed with "
            "'git show origin/main:<file>'."
        },
    )
    add(
        "lesson",
        "Real-time new-business sources: CT/SSL is the spine, but crt.sh is overloaded (last resort only), "
        "CertStream firehose died ~Mar 2025, Let's Encrypt Oak is RETIRED, Sectigo Sabre/Mammoth frozen. "
        "Use a multi-CT-log collector (rotating Google Argon/Xenon, Cloudflare Nimbus, Sectigo "
        "Elephant/Tiger, DigiCert) with failover.",
        project="atlas",
        category="data_sources",
        confidence=85,
        frequency=2,
        severity=30,
        tags=["ct_logs", "ssl", "data_sources", "real_time"],
        source="seed",
    )

    # ------------------------------------------------------------- Google Ads
    add(
        "lesson",
        "Verify against GROUND TRUTH, not a summary view. A conversion fix reported 'done, verified twice' "
        "had NEVER landed — the verifier checked the campaign-summary view (shows only Purchase primary) "
        "instead of the raw conversion-actions table (showed 6-7 junk actions still primary). Open the raw "
        "list and confirm each action individually.",
        project="google_ads",
        category="verification",
        confidence=98,
        frequency=4,
        severity=90,
        tags=["verification", "ground_truth", "conversions", "meta_principle"],
        source="seed",
    )
    add(
        "best_practice",
        "Verify twice = verify the WHOLE SYSTEM end-to-end against ground truth, not just the field you "
        "changed and not against a summary. A setting that 'saved' but doesn't produce its intended effect "
        "is still broken. Re-audit the entire surrounding system after every change.",
        project="global",
        category="verification",
        confidence=96,
        frequency=4,
        severity=80,
        tags=["verification", "meta_principle", "end_to_end"],
        source="seed",
    )
    add(
        "preference",
        "Google Ads (Art Center Gallery): UI-only (NOT Adspirer/API); only the GA4 Purchase conversion value "
        "is accurate; BI campaigns hold ONLY purchase-intent keywords; never remove negatives that admit "
        "non-BI traffic; budget cap $83/day; NO Fabio image assets anywhere; verify image attribution before "
        "use; confirm analysis before any change.",
        project="google_ads",
        category="client_rules",
        confidence=95,
        frequency=3,
        severity=70,
        tags=["art_center", "client_rules", "google_ads"],
        source="seed",
    )
    add(
        "best_practice",
        "Standing rule: a $0.00-price product must NEVER be promoted/advertised (PMax/Shopping). Exclude "
        "price=0 items from the running product set. Applies to all clients.",
        project="google_ads",
        category="client_rules",
        confidence=92,
        frequency=2,
        severity=50,
        tags=["pmax", "shopping", "zero_price"],
        source="seed",
    )
    add(
        "best_practice",
        "Google Ads launch QC (binding 10-point): campaign-specific conversion goals -> Purchase only; "
        "Purchase the SOLE primary (every other action secondary); negatives applied AT launch (not later); "
        "Search Partners + Display OFF on Search; Presence-only locations; manual CPC cap at launch; full "
        "RSAs + verified-live promo assets; every final URL loads 200; PMax scoped to top sellers; "
        "auto-apply OFF. Report a PASS/FIX table, verified twice.",
        project="google_ads",
        category="launch_qc",
        confidence=94,
        frequency=3,
        severity=70,
        tags=["launch", "qc", "checklist", "google_ads"],
        source="seed",
    )
    add(
        "lesson",
        "Only audit/manage products we ACTUALLY run. Art Center promotes ONLY Michael Godard via the live "
        "PMax 'Michael Godard Asset' set — not the ~13K merchant catalog. Don't spend time fixing feed items "
        "outside the running product set.",
        project="google_ads",
        category="scope",
        confidence=88,
        frequency=2,
        severity=30,
        tags=["scope", "art_center", "pmax"],
        source="seed",
    )

    # --------------------------------------------------------- standing prefs
    add(
        "preference",
        "Be hands-off / do-it-for-me: do the work FOR the user. Drive the browser for web UIs (e.g. "
        "WordPress deploys) and the auto-pull pipe for servers; never make him do steps Claude can do. "
        "Minimize command-pasting.",
        project="global",
        category="operating_style",
        confidence=95,
        frequency=3,
        severity=40,
        tags=["hands_off", "automation", "operating_style"],
        source="seed",
    )
    add(
        "preference",
        "Autonomous deploy directive: default to driving work THROUGH the auto-pull pipe (publish signed "
        "manifests -> the box self-applies on a ~3-min timer), council + Jarvis reviewed. Only ask the user "
        "for a credential, a payment, an approval on an irreversible action, or a real blocker.",
        project="global",
        category="operating_style",
        confidence=93,
        frequency=3,
        severity=50,
        tags=["deploy", "pipe", "autonomy"],
        source="seed",
    )
    add(
        "best_practice",
        "Every apply must take a RESTORE POINT first (pg_dump + tar, keep last ~5, symlink last-good), run a "
        "HEALTH CHECK after, and AUTO-ROLLBACK on failure. Lifeline guardrails: fail-closed reject any "
        "manifest that would disable the autopull service/timer, touch sshd_config / PasswordAuthentication "
        "/ PermitRootLogin, drop the UFW SSH allow, or change deploy keys. The pipe can never sever SSH or "
        "itself.",
        project="atlas",
        category="resilience",
        confidence=92,
        frequency=2,
        severity=85,
        tags=["resilience", "rollback", "lifeline", "deploy"],
        source="seed",
    )
    add(
        "preference",
        "Real-time reporting: all reports/dashboards show REAL-TIME live numbers + real-time dates, never "
        "stale/placeholder values. The user wants to watch the numbers climb.",
        project="global",
        category="reporting",
        confidence=90,
        frequency=2,
        severity=30,
        tags=["reporting", "realtime", "dashboards"],
        source="seed",
    )
    add(
        "preference",
        "Meta-governance: route every non-trivial request through Meta Council (multi-perspective review) + "
        "Meta Jarvis (orchestration/observability) + Meta Brain (EV/decision ranking) and make the honest "
        "best choice. 'Best' includes telling the user when something is risky or not yet live.",
        project="global",
        category="governance",
        confidence=90,
        frequency=2,
        severity=40,
        tags=["governance", "meta", "council", "jarvis"],
        source="seed",
    )
    add(
        "best_practice",
        "Project isolation / closed-loop: every project is sealed. Never mix two projects (data, accounts, "
        "credentials, deploys) by accident.",
        project="global",
        category="safety",
        confidence=92,
        frequency=2,
        severity=70,
        tags=["isolation", "safety", "closed_loop"],
        source="seed",
    )
    add(
        "lesson",
        "Honesty rule: don't claim a deploy succeeded until verified; no overclaiming. Be explicit about what "
        "is code-complete vs needs live wiring on the box.",
        project="global",
        category="honesty",
        confidence=95,
        frequency=3,
        severity=60,
        tags=["honesty", "verification"],
        source="seed",
    )

    # ----------------------------------------------------------------- wins
    add(
        "win",
        "The auto-pull manifest pipe (publish signed manifests to GitHub -> Hetzner box pulls, HMAC-verifies, "
        "applies on a timer) gives Claude+Jarvis real operational control while keeping the user out of the "
        "command-pasting loop.",
        project="atlas",
        category="automation",
        confidence=85,
        frequency=2,
        tags=["pipe", "automation", "deploy"],
        source="seed",
        meta={"conditions": "Sandbox can reach github.com; box pulls + HMAC-verifies; seq strictly increasing; "
              "3-min pull interval; restore-point + health-check + auto-rollback on every apply."},
    )
    add(
        "win",
        "TuaniChat outcome loop (demo_opened/chatted/lead_captured/converted tagged by industry+source) flips "
        "the Smart Brain from FIFO to LEARNED ranking — the path to 'which industries convert' learning.",
        project="tuanichat",
        category="learning_loop",
        confidence=80,
        frequency=1,
        tags=["outcome_loop", "smart_brain", "learning"],
        source="seed",
        meta={"conditions": "Requires the tnc_atlas_status_token WP option set so outcomes publish to the "
              "brain; until then brain reads outcome_stat_rows=0."},
    )

    # --------------------------------------------------------------- roadmap
    add(
        "roadmap",
        "Wire the TuaniChat outcome loop end-to-end (set tnc_atlas_status_token) so the Smart Brain receives "
        "real conversion outcomes and learning activates.",
        project="tuanichat",
        category="learning_loop",
        status="in_progress",
        priority=90,
        confidence=70,
        tags=["outcome_loop", "wiring", "next"],
        source="seed",
    )
    add(
        "roadmap",
        "Build the Meta Jarvis self-regulating layer (full observability across Hetzner + InterServer + "
        "DreamHost, KPI self-adjust, meta-guardians, fast failure detection). Sequence: stabilize pipe -> "
        "data flowing -> live sources live -> workers running -> THEN the meta-control layer.",
        project="atlas",
        category="meta_agent",
        status="planned",
        priority=70,
        confidence=60,
        tags=["meta_jarvis", "observability", "roadmap"],
        source="seed",
    )
    add(
        "roadmap",
        "Build the live-data-hunter agent: continuously find new free/legal data sources (vetted for "
        ".gov/.mil suppression + ToS), surfaced for approval before going live.",
        project="atlas",
        category="data_sources",
        status="planned",
        priority=60,
        confidence=60,
        tags=["data_hunter", "sources", "roadmap"],
        source="seed",
    )

    # --------------------------------------------------------------- patterns
    add(
        "pattern",
        "Trust gets rebuilt by honesty: the user values bulletproof, diligence-grade work and pressure-tests "
        "for gaps (negatives, attribution, wrong primaries). False successes destroy trust; honest 'not yet "
        "verified' preserves it.",
        project="global",
        category="relationship",
        confidence=88,
        frequency=3,
        severity=50,
        tags=["trust", "honesty", "relationship"],
        source="seed",
    )

    # Run one consolidation so high-confidence repeated lessons promote to rules.
    from .reflect import promote_rules

    promoted = promote_rules(store)

    counts = {k: len(store.load(k)) for k in (
        "mistake", "lesson", "preference", "best_practice", "pattern",
        "win", "roadbump", "roadmap", "rule", "summary",
    )}
    return {"seeded": created, "promoted_to_rules": promoted, "counts": counts}
