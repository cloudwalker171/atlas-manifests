"""
brain.schemas
=============

Record schemas and factory helpers for the /brain self-learning memory system.

Every memory record is a plain ``dict`` (JSON-serializable, stdlib only) so the
store stays dependency-free and trivially portable to SQLite later. This module
centralizes the schema so every writer produces consistent, well-formed records.

Record kinds
------------
- ``mistake``        : something that went wrong (so it is never repeated)
- ``lesson``         : a generalized rule learned (often from a correction)
- ``preference``     : a durable user/operator preference
- ``best_practice``  : a positive standard to apply
- ``pattern``        : an observed recurring pattern (e.g. "industry X converts")
- ``win``            : a successful workflow worth repeating, with the conditions
- ``roadbump``       : a blocker that was hit + exactly how it was resolved
- ``roadmap``        : a planned item with status/priority (what's next)
- ``rule``           : a promoted, always-applied lesson (high confidence)
- ``summary``        : a session / weekly consolidation summary

Common fields (present on every record)
---------------------------------------
- ``id``           : stable unique id (kind + short uuid)
- ``kind``         : one of the record kinds above
- ``project``      : project scope (e.g. "google_ads", "atlas", "global")
- ``category``     : free-text sub-category for retrieval
- ``text``         : the human-readable content (the lesson/mistake/etc.)
- ``confidence``   : 0-100 belief strength (reinforced/decayed over time)
- ``frequency``    : how many times this was observed/confirmed
- ``severity``     : 0-100 impact (SEV scale; higher = more critical)
- ``tags``         : list of keyword tags for retrieval
- ``status``       : lifecycle ("active", "archived", "superseded", plus
                     roadmap statuses: "planned"/"in_progress"/"done"/"blocked")
- ``created_at``   : ISO8601 UTC creation timestamp
- ``updated_at``   : ISO8601 UTC last-modification timestamp
- ``last_used``    : ISO8601 UTC last time this record was retrieved/applied
- ``source``       : where it came from ("user", "agent", "deploy_pipe",
                     "atlas_outcome", "markdown_import", ...)
- ``links``        : list of related record ids (e.g. superseded-by pointer)
- ``meta``         : open dict for kind-specific extra fields
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

RECORD_KINDS = (
    "mistake",
    "lesson",
    "preference",
    "best_practice",
    "pattern",
    "win",
    "roadbump",
    "roadmap",
    "rule",
    "summary",
)

#: Default JSON memory files, keyed by the kind they store.
MEMORY_FILES = {
    "mistake": "mistakes.json",
    "lesson": "lessons.json",
    "preference": "preferences.json",
    "best_practice": "best_practices.json",
    "pattern": "patterns.json",
    "win": "wins.json",
    "roadbump": "roadbumps.json",
    "roadmap": "roadmap.json",
    "rule": "rules.json",
    "summary": "summaries.json",
}

#: Known project scopes (free-form is allowed; these are the seeded folders).
PROJECTS = (
    "global",
    "google_ads",
    "seo",
    "lionclick_media",
    "tuanichat",
    "atlas",
    "client_work",
)

# Confidence thresholds used by the self-learning dynamics.
PROMOTE_CONFIDENCE = 90  # >= this (and repeated) -> auto-promote to a rule
PROMOTE_FREQUENCY = 3  # must be observed at least this many times to promote
DECAY_STALE_DAYS = 30  # records unused this long start decaying
ARCHIVE_CONFIDENCE = 15  # <= this -> archived during reflection


# ---------------------------------------------------------------------------
# Time helpers
# ---------------------------------------------------------------------------

def now_iso() -> str:
    """Return the current UTC time as an ISO8601 string (second precision)."""
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def parse_iso(value: Optional[str]) -> Optional[datetime]:
    """Parse an ISO8601 string back into a timezone-aware ``datetime``.

    Returns ``None`` if ``value`` is falsy or unparseable, so callers can treat
    missing timestamps gracefully.
    """
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(value)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except (ValueError, TypeError):
        return None


def _new_id(kind: str) -> str:
    """Generate a short, human-scannable unique id like ``lesson_3f9a1c2b``."""
    return f"{kind}_{uuid.uuid4().hex[:8]}"


# ---------------------------------------------------------------------------
# Core factory
# ---------------------------------------------------------------------------

def make_record(
    kind: str,
    text: str,
    *,
    project: str = "global",
    category: str = "general",
    confidence: int = 50,
    frequency: int = 1,
    severity: int = 0,
    tags: Optional[List[str]] = None,
    status: str = "active",
    source: str = "user",
    links: Optional[List[str]] = None,
    meta: Optional[Dict[str, Any]] = None,
    record_id: Optional[str] = None,
) -> Dict[str, Any]:
    """Build a fully-formed memory record dict.

    Parameters
    ----------
    kind:
        One of :data:`RECORD_KINDS`.
    text:
        The human-readable content of the record.
    project, category, tags:
        Scoping / retrieval metadata.
    confidence, frequency, severity:
        Self-learning signals (all clamped to sane ranges).
    status, source, links, meta, record_id:
        Lifecycle and provenance metadata. ``record_id`` lets callers supply a
        stable id (used by importers for idempotency); otherwise one is minted.

    Returns
    -------
    dict
        A new record. Raises ``ValueError`` for an unknown ``kind``.
    """
    if kind not in RECORD_KINDS:
        raise ValueError(f"unknown record kind: {kind!r} (expected one of {RECORD_KINDS})")

    ts = now_iso()
    return {
        "id": record_id or _new_id(kind),
        "kind": kind,
        "project": project or "global",
        "category": category or "general",
        "text": text.strip(),
        "confidence": clamp(confidence, 0, 100),
        "frequency": max(1, int(frequency)),
        "severity": clamp(severity, 0, 100),
        "tags": sorted({t.strip().lower() for t in (tags or []) if t.strip()}),
        "status": status,
        "created_at": ts,
        "updated_at": ts,
        "last_used": ts,
        "source": source,
        "links": list(links or []),
        "meta": dict(meta or {}),
    }


def clamp(value: int, low: int, high: int) -> int:
    """Clamp an integer into ``[low, high]``."""
    try:
        value = int(value)
    except (TypeError, ValueError):
        value = low
    return max(low, min(high, value))


def touch(record: Dict[str, Any]) -> Dict[str, Any]:
    """Mark a record as just-used (updates ``last_used``). Returns the record."""
    record["last_used"] = now_iso()
    return record


def normalize_text(text: str) -> str:
    """Lowercase + collapse whitespace, used for duplicate detection."""
    return " ".join((text or "").lower().split())
