"""
brain.store
===========

The persistence + write layer for the /brain memory system.

``BrainStore`` owns the on-disk layout and provides the primitive load/save and
add operations the rest of the package builds on. It is JSON-first (stdlib
only) with a clean upgrade path to SQLite (see ``backend`` parameter and the
README) and self-learning write dynamics baked in:

- **Reinforcement** : adding a near-duplicate bumps ``frequency`` and raises
  ``confidence`` instead of creating a new row.
- **Contradiction** : a record explicitly marked as contradicting another
  supersedes it (old archived with a ``superseded_by`` pointer; newest wins).
- **Promotion**     : a high-confidence, frequently-confirmed lesson/best_practice
  is auto-copied into ``rules.json`` as an always-applied rule.

The store writes atomically (temp file + os.replace) so a crash mid-write can
never corrupt a memory file.
"""

from __future__ import annotations

import json
import os
import tempfile
from typing import Any, Callable, Dict, List, Optional

from . import schemas
from .schemas import (
    MEMORY_FILES,
    PROJECTS,
    PROMOTE_CONFIDENCE,
    PROMOTE_FREQUENCY,
    clamp,
    make_record,
    normalize_text,
    now_iso,
)

# Directory layout created under the brain root.
SUBDIRS = ("memory", "projects", "logs", "vectors", "archive")
PROJECT_DIRS = ("google_ads", "seo", "lionclick_media", "tuanichat", "atlas", "client_work")


class BrainStore:
    """File-backed store for all brain memory records.

    Parameters
    ----------
    root:
        Root directory of the brain (the ``/brain`` folder). Created on
        :meth:`initialize` if absent.
    backend:
        ``"json"`` (default, stdlib only) or ``"sqlite"`` (reserved; see README
        upgrade path). Only ``"json"`` is implemented in this build; the method
        surface is backend-agnostic so the swap is localized.
    """

    def __init__(self, root: str, backend: str = "json") -> None:
        self.root = os.path.abspath(root)
        self.backend = backend
        if backend not in ("json", "sqlite"):
            raise ValueError("backend must be 'json' or 'sqlite'")

    # ------------------------------------------------------------------ paths
    def _memory_path(self, kind: str) -> str:
        return os.path.join(self.root, "memory", MEMORY_FILES[kind])

    def archive_path(self) -> str:
        return os.path.join(self.root, "archive", "archive.json")

    def log_path(self, name: str) -> str:
        return os.path.join(self.root, "logs", name)

    def project_path(self, project: str) -> str:
        return os.path.join(self.root, "projects", project)

    # ------------------------------------------------------------- lifecycle
    def initialize(self) -> str:
        """Create the full folder structure and empty memory files if missing.

        Idempotent: safe to call repeatedly. Returns the brain root path.
        """
        for sub in SUBDIRS:
            os.makedirs(os.path.join(self.root, sub), exist_ok=True)
        for proj in PROJECT_DIRS:
            os.makedirs(self.project_path(proj), exist_ok=True)
        for kind in MEMORY_FILES:
            path = self._memory_path(kind)
            if not os.path.exists(path):
                self._write_json(path, [])
        if not os.path.exists(self.archive_path()):
            self._write_json(self.archive_path(), [])
        return self.root

    # -------------------------------------------------------------- raw json
    @staticmethod
    def _read_json(path: str) -> List[Dict[str, Any]]:
        if not os.path.exists(path):
            return []
        try:
            with open(path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            return data if isinstance(data, list) else []
        except (json.JSONDecodeError, OSError):
            return []

    @staticmethod
    def _write_json(path: str, data: List[Dict[str, Any]]) -> None:
        """Atomically write ``data`` as pretty JSON to ``path``."""
        os.makedirs(os.path.dirname(path), exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=os.path.dirname(path), suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                json.dump(data, fh, indent=2, ensure_ascii=False)
            os.replace(tmp, path)
        finally:
            if os.path.exists(tmp):
                os.remove(tmp)

    # ----------------------------------------------------------- public load
    def load(self, kind: str) -> List[Dict[str, Any]]:
        """Load all records of one ``kind``."""
        return self._read_json(self._memory_path(kind))

    def load_all(self, include_archived: bool = False) -> List[Dict[str, Any]]:
        """Load every record across every kind (optionally including archive)."""
        out: List[Dict[str, Any]] = []
        for kind in MEMORY_FILES:
            out.extend(self.load(kind))
        if include_archived:
            out.extend(self._read_json(self.archive_path()))
        return out

    def save(self, kind: str, records: List[Dict[str, Any]]) -> None:
        """Overwrite all records of one ``kind``."""
        self._write_json(self._memory_path(kind), records)

    def get(self, record_id: str) -> Optional[Dict[str, Any]]:
        """Find a single record by id across all kinds + archive."""
        for rec in self.load_all(include_archived=True):
            if rec.get("id") == record_id:
                return rec
        return None

    # ------------------------------------------------------------- archiving
    def archive(self, records: List[Dict[str, Any]], reason: str = "") -> None:
        """Move records into the archive store, stamping a reason."""
        arc = self._read_json(self.archive_path())
        for rec in records:
            rec = dict(rec)
            rec["status"] = "archived"
            rec.setdefault("meta", {})["archived_reason"] = reason
            rec["meta"]["archived_at"] = now_iso()
            arc.append(rec)
        self._write_json(self.archive_path(), arc)

    # --------------------------------------------------------------- adding
    def add(
        self,
        kind: str,
        text: str,
        *,
        reinforce: bool = True,
        contradicts: Optional[str] = None,
        auto_promote: bool = True,
        **fields: Any,
    ) -> Dict[str, Any]:
        """Add (or reinforce) a record, applying self-learning dynamics.

        Parameters
        ----------
        kind, text, **fields:
            Passed to :func:`brain.schemas.make_record`.
        reinforce:
            If a near-duplicate already exists in the same project, bump its
            frequency/confidence instead of inserting a new row.
        contradicts:
            Id of a record this one overrides. The old record is archived with a
            ``superseded_by`` pointer and the new one links back to it.
        auto_promote:
            If True, eligible lessons/best_practices are promoted to rules.

        Returns
        -------
        dict
            The created or reinforced record.
        """
        records = self.load(kind)

        # 1) Reinforcement: collapse near-duplicates.
        if reinforce:
            dup = self._find_duplicate(records, text, fields.get("project", "global"))
            if dup is not None:
                self._reinforce(dup, text=text, **fields)
                self.save(kind, records)
                if auto_promote:
                    self._maybe_promote(dup)
                return dup

        # 2) Fresh record.
        rec = make_record(kind, text, **fields)

        # 3) Persist the new record first so a same-kind supersede (which reloads
        #    and rewrites the kind file) cannot be clobbered by a stale list.
        records.append(rec)
        self.save(kind, records)

        # 4) Contradiction handling (newest wins).
        if contradicts:
            self._supersede(contradicts, rec)
            # _supersede may mutate rec.links/meta in memory; persist that too.
            self._persist_record_fields(kind, rec)

        if auto_promote:
            self._maybe_promote(rec)
        return rec

    # ------------------------------------------------------- dynamics: helpers
    @staticmethod
    def _find_duplicate(
        records: List[Dict[str, Any]], text: str, project: str
    ) -> Optional[Dict[str, Any]]:
        """Return an existing active record with the same normalized text+project."""
        key = normalize_text(text)
        for rec in records:
            if rec.get("status") != "active":
                continue
            if rec.get("project", "global") != (project or "global"):
                continue
            if normalize_text(rec.get("text", "")) == key:
                return rec
        return None

    @staticmethod
    def _reinforce(rec: Dict[str, Any], *, text: str = "", **fields: Any) -> None:
        """Bump frequency + confidence on a repeated observation."""
        rec["frequency"] = int(rec.get("frequency", 1)) + 1
        # Diminishing-returns confidence gain: +8, +6, +5 ... toward 100.
        gain = max(2, 10 - rec["frequency"])
        rec["confidence"] = clamp(rec.get("confidence", 50) + gain, 0, 100)
        # Merge any newly supplied tags / raise severity if higher.
        new_tags = fields.get("tags")
        if new_tags:
            merged = set(rec.get("tags", [])) | {t.lower() for t in new_tags}
            rec["tags"] = sorted(merged)
        if "severity" in fields:
            rec["severity"] = max(rec.get("severity", 0), clamp(fields["severity"], 0, 100))
        rec["updated_at"] = now_iso()
        rec["last_used"] = now_iso()

    def _supersede(self, old_id: str, new_rec: Dict[str, Any]) -> None:
        """Archive the contradicted record and cross-link the pointers."""
        for kind in MEMORY_FILES:
            records = self.load(kind)
            changed = False
            for rec in records:
                if rec.get("id") == old_id and rec.get("status") == "active":
                    rec["status"] = "superseded"
                    rec.setdefault("meta", {})["superseded_by"] = new_rec["id"]
                    rec["meta"]["superseded_at"] = now_iso()
                    rec["updated_at"] = now_iso()
                    new_rec.setdefault("links", []).append(old_id)
                    new_rec.setdefault("meta", {})["supersedes"] = old_id
                    changed = True
            if changed:
                self.save(kind, records)
                return

    def _persist_record_fields(self, kind: str, rec: Dict[str, Any]) -> None:
        """Re-save a record's in-memory mutations (links/meta) to its kind file."""
        records = self.load(kind)
        for i, r in enumerate(records):
            if r.get("id") == rec["id"]:
                records[i] = rec
                self.save(kind, records)
                return

    def _maybe_promote(self, rec: Dict[str, Any]) -> None:
        """Copy an eligible lesson/best_practice into rules.json as a rule."""
        if rec.get("kind") not in ("lesson", "best_practice"):
            return
        if rec.get("confidence", 0) < PROMOTE_CONFIDENCE:
            return
        if rec.get("frequency", 0) < PROMOTE_FREQUENCY:
            return
        rules = self.load("rule")
        # Avoid duplicate promotion of the same source record.
        for r in rules:
            if r.get("meta", {}).get("promoted_from") == rec["id"]:
                return
        rule = make_record(
            "rule",
            rec["text"],
            project=rec.get("project", "global"),
            category=rec.get("category", "general"),
            confidence=rec.get("confidence", PROMOTE_CONFIDENCE),
            frequency=rec.get("frequency", PROMOTE_FREQUENCY),
            severity=rec.get("severity", 0),
            tags=rec.get("tags", []),
            source="auto_promote",
            links=[rec["id"]],
            meta={"promoted_from": rec["id"]},
        )
        rules.append(rule)
        self.save("rule", rules)
        rec.setdefault("meta", {})["promoted_to_rule"] = rule["id"]

    # ----------------------------------------------------------------- update
    def update(self, kind: str, record_id: str, mutate: Callable[[Dict[str, Any]], None]) -> bool:
        """Apply ``mutate`` to a record by id and persist. Returns True if found."""
        records = self.load(kind)
        for rec in records:
            if rec.get("id") == record_id:
                mutate(rec)
                rec["updated_at"] = now_iso()
                self.save(kind, records)
                return True
        return False

    # ------------------------------------------------------------------ logs
    def append_log(self, name: str, entry: Dict[str, Any]) -> None:
        """Append a JSON line to a log file under ``logs/`` (JSONL)."""
        path = self.log_path(name)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(entry, ensure_ascii=False) + "\n")
