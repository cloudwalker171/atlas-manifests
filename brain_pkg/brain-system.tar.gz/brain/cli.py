"""
brain.cli
=========

Command-line entrypoints so the brain can be scheduled (cron / systemd timer /
Windows Task Scheduler) and operated without writing Python.

Usage
-----
    python -m brain init            [--root DIR]
    python -m brain reflect         [--root DIR]      # the nightly/weekly "Dreams" pass
    python -m brain drain           [--root DIR]      # apply queued inbox.jsonl events
    python -m brain search "query"  [--root DIR] [--project P]
    python -m brain decide "ctx"    [--root DIR] [--project P]
    python -m brain seed            [--root DIR]      # load the real project lessons
    python -m brain import-md DIR   [--root DIR]      # import native markdown memory
    python -m brain export-md DIR   [--root DIR]      # export rules/lessons to markdown
    python -m brain stats           [--root DIR]

``python -m brain.reflect`` is also wired (see ``brain/reflect/__main__`` note in
README) — the canonical scheduled command is ``python -m brain reflect``.
"""

from __future__ import annotations

import argparse
import json
import sys
from typing import List, Optional

from .api import (
    Brain,
    initialize_brain,
)
from .integrate import import_from_markdown, export_to_markdown, drain_inbox
from .schemas import MEMORY_FILES


def _add_root(p: argparse.ArgumentParser) -> None:
    p.add_argument("--root", default="./brain", help="brain root directory (default ./brain)")
    p.add_argument("--project", default=None, help="optional project scope")


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(prog="brain", description="The /brain self-learning memory system")
    sub = parser.add_subparsers(dest="cmd", required=True)

    for name in ("init", "reflect", "drain", "seed", "stats"):
        sp = sub.add_parser(name)
        _add_root(sp)

    sp = sub.add_parser("search")
    sp.add_argument("query")
    _add_root(sp)

    sp = sub.add_parser("decide")
    sp.add_argument("context")
    _add_root(sp)

    sp = sub.add_parser("import-md")
    sp.add_argument("dir")
    _add_root(sp)

    sp = sub.add_parser("export-md")
    sp.add_argument("dir")
    _add_root(sp)

    args = parser.parse_args(argv)

    if args.cmd == "init":
        store = initialize_brain(args.root)
        print(f"Initialized brain at {store.root}")
        return 0

    if args.cmd == "seed":
        from .seed import seed_brain  # local import: seed pulls in data

        store = initialize_brain(args.root)
        report = seed_brain(store)
        print(json.dumps(report, indent=2))
        return 0

    brain = Brain(args.root)

    if args.cmd == "reflect":
        report = brain.reflect()
        print(json.dumps(report, indent=2))
        return 0

    if args.cmd == "drain":
        report = drain_inbox(brain.store)
        print(json.dumps(report, indent=2))
        return 0

    if args.cmd == "search":
        hits = brain.search(args.query, project=args.project, limit=10)
        for h in hits:
            print(f"[{h['_score']:.2f}] ({h['kind']}/{h['project']}) {h['text'][:140]}")
        if not hits:
            print("(no matches)")
        return 0

    if args.cmd == "decide":
        rec = brain.decide(args.context, project=args.project)
        print(f"ACTION: {rec['action']}")
        print(f"WHY:    {rec['rationale']}")
        print(f"CONF:   {rec['confidence']}")
        if rec["warnings"]:
            print("WARNINGS:")
            for w in rec["warnings"]:
                print(f"  - {w}")
        return 0

    if args.cmd == "import-md":
        report = import_from_markdown(brain.store, args.dir)
        print(json.dumps(report, indent=2))
        return 0

    if args.cmd == "export-md":
        report = export_to_markdown(brain.store, args.dir)
        print(json.dumps(report, indent=2))
        return 0

    if args.cmd == "stats":
        counts = {kind: len(brain.store.load(kind)) for kind in MEMORY_FILES}
        print(json.dumps({"root": brain.root, "counts": counts}, indent=2))
        return 0

    return 1


if __name__ == "__main__":
    sys.exit(main())
