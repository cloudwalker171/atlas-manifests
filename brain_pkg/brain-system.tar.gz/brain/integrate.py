"""
brain.integrate
===============

Integration hooks so the brain is actually loaded by the rest of the platform
instead of being a brain that never gets read.

Three classes of integration:

1. **Importable API** — thin helper functions the ATLAS Smart Brain outcome
   loop, the deploy pipe, and agents call directly:
   - :func:`record_atlas_outcome`   (wins/mistakes/patterns: which industries convert)
   - :func:`record_deploy_roadbump` (blockers + their resolution)
   - :func:`agent_preflight`         (what an agent calls before acting)

2. **File bridge** — :func:`drain_inbox` reads newline-delimited JSON events
   dropped into ``<root>/logs/inbox.jsonl`` by any process (even on another box)
   and applies them. This is the zero-dependency way the Hetzner workers feed the
   brain: append a JSON line, the brain ingests it on the next reflect/drain.

3. **Markdown cross-feed** — :func:`import_from_markdown` / :func:`export_to_markdown`
   keep the JSON brain in sync with the native Claude markdown memory layer.

Everything here is stdlib-only. An optional HTTP bridge is documented in the
README (a ~30-line stdlib ``http.server`` wrapper) but kept out of the core so
the package has zero attack surface by default.
"""

from __future__ import annotations

import json
import os
import re
from typing import Any, Dict, List, Optional

from .decide import next_best_action
from .retrieval import retrieve_relevant_context
from .schemas import make_record, now_iso
from .store import BrainStore


# ---------------------------------------------------------------------------
# (1) Importable API for the platform
# ---------------------------------------------------------------------------

def record_atlas_outcome(
    store: BrainStore,
    *,
    industry: str,
    source: str,
    converted: bool,
    detail: str = "",
    confidence: int = 60,
) -> Dict[str, Any]:
    """Outcome-loop hook: record which industries/sources convert.

    A conversion becomes a ``win`` + a ``pattern`` ("industry X via source Y
    converts"); a non-conversion reinforces a ``pattern`` the other way. Repeated
    calls reinforce confidence via the store's dedup/reinforce logic.
    """
    verb = "converts" if converted else "does not convert"
    text = f"Industry '{industry}' via source '{source}' {verb}."
    pattern = store.add(
        "pattern",
        text,
        project="atlas",
        category="conversion",
        confidence=confidence,
        severity=20,
        tags=[industry.lower(), source.lower(), "conversion"],
        source="atlas_outcome",
        meta={"industry": industry, "source": source, "converted": converted, "detail": detail},
    )
    if converted:
        store.add(
            "win",
            f"Demo converted: industry '{industry}' from source '{source}'. {detail}".strip(),
            project="atlas",
            category="conversion",
            confidence=confidence,
            tags=[industry.lower(), source.lower(), "win"],
            source="atlas_outcome",
            meta={"conditions": f"industry={industry}, source={source}"},
        )
    return pattern


def record_deploy_roadbump(
    store: BrainStore,
    *,
    blocker: str,
    resolution: str,
    severity: int = 80,
    project: str = "atlas",
    tags: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """Deploy-pipe hook: record a blocker and exactly how it was resolved.

    Next time the same block is hit, :func:`brain.decide.next_best_action`
    returns the recorded resolution instantly instead of re-debugging.
    """
    return store.add(
        "roadbump",
        blocker,
        project=project,
        category="deploy",
        confidence=85,
        severity=severity,
        tags=(tags or []) + ["deploy", "blocker"],
        source="deploy_pipe",
        meta={"resolution": resolution, "resolved_at": now_iso()},
    )


def agent_preflight(
    store: BrainStore,
    task: str,
    *,
    project: Optional[str] = None,
) -> Dict[str, Any]:
    """What an agent calls *before* acting.

    Returns both the injected context (RECALL) and the recommended action
    (the decision core), so an agent gets a single, ready-to-use briefing.
    """
    context = retrieve_relevant_context(store, task, project=project)
    decision = next_best_action(store, task, project=project, situation="task")
    return {
        "task": task,
        "project": project,
        "context": context,
        "recommendation": decision,
    }


# ---------------------------------------------------------------------------
# (2) File bridge — workers append JSON lines; the brain drains them
# ---------------------------------------------------------------------------

INBOX_FILE = "inbox.jsonl"

#: Event shape (one JSON object per line in logs/inbox.jsonl):
#:   {"type": "win"|"mistake"|"lesson"|"roadbump"|"pattern"|"preference"
#:            |"best_practice"|"roadmap"|"atlas_outcome"|"deploy_roadbump",
#:    "text": "...", "project": "...", ...other fields...}


def drain_inbox(store: BrainStore, inbox_path: Optional[str] = None) -> Dict[str, Any]:
    """Apply queued events from the file inbox, then truncate it.

    Any process (including the Hetzner/InterServer workers) can feed the brain by
    appending a JSON line to ``logs/inbox.jsonl`` — no network, no deps. This is
    safe to run from the same reflect schedule.

    Returns ``{"applied": n, "errors": [...]}``.
    """
    path = inbox_path or store.log_path(INBOX_FILE)
    if not os.path.exists(path):
        return {"applied": 0, "errors": []}

    with open(path, "r", encoding="utf-8") as fh:
        lines = [ln.strip() for ln in fh if ln.strip()]

    applied = 0
    errors: List[str] = []
    for ln in lines:
        try:
            event = json.loads(ln)
            _apply_event(store, event)
            applied += 1
        except Exception as exc:  # noqa: BLE001 - record + continue draining
            errors.append(f"{exc}: {ln[:120]}")

    # Truncate the inbox only after a full pass (errors kept in the report).
    open(path, "w", encoding="utf-8").close()
    store.append_log("inbox_drain.log.jsonl", {"ts": now_iso(), "applied": applied, "errors": errors})
    return {"applied": applied, "errors": errors}


def _apply_event(store: BrainStore, event: Dict[str, Any]) -> None:
    """Route one inbox event to the right writer."""
    etype = event.get("type", "")
    if etype == "atlas_outcome":
        record_atlas_outcome(
            store,
            industry=event["industry"],
            source=event["source"],
            converted=bool(event.get("converted", False)),
            detail=event.get("detail", ""),
            confidence=int(event.get("confidence", 60)),
        )
    elif etype == "deploy_roadbump":
        record_deploy_roadbump(
            store,
            blocker=event["blocker"],
            resolution=event["resolution"],
            severity=int(event.get("severity", 80)),
            project=event.get("project", "atlas"),
            tags=event.get("tags"),
        )
    else:
        # Generic record write for any known kind.
        text = event.pop("text")
        kind = event.pop("type")
        store.add(kind, text, **{k: v for k, v in event.items() if k != "type"})


# ---------------------------------------------------------------------------
# (3) Markdown cross-feed
# ---------------------------------------------------------------------------

_FRONTMATTER_RE = re.compile(r"^---\s*\n(.*?)\n---\s*\n", re.DOTALL)


def import_from_markdown(
    store: BrainStore,
    markdown_dir: str,
    *,
    default_project: str = "global",
    kind: str = "lesson",
) -> Dict[str, Any]:
    """Import durable lessons from the native Claude markdown memory layer.

    Each ``*.md`` file's body (minus YAML frontmatter) becomes one record so the
    two memory layers stay in sync. Idempotent: a stable id is derived from the
    filename, so re-importing reinforces rather than duplicates.

    Returns ``{"imported": n, "files": [...]}``.
    """
    imported = 0
    files: List[str] = []
    if not os.path.isdir(markdown_dir):
        return {"imported": 0, "files": [], "error": f"not a dir: {markdown_dir}"}

    for name in sorted(os.listdir(markdown_dir)):
        if not name.endswith(".md") or name.upper() == "MEMORY.MD":
            continue
        full = os.path.join(markdown_dir, name)
        try:
            with open(full, "r", encoding="utf-8") as fh:
                raw = fh.read()
        except OSError:
            continue

        meta = {}
        m = _FRONTMATTER_RE.match(raw)
        body = raw
        if m:
            body = raw[m.end():]
            meta = _parse_simple_frontmatter(m.group(1))

        body = body.strip()
        if not body:
            continue

        stem = os.path.splitext(name)[0]
        project = _guess_project(stem, default_project)
        record_id = f"md_{re.sub(r'[^a-z0-9]+', '_', stem.lower())}"

        store.add(
            kind,
            body if len(body) < 2000 else body[:2000] + " ...",
            record_id=record_id,
            project=project,
            category=meta.get("type", "imported"),
            confidence=70,
            tags=["markdown_import", stem.lower()],
            source="markdown_import",
            meta={"source_file": name, "frontmatter": meta},
        )
        imported += 1
        files.append(name)

    store.append_log("md_import.log.jsonl", {"ts": now_iso(), "imported": imported, "files": files})
    return {"imported": imported, "files": files}


def export_to_markdown(store: BrainStore, out_dir: str, *, min_confidence: int = 80) -> Dict[str, Any]:
    """Export high-confidence rules + lessons back to markdown files.

    Lets the native Claude markdown memory pick up what the brain has learned.
    One file per record, with YAML frontmatter. Returns ``{"exported": n}``.
    """
    os.makedirs(out_dir, exist_ok=True)
    exported = 0
    for kind in ("rule", "lesson", "best_practice", "preference"):
        for rec in store.load(kind):
            if rec.get("status") != "active" or rec.get("confidence", 0) < min_confidence:
                continue
            fname = f"brain_{rec['id']}.md"
            content = (
                f"---\n"
                f"name: {rec['id']}\n"
                f"kind: {rec['kind']}\n"
                f"project: {rec['project']}\n"
                f"confidence: {rec['confidence']}\n"
                f"source: brain_export\n"
                f"---\n\n"
                f"{rec['text']}\n"
            )
            with open(os.path.join(out_dir, fname), "w", encoding="utf-8") as fh:
                fh.write(content)
            exported += 1
    return {"exported": exported, "out_dir": out_dir}


def _parse_simple_frontmatter(block: str) -> Dict[str, str]:
    """Minimal YAML-ish frontmatter parser (key: value lines only, stdlib)."""
    out: Dict[str, str] = {}
    for line in block.splitlines():
        if ":" in line and not line.strip().startswith("#"):
            k, _, v = line.partition(":")
            k = k.strip()
            v = v.strip().strip('"').strip("'")
            if k and v and " " not in k:
                out[k] = v
    return out


def _guess_project(stem: str, default: str) -> str:
    """Map a markdown filename stem to a project scope."""
    s = stem.lower()
    if "google" in s or "ads" in s or "ga4" in s or "madreforte" in s or "art" in s:
        return "google_ads"
    if "atlas" in s or "enrich" in s or "deploy" in s or "interserver" in s or "hetzner" in s:
        return "atlas"
    if "tuanichat" in s or "chat" in s or "lead" in s:
        return "tuanichat"
    if "seo" in s:
        return "seo"
    return default
