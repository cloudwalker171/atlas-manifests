#!/usr/bin/env bash
# stage_on_box.sh — STAGES the brain on the box. Run manually or via the pipe.
# Does NOT touch any existing prod service. Idempotent. Take a restore point first.
set -euo pipefail

CODE_DIR="${BRAIN_CODE_DIR:-/opt/brain}"
DATA_DIR="${BRAIN_ROOT:-/var/lib/brain}"
TARBALL="${1:-/tmp/brain-system.tar.gz}"

echo ">> staging brain code into ${CODE_DIR}"
mkdir -p "${CODE_DIR}"
tar xzf "${TARBALL}" -C "${CODE_DIR}" --strip-components=1

echo ">> initializing brain data root at ${DATA_DIR}"
mkdir -p "${DATA_DIR}"
cd "${CODE_DIR}"
python3 -m brain init  --root "${DATA_DIR}"
python3 -m brain seed  --root "${DATA_DIR}"     # starts smart, not empty
python3 -m brain stats --root "${DATA_DIR}"

echo ">> (optional) installing the nightly reflect timer"
if [ "${INSTALL_TIMER:-0}" = "1" ]; then
  cp "${CODE_DIR}/deploy/brain-reflect.service" /etc/systemd/system/
  cp "${CODE_DIR}/deploy/brain-reflect.timer"   /etc/systemd/system/
  systemctl daemon-reload
  systemctl enable --now brain-reflect.timer
  echo ">> timer enabled:"; systemctl status brain-reflect.timer --no-pager || true
fi

echo ">> done. brain code=${CODE_DIR} data=${DATA_DIR}"
echo ">> writers feed it via ${DATA_DIR}/logs/inbox.jsonl (file bridge) or 'from brain import Brain'."
