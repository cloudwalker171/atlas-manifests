# /brain integration + deploy plan (STAGED — not applied to prod)

This plan stages the brain for all-systems use on the Hetzner box without
touching the live production system. Nothing here is auto-applied; each step is
reversible and gated.

## 0. Layout on the box (proposed)

```
/opt/brain            <- the package (code), pip-free, copied or git-pulled
/var/lib/brain        <- the brain ROOT (data): memory/, projects/, logs/, ...
/var/log/brain-reflect.log
```

Set `BRAIN_ROOT=/var/lib/brain` in the service env so every caller shares one
brain.

## 1. Stage the package (no prod impact)

The package is stdlib-only, so "install" = copy + ensure `python3` (>=3.7).

```
# staged tarball is in deploy/brain-system.tar.gz (built locally)
scp deploy/brain-system.tar.gz box:/tmp/      # or via the auto-pull pipe manifest
ssh box 'mkdir -p /opt/brain && tar xzf /tmp/brain-system.tar.gz -C /opt/brain --strip-components=1'
ssh box 'cd /opt/brain && BRAIN_ROOT=/var/lib/brain python3 -m brain init'
ssh box 'cd /opt/brain && BRAIN_ROOT=/var/lib/brain python3 -m brain seed'   # starts smart
```

> Per the autonomous-deploy directive, prefer driving this THROUGH the auto-pull
> pipe (publish a manifest that drops the tarball + runs init/seed) rather than
> manual scp. Take a restore point first; health-check after.

## 2. Wire the three writers

### (a) ATLAS Smart Brain outcome loop -> wins/patterns
The outcome loop already UPSERTs into `atlas.outcome_stats`. Add a tiny shim that,
on each outcome flush, also calls the brain. Two options:

- **In-process** (if the worker is Python and can import the package):
  ```python
  from brain import Brain
  b = Brain("/var/lib/brain")
  b.record_atlas_outcome(industry=row.industry, source=row.source,
                         converted=row.converted)
  ```
- **File bridge** (recommended — no import coupling, survives lang/env mismatch):
  append one JSON line per outcome to `/var/lib/brain/logs/inbox.jsonl`:
  ```json
  {"type":"atlas_outcome","industry":"roofing","source":"osm","converted":true}
  ```
  The brain drains it on the reflect timer. This is how "which industries
  convert" learning flows in without touching the outcome-loop code path.

### (b) Deploy pipe -> roadbumps
On any apply failure / blocker, the pipe appends:
```json
{"type":"deploy_roadbump","blocker":"<what broke>","resolution":"<the fix>","severity":90,"project":"atlas"}
```
The real seeded example is already in the brain: *"never scale the enrich pool
past PG-safe — it caused a SEV-1 PG outage; safe ~1,200/min on the 8GB box."*
Next time that block is hit, `decide()` returns the fix instantly.

### (c) Agents call preflight BEFORE acting
```python
from brain.integrate import agent_preflight
brief = agent_preflight(brain.store, task_description, project="atlas")
# inject brief["context"]["as_text"]; obey brief["recommendation"]["action"]
```

## 3. Cross-feed with the native markdown memory

One-time + periodic sync so the two layers stay aligned:
```
python -m brain import-md /path/to/agent/memory   --root /var/lib/brain   # md -> brain
python -m brain export-md /path/to/agent/memory_brain --root /var/lib/brain # rules -> md
```
The seed already distilled the durable markdown lessons; run `import-md` again
whenever the markdown memory gains a new durable note.

## 4. Schedule the reflection ("Dreams") pass

Install the systemd timer (staged in `deploy/`):
```
cp deploy/brain-reflect.service /etc/systemd/system/
cp deploy/brain-reflect.timer   /etc/systemd/system/
systemctl daemon-reload && systemctl enable --now brain-reflect.timer
```
It runs `python -m brain.reflect --root /var/lib/brain --drain` nightly: drains
the inbox, then dedups / decays / promotes / extracts insights / writes a summary.

## 5. Optional HTTP bridge (only if you need network writes)

Recommended default is the **file bridge** (step 2). If a remote service truly
needs to POST events, this ~30-line stdlib server is the drop-in (keep it bound
to localhost / behind the firewall, fail-closed):

```python
# brain_http.py  (run alongside the brain; localhost only)
import json
from http.server import BaseHTTPRequestHandler, HTTPServer
from brain import Brain
from brain.integrate import _apply_event

BRAIN = Brain("/var/lib/brain")

class H(BaseHTTPRequestHandler):
    def do_POST(self):
        if self.path != "/event":
            self.send_response(404); self.end_headers(); return
        n = int(self.headers.get("Content-Length", 0))
        try:
            _apply_event(BRAIN.store, json.loads(self.rfile.read(n)))
            self.send_response(200)
        except Exception as e:                      # fail-closed, report error
            self.send_response(400)
        self.end_headers()

HTTPServer(("127.0.0.1", 8787), H).serve_forever()
```
Front it with the firewall (UFW SSH-allow untouched, per the lifeline
guardrails) and never expose it publicly.

## 6. Safety / honesty guardrails honored

- Project isolation: every record carries a `project`; retrieval penalizes
  cross-project leakage so google_ads memory never bleeds into atlas decisions.
- No secrets in the brain: the seed deliberately excludes tokens/credentials/PII.
- Reversible: archived records keep pointers; nothing is hard-deleted.
- Honesty: `decide()` returns a low-confidence "no precedent — proceed carefully
  and STORE the outcome" when memory is thin, rather than bluffing.

## Rollback

The brain is additive and isolated. To remove: stop the timer, delete
`/opt/brain` and `/var/lib/brain`. No prod schema or service is modified by
staging the brain itself.
